import { AppSettings, Debtor, DebtorTransaction, Manager, User, InstallmentRecord, DatabaseAccount } from '../types';
import { generateShieldHeaders } from '../utils/securityShield';
import { ALDION_DATABASE_CONFIG, normalizeTursoUrl } from '../../aldion';

/**
 * Returns the backend API server base URL.
 * Supports:
 * 1. Custom URL set in settings / APK config (localStorage: aldion_backend_server_url)
 * 2. Current origin in web browser (window.location.origin)
 * 3. Default production Cloud Run backend host
 */
export function getBackendBaseUrl(): string {
  if (typeof window === 'undefined') return '';

  const saved = localStorage.getItem('aldion_backend_server_url');
  if (saved && saved.trim()) {
    return saved.trim().replace(/\/+$/, '');
  }

  // If running directly on Cloud Run backend, return current origin
  if (
    typeof window !== 'undefined' &&
    window.location &&
    window.location.origin &&
    window.location.origin.startsWith('http') &&
    window.location.origin.includes('run.app')
  ) {
    return window.location.origin;
  }

  // Default production Cloud Run backend host for Netlify / external static domains / mobile APKs
  return 'https://ais-pre-3qeeb6jl5bktm64omzuibv-349740974703.europe-west2.run.app';
}

export function setBackendBaseUrl(url: string) {
  if (url && url.trim()) {
    localStorage.setItem('aldion_backend_server_url', url.trim().replace(/\/+$/, ''));
  } else {
    localStorage.removeItem('aldion_backend_server_url');
  }
}

/**
 * محرك استعلام مدمج مشفر (Embedded Encrypted Engine)
 * يعمل تلقائياً عند تحويل المشروع إلى PWA أو تطبيق هاتف أو استضافة ثابتة،
 * بحيث يستخرج الرابط والتوكن المشفرين بالبايتات ويتصل بالقاعدة مباشرة دون الحاجة لأي خادم خارجي.
 */
export async function queryCustomTursoDirect(
  url: string,
  token: string,
  trimmedSql: string,
  args: (string | number | null | undefined)[]
) {
  if (!url || !token) {
    throw new Error('بيانات الاتصال بقاعدة البيانات غير مهيأة');
  }

  const normalizedUrl = normalizeTursoUrl(url);

  const formattedArgs = args.map((a) => {
    if (typeof a === 'number') {
      return Number.isInteger(a)
        ? { type: 'integer', value: String(a) }
        : { type: 'float', value: String(a) };
    }
    if (a === null || a === undefined) {
      return { type: 'null' };
    }
    return { type: 'text', value: String(a) };
  });

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);

  try {
    const res = await fetch(normalizedUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          { type: 'execute', stmt: { sql: trimmedSql, args: formattedArgs } },
          { type: 'close' },
        ],
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`خطأ في قاعدة البيانات السحابية (${res.status}): ${errText.slice(0, 100) || res.statusText}`);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في استعلام قاعدة البيانات');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('انتهت مهلة الاتصال بقاعدة البيانات السحابية (Timeout)');
    }
    throw err;
  }
}

async function queryEmbeddedEncryptedTurso(trimmedSql: string, args: (string | number | null | undefined)[]) {
  const { url, token } = ALDION_DATABASE_CONFIG;
  return await queryCustomTursoDirect(url, token, trimmedSql, args);
}

/**
 * استعلام موجه حصراً للقاعدة الرئيسية (Central Main Database)
 * دون توجيهها للقواعد الفرعية للمدراء، لاستخدامها في مصادقة وإدارة الحسابات
 */
export async function queryMainTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();

  if (isStaticOrNetlifyEnv()) {
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }

  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!res.ok) {
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    }

    const data = await res.json();
    return data;
  } catch {
    clearTimeout(timeoutId);
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }
}

export const DATABASE_SCHEMA_STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL
  );`,
  `CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    branch_name TEXT DEFAULT 'الفرع الرئيسي',
    is_active INTEGER DEFAULT 1,
    subscription_type TEXT DEFAULT 'permanent',
    subscription_expires_at TEXT,
    plain_password TEXT,
    allowed_modules TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS debtors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    amount REAL DEFAULT 0,
    status TEXT DEFAULT 'دين مرتفع',
    user_id INTEGER DEFAULT 1,
    created_at TEXT,
    history TEXT,
    last_debt_date TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS installments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    item TEXT NOT NULL,
    total_amount REAL DEFAULT 0,
    down_payment REAL DEFAULT 0,
    remaining_amount REAL DEFAULT 0,
    monthly_installment_amount REAL DEFAULT 0,
    registration_date TEXT,
    next_due_date TEXT,
    user_id INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    notes TEXT,
    payments TEXT,
    created_at TEXT,
    national_id TEXT,
    address TEXT,
    guarantor_enabled INTEGER DEFAULT 0,
    guarantor_name TEXT,
    guarantor_address TEXT,
    guarantor_job TEXT,
    guarantor_relation TEXT,
    guarantor_phone TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS user_settings (
    user_id INTEGER PRIMARY KEY,
    settings_json TEXT NOT NULL,
    updated_at TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS databases_registry (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    token TEXT NOT NULL,
    description TEXT,
    is_default INTEGER DEFAULT 0,
    created_at TEXT
  );`,
  "ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1;",
  "ALTER TABLE users ADD COLUMN subscription_type TEXT DEFAULT 'permanent';",
  "ALTER TABLE users ADD COLUMN subscription_expires_at TEXT;",
  "ALTER TABLE users ADD COLUMN plain_password TEXT;",
  "ALTER TABLE users ADD COLUMN allowed_modules TEXT;",
  "ALTER TABLE debtors ADD COLUMN created_at TEXT;",
  "ALTER TABLE debtors ADD COLUMN history TEXT;",
  "ALTER TABLE debtors ADD COLUMN last_debt_date TEXT;",
  "ALTER TABLE installments ADD COLUMN notes TEXT;",
  "ALTER TABLE installments ADD COLUMN payments TEXT;",
  "ALTER TABLE installments ADD COLUMN created_at TEXT;",
  "ALTER TABLE installments ADD COLUMN national_id TEXT;",
  "ALTER TABLE installments ADD COLUMN address TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;",
  "ALTER TABLE installments ADD COLUMN guarantor_name TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_address TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_job TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;",
];

/**
 * تهيئة وتجهيز قاعدة البيانات السحابية بالكامل فوراً
 * لإنشاء كافة جداول الديون والأقساط والمستخدمين والإعدادات
 */
export async function initializeCustomTursoDatabase(
  url: string,
  token: string
): Promise<{ ok: boolean; message: string; count?: number }> {
  if (!url || !token) {
    return { ok: false, message: 'رابط القاعدة أو التوكن غير متوفر' };
  }

  let successCount = 0;
  for (const sql of DATABASE_SCHEMA_STATEMENTS) {
    try {
      await queryCustomTursoDirect(url.trim(), token.trim(), sql, []);
      successCount++;
    } catch {
      // تجاهل أخطاء الأعمدة أو الجداول إذا كانت موجودة مسبقاً (Table/Column already exists)
    }
  }

  return {
    ok: true,
    message: 'تمت تهيئة وتجهيز هيكل قاعدة البيانات لاستقبال البيانات بنجاح',
    count: successCount,
  };
}

/**
 * فحص الاتصال بقاعدة البيانات واختبار سرعة الاستجابة وتهيئة الجداول تلقائياً (Test Connection & Bootstrap)
 */
export async function testDatabaseConnection(
  url: string,
  token: string,
  autoBootstrap: boolean = true
): Promise<{ ok: boolean; message: string; latencyMs?: number; initialized?: boolean }> {
  if (!url || !token) {
    return { ok: false, message: 'يرجى إدخال رابط قاعدة البيانات ومفتاح التوكن' };
  }
  const startTime = Date.now();
  try {
    await queryCustomTursoDirect(url.trim(), token.trim(), 'SELECT 1;', []);
    const latencyMs = Date.now() - startTime;

    if (autoBootstrap) {
      await initializeCustomTursoDatabase(url, token);
      return {
        ok: true,
        message: `تم فحص الاتصال بنجاح وتهيئة كافة جداول الديون والأقساط لاستقبال البيانات فوراً (${latencyMs}ms)`,
        latencyMs,
        initialized: true,
      };
    }

    return { ok: true, message: `الاتصال ناجح واستجابة القاعدة فائقة السرعة (${latencyMs}ms)`, latencyMs };
  } catch (err: any) {
    return { ok: false, message: err?.message || 'فشل الاتصال بقاعدة البيانات، يرجى التأكد من صحة الرابط والتوكن' };
  }
}

// ---------------------- MULTI-DATABASE REGISTRY HELPERS ----------------------

export function getLocalDatabases(): DatabaseAccount[] {
  try {
    const raw = localStorage.getItem('aldion_database_accounts');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function setLocalDatabases(dbs: DatabaseAccount[]) {
  try {
    localStorage.setItem('aldion_database_accounts', JSON.stringify(dbs));
  } catch (e) {
    console.error("Error saving local databases:", e);
  }
}

export function getActiveUserDatabaseAccount(): DatabaseAccount | null {
  try {
    const user = getLocalSession();
    if (user && user.databaseId) {
      const dbs = getLocalDatabases();
      const found = dbs.find((d) => d.id === user.databaseId);
      if (found && found.url && found.token) {
        return found;
      }
    }
  } catch {}
  return null;
}

export async function fetchDatabasesFromCloud(): Promise<DatabaseAccount[]> {
  try {
    let res;
    try {
      res = await queryEmbeddedEncryptedTurso('SELECT id, name, url, token, description, is_default, created_at FROM databases_registry ORDER BY created_at DESC;', []);
    } catch {
      await queryEmbeddedEncryptedTurso(`CREATE TABLE IF NOT EXISTS databases_registry (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        url TEXT NOT NULL,
        token TEXT NOT NULL,
        description TEXT,
        is_default INTEGER DEFAULT 0,
        created_at TEXT
      );`, []).catch(() => {});
      return getLocalDatabases();
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }

    const dbs: DatabaseAccount[] = rows.map((r) => ({
      id: r[0]?.value ?? r[0],
      name: r[1]?.value ?? r[1],
      url: r[2]?.value ?? r[2],
      token: r[3]?.value ?? r[3],
      description: r[4]?.value ?? r[4] ?? '',
      isDefault: Boolean(r[5]?.value ?? r[5]),
      createdAt: r[6]?.value ?? r[6],
    }));

    setLocalDatabases(dbs);
    return dbs;
  } catch (e) {
    console.warn("Could not fetch databases from cloud:", e);
    return getLocalDatabases();
  }
}

export async function syncDatabasesToCloud(dbs: DatabaseAccount[]): Promise<void> {
  setLocalDatabases(dbs);
  try {
    await queryEmbeddedEncryptedTurso(`CREATE TABLE IF NOT EXISTS databases_registry (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      url TEXT NOT NULL,
      token TEXT NOT NULL,
      description TEXT,
      is_default INTEGER DEFAULT 0,
      created_at TEXT
    );`, []).catch(() => {});

    for (const dbAccount of dbs) {
      const now = dbAccount.createdAt || new Date().toISOString();
      await queryEmbeddedEncryptedTurso(
        `INSERT INTO databases_registry (id, name, url, token, description, is_default, created_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?) 
         ON CONFLICT(id) DO UPDATE SET 
           name = excluded.name, 
           url = excluded.url, 
           token = excluded.token, 
           description = excluded.description, 
           is_default = excluded.is_default;`,
        [dbAccount.id, dbAccount.name, dbAccount.url, dbAccount.token, dbAccount.description || '', dbAccount.isDefault ? 1 : 0, now]
      );
    }
  } catch (e) {
    console.warn("Could not sync databases to cloud:", e);
  }
}

export async function deleteDatabaseFromCloud(dbId: string): Promise<void> {
  const current = getLocalDatabases().filter((d) => d.id !== dbId);
  setLocalDatabases(current);

  // 1. Reset any local cached managers assigned to this deleted database to null (default DB)
  try {
    const rawMgrs = localStorage.getItem('local_managers_list');
    if (rawMgrs) {
      const list = JSON.parse(rawMgrs);
      if (Array.isArray(list)) {
        const updatedList = list.map((m: any) => (m.databaseId === dbId ? { ...m, databaseId: null } : m));
        localStorage.setItem('local_managers_list', JSON.stringify(updatedList));
      }
    }
  } catch (e) {
    console.warn("Error updating local managers on db delete:", e);
  }

  // 2. Delete from cloud database registry and reset users assigned to this database
  try {
    await queryEmbeddedEncryptedTurso('DELETE FROM databases_registry WHERE id = ?;', [dbId]);
    await queryEmbeddedEncryptedTurso('UPDATE users SET database_id = NULL WHERE database_id = ?;', [dbId]).catch(() => {});
  } catch (e) {
    console.warn("Could not delete database from cloud:", e);
  }
}

export function isStaticOrNetlifyEnv(): boolean {
  if (typeof window === 'undefined') return false;
  const origin = window.location.origin || '';
  // If on netlify, github.io, capacitor, file, or any non-localhost / non-run.app host
  return !origin.includes('localhost') && !origin.includes('127.0.0.1') && !origin.includes('run.app');
}

/**
 * Enterprise Resilient Database Proxy:
 * 1. إذا كان التطبيق يعمل على Netlify أو استضافة ثابتة أو PWA، يتصل مباشرة بالمحرك المشفر فائق السرعة دون أي تأخير أو خادم وسيط.
 * 2. إذا كان يعمل محلياً في بيئة التطوير، يحاول أولاً الاتصال عبر الخادم المحمي (API Proxy).
 */
export async function queryTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();

  // إذا كان المستخدم ينتمي لقاعدة بيانات مخصصة تم تحديدها له من قبل الإدارة العامة
  const customDb = getActiveUserDatabaseAccount();
  if (customDb && customDb.url && customDb.token) {
    return await queryCustomTursoDirect(customDb.url, customDb.token, trimmedSql, args);
  }

  // على Netlify والتطبيقات الخارجية: اتصال فوري ومباشر بالمحرك المشفر السريع
  if (isStaticOrNetlifyEnv()) {
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }

  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    // إذا أعاد الخادم صفحة HTML أو خطأ توجيه (302/404/PWA Standalone redirect)
    const contentType = res.headers.get('content-type') || '';
    if (!res.ok || !contentType.includes('application/json')) {
      // التحول التلقائي للمحرك المدمج المشفر
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في تنفيذ استعلام القاعدة');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    // إذا تعذر الوصول للخادم بسبب CORS أو انقطاع أو تشغيل في بيئة PWA مستقلة
    try {
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    } catch (fallbackErr: any) {
      if (err.name === 'AbortError' || fallbackErr.name === 'AbortError') {
        throw new Error('انتهت مهلة الاتصال بالخادم، يرجى التحقق من اتصال الإنترنت');
      }
      throw fallbackErr || err;
    }
  }
}

// ---------------------- LOCAL STORAGE HELPERS ----------------------

export function getLocalDebtors(userId: number): Debtor[] | null {
  const data = localStorage.getItem(`debtors_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalDebtors(userId: number, debtors: Debtor[]) {
  localStorage.setItem(`debtors_user_${userId}`, JSON.stringify(debtors));
}

// Local Storage for Installments (نظام الأقساط المنفصل)
export function getLocalInstallments(userId: number): InstallmentRecord[] | null {
  const data = localStorage.getItem(`installments_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalInstallments(userId: number, installments: InstallmentRecord[]) {
  localStorage.setItem(`installments_user_${userId}`, JSON.stringify(installments));
}

export function getLocalUsers(): User[] | null {
  const data = localStorage.getItem("local_users");
  return data ? JSON.parse(data) : null;
}

export function setLocalUsers(users: User[]) {
  const safeUsers = users.map(({ password: _, ...u }) => u as User);
  localStorage.setItem("local_users", JSON.stringify(safeUsers));
}

export const DEFAULT_USER: User = {
  id: 1,
  username: 'admin',
  role: 'admin',
  branch_name: 'الفرع الرئيسي',
  isActive: true,
  subscriptionType: 'permanent',
};

export function getLocalSession(): User | null {
  try {
    const data = localStorage.getItem("session_user");
    if (!data) return null;
    const user: User = JSON.parse(data);
    if (!user || !user.id) return null;

    if (user.role !== 'admin' && user.id) {
      const forceLogout = localStorage.getItem(`force_logout_user_${user.id}`);
      if (forceLogout) {
        localStorage.removeItem("session_user");
        return null;
      }
      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        const managers: Manager[] = JSON.parse(managersData);
        const found = managers.find((m) => m.id === user.id);
        if (found && found.isActive === false) {
          localStorage.removeItem("session_user");
          return null;
        }
      }
    }
    if (!user.password) {
      const cachedPass = localStorage.getItem(`user_pwd_${user.id}`) || localStorage.getItem(`user_pwd_${user.username}`);
      if (cachedPass) {
        user.password = cachedPass;
      }
    }
    return user;
  } catch {
    return null;
  }
}

export function setLocalSession(user: User | null) {
  if (user) {
    localStorage.setItem("session_user", JSON.stringify(user));
    if (user.password) {
      localStorage.setItem(`user_pwd_${user.id}`, user.password);
      localStorage.setItem(`user_pwd_${user.username}`, user.password);
    }
  } else {
    localStorage.removeItem("session_user");
  }
}

// Multi-tab synchronization
export const sessionBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('submanager_auth_sync')
    : null;

export const debtorsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('debtors_realtime_sync')
    : null;

export const installmentsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('installments_realtime_sync')
    : null;

export const settingsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('settings_realtime_sync')
    : null;

export function broadcastDebtorsChange(userId: number, actionType?: string) {
  try {
    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.postMessage({
        type: 'DEBTORS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastInstallmentsChange(userId: number, actionType?: string) {
  try {
    if (installmentsBroadcastChannel) {
      installmentsBroadcastChannel.postMessage({
        type: 'INSTALLMENTS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastSettingsChange(userId: number, settings: AppSettings) {
  try {
    if (settingsBroadcastChannel) {
      settingsBroadcastChannel.postMessage({
        type: 'SETTINGS_UPDATED',
        userId,
        settings,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastManagerStatusChange(targetUserId: number, isActive: boolean, reason?: string) {
  try {
    if (!isActive) {
      localStorage.setItem(
        `force_logout_user_${targetUserId}`,
        JSON.stringify({
          timestamp: Date.now(),
          reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
        })
      );
      const current = getLocalSession();
      if (current && current.id === targetUserId) {
        localStorage.removeItem("session_user");
      }
    } else {
      localStorage.removeItem(`force_logout_user_${targetUserId}`);
    }

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.postMessage({
        type: isActive ? 'MANAGER_ACTIVATED' : 'FORCE_LOGOUT',
        targetUserId,
        reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
      });
    }
  } catch (e) {
    console.warn('Broadcast error:', e);
  }
}

export function getLocalManagers(): Manager[] | null {
  const data = localStorage.getItem("local_managers_list");
  return data ? JSON.parse(data) : null;
}

export function setLocalManagers(managers: Manager[]) {
  localStorage.setItem("local_managers_list", JSON.stringify(managers));
}

export const DEFAULT_SETTINGS: AppSettings = {
  enableDebtAlerts: true,
  alertDaysThreshold: 1,
  highDebtThreshold: 25000,
  numberFormat: 'english',
  language: 'ar',
  currency: 'IQD',
};

export function getLocalSettings(userId: number): AppSettings {
  try {
    const raw = localStorage.getItem(`app_settings_user_${userId}`);
    const globalLang = (localStorage.getItem('dftr_app_language') as any) || 'ar';
    const globalCurr = (localStorage.getItem('dftr_app_currency') as any) || 'IQD';
    const globalNumF = (localStorage.getItem('dftr_app_number_format') as any) || 'english';

    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enableDebtAlerts: parsed.enableDebtAlerts ?? true,
        alertDaysThreshold: parsed.alertDaysThreshold ?? 1,
        highDebtThreshold: parsed.highDebtThreshold ?? 25000,
        numberFormat: parsed.numberFormat ?? globalNumF,
        language: parsed.language ?? globalLang,
        currency: parsed.currency ?? globalCurr,
      };
    }
  } catch (e) {
    console.error("Error reading local settings:", e);
  }
  return { ...DEFAULT_SETTINGS };
}

export function setLocalSettings(userId: number, settings: AppSettings) {
  try {
    localStorage.setItem(`app_settings_user_${userId}`, JSON.stringify(settings));
  } catch (e) {
    console.error("Error saving local settings:", e);
  }
}

export function getLocalDebtorDates(userId: number): Record<number, string> {
  try {
    const raw = localStorage.getItem(`debtor_dates_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorDates(userId: number, dates: Record<number, string>) {
  try {
    localStorage.setItem(`debtor_dates_user_${userId}`, JSON.stringify(dates));
  } catch (e) {
    console.error("Error saving debtor dates:", e);
  }
}

export function getLocalDebtorHistory(userId: number): Record<number, DebtorTransaction[]> {
  try {
    const raw = localStorage.getItem(`debtor_history_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorHistory(userId: number, historyMap: Record<number, DebtorTransaction[]>) {
  try {
    localStorage.setItem(`debtor_history_user_${userId}`, JSON.stringify(historyMap));
  } catch (e) {
    console.error("Error saving debtor history:", e);
  }
}

/**
 * مزامنة الإعدادات (اللغة، العملة، الأرقام، التنبيهات، السقف) سحابياً لكل مستخدم/مدير فرعي
 */
export async function syncSettingsToCloud(userId: number, settings: AppSettings): Promise<void> {
  if (!userId || userId === 999999) return; // الحساب التجريبي محلي فقط
  try {
    const json = JSON.stringify(settings);
    const now = new Date().toISOString();
    await queryTurso(
      `INSERT INTO user_settings (user_id, settings_json, updated_at) 
       VALUES (?, ?, ?) 
       ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
      [userId, json, now]
    );
  } catch (err: any) {
    try {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`);
      const json = JSON.stringify(settings);
      const now = new Date().toISOString();
      await queryTurso(
        `INSERT INTO user_settings (user_id, settings_json, updated_at) 
         VALUES (?, ?, ?) 
         ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
        [userId, json, now]
      );
    } catch (e) {
      console.warn("Could not sync settings to cloud:", e);
    }
  }
}

/**
 * جلب الإعدادات السحابية للمستخدم عند تسجيل الدخول أو فتح الحساب من جهاز آخر
 */
export async function fetchSettingsFromCloud(userId: number): Promise<AppSettings | null> {
  if (!userId || userId === 999999) return null;
  try {
    let res;
    try {
      res = await queryTurso(
        `SELECT settings_json FROM user_settings WHERE user_id = ? LIMIT 1;`,
        [userId]
      );
    } catch {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`).catch(() => {});
      return null;
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }
    if (rows.length > 0 && rows[0][0]) {
      const val = rows[0][0]?.value ?? rows[0][0];
      if (typeof val === 'string') {
        return JSON.parse(val) as AppSettings;
      }
    }
  } catch (err) {
    console.warn("Could not fetch settings from cloud:", err);
  }
  return null;
}

