import { Debtor, InstallmentRecord } from '../types';

/**
 * Formats a phone number for WhatsApp URL.
 * Handles Iraqi phone numbers (07xxxxxxxxx -> 9647xxxxxxxxx)
 * and cleans up any spaces, dashes, or non-numeric characters.
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^\d+]/g, '');

  // Handle + prefix
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // If starts with 07... (11 digits Iraq), convert to 9647...
  if (cleaned.startsWith('07') && cleaned.length === 11) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.startsWith('7') && cleaned.length === 10) {
    cleaned = '964' + cleaned;
  }

  return cleaned;
}

/**
 * Generates the full WhatsApp API URL for sending a message
 */
export function getWhatsAppUrl(phone: string, message: string): string {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone);
  const encodedText = encodeURIComponent(message);
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * Directly opens WhatsApp without any intermediate UI
 */
export function openWhatsAppDirect(phone: string, message: string): boolean {
  try {
    const formattedPhone = formatPhoneNumberForWhatsApp(phone);
    if (!formattedPhone) return false;
    const url = getWhatsAppUrl(phone, message);

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 200);
    return true;
  } catch (err) {
    console.warn('Could not open WhatsApp directly:', err);
    try {
      const url = getWhatsAppUrl(phone, message);
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch {
      return false;
    }
  }
}

export interface WhatsAppNotificationData {
  customerName: string;
  phone: string;
  title: string;
  message: string;
  url: string;
}

/**
 * 1. عند إضافة عميل / دين جديد (New Debtor) - بدون أي إيموجي
 */
export function createNewDebtorWhatsAppNotice(
  debtor: Debtor,
  currencySymbol: string,
  storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAmount = Number(debtor.amount || 0).toLocaleString('en-US');
  const dateStr = debtor.createdAt
    ? debtor.createdAt.split('T')[0]
    : new Date().toISOString().split('T')[0];

  const message = `مرحباً ${debtor.name}
تم تسجيل حساب جديد لكم لدى (${storeName}):

تفاصيل الحساب:
المبلغ المطلوب: ${formattedAmount} ${currencySymbol}
التاريخ: ${dateStr}
${debtor.notes ? `ملاحظات: ${debtor.notes}\n` : ''}
شكراً لتعاملكم معنا.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'تسجيل حساب دين جديد',
    message,
    url,
  };
}

/**
 * 2. عند إضافة دين جديد لعميل موجود (Add Debt) - بدون أي إيموجي
 */
export function createAddDebtWhatsAppNotice(
  debtor: Debtor,
  addedAmount: number,
  newTotalAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAdded = addedAmount.toLocaleString('en-US');
  const formattedTotal = newTotalAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const message = `مرحباً ${debtor.name}
إشعار إضافة دين جديد لحسابكم لدى (${storeName}):

المبلغ المضاف: ${formattedAdded} ${currencySymbol}
التاريخ: ${dateStr}
إجمالي الدين الحالي: ${formattedTotal} ${currencySymbol}
${notes ? `ملاحظات: ${notes}\n` : ''}
شكراً لتعاملكم معنا.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار إضافة دين',
    message,
    url,
  };
}

/**
 * 3. عند تسديد دين (Pay Debt) - بدون أي إيموجي
 */
export function createPayDebtWhatsAppNotice(
  debtor: Debtor,
  paidAmount: number,
  remainingAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = remainingAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const statusLine =
    remainingAmount <= 0
      ? 'تم تسديد كامل الدين وتصفير الحساب بنجاح. شكراً لكم.'
      : `المبلغ المتبقي عليكم: ${formattedRemaining} ${currencySymbol}`;

  const message = `مرحباً ${debtor.name}
إيصال استلام وتسديد من (${storeName}):

المبلغ المسدد: ${formattedPaid} ${currencySymbol}
تاريخ التسديد: ${dateStr}
${statusLine}
${notes ? `ملاحظات: ${notes}\n` : ''}
شكراً لالتزامكم بالتسديد.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إيصال تسديد دين',
    message,
    url,
  };
}

/**
 * 4. عند إضافة عقد قسط جديد (New Installment) - بدون أي إيموجي
 */
export function createNewInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  currencySymbol: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedTotal = Number(inst.totalAmount || 0).toLocaleString('en-US');
  const formattedDown = Number(inst.downPayment || 0).toLocaleString('en-US');
  const formattedRemaining = Number(inst.remainingAmount || 0).toLocaleString('en-US');

  const message = `مرحباً ${inst.name}
تم تسجيل معاملة قسط جديدة لكم لدى (${storeName}):

السلعة: ${inst.item}
إجمالي قيمة الأقساط: ${formattedTotal} ${currencySymbol}
الدفعة المقدمة: ${formattedDown} ${currencySymbol}
المبلغ المتبقي: ${formattedRemaining} ${currencySymbol}
تاريخ القسط القادم: ${inst.nextDueDate}
${inst.notes ? `ملاحظات: ${inst.notes}\n` : ''}
شكراً لثقتكم بنا.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'تسجيل معاملة قسط جديدة',
    message,
    url,
  };
}

/**
 * 5. عند تسديد قسط (Pay Installment) - بدون أي إيموجي
 */
export function createPayInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  paidAmount: number,
  newRemaining: number,
  nextDueDate: string,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemaining.toLocaleString('en-US');
  const dateStr = payDate ? payDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const isCompleted = newRemaining <= 0;
  const statusLine = isCompleted
    ? 'تم تسديد كامل الأقساط بنجاح واكتمل العقد بالكامل.'
    : `المتبقي الكلي: ${formattedRemaining} ${currencySymbol}\nموعد القسط القادم: ${nextDueDate}`;

  const message = `مرحباً ${inst.name}
إيصال تسديد قسط لدى (${storeName}):

السلعة: ${inst.item}
المبلغ المسدد: ${formattedPaid} ${currencySymbol}
تاريخ الدفع: ${dateStr}
${statusLine}
${notes ? `ملاحظات: ${notes}\n` : ''}
شكراً لالتزامكم بالتسديد.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'إيصال تسديد قسط',
    message,
    url,
  };
}
