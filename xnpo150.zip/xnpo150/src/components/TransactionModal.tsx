import React, { useState, useEffect } from 'react';
import { Debtor } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatAmountInput, formatNumber, parseFormattedNumber } from '../utils/formatters';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';

interface TransactionModalProps {
  isOpen: boolean;
  type: 'pay' | 'add';
  debtor: Debtor | null;
  onClose: () => void;
  onConfirm: (debtorId: number, amount: number, date?: string, notes?: string) => Promise<void>;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  type,
  debtor,
  onClose,
  onConfirm
}) => {
  const { t, currency } = useI18n();
  const [amountStr, setAmountStr] = useState('');
  const [notes, setNotes] = useState('');
  const [debtDate, setDebtDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useModalKeyboardAdjust(isOpen);

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (isOpen) {
      setAmountStr('');
      setNotes('');
      setDebtDate(new Date().toISOString().split('T')[0]);
      setError(null);
    }
  }, [isOpen]);

  if (!isOpen || !debtor) return null;

  const isPayment = type === 'pay';
  const enteredAmount = parseFormattedNumber(amountStr);
  const currentAmount = debtor.amount || 0;
  const newCalculatedAmount = isPayment
    ? Math.max(0, currentAmount - enteredAmount)
    : currentAmount + enteredAmount;

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmountStr(formatAmountInput(e.target.value));
  };

  const handleQuickSelect = (val: number) => {
    setAmountStr(val.toLocaleString('en-US'));
  };

  const handlePayFull = () => {
    setAmountStr(currentAmount.toLocaleString('en-US'));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (enteredAmount <= 0) {
      setError(t('modals.enterAmountGreaterThanZero', 'يرجى إدخال مبلغ أكبر من صفر'));
      return;
    }

    try {
      setIsSubmitting(true);
      const formattedDate = debtDate ? new Date(debtDate).toISOString() : new Date().toISOString();
      const trimmedNotes = notes.trim() || undefined;
      await onConfirm(debtor.id, enteredAmount, formattedDate, trimmedNotes);
      onClose();
    } catch (err: any) {
      setError(err.message || t('common.syncError', 'حدث خطأ في المزامنة'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 text-start">
      <div className="bg-white rounded-3xl w-full max-w-sm p-5 sm:p-6 shadow-2xl relative border border-slate-100 max-h-[92vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold ${
                isPayment ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'
              }`}
            >
              <i className={`fa-solid ${isPayment ? 'fa-arrow-down' : 'fa-plus'}`}></i>
            </div>
            <div>
              <div className="font-bold text-sm text-slate-800">
                {isPayment ? t('debts.payAmount', 'تسديد مبلغ من الدين') : t('debts.addDebt', 'إضافة دين جديد')}
              </div>
              <div className="text-[11px] text-slate-500 font-medium">{debtor.name}</div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Balance Preview Card */}
        <div className="bg-slate-50 rounded-2xl p-2.5 mb-3 border border-slate-100 grid grid-cols-2 gap-2 text-center">
          <div>
            <span className="text-[10px] text-slate-400 block mb-0.5 font-medium">{t('debts.currentDebt', 'الدين الحالي')}</span>
            <span className="text-xs font-bold text-slate-700 font-mono">
              {formatNumber(currentAmount)} {currency}
            </span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 block mb-0.5 font-medium">{t('debts.balanceAfterAction', 'الرصيد بعد العملية')}</span>
            <span
              className={`text-xs font-bold font-mono ${
                newCalculatedAmount === 0 ? 'text-emerald-600' : 'text-blue-600'
              }`}
            >
              {formatNumber(newCalculatedAmount)} {currency}
            </span>
          </div>
        </div>

        {error && (
          <div className="mb-3 p-2 bg-red-50 border border-red-200 text-red-600 text-xs rounded-xl flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation shrink-0"></i>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-3 pb-24 sm:pb-0">
          {/* Amount Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {isPayment ? t('debts.paidAmount', 'المبلغ المسدد') : t('debts.additionalDebtAmount', 'مبلغ الدين الإضافي')} ({currency})
            </label>
            <div className="relative">
              <input
                type="text"
                dir="ltr"
                inputMode="numeric"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base outline-none focus:border-blue-600 focus:bg-white text-slate-800 font-bold font-mono transition-all"
                placeholder="0"
                value={amountStr}
                onChange={handleAmountChange}
                onFocus={handleInputFocus}
                autoFocus
              />
            </div>
          </div>

          {/* Quick Amount Buttons */}
          <div className="flex flex-wrap gap-1.5">
            {isPayment && currentAmount > 0 && (
              <button
                type="button"
                onClick={handlePayFull}
                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
              >
                {t('debts.fullAmount', 'كامل المبلغ')} ({formatNumber(currentAmount)})
              </button>
            )}
            {[5000, 10000, 25000, 50000].map((val) => (
              <button
                key={val}
                type="button"
                onClick={() => handleQuickSelect(val)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-[10px] font-semibold cursor-pointer transition-colors"
              >
                +{val.toLocaleString('en-US')}
              </button>
            ))}
          </div>

          {/* Notes Field (Optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span>
                {t('common.notes', 'ملاحظات')}{' '}
                <span className="text-slate-400 font-normal text-[10px]">({t('common.optional', 'اختياري')})</span>
              </span>
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all placeholder:text-slate-400"
              placeholder={
                isPayment
                  ? t('debts.paymentPlaceholder', 'مثال: تسديد نقدي، حوالة، دفعة أسبوعية...')
                  : t('debts.debtPlaceholder', 'مثال: بضاعة، كارت شحن، مسواك...')
              }
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              onFocus={handleInputFocus}
              maxLength={150}
            />
          </div>

          {/* Date Picker */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700">
                {isPayment ? t('debts.paymentDate', 'تاريخ التسديد') : t('debts.debtRegistrationDate', 'تاريخ تسجيل الدين')}
              </label>
              {debtDate !== todayStr ? (
                <button
                  type="button"
                  onClick={() => setDebtDate(todayStr)}
                  className="text-[10px] font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-2 py-0.5 rounded-md cursor-pointer transition-colors flex items-center gap-1"
                >
                  <i className="fa-solid fa-arrow-rotate-left text-[9px]"></i>
                  <span>{t('debts.resetToToday', 'إعادة لتاريخ اليوم')}</span>
                </button>
              ) : (
                <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1 border border-emerald-100">
                  <i className="fa-solid fa-check text-[9px]"></i>
                  <span>{t('debts.todayDate', 'تاريخ اليوم')}</span>
                </span>
              )}
            </div>
            <input
              type="date"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all font-mono"
              value={debtDate}
              onChange={(e) => setDebtDate(e.target.value)}
              onFocus={handleInputFocus}
            />
          </div>

          <div className="flex gap-2 mt-2 pt-2 border-t border-slate-100">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex-1 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-md cursor-pointer transition-all flex items-center justify-center gap-2 text-white ${
                isPayment
                  ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20'
                  : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20'
              }`}
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.processing', 'جاري المعالجة...')}</span>
                </>
              ) : (
                <span>{isPayment ? t('debts.confirmPayment', 'تأكيد التسديد') : t('debts.confirmAddition', 'تأكيد الإضافة')}</span>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl font-bold text-xs sm:text-sm cursor-pointer transition-all"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
