import React, { useState, useMemo } from 'react';
import { Debtor, DebtorTransaction } from '../types';
import {
  formatNumber,
  formatIraqiPhoneNumber,
  formatDateTimeArabic,
  formatDateArabic,
} from '../utils/formatters';

interface DebtorShareModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  storeName?: string;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DebtorShareModal: React.FC<DebtorShareModalProps> = ({
  isOpen,
  debtor,
  storeName = 'دفتر الديون',
  onClose,
  onShowToast,
}) => {
  const [shareMode, setShareMode] = useState<'statement' | 'summary'>('statement');
  const [customPhone, setCustomPhone] = useState('');
  const [copied, setCopied] = useState(false);

  // Sync phone when debtor changes
  React.useEffect(() => {
    if (debtor?.phone) {
      setCustomPhone(debtor.phone);
    } else {
      setCustomPhone('');
    }
    setCopied(false);
  }, [debtor]);

  // Generate formatted text based on mode (ensure hook is always executed)
  const generatedText = useMemo(() => {
    if (!debtor) return '';

    const currentBalance = debtor.amount || 0;
    const titleHeader = storeName ? `*${storeName.trim()}*` : '*دفتر الديون*';
    const clientName = debtor.name.trim();

    // Build history list
    const rawHistory: DebtorTransaction[] = debtor.history && debtor.history.length > 0
      ? debtor.history
      : [
          {
            id: `initial-${debtor.id}`,
            debtorId: debtor.id,
            type: 'initial',
            amount: debtor.amount,
            balanceAfter: debtor.amount,
            date: debtor.createdAt || new Date().toISOString(),
            description: 'رصيد أولي',
          },
        ];

    const sortedHistory = [...rawHistory].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    const totalAdded = rawHistory
      .filter((h) => h.type === 'add' || h.type === 'initial')
      .reduce((sum, h) => sum + h.amount, 0);

    const totalPaid = rawHistory
      .filter((h) => h.type === 'pay')
      .reduce((sum, h) => sum + h.amount, 0);

    if (shareMode === 'statement') {
      let text = `السلام عليكم ورحمة الله وبركاته\n`;
      text += `أخي الكريم: *${clientName}*\n`;
      text += `تحية طيبة، مرفق لكم كشف الحساب المالي بذمتكم لدى ${titleHeader}:\n\n`;
      text += `💰 *الرصيد الحالي المتبقي:* ${formatNumber(currentBalance)} د.ع\n`;
      text += `➕ *إجمالي الديون المسجلة:* ${formatNumber(totalAdded)} د.ع\n`;
      text += `➖ *إجمالي المبالغ المسددة:* ${formatNumber(totalPaid)} د.ع\n`;

      if (sortedHistory.length > 0) {
        text += `\n━━━━━━━━━━━━━━━━━━━━\n`;
        text += `📜 *آخر العمليات المسجلة:*\n`;
        sortedHistory.slice(0, 5).forEach((tx, idx) => {
          const typeLabel =
            tx.type === 'pay'
              ? '✅ تسديد'
              : tx.type === 'initial'
              ? '📂 رصيد أولي'
              : '➕ دين جديد';
          const sign = tx.type === 'pay' ? '-' : '+';
          const dateStr = formatDateTimeArabic(tx.date);
          text += `${idx + 1}. ${typeLabel}: ${sign}${formatNumber(tx.amount)} د.ع (${dateStr})\n`;
        });
        if (sortedHistory.length > 5) {
          text += `... وهناك ${sortedHistory.length - 5} عمليات سابقة أخرى\n`;
        }
      }

      text += `━━━━━━━━━━━━━━━━━━━━\n`;
      text += `يرجى التكرم بمراجعة الحساب وإتمام التسديد في أقرب وقت.\n`;
      text += `شاكرين لكم حسن تعاونكم.\n`;
      text += `${titleHeader}`;
      return text;
    } else {
      // Summary mode
      let text = `السلام عليكم ورحمة الله وبركاته\n`;
      text += `أخي الكريم: *${clientName}*\n\n`;
      text += `نود تذكيركم بلطف بالرصيد المالي القائم بذمتكم لدى ${titleHeader}:\n`;
      text += `💰 *المبلغ المطلوب تسديده:* ${formatNumber(currentBalance)} د.ع\n`;
      if (debtor.createdAt) {
        text += `📅 *تاريخ التسجيل:* ${formatDateArabic(debtor.createdAt)}\n`;
      }
      text += `\nيرجى التكرم بمراجعة الحساب وإتمام التسديد مع جزيل الشكر والامتنان.\n`;
      text += `${titleHeader}`;
      return text;
    }
  }, [shareMode, debtor, storeName]);

  // If not open or no debtor, return null after all hooks have been invoked
  if (!isOpen || !debtor) return null;

  const currentBalance = debtor.amount || 0;

  const handleCopyText = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(generatedText);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = generatedText;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      onShowToast('تم نسخ كشف الحساب وتفاصيل الدين بنجاح', 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      onShowToast('تعذر نسخ النص إلى الحافظة', 'error');
    }
  };

  const handleSendWhatsApp = () => {
    const targetPhone = customPhone.trim() || debtor.phone?.trim();
    if (!targetPhone) {
      onShowToast('يرجى تحديد أو كتابة رقم هاتف المدين أولاً للإرسال عبر واتساب', 'error');
      return;
    }

    const formatted = formatIraqiPhoneNumber(targetPhone);
    if (!formatted || formatted.length < 9) {
      onShowToast('رقم الهاتف غير صالح، يرجى كتابته بالصيغة العراقية الصحيحة', 'error');
      return;
    }

    const waUrl = `https://wa.me/${formatted}?text=${encodeURIComponent(generatedText)}`;
    window.open(waUrl, '_blank');
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `كشف حساب - ${debtor.name}`,
          text: generatedText,
        });
        onShowToast('تم فتح نافذة المشاركة بنجاح', 'success');
      } catch {
        // User cancelled or share failed silently
      }
    } else {
      handleCopyText();
    }
  };

  return (
    <div
      id="debtorShareModalBackdrop"
      className="fixed inset-0 bg-slate-950/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150 select-none"
      onClick={onClose}
    >
      <div
        id="debtorShareModal"
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-100 animate-in zoom-in-95 duration-200 text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-base shadow-md shadow-blue-500/20">
              <i className="fa-solid fa-share-nodes"></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  مشاركة كشف الحساب
                </h2>
                <span className="text-[11px] font-bold bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-full font-mono">
                  {formatNumber(currentBalance)} د.ع
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                إرسال تفاصيل الدين للمدين: <strong className="text-slate-800 font-bold">{debtor.name}</strong>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-300 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs transition-colors cursor-pointer"
            title="إغلاق"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* Format Selector Tabs */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              صيغة ونوع الرسالة:
            </label>
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-2xl border border-slate-200/60">
              <button
                type="button"
                onClick={() => setShareMode('statement')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  shareMode === 'statement'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-file-invoice-dollar text-xs"></i>
                <span>كشف حساب تفصيلي</span>
              </button>
              <button
                type="button"
                onClick={() => setShareMode('summary')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  shareMode === 'summary'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-bell text-xs"></i>
                <span>تذكير مباشر وتفاصيل الدين</span>
              </button>
            </div>
          </div>

          {/* Optional Phone input if empty or needs correction */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-phone text-[11px] text-slate-400"></i>
                <span>رقم هاتف المستلم (واتساب):</span>
              </label>
              {debtor.phone && (
                <span className="text-[11px] text-slate-400 font-mono dir-ltr">
                  {debtor.phone}
                </span>
              )}
            </div>
            <input
              type="tel"
              value={customPhone}
              onChange={(e) => setCustomPhone(e.target.value)}
              placeholder="مثال: 07701234567"
              className="w-full py-2.5 px-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white text-left dir-ltr transition-colors"
            />
          </div>

          {/* Formatted Text Preview */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-regular fa-message text-[11px] text-slate-400"></i>
                <span>معاينة نص كشف الحساب للمشاركة:</span>
              </label>
              <button
                type="button"
                onClick={handleCopyText}
                className="text-xs text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer transition-colors"
              >
                <i className={`fa-regular ${copied ? 'fa-circle-check text-emerald-600' : 'fa-copy'}`}></i>
                <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
              </button>
            </div>

            <div className="relative group">
              <textarea
                readOnly
                value={generatedText}
                rows={7}
                className="w-full p-3.5 bg-slate-50 border border-slate-200/90 rounded-2xl text-[12px] leading-relaxed text-slate-800 font-sans resize-none focus:outline-none select-all"
              />
              <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                <span>النص منسق وجاهز للإرسال الفوري</span>
                <span>{generatedText.length} حرف</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-2.5">
          {/* WhatsApp Primary Action Button */}
          <button
            type="button"
            id="btnShareWhatsApp"
            onClick={handleSendWhatsApp}
            className="flex-1 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className="fa-brands fa-whatsapp text-base"></i>
            <span>إرسال عبر واتساب</span>
          </button>

          {/* Copy Formatted Text Button */}
          <button
            type="button"
            id="btnCopyFormattedStatement"
            onClick={handleCopyText}
            className={`py-3 px-4 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer border ${
              copied
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 active:scale-[0.99] shadow-xs'
            }`}
          >
            <i className={`fa-regular ${copied ? 'fa-circle-check text-emerald-600' : 'fa-copy text-blue-600'}`}></i>
            <span>{copied ? 'تم النسخ بنجاح' : 'نسخ تفاصيل الدين كنص'}</span>
          </button>

          {/* Native Share button (if supported on device/browser) */}
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              type="button"
              id="btnNativeShare"
              onClick={handleNativeShare}
              className="py-3 px-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-slate-200/70"
              title="مشاركة عبر تطبيقات أخرى"
            >
              <i className="fa-solid fa-arrow-up-from-bracket text-xs"></i>
              <span className="hidden sm:inline">تطبيقات أخرى</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
