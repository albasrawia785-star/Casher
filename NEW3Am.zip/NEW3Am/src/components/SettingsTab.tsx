import React, { useState, useEffect } from 'react';
import bcrypt from 'bcryptjs';
import { AppSettings, DebtStats, Debtor, Manager, SubscriptionType, User, InstallmentRecord, ManagerModuleAccess } from '../types';
import { formatNumber, formatDateArabic, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';
import { queryTurso, setLocalSession } from '../services/turso';
import { ManagersTab } from './ManagersTab';
import { BackupRestoreSection } from './BackupRestoreSection';

interface SettingsTabProps {
  currentUser: User;
  managers: Manager[];
  stats?: DebtStats;
  currentDebts?: number;
  onUpdateStats?: (newStats: DebtStats) => void;
  onCreateManager: (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType,
    subscriptionMonths?: number,
    allowedModules?: ManagerModuleAccess
  ) => Promise<void>;
  onToggleManagerStatus: (id: number, currentActive: boolean) => Promise<void>;
  onRenewSubscription: (id: number, months?: number) => Promise<void>;
  onChangeSubscriptionType?: (id: number, newType: SubscriptionType, months?: number) => Promise<void>;
  onChangeManagerModules?: (id: number, newAllowedModules: ManagerModuleAccess) => Promise<void>;
  onDeleteManager: (id: number) => void;
  onRefreshCloud?: () => void;
  onLogout: () => void;
  isSyncing?: boolean;
  isManagersLoading: boolean;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  totalDebtorsCount: number;
  highDebtorsCount: number;
  alertTriggeredCount: number;
  allDebtors?: Debtor[];
  installments?: InstallmentRecord[];
  onImportBackup?: (
    importedDebtors: Debtor[],
    importedInstallments: InstallmentRecord[],
    mode: 'merge' | 'replace'
  ) => Promise<void>;
  onImportDebtors?: (importedDebtors: Debtor[], mode: 'merge' | 'replace') => Promise<void>;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
  onAddDemoDebtors?: () => void;
  onClearDemoDebtors?: () => void;
  demoDebtorsCount?: number;
  onUpdateManagerPassword?: (id: number, newPass: string) => Promise<void>;
  onRefreshManagers?: () => Promise<void> | void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  currentUser,
  managers,
  onCreateManager,
  onToggleManagerStatus,
  onRenewSubscription,
  onChangeSubscriptionType,
  onChangeManagerModules,
  onDeleteManager,
  onLogout,
  isManagersLoading,
  settings,
  onUpdateSettings,
  totalDebtorsCount,
  highDebtorsCount,
  alertTriggeredCount,
  allDebtors = [],
  installments = [],
  onImportBackup,
  onImportDebtors,
  onShowToast,
  onAddDemoDebtors,
  onClearDemoDebtors,
  demoDebtorsCount = 0,
  onUpdateManagerPassword,
  onRefreshManagers,
}) => {
  const isAdmin = currentUser.role === 'admin';

  // Accordion Sections Open/Close State (Organized Dropdowns - all collapsed by default)
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    profile: false,
    alerts: false,
    highDebt: false,
    backup: false,
    managers: false,
    database: false,
    demo: false,
  });

  const toggleSection = (key: string) => {
    setOpenSections((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Settings State
  const [enableAlerts, setEnableAlerts] = useState(settings.enableDebtAlerts);
  const [alertDays, setAlertDays] = useState(settings.alertDaysThreshold);
  const [highDebtThreshold, setHighDebtThreshold] = useState(settings.highDebtThreshold);
  const [isSettingsSaved, setIsSettingsSaved] = useState(false);

  // Sub-manager Password state & handlers
  const [userPassword, setUserPassword] = useState<string>(() => {
    return (
      currentUser.password ||
      localStorage.getItem(`user_pwd_${currentUser.id}`) ||
      localStorage.getItem(`user_pwd_${currentUser.username}`) ||
      ''
    );
  });
  const [showUserPassword, setShowUserPassword] = useState(false);
  const [copiedPassword, setCopiedPassword] = useState(false);
  const [isEditingPassword, setIsEditingPassword] = useState(false);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [isSavingNewPassword, setIsSavingNewPassword] = useState(false);
  const [passwordChangeMessage, setPasswordChangeMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Sync password if currentUser changes or if updated in local storage
  useEffect(() => {
    const pwd =
      currentUser.password ||
      localStorage.getItem(`user_pwd_${currentUser.id}`) ||
      localStorage.getItem(`user_pwd_${currentUser.username}`) ||
      '';
    if (pwd) {
      setUserPassword(pwd);
    }
  }, [currentUser]);

  const handleCopyPassword = () => {
    if (!userPassword) return;
    navigator.clipboard.writeText(userPassword);
    setCopiedPassword(true);
    if (onShowToast) {
      onShowToast('تم نسخ كلمة المرور إلى الحافظة بنجاح', 'success');
    }
    setTimeout(() => setCopiedPassword(false), 2000);
  };

  const handleSaveNewPassword = async () => {
    const trimmed = newPasswordInput.trim();
    if (!trimmed) {
      setPasswordChangeMessage({ text: 'يرجى كتابة كلمة المرور الجديدة', type: 'error' });
      return;
    }
    if (trimmed.length < 3) {
      setPasswordChangeMessage({ text: 'كلمة المرور يجب ألا تقل عن 3 أحرف/أرقام', type: 'error' });
      return;
    }

    try {
      setIsSavingNewPassword(true);
      setPasswordChangeMessage(null);

      const salt = bcrypt.genSaltSync(10);
      const hashed = bcrypt.hashSync(trimmed, salt);

      try {
        await queryTurso('UPDATE users SET password = ?, plain_password = ? WHERE id = ?;', [hashed, trimmed, currentUser.id]);
      } catch {
        await queryTurso('ALTER TABLE users ADD COLUMN plain_password TEXT;').catch(() => {});
        await queryTurso('UPDATE users SET password = ?, plain_password = ? WHERE id = ?;', [hashed, trimmed, currentUser.id]);
      }

      setUserPassword(trimmed);
      currentUser.password = trimmed;
      localStorage.setItem(`user_pwd_${currentUser.id}`, trimmed);
      localStorage.setItem(`user_pwd_${currentUser.username}`, trimmed);
      setLocalSession(currentUser);

      // Update local_managers_list cache so admin sees it if cached
      const cachedMgrs = localStorage.getItem("local_managers_list");
      if (cachedMgrs) {
        try {
          const list = JSON.parse(cachedMgrs);
          const updated = list.map((m: any) => m.id === currentUser.id ? { ...m, plainPassword: trimmed } : m);
          localStorage.setItem("local_managers_list", JSON.stringify(updated));
        } catch {}
      }

      // Notify other open tabs/windows (e.g. Admin view) instantly
      if (typeof BroadcastChannel !== 'undefined') {
        try {
          const bc = new BroadcastChannel('dftr_session_sync');
          bc.postMessage({
            type: 'MANAGER_PASSWORD_CHANGED',
            managerId: currentUser.id,
            username: currentUser.username,
            newPassword: trimmed,
          });
          bc.close();
        } catch {}
      }

      setIsEditingPassword(false);
      setNewPasswordInput('');
      setShowUserPassword(true);
      setPasswordChangeMessage({ text: 'تم تحديث كلمة المرور وحفظها بنجاح!', type: 'success' });
      if (onShowToast) {
        onShowToast('تم تحديث كلمة المرور وحفظها بنجاح', 'success');
      }
    } catch (err: any) {
      setPasswordChangeMessage({ text: err.message || 'فشل حفظ كلمة المرور في الخادم', type: 'error' });
    } finally {
      setIsSavingNewPassword(false);
    }
  };

  // Database Connection Test State (Only for Admin)
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionTestResult, setConnectionTestResult] = useState<{
    success: boolean;
    message: string;
    host?: string;
    responseTimeMs?: number;
  } | null>(null);

  const handleTestDatabaseConnection = async () => {
    setIsTestingConnection(true);
    setConnectionTestResult(null);
    try {
      const startTime = Date.now();
      await queryTurso("SELECT 1 as test_val;");
      const responseTime = Date.now() - startTime;
      setConnectionTestResult({
        success: true,
        message: 'الاتصال بقاعدة البيانات السحابية ناجح ومستقر!',
        host: 'Turso Cloud (قاعدة البيانات السحابية المشتركة)',
        responseTimeMs: responseTime,
      });
    } catch (err: any) {
      setConnectionTestResult({
        success: false,
        message: `تعذر الاتصال بالسحابة: ${err?.message || 'خطأ غير متوقع'}`,
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  useEffect(() => {
    setEnableAlerts(settings.enableDebtAlerts);
    setAlertDays(settings.alertDaysThreshold);
    setHighDebtThreshold(settings.highDebtThreshold);
  }, [settings]);

  const handleSaveAppSettings = (
    newEnableAlerts = enableAlerts,
    newDays = alertDays,
    newThreshold = highDebtThreshold
  ) => {
    const updated: AppSettings = {
      enableDebtAlerts: newEnableAlerts,
      alertDaysThreshold: Math.max(1, Number(newDays) || 1),
      highDebtThreshold: Math.max(0, Number(newThreshold) || 0),
    };
    onUpdateSettings(updated);
    setIsSettingsSaved(true);
    setTimeout(() => setIsSettingsSaved(false), 2500);
  };

  const dayPresets = [
    { label: 'يوم واحد (1)', value: 1 },
    { label: 'يومان (2)', value: 2 },
    { label: '3 أيام', value: 3 },
    { label: '7 أيام', value: 7 },
    { label: '14 يوماً', value: 14 },
    { label: '30 يوماً', value: 30 },
  ];

  const highDebtPresets = [
    { label: '10,000 د.ع', value: 10000 },
    { label: '25,000 د.ع', value: 25000 },
    { label: '50,000 د.ع', value: 50000 },
    { label: '100,000 د.ع', value: 100000 },
    { label: '250,000 د.ع', value: 250000 },
  ];

  return (
    <div id="tab-settings" className="pb-24 space-y-3 animate-in fade-in duration-150 text-right">
      {/* Header - Sticky */}
      <div className="sticky top-0 z-30 bg-slate-50/95 backdrop-blur-md px-4 pt-3.5 pb-2.5 border-b border-slate-200/60 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.05)] text-right">
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">الإعدادات</h1>
        <p className="text-xs font-medium text-slate-500 mt-0.5">
          إدارة تنبيهات الديون، سقف المبالغ، الحساب، والفروع
        </p>
      </div>

      <div className="px-4 space-y-3">
        {/* ---------------------------------------------------- */}
        {/* 1. قائمة منسدلة: الملف الشخصي والفرع */}
        {/* ---------------------------------------------------- */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
        <button
          type="button"
          onClick={() => toggleSection('profile')}
          className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-right cursor-pointer select-none"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
              <i className="fa-solid fa-store"></i>
            </div>
            <div className="truncate">
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <span>الملف الشخصي والفرع</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  currentUser.role === 'trial' || currentUser.subscriptionType === 'trial'
                    ? 'bg-amber-50 text-amber-700 border-amber-200'
                    : 'bg-blue-50 text-blue-700 border-blue-100'
                }`}>
                  {currentUser.role === 'admin' ? 'مدير عام' : (currentUser.role === 'trial' || currentUser.subscriptionType === 'trial') ? 'حساب تجريبي' : 'مدير فرع'}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 truncate mt-0.5">
                {currentUser.branch_name || 'الفرع الرئيسي'} • المستخدم: {currentUser.username}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {!isAdmin && (
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-xl border bg-slate-50 text-slate-700 border-slate-200 hidden sm:inline-block">
                {(currentUser.role === 'trial' || currentUser.subscriptionType === 'trial')
                  ? 'تجريبي (2 مدينين)'
                  : currentUser.subscriptionType === 'permanent'
                  ? 'دائم'
                  : `متبقي ${getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt)} يوم`}
              </span>
            )}
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                openSections.profile ? 'bg-blue-50 text-blue-600 rotate-180' : 'bg-slate-100 text-slate-400'
              }`}
            >
              <i className="fa-solid fa-chevron-down text-xs"></i>
            </div>
          </div>
        </button>

        {openSections.profile && (
          <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
            {/* Account Details Box */}
            <div className="bg-slate-50 border border-slate-200/70 rounded-2xl p-4 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200/60">
                  <span className="text-slate-500 font-medium">اسم الفرع:</span>
                  <span className="font-bold text-slate-900">{currentUser.branch_name || 'الفرع الرئيسي'}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200/60">
                  <span className="text-slate-500 font-medium">اسم المستخدم:</span>
                  <span className="font-mono font-bold text-slate-900">{currentUser.username}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200/60">
                  <span className="text-slate-500 font-medium">نوع الصلاحية:</span>
                  <span className="font-bold text-blue-700">
                    {currentUser.role === 'admin'
                      ? 'مدير عام للنظام'
                      : (currentUser.role === 'trial' || currentUser.subscriptionType === 'trial')
                      ? 'حساب تجريبي (محلي)'
                      : 'مدير فرع فرعي'}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-200/60">
                  <span className="text-slate-500 font-medium">حالة الاشتراك:</span>
                  {isAdmin ? (
                    <span className="font-bold text-emerald-700">دائم (حساب رئيسي)</span>
                  ) : (currentUser.role === 'trial' || currentUser.subscriptionType === 'trial') ? (
                    <span className="font-bold text-amber-700">وضع تجريبي (حد 2 مدينين - حفظ محلي)</span>
                  ) : currentUser.subscriptionType === 'permanent' ? (
                    <span className="font-bold text-emerald-700">حساب دائم غير محدود</span>
                  ) : (
                    <span className="font-bold text-purple-700">
                      شهري (ينتهي: {formatDateArabic(currentUser.subscriptionExpiresAt)})
                    </span>
                  )}
                </div>
              </div>

              {/* Trial Upgrade Banner inside Profile if Trial */}
              {(currentUser.role === 'trial' || currentUser.subscriptionType === 'trial') && (
                <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-bold text-xs">
                      <i className="fa-solid fa-lock text-amber-600"></i>
                      <span>أنت تستخدم النسخة التجريبية</span>
                    </div>
                    <span className="text-[10px] bg-amber-200/70 text-amber-800 font-bold px-2 py-0.5 rounded-md">
                      تخزين محلي فقط
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed">
                    يسمح لك الوضع التجريبي بتسجيل حتى (2) مدينين فقط. للاشتراك في النسخة الكاملة بدون حدود مع التخزين السحابي:
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      const msg = encodeURIComponent("السلام عليكم، أود تفعيل النسخة الكاملة من تطبيق دفتر الديون لفتح عدد غير محدود من المدينين والمزامنة السحابية.");
                      window.open(`https://wa.me/9647810936407?text=${msg}`, '_blank');
                    }}
                    className="w-full py-2.5 px-3 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <i className="fa-brands fa-whatsapp text-sm"></i>
                    <span>مراسلة الإدارة للاشتراك في النسخة الكاملة</span>
                  </button>
                </div>
              )}

              {/* حقل كلمة سر المدير الفرعي / الحساب */}
              <div className="p-3.5 bg-white rounded-2xl border border-blue-100/90 shadow-xs space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold shrink-0">
                      <i className="fa-solid fa-key"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <span>{currentUser.role === 'admin' ? 'كلمة المرور الخاصة بالحساب:' : 'كلمة سر المدير الفرعي:'}</span>
                        <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-blue-50 text-blue-700 border border-blue-100">
                          {currentUser.role === 'admin' ? 'الإدارة' : 'الفرع'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        الرمز المخصص لتسجيل الدخول إلى هذا الحساب
                      </span>
                    </div>
                  </div>

                  {/* Actions: Show/Hide, Copy, Edit */}
                  <div className="flex items-center gap-1.5">
                    {userPassword && !isEditingPassword && (
                      <>
                        <button
                          type="button"
                          onClick={() => setShowUserPassword(!showUserPassword)}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                          title={showUserPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                        >
                          <i className={`fa-solid ${showUserPassword ? 'fa-eye-slash text-slate-500' : 'fa-eye text-blue-600'}`}></i>
                          <span>{showUserPassword ? 'إخفاء' : 'إظهار'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleCopyPassword}
                          className="px-2.5 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 active:bg-blue-200 text-blue-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                          title="نسخ كلمة المرور"
                        >
                          <i className={`fa-solid ${copiedPassword ? 'fa-check text-emerald-600' : 'fa-copy'}`}></i>
                          <span>{copiedPassword ? 'تم النسخ' : 'نسخ'}</span>
                        </button>
                      </>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setIsEditingPassword(!isEditingPassword);
                        setNewPasswordInput(userPassword || '');
                        setPasswordChangeMessage(null);
                      }}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                        isEditingPassword
                          ? 'bg-slate-200 text-slate-800'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                      title={isEditingPassword ? 'إلغاء التعديل' : 'تعديل كلمة المرور'}
                    >
                      <i className={`fa-solid ${isEditingPassword ? 'fa-xmark' : 'fa-pen-to-square text-slate-500'}`}></i>
                      <span>{isEditingPassword ? 'إلغاء' : 'تعديل'}</span>
                    </button>
                  </div>
                </div>

                {/* Password display or edit input */}
                {!isEditingPassword ? (
                  <div className="flex items-center justify-between bg-slate-50 px-3.5 py-2.5 rounded-xl border border-slate-200/80">
                    <span className="text-[11px] text-slate-500 font-medium">الرمز الحالي:</span>
                    {userPassword ? (
                      <span className="font-mono font-bold text-sm tracking-wider text-slate-900 select-all">
                        {showUserPassword ? userPassword : '••••••••••••'}
                      </span>
                    ) : (
                      <span className="text-xs text-amber-600 font-medium">
                        لم يتم حفظ كلمة المرور في هذه الجلسة (اضغط تعديل لحفظها)
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={newPasswordInput}
                        onChange={(e) => setNewPasswordInput(e.target.value)}
                        placeholder="اكتب كلمة المرور الجديدة..."
                        className="flex-1 bg-white border border-blue-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-xs font-mono font-bold px-3 py-2 rounded-xl text-right outline-none text-slate-900"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleSaveNewPassword();
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={handleSaveNewPassword}
                        disabled={isSavingNewPassword}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shrink-0 shadow-xs"
                      >
                        {isSavingNewPassword ? (
                          <i className="fa-solid fa-spinner fa-spin"></i>
                        ) : (
                          <i className="fa-solid fa-check"></i>
                        )}
                        <span>حفظ</span>
                      </button>
                    </div>
                  </div>
                )}

                {passwordChangeMessage && (
                  <div
                    className={`text-[11px] font-bold p-2 rounded-xl ${
                      passwordChangeMessage.type === 'success'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-red-50 text-red-800 border border-red-200'
                    }`}
                  >
                    {passwordChangeMessage.text}
                  </div>
                )}
              </div>

              {!isAdmin && currentUser.subscriptionType === 'monthly' && (
                <div
                  className={`p-3 rounded-xl text-xs font-bold border flex items-center justify-between gap-2 ${
                    isSubscriptionExpired('monthly', currentUser.subscriptionExpiresAt)
                      ? 'bg-rose-50 text-rose-800 border-rose-200'
                      : getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) <= 3
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : 'bg-purple-50 text-purple-800 border-purple-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <i className="fa-solid fa-clock-rotate-left"></i>
                    <span>تاريخ انتهاء الصلاحية: {formatDateArabic(currentUser.subscriptionExpiresAt)}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-white/80 border border-current">
                    {isSubscriptionExpired('monthly', currentUser.subscriptionExpiresAt)
                      ? 'منتهي'
                      : `متبقي ${getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt)} يوم`}
                  </span>
                </div>
              )}
            </div>

            {/* Logout Action */}
            <button
              type="button"
              onClick={onLogout}
              className="w-full bg-rose-50 hover:bg-rose-100 text-rose-600 py-3 rounded-2xl font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer border border-rose-200/80"
            >
              <i className="fa-solid fa-arrow-right-from-bracket"></i>
              <span>تسجيل الخروج من الحساب</span>
            </button>
          </div>
        )}
      </div>

      {/* ---------------------------------------------------- */}
      {/* 2 & 3. إعدادات الديون: تنبيهات مدة الدين وسقف الدين المرتفع (تخفى في حال كان المدير مخصصاً للأقساط فقط) */}
      {/* ---------------------------------------------------- */}
      {currentUser.allowedModules !== 'installments' && (
        <>
          {/* 2. قائمة منسدلة: نظام تنبيهات مدة الدين */}
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
            <button
              type="button"
              onClick={() => toggleSection('alerts')}
              className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-right cursor-pointer select-none"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                  <i className="fa-solid fa-bell"></i>
                </div>
                <div className="truncate">
                  <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <span>نظام تنبيهات مدة الدين</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        enableAlerts
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : 'bg-slate-100 text-slate-500 border-slate-200'
                      }`}
                    >
                      {enableAlerts ? 'مفعل' : 'معطل'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    إظهار وسم «متأخر عن دفع» بعد تجاوز المدة المحددة
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {enableAlerts && (
                  <span className="text-[11px] font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-xl border border-rose-100 hidden sm:inline-block">
                    {alertDays} {alertDays === 1 ? 'يوم' : 'أيام'}
                  </span>
                )}
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                    openSections.alerts ? 'bg-rose-50 text-rose-600 rotate-180' : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  <i className="fa-solid fa-chevron-down text-xs"></i>
                </div>
              </div>
            </button>

            {openSections.alerts && (
              <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
                {/* Toggle Row */}
                <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200/60">
                  <div>
                    <div className="font-bold text-xs text-slate-900">تفعيل تنبيهات التأخر في السداد</div>
                    <div className="text-[11px] text-slate-500">إظهار شارة باللون الأحمر للزبائن المتأخرين</div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    <input
                      type="checkbox"
                      id="toggleDebtAlerts"
                      checked={enableAlerts}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setEnableAlerts(checked);
                        handleSaveAppSettings(checked, alertDays, highDebtThreshold);
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
                  </label>
                </div>

                {enableAlerts && (
                  <div className="space-y-3 pt-1">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-bold text-slate-700">
                        مدة اعتبار الزبون متأخراً (بالأيام):
                      </label>
                      <span className="text-xs font-extrabold text-rose-600 font-mono bg-rose-50 px-2.5 py-0.5 rounded-lg border border-rose-100">
                        {alertDays} {alertDays === 1 ? 'يوم واحد' : alertDays === 2 ? 'يومان' : 'أيام'}
                      </span>
                    </div>

                    {/* Day Presets */}
                    <div className="flex flex-wrap gap-1.5">
                      {dayPresets.map((preset) => (
                        <button
                          key={preset.value}
                          type="button"
                          onClick={() => {
                            setAlertDays(preset.value);
                            handleSaveAppSettings(enableAlerts, preset.value, highDebtThreshold);
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            alertDays === preset.value
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>

                    {/* Custom Input */}
                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-xs text-slate-500 font-medium shrink-0">أو حدد أياماً مخصصة:</span>
                      <input
                        type="number"
                        min="1"
                        max="365"
                        value={alertDays}
                        onChange={(e) => {
                          const val = Math.max(1, parseInt(e.target.value) || 1);
                          setAlertDays(val);
                        }}
                        className="w-24 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-center outline-none focus:border-rose-600"
                      />
                      <span className="text-xs text-slate-400">يوماً</span>
                    </div>

                    {/* Impact Info */}
                    <div className="bg-rose-50/70 border border-rose-100 rounded-2xl p-3 flex items-center gap-2 text-xs text-rose-900">
                      <i className="fa-solid fa-triangle-exclamation text-rose-600 text-sm shrink-0"></i>
                      <div>
                        تظهر عبارة <span className="font-bold text-rose-700">(متأخر عن دفع)</span> حالياً على{' '}
                        <span className="font-extrabold font-mono text-rose-800">({alertTriggeredCount})</span> مدين تجاوزت ديونهم هذه المدة.
                      </div>
                    </div>

                    {/* Save Button */}
                    <button
                      type="button"
                      onClick={() => handleSaveAppSettings()}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    >
                      {isSettingsSaved ? (
                        <>
                          <i className="fa-solid fa-check text-emerald-400"></i>
                          <span>تم حفظ التنبيهات بنجاح!</span>
                        </>
                      ) : (
                        <span>تطبيق وحفظ إعدادات التنبيهات</span>
                      )}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* 3. قائمة منسدلة: سقف وقيمة الدين المرتفع */}
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
            <button
              type="button"
              onClick={() => toggleSection('highDebt')}
              className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-right cursor-pointer select-none"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                  <i className="fa-solid fa-arrow-trend-up"></i>
                </div>
                <div className="truncate">
                  <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <span>سقف وقيمة الدين المرتفع</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                      تصنيف ذكي
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    تمييز الزبائن ذوي الديون المرتفعة بشارة خاصة
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] font-mono font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-xl border border-amber-200 hidden sm:inline-block">
                  {formatNumber(highDebtThreshold)} د.ع
                </span>
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                    openSections.highDebt ? 'bg-amber-50 text-amber-600 rotate-180' : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  <i className="fa-solid fa-chevron-down text-xs"></i>
                </div>
              </div>
            </button>

            {openSections.highDebt && (
              <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200">
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="text-xs font-bold text-slate-700">
                      الحد الأدنى لاعتبار الدين مرتفعاً (د.ع):
                    </label>
                    <span className="text-xs font-extrabold text-amber-800 font-mono bg-amber-50 px-2.5 py-0.5 rounded-lg border border-amber-200">
                      {formatNumber(highDebtThreshold)} د.ع
                    </span>
                  </div>

                  {/* Presets */}
                  <div className="flex flex-wrap gap-1.5 mb-2.5">
                    {highDebtPresets.map((preset) => (
                      <button
                        key={preset.value}
                        type="button"
                        onClick={() => {
                          setHighDebtThreshold(preset.value);
                          handleSaveAppSettings(enableAlerts, alertDays, preset.value);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          highDebtThreshold === preset.value
                            ? 'bg-amber-600 text-white shadow-xs'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>

                  {/* Custom Input */}
                  <div className="relative">
                    <input
                      type="number"
                      step="1000"
                      min="0"
                      value={highDebtThreshold}
                      onChange={(e) => {
                        const val = Math.max(0, parseFloat(e.target.value) || 0);
                        setHighDebtThreshold(val);
                      }}
                      className="w-full pl-12 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono outline-none focus:border-amber-600"
                      placeholder="أدخل مبلغ السقف المخصص"
                    />
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold pointer-events-none">
                      د.ع
                    </span>
                  </div>
                </div>

                {/* Impact info */}
                <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-3 flex items-center gap-2 text-xs text-amber-900">
                  <i className="fa-solid fa-circle-info text-amber-600 text-sm shrink-0"></i>
                  <div>
                    يوجد حالياً <span className="font-extrabold font-mono text-amber-800">({highDebtorsCount})</span> مدين من أصل{' '}
                    <span className="font-bold font-mono">({totalDebtorsCount})</span> يصنف دينهم كـ مرتفع (أكبر من أو يساوي {formatNumber(highDebtThreshold)} د.ع).
                  </div>
                </div>

                {/* Save Button */}
                <button
                  type="button"
                  onClick={() => handleSaveAppSettings()}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  {isSettingsSaved ? (
                    <>
                      <i className="fa-solid fa-check text-emerald-400"></i>
                      <span>تم حفظ سقف الدين بنجاح!</span>
                    </>
                  ) : (
                    <span>تطبيق وحفظ سقف الدين المرتفع</span>
                  )}
                </button>
              </div>
            )}
          </div>
        </>
      )}

      {/* ---------------------------------------------------- */}
      {/* 4. قائمة منسدلة: النسخ الاحتياطي واسترجاع البيانات */}
      {/* ---------------------------------------------------- */}
      {(onImportBackup || onImportDebtors) && onShowToast && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('backup')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-right cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-cyan-50 text-cyan-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-arrows-rotate"></i>
              </div>
              <div className="truncate">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>النسخ الاحتياطي واستيراد البيانات</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-50 text-cyan-700 border border-cyan-100">
                    ديون + أقساط
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  تصدير نسخة شاملة لكافة المدينين وعقود الأقساط أو استرجاعها
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-xl border border-slate-200 hidden sm:inline-block">
                {allDebtors.length} مدين • {installments.length} قسط
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.backup ? 'bg-cyan-50 text-cyan-600 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.backup && (
            <div className="p-5 pt-3 border-t border-slate-100 animate-in fade-in duration-200">
              <BackupRestoreSection
                currentUser={currentUser}
                debtors={allDebtors}
                installments={installments}
                settings={settings}
                onImportBackup={onImportBackup}
                onImportDebtors={onImportDebtors}
                onShowToast={onShowToast}
                flat={true}
              />
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 5. قائمة منسدلة: إدارة الفروع والمدراء (خاص بالمدير العام) */}
      {/* ---------------------------------------------------- */}
      {isAdmin && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('managers')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-right cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-users-gear"></i>
              </div>
              <div className="truncate">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>إدارة الفروع والمدراء</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">
                    المدير العام فقط
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  إنشاء فروع جديدة، تحديد نوع الاشتراك (شهري / دائم)، وتجديده
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-xl border border-purple-100 hidden sm:inline-block">
                {managers.length} فرع
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.managers ? 'bg-purple-50 text-purple-600 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.managers && (
            <div className="p-5 pt-3 border-t border-slate-100 animate-in fade-in duration-200">
              <ManagersTab
                managers={managers}
                onCreateManager={onCreateManager}
                onToggleManagerStatus={onToggleManagerStatus}
                onRenewSubscription={onRenewSubscription}
                onChangeSubscriptionType={onChangeSubscriptionType}
                onChangeManagerModules={onChangeManagerModules}
                onDeleteManager={onDeleteManager}
                onUpdateManagerPassword={onUpdateManagerPassword}
                onRefreshManagers={onRefreshManagers}
                isLoading={isManagersLoading}
              />
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 6. قائمة منسدلة: قاعدة البيانات السحابية وفحص الاتصال (خاص بالمدير العام) */}
      {/* ---------------------------------------------------- */}
      {isAdmin && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('database')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-right cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-database"></i>
              </div>
              <div className="truncate">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>قاعدة البيانات السحابية (Turso)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                    المدير العام
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  فحص الاتصال والتحقق من الربط مع خادم aldion.ts
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-xl border border-slate-200 hidden sm:inline-block">
                aldion.ts
              </span>
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.database ? 'bg-slate-100 text-slate-900 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.database && (
            <div className="p-5 pt-3 border-t border-slate-100 space-y-3 animate-in fade-in duration-200">
              <div className="bg-slate-50 border border-slate-200/70 rounded-2xl p-3.5 text-xs text-slate-600 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">ملف الإعدادات:</span>
                  <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
                    aldion.ts
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 leading-relaxed">
                  عند الرغبة في تبديل قاعدة البيانات، افتح ملف <strong className="text-slate-700 font-mono">aldion.ts</strong> في المحرر وضع الرابط والرمز الجديدين مباشرة، ثم اضغط على زر فحص الاتصال بالأسفل للتحقق.
                </div>
              </div>

              {/* Test Connection Button */}
              <button
                type="button"
                onClick={handleTestDatabaseConnection}
                disabled={isTestingConnection}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:cursor-not-allowed"
              >
                {isTestingConnection ? (
                  <>
                    <i className="fa-solid fa-circle-notch fa-spin text-sm"></i>
                    <span>جاري فحص الاتصال بقاعدة البيانات...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-plug text-sm"></i>
                    <span>فحص الاتصال بقاعدة البيانات</span>
                  </>
                )}
              </button>

              {/* Result Alert */}
              {connectionTestResult && (
                <div
                  className={`p-3.5 rounded-2xl text-xs border flex items-start gap-2.5 animate-in fade-in duration-200 ${
                    connectionTestResult.success
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-red-50 border-red-200 text-red-900'
                  }`}
                >
                  <i
                    className={`fa-solid ${
                      connectionTestResult.success ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-red-600'
                    } text-base shrink-0 mt-0.5`}
                  ></i>
                  <div className="space-y-1 flex-1">
                    <div className="font-bold">{connectionTestResult.message}</div>
                    {connectionTestResult.success && (
                      <div className="text-[11px] opacity-80 flex flex-wrap items-center gap-3 font-mono pt-1 border-t border-emerald-200/60">
                        {connectionTestResult.host && <span>الخادم: {connectionTestResult.host}</span>}
                        {connectionTestResult.responseTimeMs !== undefined && (
                          <span>سرعة الاستجابة: {connectionTestResult.responseTimeMs}ms</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 7. قائمة منسدلة: البيانات التجريبية للاختبار (خاص بالمدير العام) */}
      {/* ---------------------------------------------------- */}
      {isAdmin && onAddDemoDebtors && onClearDemoDebtors && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all">
          <button
            type="button"
            onClick={() => toggleSection('demo')}
            className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-right cursor-pointer select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-lg font-bold shrink-0 shadow-xs">
                <i className="fa-solid fa-flask-vial"></i>
              </div>
              <div className="truncate">
                <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <span>البيانات التجريبية للاختبار (100 مدين)</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                    المدير العام
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                  إضافة 100 مدين محلياً بأرقام 077 لاختبار الأداء بدون التأثير على السحابة
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {demoDebtorsCount > 0 ? (
                <span className="text-[11px] font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-xl border border-indigo-200">
                  {demoDebtorsCount} تجريبي
                </span>
              ) : (
                <span className="text-[11px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-xl border border-slate-200 hidden sm:inline-block">
                  غير مفعل
                </span>
              )}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  openSections.demo ? 'bg-indigo-50 text-indigo-600 rotate-180' : 'bg-slate-100 text-slate-400'
                }`}
              >
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </button>

          {openSections.demo && (
            <div className="p-5 pt-3 border-t border-slate-100 space-y-3.5 animate-in fade-in duration-200">
              <div className="bg-indigo-50/60 border border-indigo-100 rounded-2xl p-3.5 text-xs text-indigo-950 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-indigo-800 font-medium">صيغة الهواتف التجريبية:</span>
                  <span className="font-mono font-bold text-indigo-800 bg-white px-2 py-0.5 rounded-md border border-indigo-200">
                    077********
                  </span>
                </div>
                <p className="text-[11px] text-indigo-900/80 leading-relaxed">
                  توليد 100 مدين بأسماء واقعية، وأرقام هواتف تبدأ بـ <strong className="font-mono">077</strong>، ومبالغ ديون وتواريخ متباينة لاختبار سرعة البحث وتنبيهات المتأخرين. هذه السجلات محلية فقط ولا تلمس السحابة.
                </p>
              </div>

              {/* Demo Action Buttons */}
              <div className="pt-1">
                {demoDebtorsCount === 0 ? (
                  <button
                    type="button"
                    onClick={onAddDemoDebtors}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <i className="fa-solid fa-users-viewfinder text-sm"></i>
                    <span>إضافة 100 مدين تجريبي للاختبار (077********)</span>
                  </button>
                ) : (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={onClearDemoDebtors}
                      className="w-full bg-rose-600 hover:bg-rose-700 active:scale-[0.99] text-white py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                    >
                      <i className="fa-solid fa-trash-can text-sm"></i>
                      <span>حذف كافة المدينين التجريبيين ({demoDebtorsCount} مدين)</span>
                    </button>
                    <p className="text-center text-[10.5px] text-slate-400">
                      سيتم حذف السجلات التجريبية الـ {demoDebtorsCount} فقط، وتبقى سجلاتك الحقيقية سليمة ومحفوظة.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
      </div>
    </div>
  );
};
