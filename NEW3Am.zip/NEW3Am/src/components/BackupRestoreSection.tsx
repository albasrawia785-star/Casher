import React, { useState, useRef } from 'react';
import { AppSettings, Debtor, User, InstallmentRecord } from '../types';
import { formatNumber } from '../utils/formatters';
import { getLocalDebtorHistory } from '../services/turso';

interface BackupRestoreSectionProps {
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  settings: AppSettings;
  onImportBackup?: (
    importedDebtors: Debtor[],
    importedInstallments: InstallmentRecord[],
    mode: 'merge' | 'replace'
  ) => Promise<void>;
  onImportDebtors?: (importedDebtors: Debtor[], mode: 'merge' | 'replace') => Promise<void>;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
  flat?: boolean;
}

interface ImportPreview {
  fileName: string;
  exportDate?: string;
  sourceBranch?: string;
  debtorsCount: number;
  totalDebt: number;
  debtorsList: Debtor[];
  installmentsCount: number;
  totalInstallmentsRemaining: number;
  installmentsList: InstallmentRecord[];
}

export const BackupRestoreSection: React.FC<BackupRestoreSectionProps> = ({
  currentUser,
  debtors,
  installments = [],
  settings,
  onImportBackup,
  onImportDebtors,
  onShowToast,
  flat = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [preview, setPreview] = useState<ImportPreview | null>(null);

  // ----------------------------------------------------
  // 1. EXPORT FULL BACKUP (DEBTS + INSTALLMENTS)
  // ----------------------------------------------------
  const handleExportBackup = () => {
    try {
      setIsExporting(true);

      // 1. Attach complete transactions history for each debtor (excluding demo testing records)
      const realDebtors = debtors.filter((d) => !d.isDemo);
      const historyMap = getLocalDebtorHistory(currentUser.id);
      const enrichedDebtors = realDebtors.map((d) => ({
        ...d,
        history: historyMap[d.id] || d.history || [],
      }));

      const totalDebt = realDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

      // 2. Prepare clean installments list
      const realInstallments = installments.map((inst) => ({
        ...inst,
        payments: Array.isArray(inst.payments) ? inst.payments : [],
      }));
      const totalInstallmentsAmount = realInstallments.reduce(
        (sum, i) => sum + (Number(i.totalAmount) || 0),
        0
      );
      const totalInstallmentsRemaining = realInstallments.reduce(
        (sum, i) => sum + (Number(i.remainingAmount) || 0),
        0
      );

      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);

      const backupPayload = {
        appName: 'دفتر الديون والأقساط',
        version: '3.0',
        exportTimestamp: now.toISOString(),
        exportDateFormatted: now.toLocaleDateString('ar-IQ', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        }),
        branchName: currentUser.branch_name || 'الفرع الرئيسي',
        username: currentUser.username,
        userId: currentUser.id,
        // Debts Stats
        totalDebtorsCount: realDebtors.length,
        totalDebtAmount: totalDebt,
        // Installments Stats
        totalInstallmentsCount: realInstallments.length,
        totalInstallmentsAmount,
        totalInstallmentsRemaining,
        settings,
        debtors: enrichedDebtors,
        installments: realInstallments,
      };

      const jsonStr = JSON.stringify(backupPayload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
      const url = URL.createObjectURL(blob);

      const downloadLink = document.createElement('a');
      downloadLink.href = url;
      downloadLink.download = `نسخة_احتياطية_الديون_والأقساط_${dateStr}.json`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);

      onShowToast(
        `تم تصدير النسخة بنجاح (${realDebtors.length} مدين - ${realInstallments.length} قسط)`,
        'success'
      );
    } catch (err: any) {
      console.error('Error exporting backup:', err);
      onShowToast(`فشل تصدير النسخة الاحتياطية: ${err?.message || 'خطأ غير متوقع'}`, 'error');
    } finally {
      setIsExporting(false);
    }
  };

  // ----------------------------------------------------
  // 2. PARSE & PREVIEW IMPORT FILE (DEBTS & INSTALLMENTS)
  // ----------------------------------------------------
  const processSelectedFile = (file: File) => {
    if (!file.name.endsWith('.json') && file.type !== 'application/json') {
      onShowToast('يرجى اختيار ملف نسخة احتياطية بصيغة JSON (.json)', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) {
          throw new Error('الملف فارغ');
        }

        const parsed = JSON.parse(text);

        let rawDebtorsList: any[] = [];
        let rawInstallmentsList: any[] = [];
        let exportDate: string | undefined;
        let sourceBranch: string | undefined;

        if (Array.isArray(parsed)) {
          // Backward compatibility: raw array of debtors
          rawDebtorsList = parsed;
        } else if (parsed && typeof parsed === 'object') {
          if (Array.isArray(parsed.debtors)) {
            rawDebtorsList = parsed.debtors;
          }
          if (Array.isArray(parsed.installments)) {
            rawInstallmentsList = parsed.installments;
          }
          exportDate = parsed.exportDateFormatted || parsed.exportTimestamp;
          sourceBranch = parsed.branchName;
        } else {
          throw new Error('صيغة ملف النسخة الاحتياطية غير مدعومة');
        }

        if (rawDebtorsList.length === 0 && rawInstallmentsList.length === 0) {
          throw new Error('ملف النسخة الاحتياطية لا يحتوي على أي سجلات للديون أو الأقساط');
        }

        // Validate and clean debtor objects
        const cleanedDebtors: Debtor[] = rawDebtorsList.map((item, index) => {
          const name = String(item.name || '').trim();
          if (!name) {
            throw new Error(`سجل المدين رقم (${index + 1}) لا يحتوي على اسم صالح`);
          }
          const amount = Math.max(0, Number(item.amount) || 0);
          const phone = String(item.phone || '').trim();
          const status = String(item.status || (amount === 0 ? 'خالي من الدين' : 'مستمر'));

          return {
            id: Number(item.id) || Date.now() + index,
            name,
            phone,
            amount,
            status,
            userId: currentUser.id,
            createdAt: item.createdAt || new Date().toISOString(),
            lastDebtDate: item.lastDebtDate,
            history: Array.isArray(item.history) ? item.history : [],
          };
        });

        // Validate and clean installment objects
        const cleanedInstallments: InstallmentRecord[] = rawInstallmentsList.map((item, index) => {
          const name = String(item.name || '').trim();
          const phone = String(item.phone || '').trim();
          const itm = String(item.item || 'سلعة غير محددة').trim();
          const totalAmount = Math.max(0, Number(item.totalAmount) || 0);
          const downPayment = Math.max(0, Number(item.downPayment) || 0);
          const remainingAmount = Number.isFinite(Number(item.remainingAmount))
            ? Number(item.remainingAmount)
            : Math.max(0, totalAmount - downPayment);
          const registrationDate = item.registrationDate || new Date().toISOString().slice(0, 10);
          const nextDueDate = item.nextDueDate || registrationDate;
          const status = item.status || (remainingAmount <= 0 ? 'completed' : 'active');

          return {
            id: Number(item.id) || Date.now() + 1000 + index,
            name: name || `صاحب قسط ${index + 1}`,
            phone,
            item: itm,
            totalAmount,
            downPayment,
            remainingAmount,
            monthlyInstallmentAmount: item.monthlyInstallmentAmount ? Number(item.monthlyInstallmentAmount) : undefined,
            registrationDate,
            nextDueDate,
            userId: currentUser.id,
            status,
            notes: item.notes || '',
            payments: Array.isArray(item.payments) ? item.payments : [],
            createdAt: item.createdAt || new Date().toISOString(),
          };
        });

        const totalDebt = cleanedDebtors.reduce((sum, d) => sum + d.amount, 0);
        const totalInstallmentsRemaining = cleanedInstallments.reduce(
          (sum, i) => sum + (i.remainingAmount || 0),
          0
        );

        setPreview({
          fileName: file.name,
          exportDate,
          sourceBranch,
          debtorsCount: cleanedDebtors.length,
          totalDebt,
          debtorsList: cleanedDebtors,
          installmentsCount: cleanedInstallments.length,
          totalInstallmentsRemaining,
          installmentsList: cleanedInstallments,
        });

        onShowToast(
          `تمت قراءة الملف: ${cleanedDebtors.length} مدين و ${cleanedInstallments.length} قسط`,
          'info'
        );
      } catch (parseErr: any) {
        console.error('JSON Parse error:', parseErr);
        onShowToast(
          `خطأ في قراءة ملف النسخة الاحتياطية: ${parseErr.message || 'الملف تالف'}`,
          'error'
        );
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    reader.onerror = () => {
      onShowToast('حدث خطأ أثناء قراءة الملف من الجهاز', 'error');
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    reader.readAsText(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  // ----------------------------------------------------
  // 3. CONFIRM & EXECUTE IMPORT
  // ----------------------------------------------------
  const handleConfirmImport = async () => {
    if (!preview) return;
    try {
      setIsImporting(true);
      if (onImportBackup) {
        await onImportBackup(preview.debtorsList, preview.installmentsList, importMode);
      } else if (onImportDebtors) {
        await onImportDebtors(preview.debtorsList, importMode);
      }
      setPreview(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: any) {
      console.error('Import execution error:', err);
    } finally {
      setIsImporting(false);
    }
  };

  const handleCancelImport = () => {
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const currentTotalDebt = debtors.reduce((sum, d) => sum + (d.amount || 0), 0);
  const currentTotalInstallmentsRemaining = installments.reduce(
    (sum, i) => sum + (Number(i.remainingAmount) || 0),
    0
  );

  return (
    <div className={flat ? "space-y-4" : "bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4"}>
      {/* Section Header (Only shown if not flat) */}
      {!flat && (
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-base font-bold shadow-xs">
              <i className="fa-solid fa-arrows-rotate"></i>
            </div>
            <div>
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <span>النسخ الاحتياطي الشامل للديون والأقساط</span>
                <span className="text-[10px] font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full border border-blue-100">
                  شامل وآمن 100%
                </span>
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                تصدير نسخة متكاملة تشمل كافة سجلات المدينين وعقود الأقساط أو استرجاعها
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Current Data Overview */}
      <div className="grid grid-cols-2 gap-2.5 bg-slate-50 border border-slate-200/60 rounded-2xl p-3 text-xs">
        <div className="space-y-1.5 pl-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">المدينون المسجلون:</span>
            <span className="font-bold font-mono text-slate-900 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {debtors.length} مدين
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">إجمالي الديون:</span>
            <span className="font-bold font-mono text-blue-700 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {formatNumber(currentTotalDebt)} د.ع
            </span>
          </div>
        </div>

        <div className="space-y-1.5 pr-2 border-r border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">عقود الأقساط:</span>
            <span className="font-bold font-mono text-emerald-800 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {installments.length} قسط
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-500 font-medium">متبقي الأقساط:</span>
            <span className="font-bold font-mono text-emerald-700 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
              {formatNumber(currentTotalInstallmentsRemaining)} د.ع
            </span>
          </div>
        </div>
      </div>

      {/* Action Cards: 1. Export, 2. Import */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
        {/* Card 1: Export Backup */}
        <div className="bg-slate-50/70 border border-slate-200/70 rounded-2xl p-4 flex flex-col justify-between hover:border-blue-200 transition-all">
          <div>
            <div className="flex items-center gap-2 font-bold text-xs text-slate-800 mb-1">
              <i className="fa-solid fa-cloud-arrow-down text-blue-600"></i>
              <span>تصدير نسخة احتياطية شاملة</span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              تنزيل ملف <span className="font-mono font-bold text-slate-700">JSON</span> يحتوي على كافة بيانات المدينين وسجلاتهم + كافة عقود الأقساط وجداول سدادها.
            </p>
          </div>

          <button
            type="button"
            onClick={handleExportBackup}
            disabled={isExporting || (debtors.length === 0 && installments.length === 0)}
            className="mt-3.5 w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isExporting ? (
              <>
                <i className="fa-solid fa-spinner fa-spin"></i>
                <span>جاري تصدير النسخة الشاملة...</span>
              </>
            ) : (
              <>
                <i className="fa-solid fa-download text-xs"></i>
                <span>تنزيل النسخة الشاملة (ديون + أقساط)</span>
              </>
            )}
          </button>
        </div>

        {/* Card 2: Import Backup Trigger */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-2xl p-4 flex flex-col justify-between transition-all ${
            isDragging
              ? 'border-blue-500 bg-blue-50/50'
              : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
          }`}
        >
          <div>
            <div className="flex items-center gap-2 font-bold text-xs text-slate-800 mb-1">
              <i className="fa-solid fa-cloud-arrow-up text-emerald-600"></i>
              <span>استيراد واسترجاع نسخة كاملة</span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              اسحب وأفلت ملف النسخة الاحتياطية هنا أو انقر لاختيار الملف من جهازك لاسترجاع الديون والأقساط.
            </p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileInputChange}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="mt-3.5 w-full bg-white hover:bg-slate-100 active:scale-[0.99] text-slate-700 border border-slate-200/80 py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
          >
            <i className="fa-solid fa-folder-open text-xs text-slate-500"></i>
            <span>اختيار ملف النسخة (.json)</span>
          </button>
        </div>
      </div>

      {/* Import Preview & Confirmation Dialog */}
      {preview && (
        <div className="mt-4 p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 animate-in fade-in zoom-in-95 duration-150 space-y-3">
          <div className="flex items-center justify-between border-b border-amber-200/70 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-amber-500 text-white flex items-center justify-center text-xs">
                <i className="fa-solid fa-file-invoice"></i>
              </div>
              <div>
                <div className="font-extrabold text-xs text-slate-900">
                  معاينة محتويات النسخة الاحتياطية
                </div>
                <div className="text-[10.5px] text-slate-500 truncate max-w-[240px]">
                  الملف: <span className="font-mono font-bold text-slate-700">{preview.fileName}</span>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleCancelImport}
              className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer transition-colors"
              title="إلغاء المعاينة"
            >
              <i className="fa-solid fa-xmark text-sm"></i>
            </button>
          </div>

          {/* Backup Meta Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">المدينين</span>
              <span className="font-extrabold font-mono text-sm text-slate-800">
                {preview.debtorsCount} مدين
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">إجمالي الديون</span>
              <span className="font-extrabold font-mono text-sm text-blue-700">
                {formatNumber(preview.totalDebt)} د.ع
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">الأقساط</span>
              <span className="font-extrabold font-mono text-sm text-emerald-800">
                {preview.installmentsCount} قسط
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">متبقي الأقساط</span>
              <span className="font-extrabold font-mono text-sm text-emerald-700">
                {formatNumber(preview.totalInstallmentsRemaining)} د.ع
              </span>
            </div>
          </div>

          {preview.exportDate && (
            <div className="bg-white/80 px-3 py-1.5 rounded-xl border border-amber-200/50 flex items-center justify-between text-[11px] text-slate-600">
              <span>تاريخ إنشاء النسخة: <strong className="text-slate-800">{preview.exportDate}</strong></span>
              {preview.sourceBranch && <span>الفرع: <strong className="text-slate-800">{preview.sourceBranch}</strong></span>}
            </div>
          )}

          {/* Import Mode Selector */}
          <div className="bg-white p-3 rounded-xl border border-amber-200/60 space-y-2">
            <span className="text-[11px] font-bold text-slate-700 block">طريقة استرجاع وتطبيق البيانات:</span>
            <div className="space-y-1.5">
              <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded-lg hover:bg-slate-50 transition-colors">
                <input
                  type="radio"
                  name="importMode"
                  value="merge"
                  checked={importMode === 'merge'}
                  onChange={() => setImportMode('merge')}
                  className="text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-bold text-slate-800">دمج مع البيانات الحالية (موصى به)</span>
                  <span className="text-[10.5px] text-slate-500 block">
                    يحتفظ بالسجلات الحالية ويضيف سجلات الديون وعقود الأقساط الجديدة ويحدث المطابق منها.
                  </span>
                </div>
              </label>

              <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded-lg hover:bg-rose-50/50 transition-colors">
                <input
                  type="radio"
                  name="importMode"
                  value="replace"
                  checked={importMode === 'replace'}
                  onChange={() => setImportMode('replace')}
                  className="text-rose-600 focus:ring-rose-500 w-4 h-4 cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-bold text-rose-700">استبدال شامل لكافة الديون والأقساط</span>
                  <span className="text-[10.5px] text-slate-500 block">
                    سيتم مسح كافة الديون والأقساط الحالية واستبدالها بنسخة هذا الملف تماماً.
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleConfirmImport}
              disabled={isImporting}
              className={`flex-1 text-white py-2.5 px-4 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 ${
                importMode === 'replace'
                  ? 'bg-rose-600 hover:bg-rose-700'
                  : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              {isImporting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin"></i>
                  <span>جاري تطبيق واسترجاع البيانات...</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>
                    تأكيد {importMode === 'replace' ? 'الاستبدال الشامل' : 'الدمج والاسترجاع'}
                  </span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleCancelImport}
              disabled={isImporting}
              className="bg-slate-200/80 hover:bg-slate-300 active:scale-95 text-slate-700 py-2.5 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
