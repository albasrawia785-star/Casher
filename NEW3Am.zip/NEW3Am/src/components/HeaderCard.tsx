import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { formatNumber, formatDateArabic, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';
import { PWAInstallButton } from './PWAInstallButton';

export type HeaderMode = 'debts' | 'installments';

interface HeaderCardProps {
  currentUser: User;
  debtorsCount: number;
  totalAmount: number;
  installmentsCount?: number;
  totalInstallmentsRemaining?: number;
  headerMode?: HeaderMode;
  mode?: HeaderMode;
  onHeaderModeChange?: (mode: HeaderMode) => void;
  onModeChange?: (mode: HeaderMode) => void;
  onLogout: () => void;
  isSaving?: boolean;
  searchTerm?: string;
  onSearchChange?: (val: string) => void;
  onSecretAdminUnlock?: () => void;
}

export const HeaderCard: React.FC<HeaderCardProps> = ({
  currentUser,
  debtorsCount,
  totalAmount,
  installmentsCount = 0,
  totalInstallmentsRemaining = 0,
  headerMode,
  mode,
  onHeaderModeChange,
  onModeChange,
  onLogout,
  isSaving = false,
  searchTerm = '',
  onSearchChange,
  onSecretAdminUnlock,
}) => {
  const currentMode: HeaderMode = headerMode || mode || 'debts';
  const isInstallments = currentMode === 'installments';
  const canSwitchModules =
    currentUser.role === 'admin' ||
    !currentUser.allowedModules ||
    currentUser.allowedModules === 'both';

  const handleSwitchMode = (newMode: HeaderMode) => {
    if (onHeaderModeChange) onHeaderModeChange(newMode);
    if (onModeChange) onModeChange(newMode);
    setIsDropdownOpen(false);
  };

  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [secretClicks, setSecretClicks] = useState(0);
  const secretTimerRef = useRef<any>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleTitleTripleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSecretClicks((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        if (secretTimerRef.current) clearTimeout(secretTimerRef.current);
        if (onSecretAdminUnlock) {
          onSecretAdminUnlock();
        }
        return 0;
      }
      if (secretTimerRef.current) clearTimeout(secretTimerRef.current);
      secretTimerRef.current = setTimeout(() => {
        setSecretClicks(0);
      }, 1200);
      return next;
    });
  };

  // When search is opened, focus the input
  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchOpen]);

  // Keep search bar open if there is an active search query
  useEffect(() => {
    if (searchTerm) {
      setIsSearchOpen(true);
    }
  }, [searchTerm]);

  const handleToggleSearch = () => {
    if (isSearchOpen && searchTerm && onSearchChange) {
      onSearchChange('');
    }
    setIsSearchOpen(!isSearchOpen);
  };

  return (
    <div
      id="mainHeaderCard"
      className={`text-white px-4 pt-3.5 pb-4 rounded-b-3xl shadow-[0_10px_30px_-5px_rgba(2,6,23,0.3)] border-b relative text-right select-none transition-all duration-300 ${
        isInstallments
          ? 'bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-950 border-emerald-800/60'
          : 'bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 border-slate-800/80'
      }`}
    >
      {/* Ambient luxury lighting accents */}
      <div className={`absolute -top-16 -left-12 w-48 h-48 rounded-full blur-3xl pointer-events-none transition-colors duration-500 ${
        isInstallments ? 'bg-emerald-500/20' : 'bg-blue-500/15'
      }`}></div>
      <div className={`absolute top-1/2 -right-16 w-40 h-40 rounded-full blur-2xl pointer-events-none transition-colors duration-500 ${
        isInstallments ? 'bg-teal-500/15' : 'bg-indigo-500/10'
      }`}></div>

      {/* Sub-Manager Subscription Indicator */}
      {currentUser.role !== 'admin' && (
        <div
          id="subManagerSubscriptionBanner"
          className="relative z-10 mb-2.5 px-3 py-1.5 rounded-xl bg-white/[0.08] backdrop-blur-md border border-white/10 flex items-center justify-between gap-2 text-xs select-text"
        >
          {currentUser.subscriptionType === 'trial' || currentUser.role === 'trial' ? (
            <>
              <div className="flex items-center gap-1.5 text-amber-200 min-w-0">
                <i className="fa-solid fa-flask-vial text-amber-400 text-xs shrink-0"></i>
                <span className="text-amber-200/90 text-[11px] font-medium shrink-0">حالة الحساب:</span>
                <span className="font-bold text-amber-300 text-xs flex items-center gap-1">
                  <span>وضع تجريبي</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  const msg = encodeURIComponent("السلام عليكم، أود تفعيل النسخة الكاملة من تطبيق دفتر الديون لفتح عدد غير محدود من المدينين والمزامنة السحابية.");
                  window.open(`https://wa.me/9647810936407?text=${msg}`, '_blank');
                }}
                className="shrink-0 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/25 hover:bg-amber-500/40 text-amber-200 border border-amber-400/40 flex items-center gap-1 cursor-pointer transition-colors"
                title="مراسلة الإدارة لتفعيل النسخة الكاملة"
              >
                <i className="fa-brands fa-whatsapp text-[10px] text-emerald-400"></i>
                <span>ترقية للنسخة الكاملة</span>
              </button>
            </>
          ) : currentUser.subscriptionType === 'monthly' ? (
            <>
              <div className="flex items-center gap-1.5 min-w-0">
                <i className="fa-solid fa-calendar-check text-purple-400 text-xs shrink-0"></i>
                <span className="text-slate-300 text-[11px] font-medium shrink-0">تاريخ انتهاء الاشتراك:</span>
                <span className="font-bold text-white text-xs font-mono truncate" dir="ltr">
                  {formatDateArabic(currentUser.subscriptionExpiresAt) || 'غير محدد'}
                </span>
              </div>
              <div className="shrink-0">
                {isSubscriptionExpired('monthly', currentUser.subscriptionExpiresAt) ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/25 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                    <i className="fa-solid fa-triangle-exclamation text-[9px]"></i>
                    <span>اشتراك منتهي</span>
                  </span>
                ) : (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${
                      getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) <= 3
                        ? 'bg-amber-500/25 text-amber-300 border-amber-500/40 animate-pulse'
                        : 'bg-purple-500/25 text-purple-200 border-purple-400/30'
                    }`}
                  >
                    <i className="fa-solid fa-hourglass-half text-[9px]"></i>
                    <span>
                      متبقي {getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt)}{' '}
                      {getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) === 1
                        ? 'يوم'
                        : getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) === 2
                        ? 'يومان'
                        : getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) <= 10
                        ? 'أيام'
                        : 'يوماً'}
                    </span>
                  </span>
                )}
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center gap-1.5 text-slate-200 min-w-0">
                <i className="fa-solid fa-shield-check text-emerald-400 text-xs shrink-0"></i>
                <span className="text-slate-300 text-[11px] font-medium shrink-0">نوع الحساب:</span>
                <span className="font-bold text-emerald-300 text-xs flex items-center gap-1">
                  <i className="fa-solid fa-infinity text-[10px] text-emerald-400"></i>
                  <span>حساب دائم</span>
                </span>
              </div>
              <span className="shrink-0 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <i className="fa-solid fa-circle-check text-[9px] text-emerald-400"></i>
                <span>اشتراك غير محدود</span>
              </span>
            </>
          )}
        </div>
      )}

      {/* Row 1: Branch Name & Action Controls */}
      <div className="flex justify-between items-center relative z-30 mb-3">
        {/* Branch Name Display (Click 3 times for secret admin) */}
        <div
          id="headerBranchNameDisplay"
          onClick={handleTitleTripleClick}
          className="flex items-center gap-2.5 cursor-pointer select-none py-0.5 group min-w-0"
          title={`${currentUser.branch_name || 'الفرع الرئيسي'} (انقر 3 مرات للوحة السرية)`}
        >
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm shadow-xs shrink-0 transition-colors ${
            isInstallments
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 group-hover:bg-emerald-500/30'
              : 'bg-blue-500/20 text-blue-300 border border-blue-500/30 group-hover:bg-blue-500/30'
          }`}>
            <i className="fa-solid fa-store text-xs"></i>
          </div>
          <div className="text-right truncate">
            <h1 className="font-black text-sm sm:text-base text-white tracking-tight truncate leading-tight">
              {currentUser.branch_name || 'الفرع الرئيسي'}
            </h1>
            <span className="text-[10px] text-slate-400 font-medium block truncate">
              {currentUser.role === 'admin'
                ? 'الإدارة العامة'
                : currentUser.subscriptionType === 'trial' || currentUser.role === 'trial'
                ? 'حساب تجريبي'
                : 'فرع معتمد'}
            </span>
          </div>
        </div>

        {/* Controls: PWA Install, Search Button, Count Badge, Logout */}
        <div className="flex items-center gap-1.5 shrink-0">
          <PWAInstallButton />

          {/* Search Button */}
          {onSearchChange && (
            <button
              id="headerSearchBtn"
              type="button"
              onClick={handleToggleSearch}
              title={isSearchOpen ? 'إغلاق البحث' : 'بحث بالاسم أو الهاتف'}
              className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs transition-all cursor-pointer relative border ${
                isSearchOpen || searchTerm
                  ? isInstallments
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-md shadow-emerald-600/30 font-bold scale-105'
                    : 'bg-blue-600 border-blue-400 text-white shadow-md shadow-blue-600/30 font-bold scale-105'
                  : 'bg-white/8 hover:bg-white/15 border-white/10 text-slate-300 active:scale-95'
              }`}
            >
              <i className="fa-solid fa-magnifying-glass text-[11.5px]"></i>
              {searchTerm && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 ring-2 ring-slate-900 animate-pulse"></span>
              )}
            </button>
          )}

          {/* Dynamic Count Badge (Debtors vs Installments) */}
          <div className="bg-white/8 border border-white/10 px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1 text-slate-200">
            <i className={`fa-solid ${isInstallments ? 'fa-file-invoice-dollar text-emerald-300' : 'fa-users text-blue-300'} text-[10px]`}></i>
            <span id="debtorsCountBadge" className="font-mono">
              {isInstallments ? installmentsCount : debtorsCount}
            </span>
            <span className="text-[10px] font-normal text-slate-400">
              {isInstallments ? 'معاملة' : 'مدين'}
            </span>
          </div>

          {/* Logout Button */}
          <button
            id="logoutBtn"
            type="button"
            onClick={onLogout}
            title="تسجيل الخروج"
            className="w-8 h-8 rounded-xl bg-white/8 hover:bg-rose-500/80 active:scale-95 border border-white/10 flex items-center justify-center text-xs transition-all cursor-pointer text-slate-300 hover:text-white"
          >
            <i className="fa-solid fa-arrow-right-from-bracket text-[11px]"></i>
          </button>
        </div>
      </div>

      {/* Expandable Live Search Input */}
      {isSearchOpen && onSearchChange && (
        <div className="relative z-10 mb-3 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="relative flex items-center">
            <input
              ref={searchInputRef}
              type="text"
              id="headerSearchInput"
              className={`w-full pl-8 pr-9 py-2 bg-slate-900/90 text-white placeholder:text-slate-400 rounded-xl text-xs font-medium outline-none shadow-inner border border-slate-700/80 transition-all ${
                isInstallments
                  ? 'focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30'
                  : 'focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30'
              }`}
              placeholder={isInstallments ? "ابحث بالاسم أو السلعة أو الهاتف..." : "ابحث بالاسم أو رقم الهاتف..."}
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
            />
            <i className="fa-solid fa-magnifying-glass absolute right-3 text-slate-400 text-xs pointer-events-none"></i>
            {searchTerm ? (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title="مسح البحث"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setIsSearchOpen(false)}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title="إغلاق البحث"
              >
                <i className="fa-solid fa-chevron-up text-[10px]"></i>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Row 2: Outstanding Balance / Remaining Installments & Bottom-Left Compact Dropdown */}
      <div className="flex items-center justify-between relative z-10 pt-2 border-t border-white/10">
        <div>
          <div className="text-[11px] text-slate-400 font-medium flex items-center gap-1.5">
            <span className={`w-1.5 h-1.5 rounded-full ${isInstallments ? 'bg-emerald-400' : 'bg-blue-400'}`}></span>
            <span>{isInstallments ? 'المتبقي المطلوب تحصيله (أقساط)' : 'إجمالي الديون القائمة'}</span>
          </div>
          <div
            className="text-base sm:text-[17px] font-bold tracking-tight font-mono text-white leading-tight mt-0.5 flex items-baseline gap-1"
            id="totalAmount"
          >
            <span>{formatNumber(isInstallments ? totalInstallmentsRemaining : totalAmount)}</span>
            <span className={`text-[11px] font-medium font-sans ${isInstallments ? 'text-emerald-300/80' : 'text-blue-300/80'}`}>د.ع</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isSaving && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-[11px]">
              <i className="fa-solid fa-spinner animate-spin text-[10px] text-blue-400"></i>
              <span>جارِ الحفظ...</span>
            </div>
          )}

          {/* COMPACT BOTTOM-LEFT DROPDOWN (ONLY IF ACCESSIBLE TO BOTH DEPARTMENTS) */}
          {canSwitchModules && (
            <div className="relative" ref={dropdownRef}>
              <button
                type="button"
                id="headerModeDropdownBtn"
                onClick={() => setIsDropdownOpen((prev) => !prev)}
                className={`px-2.5 py-1 rounded-xl flex items-center gap-1.5 border shadow-xs transition-all cursor-pointer text-xs font-bold select-none active:scale-95 ${
                  isInstallments
                    ? 'bg-emerald-900/90 hover:bg-emerald-800 border-emerald-400/60 text-emerald-100 ring-1 ring-emerald-400/30'
                    : 'bg-slate-800/95 hover:bg-slate-700 border-blue-400/50 text-blue-100 ring-1 ring-blue-400/25'
                }`}
                title="تبديل القسم المعروض"
              >
                <div className={`w-4 h-4 rounded-md flex items-center justify-center text-[10px] ${
                  isInstallments ? 'bg-emerald-400 text-slate-950 font-black' : 'bg-blue-500 text-white font-black'
                }`}>
                  <i className={`fa-solid ${isInstallments ? 'fa-clock-rotate-left' : 'fa-users'}`}></i>
                </div>
                <span>{isInstallments ? 'الأقساط' : 'الديون'}</span>
                <i className={`fa-solid fa-chevron-down text-[9px] text-slate-300 transition-transform duration-200 ${
                  isDropdownOpen ? 'rotate-180 text-white' : ''
                }`}></i>
              </button>

              {/* Dropdown Options Menu */}
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-1.5 w-48 bg-slate-900/98 backdrop-blur-2xl border border-slate-700/90 rounded-2xl shadow-[0_15px_35px_rgba(0,0,0,0.6)] p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-1 text-right">
                  <div className="px-2 py-1 text-[10px] font-bold text-slate-400 border-b border-slate-800/80">
                    تبديل عرض القسم:
                  </div>

                  {/* Option 1: Debts */}
                  <button
                    type="button"
                    id="selectModeDebtsBtn"
                    onClick={() => handleSwitchMode('debts')}
                    className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                      !isInstallments
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <i className="fa-solid fa-users text-xs text-blue-400"></i>
                      <span>دفتر الديون</span>
                    </div>
                    {!isInstallments && <i className="fa-solid fa-check text-xs"></i>}
                  </button>

                  {/* Option 2: Installments */}
                  <button
                    type="button"
                    id="selectModeInstallmentsBtn"
                    onClick={() => handleSwitchMode('installments')}
                    className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                      isInstallments
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <i className="fa-solid fa-clock-rotate-left text-xs text-emerald-400"></i>
                      <span>نظام الأقساط</span>
                    </div>
                    {isInstallments && <i className="fa-solid fa-check text-xs"></i>}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
