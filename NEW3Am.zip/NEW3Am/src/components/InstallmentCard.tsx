import React from 'react';
import { InstallmentRecord } from '../types';
import { formatNumber } from '../utils/formatters';
import { formatDueDateBadge, buildInstallmentWhatsAppUrl } from '../utils/installmentHelpers';

interface InstallmentCardProps {
  installment: InstallmentRecord;
  onOpenDetails: (inst: InstallmentRecord) => void;
  onOpenSettleModal: (inst: InstallmentRecord) => void;
  onOpenEditModal?: (inst: InstallmentRecord) => void;
  onDelete: (id: number) => void;
}

export const InstallmentCard: React.FC<InstallmentCardProps> = ({
  installment,
  onOpenDetails,
  onOpenSettleModal,
  onOpenEditModal,
  onDelete,
}) => {
  const badgeInfo = formatDueDateBadge(installment.nextDueDate, installment.status);
  const totalPaid = installment.totalAmount - installment.remainingAmount;
  const progressPercent = Math.min(100, Math.round((totalPaid / (installment.totalAmount || 1)) * 100));

  const whatsappUrl = installment.phone && installment.remainingAmount > 0
    ? buildInstallmentWhatsAppUrl(
        installment.phone,
        installment.name,
        installment.item,
        installment.remainingAmount,
        installment.nextDueDate
      )
    : '';

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(installment.id);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all p-4 space-y-3 relative overflow-hidden text-right group">
      {/* Top Banner with Item & Status Badge */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <h3
              onClick={() => onOpenDetails(installment)}
              className="text-sm font-black text-slate-900 hover:text-emerald-700 cursor-pointer break-words leading-snug transition-colors"
            >
              {installment.name}
            </h3>
            {installment.phone && (
              <span dir="ltr" className="text-[11px] font-mono text-slate-400">
                {installment.phone}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 mt-0.5 text-xs text-slate-600 flex-wrap">
            <span className="font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 text-[10.5px]">
              {installment.item}
            </span>
            <span className="text-[10px] text-slate-400">تاريخ التسجيل: {installment.registrationDate}</span>
          </div>
        </div>

        {/* Due date status badge */}
        <span
          className={`px-2.5 py-1 rounded-full text-[10.5px] font-bold border flex items-center gap-1 shrink-0 ${badgeInfo.badgeClass}`}
        >
          <i className={`fa-solid ${badgeInfo.icon} text-[10px]`}></i>
          <span>{badgeInfo.label}</span>
        </span>
      </div>

      {/* Additional Info Badges (National ID, Address, Guarantor) */}
      {(installment.nationalId || installment.address || installment.guarantorName) && (
        <div className="flex items-center gap-1.5 flex-wrap text-[10.5px]">
          {installment.nationalId && (
            <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-mono font-medium flex items-center gap-1">
              <i className="fa-solid fa-id-card text-slate-400 text-[9px]"></i>
              <span dir="ltr">{installment.nationalId}</span>
            </span>
          )}

          {installment.address && (
            <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-medium flex items-center gap-1 max-w-[200px] truncate" title={installment.address}>
              <i className="fa-solid fa-location-dot text-slate-400 text-[9px]"></i>
              <span className="truncate">{installment.address}</span>
            </span>
          )}

          {installment.guarantorName && (
            <span className="px-2 py-0.5 rounded-lg bg-purple-50 text-purple-700 border border-purple-100 font-medium flex items-center gap-1" title={`الكفيل: ${installment.guarantorName}`}>
              <i className="fa-solid fa-user-shield text-purple-500 text-[9px]"></i>
              <span>الكفيل: {installment.guarantorName}</span>
            </span>
          )}
        </div>
      )}

      {/* Financial Numbers Grid */}
      <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-center">
        <div>
          <span className="text-[10px] text-slate-400 block font-medium">مبلغ القسط</span>
          <span className="text-xs font-black text-slate-800 font-mono block">
            {formatNumber(installment.totalAmount)}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 block font-medium">المقدم والمسدد</span>
          <span className="text-xs font-black text-teal-700 font-mono block">
            {formatNumber(totalPaid)}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-400 block font-bold">المتبقي المطلوب</span>
          <span className={`text-xs font-black font-mono block ${
            installment.remainingAmount <= 0 ? 'text-emerald-600' : 'text-rose-600'
          }`}>
            {formatNumber(installment.remainingAmount)}
          </span>
        </div>
      </div>

      {/* Progress Bar & Next Due Date */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[10.5px]">
          <span className="text-slate-500 font-medium">
            تاريخ الاستحقاق: <strong className="font-mono text-slate-700">{installment.nextDueDate}</strong>
          </span>
          <span className="font-mono font-bold text-emerald-700">{progressPercent}% مسدد</span>
        </div>
        <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-teal-500 to-emerald-600 transition-all rounded-full"
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-1 flex items-center gap-1.5">
        {installment.remainingAmount > 0 ? (
          <button
            type="button"
            onClick={() => onOpenSettleModal(installment)}
            className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
          >
            <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
            <span>تسديد قسط</span>
          </button>
        ) : (
          <div className="flex-1 py-1.5 px-3 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-bold flex items-center justify-center gap-1.5 border border-emerald-200">
            <i className="fa-solid fa-circle-check text-xs"></i>
            <span>مكتمل التسديد</span>
          </div>
        )}

        {whatsappUrl && (
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors flex items-center justify-center text-xs cursor-pointer"
            title="إرسال تذكير بالاستحقاق عبر واتساب"
          >
            <i className="fa-brands fa-whatsapp text-sm"></i>
          </a>
        )}

        {onOpenEditModal && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenEditModal(installment);
            }}
            className="p-2 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-600 transition-colors flex items-center justify-center text-xs cursor-pointer"
            title="تعديل تفاصيل القسط"
          >
            <i className="fa-solid fa-pen-to-square text-xs"></i>
          </button>
        )}

        <button
          type="button"
          onClick={() => onOpenDetails(installment)}
          className="py-2 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
          title="عرض تفاصيل المعاملة والسجل"
        >
          <i className="fa-solid fa-eye text-xs"></i>
          <span className="mr-1">التفاصيل</span>
        </button>

        <button
          type="button"
          onClick={handleDelete}
          className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-100 transition-colors flex items-center justify-center text-xs cursor-pointer"
          title="حذف القسط"
        >
          <i className="fa-solid fa-trash-can text-xs"></i>
        </button>
      </div>
    </div>
  );
};
