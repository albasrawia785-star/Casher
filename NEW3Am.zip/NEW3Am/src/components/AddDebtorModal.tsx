import React, { useState } from 'react';
import { formatAmountInput, parseFormattedNumber } from '../utils/formatters';

interface AddDebtorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string, phone: string, amount: number, debtDate?: string, notes?: string) => Promise<void>;
}

export const AddDebtorModal: React.FC<AddDebtorModalProps> = ({
  isOpen,
  onClose,
  onSave
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [amountStr, setAmountStr] = useState('0');
  const [debtDate, setDebtDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmountStr(formatAmountInput(e.target.value));
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (error) setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError("يرجى كتابة اسم المدين أولاً");
      return;
    }

    const trimmedPhone = phone.trim();
    if (trimmedPhone && trimmedPhone.length !== 11) {
      setError("رقم الهاتف يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)");
      return;
    }

    const numericAmount = parseFormattedNumber(amountStr);

    try {
      setIsSubmitting(true);
      await onSave(
        trimmedName,
        trimmedPhone,
        numericAmount,
        debtDate ? new Date(debtDate).toISOString() : undefined,
        notes.trim() || undefined
      );
      setName('');
      setPhone('');
      setAmountStr('0');
      setDebtDate(new Date().toISOString().split('T')[0]);
      setNotes('');
      onClose();
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء الحفظ');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="addModal"
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex justify-center items-end sm:items-center z-50 p-0 sm:p-4 animate-in fade-in duration-150 text-right"
    >
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-md shadow-2xl relative border border-slate-100 max-h-[92dvh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-blue-700 via-indigo-800 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center text-blue-300 border border-white/10">
              <i className="fa-solid fa-user-plus text-base"></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">إضافة مدين جديد</h2>
              <p className="text-[10.5px] text-blue-200/80 mt-0.5 font-medium">
                تسجيل حساب دين جديد في الدفتر
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form id="addDebtorForm" onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 overscroll-contain flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
              <i className="fa-solid fa-circle-exclamation shrink-0"></i>
              <span>{error}</span>
            </div>
          )}

          {/* Debtor Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-user text-blue-600 text-xs"></i>
              <span>اسم المدين</span>
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              id="modalName"
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all font-medium"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              required
              autoFocus
            />
          </div>

          {/* Phone Number */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-phone text-slate-400 text-xs"></i>
              <span>رقم الهاتف (اختياري)</span>
            </label>
            <div className="relative">
              <input
                type="tel"
                id="modalPhone"
                className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all font-mono dir-ltr text-right font-medium"
                maxLength={11}
                value={phone}
                onChange={handlePhoneChange}
              />
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                <i className="fa-solid fa-mobile-screen"></i>
              </div>
            </div>
          </div>

          {/* Initial Debt Amount */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-money-bill-wave text-blue-600 text-xs"></i>
              <span>مبلغ الدين الأولي</span>
            </label>
            <div className="relative">
              <input
                type="text"
                id="modalAmount"
                inputMode="numeric"
                className="w-full pl-12 pr-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all font-black font-mono"
                value={amountStr}
                onChange={handleAmountChange}
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold pointer-events-none">
                د.ع
              </span>
            </div>
          </div>

          {/* Debt Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-calendar-day text-blue-600 text-xs"></i>
              <span>تاريخ تسجيل الدين</span>
            </label>
            <input
              type="date"
              id="modalDate"
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs font-semibold outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all font-mono"
              value={debtDate}
              onChange={(e) => setDebtDate(e.target.value)}
            />
          </div>

          {/* Notes Field (Optional) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-note-sticky text-slate-400 text-xs"></i>
              <span>ملاحظات (اختياري)</span>
            </label>
            <textarea
              id="modalNotes"
              rows={2}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-800 transition-all resize-none font-medium"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={250}
            />
          </div>

          {/* Actions */}
          <div className="pt-3 pb-1 flex items-center gap-2">
            <button
              type="submit"
              id="btnSaveSubmit"
              disabled={isSubmitting}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-extrabold shadow-md shadow-blue-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>جاري الحفظ...</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>حفظ المدين</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
