import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initializeCyberShield } from './utils/securityShield';

// تفعيل درع الحماية السيبرانية الفوري لمنع F12 وتعطيل أدوات الفحص
initializeCyberShield();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
