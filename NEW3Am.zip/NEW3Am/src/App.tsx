import React, { useState, useEffect, useCallback, useMemo } from 'react';
import bcrypt from 'bcryptjs';
import {
  AppSettings,
  Debtor,
  DebtorTransaction,
  DebtStats,
  FilterType,
  InstallmentRecord,
  Manager,
  ManagerModuleAccess,
  SubscriptionType,
  TabType,
  User,
  ViewMode,
} from './types';
import {
  DEFAULT_SETTINGS,
  broadcastManagerStatusChange,
  broadcastDebtorsChange,
  broadcastInstallmentsChange,
  sessionBroadcastChannel,
  debtorsBroadcastChannel,
  installmentsBroadcastChannel,
  getLocalDebtorDates,
  getLocalDebtors,
  getLocalDebtorHistory,
  getLocalInstallments,
  getLocalManagers,
  getLocalSession,
  getLocalSettings,
  queryTurso,
  setLocalDebtorDates,
  setLocalDebtors,
  setLocalDebtorHistory,
  setLocalInstallments,
  setLocalManagers,
  setLocalSession,
  setLocalSettings,
  DEFAULT_USER,
} from './services/turso';
import {
  getIdbDebtors,
  saveIdbDebtors,
  putIdbDebtor,
  deleteIdbDebtor,
  getIdbInstallments,
  saveIdbInstallments,
  putIdbInstallment,
  deleteIdbInstallment,
  getIdbStats,
  saveIdbStats,
  getIdbSettings,
  saveIdbSettings,
  getIdbManagers,
  saveIdbManagers,
} from './services/idb';
import { calculateDaysElapsed } from './utils/formatters';
import { calculateNextMonthDueDate, computeInstallmentStatus } from './utils/installmentHelpers';
import { LoginOverlay } from './components/LoginOverlay';
import { HeaderCard, HeaderMode } from './components/HeaderCard';
import { SecretAdminModal } from './components/SecretAdminModal';
import { Controls } from './components/Controls';
import { DebtorListItem } from './components/DebtorListItem';
import { DebtorHistoryModal } from './components/DebtorHistoryModal';
import { DebtorShareModal } from './components/DebtorShareModal';
import { AddDebtorModal } from './components/AddDebtorModal';
import { AddInstallmentModal } from './components/AddInstallmentModal';
import { EditDebtorNameModal } from './components/EditDebtorNameModal';
import { TransactionModal } from './components/TransactionModal';
import { ConfirmModal } from './components/ConfirmModal';
import { SettleCompleteModal } from './components/SettleCompleteModal';
import { InstallmentsTab } from './components/InstallmentsTab';
import { ManagersTab } from './components/ManagersTab';
import { ReportsTab } from './components/ReportsTab';
import { OverdueTab } from './components/OverdueTab';
import { SettingsTab } from './components/SettingsTab';
import { BottomNav } from './components/BottomNav';
import { ToastContainer, ToastMessage } from './components/Toast';
import { TrialLimitModal } from './components/TrialLimitModal';
import { generate100DemoDebtors, isDemoDebtor } from './utils/mockDebtors';

const getLocalStats = (userId: number): DebtStats | null => {
  try {
    const raw = localStorage.getItem(`debts_stats_${userId}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

const setLocalStats = (userId: number, stats: DebtStats) => {
  try {
    localStorage.setItem(`debts_stats_${userId}`, JSON.stringify(stats));
  } catch (e) {
    console.error(e);
  }
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => getLocalSession());
  const [loginErrorMessage, setLoginErrorMessage] = useState<string | null>(null);
  const [allDebtors, setAllDebtors] = useState<Debtor[]>([]);
  const [installments, setInstallments] = useState<InstallmentRecord[]>([]);
  const [managers, setManagers] = useState<Manager[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [headerMode, setHeaderMode] = useState<HeaderMode>(() => {
    const session = getLocalSession();
    if (session?.allowedModules === 'installments') return 'installments';
    return 'debts';
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    try {
      const saved = localStorage.getItem('aldion_debtors_view_mode');
      return saved === 'list' ? 'list' : 'cards';
    } catch {
      return 'cards';
    }
  });

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    try {
      localStorage.setItem('aldion_debtors_view_mode', mode);
    } catch (e) {
      console.error(e);
    }
  };

  const [isAddDebtorModalOpen, setIsAddDebtorModalOpen] = useState(false);
  const [isAddInstallmentModalOpen, setIsAddInstallmentModalOpen] = useState(false);
  const [isSecretAdminModalOpen, setIsSecretAdminModalOpen] = useState(false);
  const [isTrialLimitModalOpen, setIsTrialLimitModalOpen] = useState(false);
  const isTrialMode = Boolean(
    currentUser &&
      (currentUser.subscriptionType === 'trial' ||
        currentUser.role === 'trial' ||
        currentUser.id === 999999)
  );

  const handleOpenAddModal = () => {
    const isInstallmentsView =
      activeTab === 'installments' || (activeTab === 'home' && headerMode === 'installments');

    if (isInstallmentsView) {
      setIsAddInstallmentModalOpen(true);
    } else {
      if (isTrialMode && allDebtors.length >= 2) {
        setIsTrialLimitModalOpen(true);
        return;
      }
      setIsAddDebtorModalOpen(true);
    }
  };

  const [isSavingCloud, setIsSavingCloud] = useState(false);
  const [isManagersLoading, setIsManagersLoading] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [settings, setSettings] = useState<AppSettings>(() => {
    const session = getLocalSession();
    return session ? getLocalSettings(session.id) : DEFAULT_SETTINGS;
  });
  const [stats, setStats] = useState<DebtStats>(() => {
    const session = getLocalSession();
    if (session) {
      const cached = getLocalStats(session.id);
      if (cached && !(cached.totalAdded === 70000 && cached.totalPaid === 25000)) {
        return cached;
      }
    }
    return { totalAdded: 0, totalPaid: 0 };
  });

  // Transaction Modal State (for Pay and Add Debt)
  const [transactionState, setTransactionState] = useState<{
    isOpen: boolean;
    type: 'pay' | 'add';
    debtor: Debtor | null;
  }>({
    isOpen: false,
    type: 'pay',
    debtor: null,
  });

  // Confirm Modal State
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Debtor History Modal State
  const [historyModalState, setHistoryModalState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Debtor Share Modal State
  const [shareModalState, setShareModalState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Settle Complete Modal State (when debtor balance reaches 0)
  const [settleCompleteState, setSettleCompleteState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Edit Debtor Name Modal State
  const [isEditNameModalOpen, setIsEditNameModalOpen] = useState(false);
  const [editingNameDebtor, setEditingNameDebtor] = useState<Debtor | null>(null);

  const showToast = useCallback(
    (message: string, type: 'success' | 'error' | 'info' = 'info') => {
      const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
      setToasts((prev) => [...prev, { id, message, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 1000);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // ----------------------------------------------------
  // CLOUD SYNC & FINGERPRINTING FOR DEBTORS
  // ----------------------------------------------------

  const fetchAndCacheCloudData = useCallback(
    async (userId: number, isSilent = true) => {
      try {
        setIsSavingCloud(true);
        let res;
        try {
          res = await queryTurso(
            "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE user_id = ? ORDER BY id ASC;",
            [userId]
          );
        } catch {
          await queryTurso("ALTER TABLE debtors ADD COLUMN created_at TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE debtors ADD COLUMN history TEXT;").catch(() => {});
          res = await queryTurso(
            "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE user_id = ? ORDER BY id ASC;",
            [userId]
          );
        }

        let rows: any[] = [];
        if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
          rows = res.results[0].response.result.rows;
        }

        const datesMap = getLocalDebtorDates(userId);
        const historyMap = getLocalDebtorHistory(userId);
        let datesModified = false;
        let historyModified = false;

        const cloudDebtors: Debtor[] = rows.map((r) => {
          const id = parseInt(r[0].value);
          const name = r[1].value;
          const phone = r[2]?.value || '';
          const amount = parseFloat(r[3]?.value || 0);
          const status = r[4]?.value || 'دين مرتفع';
          const uId = parseInt(r[5]?.value);
          const cloudCreatedAt = r[6]?.value;
          const cloudHistoryRaw = r[7]?.value;

          let createdAt = cloudCreatedAt || datesMap[id];
          if (!createdAt) {
            createdAt = new Date().toISOString();
            datesModified = true;
          } else if (cloudCreatedAt && datesMap[id] !== cloudCreatedAt) {
            datesModified = true;
          }
          datesMap[id] = createdAt;

          let debtorHistory: DebtorTransaction[] | undefined = undefined;
          if (cloudHistoryRaw) {
            try {
              const parsed = JSON.parse(cloudHistoryRaw);
              if (Array.isArray(parsed) && parsed.length > 0) {
                debtorHistory = parsed;
                historyMap[id] = parsed;
                historyModified = true;
              }
            } catch {}
          }
          if (!debtorHistory && historyMap[id]) {
            debtorHistory = historyMap[id];
          }

          return {
            id,
            name,
            phone,
            amount,
            status,
            userId: uId,
            createdAt,
            lastDebtDate: createdAt,
            history: debtorHistory,
          };
        });

        if (datesModified) {
          setLocalDebtorDates(userId, datesMap);
        }
        if (historyModified) {
          setLocalDebtorHistory(userId, historyMap);
        }

        setAllDebtors((prev) => {
          const demoDebtors = prev.filter(isDemoDebtor);
          const cleanCloudDebtors = cloudDebtors.filter((d) => !isDemoDebtor(d));
          const combined = [...demoDebtors, ...cleanCloudDebtors];
          setLocalDebtors(userId, combined);
          saveIdbDebtors(userId, cleanCloudDebtors).catch(() => {});
          return combined;
        });

        if (!isSilent) {
          showToast("تمت المزامنة اللحظية مع السحابة بنجاح", "success");
        }
      } catch (err: any) {
        console.warn("تنبيه جلب البيانات السحابية:", err?.message || err);
        if (!isSilent) {
          const cached = getLocalDebtors(userId);
          if (!cached || cached.length === 0) {
            showToast("تعذر الاتصال بالسحابة، يعمل التطبيق في الوضع المحلي", "info");
          }
        }
      } finally {
        setIsSavingCloud(false);
      }
    },
    [showToast]
  );

  const syncCloudDataIfChanged = useCallback(
    async (userId: number, force = false, isSilent = true) => {
      try {
        const cached = getLocalDebtors(userId) || [];
        const realLocal = cached.filter((d) => !isDemoDebtor(d));

        if (realLocal.length === 0 || force) {
          await fetchAndCacheCloudData(userId, isSilent);
          return;
        }

        let fpRes;
        try {
          fpRes = await queryTurso(
            "SELECT COUNT(*), COALESCE(MAX(id), 0), COALESCE(SUM(amount), 0) FROM debtors WHERE user_id = ?;",
            [userId]
          );
        } catch {
          await fetchAndCacheCloudData(userId, isSilent);
          return;
        }

        if (fpRes.results && fpRes.results[0] && fpRes.results[0].response?.result?.rows) {
          const row = fpRes.results[0].response.result.rows[0];
          const cloudCount = parseInt(row[0]?.value || 0);
          const cloudMaxId = parseInt(row[1]?.value || 0);
          const cloudSum = parseFloat(row[2]?.value || 0);

          const localCount = realLocal.length;
          const localMaxId = realLocal.reduce((max, d) => (d.id > max ? d.id : max), 0);
          const localSum = realLocal.reduce((sum, d) => sum + (d.amount || 0), 0);

          if (cloudCount === localCount && cloudMaxId === localMaxId && Math.abs(cloudSum - localSum) < 0.01) {
            if (!isSilent) {
              showToast("البيانات متطابقة ومحدثة مع السحابة بدون استهلاك بيانات", "success");
            }
            return;
          }
        }

        await fetchAndCacheCloudData(userId, isSilent);
      } catch (err: any) {
        console.warn("فحص البصمة السحابية:", err?.message || err);
      }
    },
    [fetchAndCacheCloudData, showToast]
  );

  // ----------------------------------------------------
  // CLOUD SYNC FOR INSTALLMENTS (نظام الأقساط المنفصل)
  // ----------------------------------------------------

  const fetchAndCacheInstallments = useCallback(
    async (userId: number, isSilent = true) => {
      try {
        let res;
        try {
          res = await queryTurso(
            "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone FROM installments WHERE user_id = ? ORDER BY id DESC;",
            [userId]
          );
        } catch {
          // In case new columns need to be added
          await queryTurso("ALTER TABLE installments ADD COLUMN national_id TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_name TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_job TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;").catch(() => {});
          
          res = await queryTurso(
            "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone FROM installments WHERE user_id = ? ORDER BY id DESC;",
            [userId]
          );
        }

        let rows: any[] = [];
        if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
          rows = res.results[0].response.result.rows;
        }

        const cloudInsts: InstallmentRecord[] = rows.map((r) => {
          const id = parseInt(r[0].value);
          const name = r[1].value;
          const phone = r[2]?.value || '';
          const item = r[3]?.value || '';
          const totalAmount = parseFloat(r[4]?.value || 0);
          const downPayment = parseFloat(r[5]?.value || 0);
          const remainingAmount = parseFloat(r[6]?.value || 0);
          const registrationDate = r[7]?.value || new Date().toISOString().split('T')[0];
          const nextDueDate = r[8]?.value || calculateNextMonthDueDate(registrationDate);
          const uId = parseInt(r[9]?.value);
          const notes = r[11]?.value || undefined;
          const paymentsRaw = r[12]?.value;
          const createdAt = r[13]?.value || undefined;
          const nationalId = r[14]?.value || undefined;
          const address = r[15]?.value || undefined;
          const guarantorEnabledVal = r[16]?.value;
          const guarantorEnabled = guarantorEnabledVal === 1 || guarantorEnabledVal === '1' || guarantorEnabledVal === true;
          const guarantorName = r[17]?.value || undefined;
          const guarantorAddress = r[18]?.value || undefined;
          const guarantorJob = r[19]?.value || undefined;
          const guarantorRelation = r[20]?.value || undefined;
          const guarantorPhone = r[21]?.value || undefined;

          let payments = [];
          if (paymentsRaw) {
            try {
              payments = JSON.parse(paymentsRaw);
            } catch {}
          }

          const dynamicStatus = computeInstallmentStatus({
            remainingAmount,
            nextDueDate,
            registrationDate,
          });

          return {
            id,
            name,
            phone,
            item,
            totalAmount,
            downPayment,
            remainingAmount,
            registrationDate,
            nextDueDate,
            userId: uId,
            status: dynamicStatus,
            nationalId,
            address,
            guarantorEnabled: guarantorEnabled || undefined,
            guarantorName,
            guarantorAddress,
            guarantorJob,
            guarantorRelation,
            guarantorPhone,
            notes,
            payments,
            createdAt,
          };
        });

        setInstallments(cloudInsts);
        setLocalInstallments(userId, cloudInsts);
        saveIdbInstallments(userId, cloudInsts).catch(() => {});
      } catch (err: any) {
        console.warn("تنبيه جلب بيانات الأقساط من السحابة:", err?.message || err);
      }
    },
    []
  );

  // Load managers from cloud (for admin)
  const loadManagersFromCloud = useCallback(async (isSilent = true) => {
    try {
      setIsManagersLoading(true);
      let res;
      try {
        res = await queryTurso(
          "SELECT id, username, branch_name, is_active, subscription_type, subscription_expires_at, plain_password, allowed_modules FROM users WHERE role = 'manager';"
        );
      } catch {
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
        res = await queryTurso(
          "SELECT id, username, branch_name, is_active, subscription_type, subscription_expires_at, plain_password, allowed_modules FROM users WHERE role = 'manager';"
        );
      }

      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      const cloudManagers: Manager[] = rows.map((r) => {
        const id = parseInt(r[0].value);
        const username = r[1].value;
        const isActiveVal = r[3]?.value;
        const isActive = isActiveVal === 0 || isActiveVal === '0' ? false : true;
        const subscriptionType = (r[4]?.value as SubscriptionType) || 'permanent';
        const subscriptionExpiresAt = r[5]?.value || null;
        const plainPassword = r[6]?.value || '';
        const allowedModules = (r[7]?.value as ManagerModuleAccess) || 'both';

        if (plainPassword) {
          localStorage.setItem(`user_pwd_${id}`, plainPassword);
          localStorage.setItem(`user_pwd_${username}`, plainPassword);
        }

        const effectivePassword =
          plainPassword ||
          localStorage.getItem(`user_pwd_${id}`) ||
          localStorage.getItem(`user_pwd_${username}`) ||
          undefined;

        return {
          id,
          username,
          branch: r[2]?.value || 'فرع بدون اسم',
          isActive,
          subscriptionType,
          subscriptionExpiresAt,
          plainPassword: effectivePassword,
          allowedModules,
        };
      });

      setLocalManagers(cloudManagers);
      setManagers(cloudManagers);
      await saveIdbManagers(cloudManagers);
    } catch (err: any) {
      if (!isSilent) {
        console.warn("تنبيه جلب قائمة المدراء:", err?.message || err);
      }
    } finally {
      setIsManagersLoading(false);
    }
  }, []);

  // Initialize session data from IndexedDB & LocalStorage
  useEffect(() => {
    if (!currentUser) {
      setStats({ totalAdded: 0, totalPaid: 0 });
      return;
    }

    let isMounted = true;

    async function loadData() {
      if (!currentUser) return;

      // 1. Settings (IDB first)
      const idbSettings = await getIdbSettings(currentUser.id);
      if (idbSettings && isMounted) {
        setSettings(idbSettings);
      } else {
        const localSettings = getLocalSettings(currentUser.id);
        if (isMounted) setSettings(localSettings);
        saveIdbSettings(currentUser.id, localSettings);
      }

      // 2. Stats (IDB first)
      const idbStats = await getIdbStats(currentUser.id);
      if (idbStats && !(idbStats.totalAdded === 70000 && idbStats.totalPaid === 25000) && isMounted) {
        setStats(idbStats);
      } else {
        const cachedStats = getLocalStats(currentUser.id);
        if (cachedStats && !(cachedStats.totalAdded === 70000 && cachedStats.totalPaid === 25000)) {
          if (isMounted) setStats(cachedStats);
          saveIdbStats(currentUser.id, cachedStats);
        } else {
          const initialStats = { totalAdded: 0, totalPaid: 0 };
          if (isMounted) setStats(initialStats);
          setLocalStats(currentUser.id, initialStats);
          saveIdbStats(currentUser.id, initialStats);
        }
      }

      // 3. Debtors: Render local data first
      const idbDebtors = await getIdbDebtors(currentUser.id);
      if (idbDebtors && idbDebtors.length > 0) {
        const hasDemo = idbDebtors.some(isDemoDebtor);
        let enriched = idbDebtors.map((d) => (isDemoDebtor(d) ? { ...d, isDemo: true } : d));
        if (hasDemo && currentUser.role === 'admin') {
          const realOnly = enriched.filter((d) => !isDemoDebtor(d));
          const newDemo = generate100DemoDebtors(currentUser.id, idbSettings?.highDebtThreshold || 25000);
          enriched = [...newDemo, ...realOnly];
        }
        if (isMounted) setAllDebtors(enriched);
      } else {
        const cachedDebtors = getLocalDebtors(currentUser.id);
        if (cachedDebtors !== null && cachedDebtors.length > 0) {
          const datesMap = getLocalDebtorDates(currentUser.id);
          let datesModified = false;
          let debtorsWithDates = cachedDebtors.map((d, idx) => {
            const isDemo = isDemoDebtor(d);
            if (!d.createdAt) {
              if (datesMap[d.id]) {
                d.createdAt = datesMap[d.id];
              } else {
                const pastDays = (idx % 3) + 1;
                d.createdAt = new Date(Date.now() - pastDays * 24 * 60 * 60 * 1000).toISOString();
                datesMap[d.id] = d.createdAt;
                datesModified = true;
              }
            }
            return isDemo ? { ...d, isDemo: true } : d;
          });

          if (debtorsWithDates.some(isDemoDebtor) && currentUser.role === 'admin') {
            const realOnly = debtorsWithDates.filter((d) => !isDemoDebtor(d));
            const newDemo = generate100DemoDebtors(currentUser.id, idbSettings?.highDebtThreshold || 25000);
            debtorsWithDates = [...newDemo, ...realOnly];
          }

          if (datesModified) {
            setLocalDebtorDates(currentUser.id, datesMap);
          }

          if (isMounted) setAllDebtors(debtorsWithDates);
        }
      }

      // 4. Installments (نظام الأقساط المنفصل) - IDB and LocalStorage first
      const idbInsts = await getIdbInstallments(currentUser.id);
      if (idbInsts && idbInsts.length > 0) {
        // Recompute dynamic status with today's date
        const refreshed = idbInsts.map((inst) => ({
          ...inst,
          status: computeInstallmentStatus(inst),
        }));
        if (isMounted) setInstallments(refreshed);
      } else {
        const cachedInsts = getLocalInstallments(currentUser.id);
        if (cachedInsts && cachedInsts.length > 0 && isMounted) {
          const refreshed = cachedInsts.map((inst) => ({
            ...inst,
            status: computeInstallmentStatus(inst),
          }));
          setInstallments(refreshed);
        }
      }

      // 5. Managers if admin
      if (currentUser.role === 'admin') {
        const idbManagers = await getIdbManagers();
        if (idbManagers && idbManagers.length > 0) {
          if (isMounted) setManagers(idbManagers);
        } else {
          const cachedManagers = getLocalManagers();
          if (cachedManagers !== null && isMounted) {
            setManagers(cachedManagers);
            saveIdbManagers(cachedManagers);
          }
        }
      }

      // 6. Cloud Sync
      if (isMounted && !isTrialMode) {
        await syncCloudDataIfChanged(currentUser.id, false, true);
        await fetchAndCacheInstallments(currentUser.id, true);
        if (currentUser.role === 'admin') {
          await loadManagersFromCloud(true);
        }
      }
    }

    loadData();

    return () => {
      isMounted = false;
    };
  }, [currentUser, syncCloudDataIfChanged, fetchAndCacheInstallments, loadManagersFromCloud]);

  // Event-Driven Sync
  useEffect(() => {
    if (!currentUser || isTrialMode) return;

    const handleBroadcastDebtors = (event: MessageEvent) => {
      if (event.data?.type === 'DEBTORS_UPDATED' && event.data?.userId === currentUser.id) {
        fetchAndCacheCloudData(currentUser.id, true);
      }
    };

    const handleBroadcastInstallments = (event: MessageEvent) => {
      if (event.data?.type === 'INSTALLMENTS_UPDATED' && event.data?.userId === currentUser.id) {
        fetchAndCacheInstallments(currentUser.id, true);
      }
    };

    const handleOnline = () => {
      syncCloudDataIfChanged(currentUser.id, false, false);
      fetchAndCacheInstallments(currentUser.id, false);
      if (currentUser.role === 'admin') {
        loadManagersFromCloud(false);
      }
    };

    window.addEventListener('online', handleOnline);

    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.addEventListener('message', handleBroadcastDebtors);
    }
    if (installmentsBroadcastChannel) {
      installmentsBroadcastChannel.addEventListener('message', handleBroadcastInstallments);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      if (debtorsBroadcastChannel) {
        debtorsBroadcastChannel.removeEventListener('message', handleBroadcastDebtors);
      }
      if (installmentsBroadcastChannel) {
        installmentsBroadcastChannel.removeEventListener('message', handleBroadcastInstallments);
      }
    };
  }, [currentUser, fetchAndCacheCloudData, fetchAndCacheInstallments, syncCloudDataIfChanged, loadManagersFromCloud]);

  const handleForceLogout = useCallback(
    (reason: string) => {
      setCurrentUser(null);
      setLocalSession(null);
      setActiveTab('home');
      setAllDebtors([]);
      setInstallments([]);
      setStats({ totalAdded: 0, totalPaid: 0 });
      setLoginErrorMessage(reason);
      showToast(reason, "error");
    },
    [showToast]
  );

  useEffect(() => {
    if (currentUser) {
      if (currentUser.allowedModules === 'installments') {
        setHeaderMode('installments');
      } else if (currentUser.allowedModules === 'debts') {
        setHeaderMode('debts');
      }
    }
  }, [currentUser]);

  const handleLoginSuccess = async (user: User) => {
    setLoginErrorMessage(null);
    setCurrentUser(user);
    if (user.allowedModules === 'installments') {
      setHeaderMode('installments');
    } else if (user.allowedModules === 'debts') {
      setHeaderMode('debts');
    }
    setSettings(getLocalSettings(user.id));
    const cachedStats = getLocalStats(user.id);
    if (cachedStats && !(cachedStats.totalAdded === 70000 && cachedStats.totalPaid === 25000)) {
      setStats(cachedStats);
    } else {
      const freshStats = { totalAdded: 0, totalPaid: 0 };
      setStats(freshStats);
      setLocalStats(user.id, freshStats);
      saveIdbStats(user.id, freshStats);
    }
    setActiveTab('home');
    showToast(`مرحباً بك! فرع: ${user.branch_name}`, "success");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setLocalSession(null);
    setActiveTab('home');
    setAllDebtors([]);
    setInstallments([]);
    setStats({ totalAdded: 0, totalPaid: 0 });
    setLoginErrorMessage(null);
    showToast("تم تسجيل الخروج بنجاح", "info");
  };

  const handleSecretAdminUnlock = useCallback(() => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([40, 60, 40]);
      } catch {}
    }
    showToast("🔓 تم فتح لوحة التحكم والإدارة السرية", "success");
    setIsSecretAdminModalOpen(true);
  }, []);

  const checkManagerActiveStatus = useCallback(
    async (user: User): Promise<boolean> => {
      if (
        !user ||
        user.role === 'admin' ||
        user.role === 'trial' ||
        user.subscriptionType === 'trial' ||
        user.id === 999999
      )
        return true;

      const localFlag = localStorage.getItem(`force_logout_user_${user.id}`);
      if (localFlag) {
        let reason = 'تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.';
        try {
          const parsed = JSON.parse(localFlag);
          if (parsed.reason) reason = parsed.reason;
        } catch {}
        handleForceLogout(reason);
        return false;
      }

      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        try {
          const managersList: Manager[] = JSON.parse(managersData);
          const found = managersList.find((m) => m.id === user.id);
          if (found && found.isActive === false) {
            handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
            return false;
          }
        } catch {}
      }

      try {
        const res = await queryTurso(
          "SELECT is_active, subscription_type, subscription_expires_at FROM users WHERE id = ?;",
          [user.id]
        );
        if (res.results && res.results[0] && res.results[0].response?.result?.rows?.length > 0) {
          const row = res.results[0].response.result.rows[0];
          const isActiveVal = row[0]?.value;
          const isActive = isActiveVal === 0 || isActiveVal === '0' ? false : true;

          if (!isActive) {
            handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
            return false;
          }
        }
      } catch {}

      return true;
    },
    [handleForceLogout]
  );

  // Sub-Manager Session Security Watcher
  useEffect(() => {
    if (
      !currentUser ||
      currentUser.role === 'admin' ||
      currentUser.role === 'trial' ||
      currentUser.subscriptionType === 'trial' ||
      currentUser.id === 999999
    ) {
      return;
    }

    let isCancelled = false;

    const handleBroadcastMessage = (event: MessageEvent) => {
      const data = event.data;
      if (data && data.type === 'FORCE_LOGOUT' && data.targetUserId === currentUser.id) {
        handleForceLogout(data.reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً.');
      }
    };

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.addEventListener('message', handleBroadcastMessage);
    }

    const handleStorageEvent = (e: StorageEvent) => {
      if (e.key === `force_logout_user_${currentUser.id}` && e.newValue) {
        let reason = 'تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.';
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed.reason) reason = parsed.reason;
        } catch {}
        handleForceLogout(reason);
      } else if (e.key === 'local_managers_list' && e.newValue) {
        try {
          const list: Manager[] = JSON.parse(e.newValue);
          const found = list.find((m) => m.id === currentUser.id);
          if (found && found.isActive === false) {
            handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
          }
        } catch {}
      } else if (e.key === 'session_user' && !e.newValue) {
        handleForceLogout('تم تسجيل الخروج من هذا الحساب.');
      }
    };
    window.addEventListener('storage', handleStorageEvent);

    const intervalId = setInterval(() => {
      if (!isCancelled && document.visibilityState === 'visible') {
        checkManagerActiveStatus(currentUser);
      }
    }, 3500);

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && !isCancelled) {
        checkManagerActiveStatus(currentUser);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleVisibilityChange);

    return () => {
      isCancelled = true;
      if (sessionBroadcastChannel) {
        sessionBroadcastChannel.removeEventListener('message', handleBroadcastMessage);
      }
      window.removeEventListener('storage', handleStorageEvent);
      clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleVisibilityChange);
    };
  }, [currentUser, checkManagerActiveStatus, handleForceLogout]);

  // ----------------------------------------------------
  // INSTALLMENTS CRUD ACTIONS (إدارة الأقساط)
  // ----------------------------------------------------

  const handleAddInstallment = async (instData: Omit<InstallmentRecord, 'id'>) => {
    if (!currentUser) return;
    const tempId = Date.now();
    const newInst: InstallmentRecord = {
      ...instData,
      id: tempId,
      userId: currentUser.id,
    };

    // 1. Instant Optimistic Update
    const updated = [newInst, ...installments];
    setInstallments(updated);
    setLocalInstallments(currentUser.id, updated);
    await putIdbInstallment(newInst);

    showToast(`تم تسجيل معاملة القسط لـ (${newInst.name}) بنجاح`, "success");

    // 2. Cloud DB Sync
    if (!isTrialMode) {
      try {
        setIsSavingCloud(true);
        const paymentsJson = JSON.stringify(newInst.payments || []);
        let res;
        try {
          res = await queryTurso(
            "INSERT INTO installments (name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id;",
            [
              newInst.name,
              newInst.phone || '',
              newInst.item,
              newInst.totalAmount,
              newInst.downPayment,
              newInst.remainingAmount,
              newInst.registrationDate,
              newInst.nextDueDate,
              currentUser.id,
              newInst.status,
              newInst.notes || '',
              paymentsJson,
              newInst.createdAt || new Date().toISOString(),
              newInst.nationalId || null,
              newInst.address || null,
              newInst.guarantorEnabled ? 1 : 0,
              newInst.guarantorName || null,
              newInst.guarantorAddress || null,
              newInst.guarantorJob || null,
              newInst.guarantorRelation || null,
              newInst.guarantorPhone || null,
            ]
          );
        } catch {
          await queryTurso("ALTER TABLE installments ADD COLUMN national_id TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_name TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_job TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;").catch(() => {});

          res = await queryTurso(
            "INSERT INTO installments (name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id;",
            [
              newInst.name,
              newInst.phone || '',
              newInst.item,
              newInst.totalAmount,
              newInst.downPayment,
              newInst.remainingAmount,
              newInst.registrationDate,
              newInst.nextDueDate,
              currentUser.id,
              newInst.status,
              newInst.notes || '',
              paymentsJson,
              newInst.createdAt || new Date().toISOString(),
              newInst.nationalId || null,
              newInst.address || null,
              newInst.guarantorEnabled ? 1 : 0,
              newInst.guarantorName || null,
              newInst.guarantorAddress || null,
              newInst.guarantorJob || null,
              newInst.guarantorRelation || null,
              newInst.guarantorPhone || null,
            ]
          );
        }

        if (res.results && res.results[0] && res.results[0].response?.result?.rows?.length > 0) {
          const realId = parseInt(res.results[0].response.result.rows[0][0].value);
          if (!isNaN(realId)) {
            const withRealId = updated.map((i) => (i.id === tempId ? { ...i, id: realId } : i));
            setInstallments(withRealId);
            setLocalInstallments(currentUser.id, withRealId);
            await deleteIdbInstallment(tempId);
            await putIdbInstallment({ ...newInst, id: realId });
          }
        }
        broadcastInstallmentsChange(currentUser.id, 'add');
      } catch (err: any) {
        console.warn("تنبيه حفظ القسط سحابياً:", err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleUpdateInstallment = async (updatedInst: InstallmentRecord) => {
    if (!currentUser) return;
    const target = installments.find((i) => i.id === updatedInst.id);
    if (!target) return;

    // Recalculate status based on new values
    const newStatus = computeInstallmentStatus({
      remainingAmount: updatedInst.remainingAmount,
      nextDueDate: updatedInst.nextDueDate,
      registrationDate: updatedInst.registrationDate,
    });

    const finalInst: InstallmentRecord = {
      ...updatedInst,
      status: newStatus,
    };

    const updated = installments.map((i) => (i.id === updatedInst.id ? finalInst : i));
    setInstallments(updated);
    setLocalInstallments(currentUser.id, updated);
    await putIdbInstallment(finalInst);

    showToast(`تم تعديل وحفظ بيانات قسط (${finalInst.name}) بنجاح`, "success");

    // Cloud Turso sync
    if (!isTrialMode && updatedInst.id > 0) {
      try {
        setIsSavingCloud(true);
        const paymentsJson = JSON.stringify(finalInst.payments || []);
        try {
          await queryTurso(
            `UPDATE installments SET 
              name = ?, 
              phone = ?, 
              item = ?, 
              total_amount = ?, 
              down_payment = ?, 
              remaining_amount = ?, 
              registration_date = ?, 
              next_due_date = ?, 
              status = ?, 
              notes = ?, 
              payments = ?, 
              national_id = ?, 
              address = ?, 
              guarantor_enabled = ?, 
              guarantor_name = ?, 
              guarantor_address = ?, 
              guarantor_job = ?, 
              guarantor_relation = ?, 
              guarantor_phone = ? 
            WHERE id = ? AND user_id = ?;`,
            [
              finalInst.name,
              finalInst.phone || '',
              finalInst.item,
              finalInst.totalAmount,
              finalInst.downPayment,
              finalInst.remainingAmount,
              finalInst.registrationDate,
              finalInst.nextDueDate,
              finalInst.status,
              finalInst.notes || '',
              paymentsJson,
              finalInst.nationalId || null,
              finalInst.address || null,
              finalInst.guarantorEnabled ? 1 : 0,
              finalInst.guarantorName || null,
              finalInst.guarantorAddress || null,
              finalInst.guarantorJob || null,
              finalInst.guarantorRelation || null,
              finalInst.guarantorPhone || null,
              finalInst.id,
              currentUser.id,
            ]
          );
        } catch {
          await queryTurso("ALTER TABLE installments ADD COLUMN national_id TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_name TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_job TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;").catch(() => {});

          await queryTurso(
            `UPDATE installments SET 
              name = ?, 
              phone = ?, 
              item = ?, 
              total_amount = ?, 
              down_payment = ?, 
              remaining_amount = ?, 
              registration_date = ?, 
              next_due_date = ?, 
              status = ?, 
              notes = ?, 
              payments = ?, 
              national_id = ?, 
              address = ?, 
              guarantor_enabled = ?, 
              guarantor_name = ?, 
              guarantor_address = ?, 
              guarantor_job = ?, 
              guarantor_relation = ?, 
              guarantor_phone = ? 
            WHERE id = ? AND user_id = ?;`,
            [
              finalInst.name,
              finalInst.phone || '',
              finalInst.item,
              finalInst.totalAmount,
              finalInst.downPayment,
              finalInst.remainingAmount,
              finalInst.registrationDate,
              finalInst.nextDueDate,
              finalInst.status,
              finalInst.notes || '',
              paymentsJson,
              finalInst.nationalId || null,
              finalInst.address || null,
              finalInst.guarantorEnabled ? 1 : 0,
              finalInst.guarantorName || null,
              finalInst.guarantorAddress || null,
              finalInst.guarantorJob || null,
              finalInst.guarantorRelation || null,
              finalInst.guarantorPhone || null,
              finalInst.id,
              currentUser.id,
            ]
          );
        }
        broadcastInstallmentsChange(currentUser.id, 'edit');
      } catch (err: any) {
        console.warn("تنبيه تعديل القسط سحابياً:", err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleSettleInstallmentPayment = async (
    installmentId: number,
    paidAmount: number,
    paymentDate: string,
    notes?: string
  ) => {
    if (!currentUser) return;
    const target = installments.find((i) => i.id === installmentId);
    if (!target) return;

    const newRemaining = Math.max(0, target.remainingAmount - paidAmount);
    // When payment is recorded, next due date moves forward 1 month from payment date (or previous due date)
    const nextDueDate = newRemaining <= 0
      ? target.nextDueDate
      : calculateNextMonthDueDate(target.nextDueDate || paymentDate, 1);

    const newStatus = computeInstallmentStatus({
      remainingAmount: newRemaining,
      nextDueDate,
      registrationDate: target.registrationDate,
    });

    const newPayment = {
      id: `pay-${Date.now()}`,
      installmentId,
      amount: paidAmount,
      date: paymentDate,
      remainingAfter: newRemaining,
      notes: notes || 'تسديد قسط',
    };

    const updatedPayments = [newPayment, ...(target.payments || [])];
    const updatedInst: InstallmentRecord = {
      ...target,
      remainingAmount: newRemaining,
      nextDueDate,
      status: newStatus,
      payments: updatedPayments,
    };

    // Optimistic local update
    const updated = installments.map((i) => (i.id === installmentId ? updatedInst : i));
    setInstallments(updated);
    setLocalInstallments(currentUser.id, updated);
    await putIdbInstallment(updatedInst);

    showToast(
      `تم استلام وتسجيل ${paidAmount.toLocaleString('en-US')} د.ع من قسط (${target.name})`,
      "success"
    );

    // Cloud Sync
    if (!isTrialMode && installmentId > 0) {
      try {
        setIsSavingCloud(true);
        await queryTurso(
          "UPDATE installments SET remaining_amount = ?, next_due_date = ?, status = ?, payments = ? WHERE id = ? AND user_id = ?;",
          [
            newRemaining,
            nextDueDate,
            newStatus,
            JSON.stringify(updatedPayments),
            installmentId,
            currentUser.id,
          ]
        );
        broadcastInstallmentsChange(currentUser.id, 'settle');
      } catch (err: any) {
        console.warn("تنبيه مزامنة دفعة القسط:", err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleDeleteInstallment = async (id: number) => {
    if (!currentUser) return;
    const target = installments.find((i) => i.id === id);
    if (!target) return;

    setConfirmState({
      isOpen: true,
      title: "تأكيد حذف معاملة القسط",
      message: `هل أنت متأكد من حذف معاملة القسط لـ "${target.name}" (${target.item}) نهائياً؟ لا يمكن التراجع عن هذا الإجراء.`,
      onConfirm: async () => {
        const updated = installments.filter((i) => i.id !== id);
        setInstallments(updated);
        setLocalInstallments(currentUser.id, updated);
        await deleteIdbInstallment(id);

        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast(`تم حذف معاملة القسط (${target.name}) بنجاح`, "info");

        if (!isTrialMode && id > 0) {
          try {
            setIsSavingCloud(true);
            await queryTurso("DELETE FROM installments WHERE id = ? AND user_id = ?;", [
              id,
              currentUser.id,
            ]);
            broadcastInstallmentsChange(currentUser.id, 'delete');
          } catch (err: any) {
            console.warn("تنبيه حذف القسط سحابياً:", err);
          } finally {
            setIsSavingCloud(false);
          }
        }
      },
    });
  };

  // ----------------------------------------------------
  // DEBTORS CRUD ACTIONS (دفتر الديون)
  // ----------------------------------------------------

  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    if (currentUser) {
      setLocalSettings(currentUser.id, newSettings);
      saveIdbSettings(currentUser.id, newSettings);
    }
    showToast("تم حفظ وتطبيق إعدادات التنبيهات وسقف الدين بنجاح", "success");
  };

  const handleUpdateStats = (newStats: DebtStats) => {
    if (!currentUser) return;
    setStats(newStats);
    setLocalStats(currentUser.id, newStats);
    saveIdbStats(currentUser.id, newStats);
    showToast("تم تحديث أرقام التقارير بنجاح", "success");
  };

  const handleResetStats = () => {
    if (!currentUser) return;
    setConfirmState({
      isOpen: true,
      title: "تصفير سجل التقارير",
      message:
        "هل أنت متأكد من تصفير إحصائيات الديون التراكمية في صفحة التقارير لبدء دورة محاسبية جديدة؟",
      onConfirm: async () => {
        const zeroStats = { totalAdded: 0, totalPaid: 0 };
        setStats(zeroStats);
        setLocalStats(currentUser.id, zeroStats);
        await saveIdbStats(currentUser.id, zeroStats);
        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast("تم تصفير سجل التقارير والإحصائيات بنجاح", "info");
      },
    });
  };

  const handleImportBackup = async (
    importedDebtors: Debtor[],
    importedInstallments: InstallmentRecord[],
    mode: 'merge' | 'replace'
  ) => {
    if (!currentUser) return;
    setIsSavingCloud(true);
    try {
      // ----------------------------------------------------
      // 1. IMPORT & PROCESS DEBTORS
      // ----------------------------------------------------
      let finalDebtors: Debtor[] = [];
      const currentHistoryMap = getLocalDebtorHistory(currentUser.id);
      const updatedHistoryMap = { ...currentHistoryMap };
      const currentDatesMap = getLocalDebtorDates(currentUser.id);
      const updatedDatesMap = { ...currentDatesMap };

      if (mode === 'replace') {
        finalDebtors = importedDebtors.map((d, index) => {
          const debtorId = d.id || Date.now() + index;
          if (d.history && d.history.length > 0) {
            updatedHistoryMap[debtorId] = d.history;
          }
          if (d.createdAt || d.lastDebtDate) {
            updatedDatesMap[debtorId] = d.lastDebtDate || d.createdAt || new Date().toISOString();
          }
          return {
            ...d,
            id: debtorId,
            userId: currentUser.id,
          };
        });
      } else {
        const existingMap = new Map<string, Debtor>();
        allDebtors.forEach((d) => {
          existingMap.set(d.name.trim().toLowerCase(), d);
        });

        const mergedList = [...allDebtors];
        importedDebtors.forEach((imp, index) => {
          const key = imp.name.trim().toLowerCase();
          if (existingMap.has(key)) {
            const exist = existingMap.get(key)!;
            const newAmount = exist.amount + imp.amount;
            const updatedHistory = [
              ...(imp.history || []),
              ...(updatedHistoryMap[exist.id] || []),
            ];
            updatedHistoryMap[exist.id] = updatedHistory;
            const idx = mergedList.findIndex((m) => m.id === exist.id);
            if (idx >= 0) {
              mergedList[idx] = {
                ...exist,
                amount: newAmount,
                phone: imp.phone || exist.phone,
                status: newAmount >= settings.highDebtThreshold ? 'دين مرتفع' : exist.status,
                history: updatedHistory,
              };
            }
          } else {
            const newId = imp.id || Date.now() + index;
            if (imp.history && imp.history.length > 0) {
              updatedHistoryMap[newId] = imp.history;
            }
            if (imp.createdAt || imp.lastDebtDate) {
              updatedDatesMap[newId] = imp.lastDebtDate || imp.createdAt || new Date().toISOString();
            }
            mergedList.push({
              ...imp,
              id: newId,
              userId: currentUser.id,
            });
          }
        });
        finalDebtors = mergedList;
      }

      setAllDebtors(finalDebtors);
      setLocalDebtors(currentUser.id, finalDebtors);
      setLocalDebtorHistory(currentUser.id, updatedHistoryMap);
      setLocalDebtorDates(currentUser.id, updatedDatesMap);
      await saveIdbDebtors(currentUser.id, finalDebtors);

      // ----------------------------------------------------
      // 2. IMPORT & PROCESS INSTALLMENTS (الأقساط)
      // ----------------------------------------------------
      let finalInstallments: InstallmentRecord[] = [];

      if (mode === 'replace') {
        finalInstallments = importedInstallments.map((inst, index) => ({
          ...inst,
          id: inst.id || Date.now() + 2000 + index,
          userId: currentUser.id,
          payments: Array.isArray(inst.payments) ? inst.payments : [],
        }));
      } else {
        const existingInstMap = new Map<string, InstallmentRecord>();
        installments.forEach((inst) => {
          const key = `${inst.name.trim().toLowerCase()}___${inst.item.trim().toLowerCase()}`;
          existingInstMap.set(key, inst);
        });

        const mergedInstallments = [...installments];
        importedInstallments.forEach((imp, index) => {
          const key = `${imp.name.trim().toLowerCase()}___${imp.item.trim().toLowerCase()}`;
          if (existingInstMap.has(key)) {
            const exist = existingInstMap.get(key)!;
            const existPayments = Array.isArray(exist.payments) ? exist.payments : [];
            const impPayments = Array.isArray(imp.payments) ? imp.payments : [];
            // Merge payments uniquely by id
            const payMap = new Map<string | number, any>();
            existPayments.forEach((p) => payMap.set(p.id, p));
            impPayments.forEach((p) => payMap.set(p.id, p));
            const mergedPayments = Array.from(payMap.values());

            const totalPaid = mergedPayments.reduce((s, p) => s + (Number(p.amount) || 0), 0);
            const remainingAmount = Math.max(0, exist.totalAmount - exist.downPayment - totalPaid);
            const status = remainingAmount <= 0 ? 'completed' : exist.status;

            const idx = mergedInstallments.findIndex((m) => m.id === exist.id);
            if (idx >= 0) {
              mergedInstallments[idx] = {
                ...exist,
                phone: imp.phone || exist.phone,
                remainingAmount,
                status,
                payments: mergedPayments,
                notes: imp.notes ? (exist.notes ? `${exist.notes} | ${imp.notes}` : imp.notes) : exist.notes,
              };
            }
          } else {
            const newInstId = imp.id || Date.now() + 2000 + index;
            mergedInstallments.push({
              ...imp,
              id: newInstId,
              userId: currentUser.id,
              payments: Array.isArray(imp.payments) ? imp.payments : [],
            });
          }
        });
        finalInstallments = mergedInstallments;
      }

      setInstallments(finalInstallments);
      setLocalInstallments(currentUser.id, finalInstallments);
      await saveIdbInstallments(currentUser.id, finalInstallments);

      // Cloud Turso sync if active account
      if (!isTrialMode && currentUser.id > 0) {
        try {
          if (mode === 'replace') {
            await queryTurso("DELETE FROM debtors WHERE user_id = ?;", [currentUser.id]);
            for (const d of finalDebtors) {
              await queryTurso(
                "INSERT INTO debtors (id, name, phone, amount, status, user_id, last_debt_date, history, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);",
                [
                  d.id,
                  d.name,
                  d.phone || '',
                  d.amount || 0,
                  d.status || 'مستمر',
                  currentUser.id,
                  d.lastDebtDate || d.createdAt || null,
                  JSON.stringify(updatedHistoryMap[d.id] || []),
                  d.createdAt || new Date().toISOString(),
                ]
              );
            }

            await queryTurso("DELETE FROM installments WHERE user_id = ?;", [currentUser.id]);
            for (const inst of finalInstallments) {
              await queryTurso(
                "INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
                [
                  inst.id,
                  inst.name,
                  inst.phone || '',
                  inst.item || '',
                  inst.totalAmount || 0,
                  inst.downPayment || 0,
                  inst.remainingAmount || 0,
                  inst.registrationDate || new Date().toISOString().slice(0, 10),
                  inst.nextDueDate || new Date().toISOString().slice(0, 10),
                  currentUser.id,
                  inst.status || 'active',
                  inst.notes || '',
                  JSON.stringify(inst.payments || []),
                  inst.createdAt || new Date().toISOString(),
                ]
              );
            }
          }
        } catch (cloudErr) {
          console.warn("Cloud restore sync warning:", cloudErr);
        }
      }

      broadcastDebtorsChange(currentUser.id, 'import');
      broadcastInstallmentsChange(currentUser.id, 'import');

      const totalDebtsSum = finalDebtors.reduce((sum, d) => sum + (d.amount || 0), 0);
      setStats((prev) => {
        const next = { ...prev, totalAdded: Math.max(prev.totalAdded, totalDebtsSum + prev.totalPaid) };
        setLocalStats(currentUser.id, next);
        saveIdbStats(currentUser.id, next);
        return next;
      });

      showToast(
        `تم استرجاع وتحديث البيانات بنجاح (${importedDebtors.length} مدين و ${importedInstallments.length} قسط)`,
        "success"
      );
    } catch (err: any) {
      showToast(err.message || "حدث خطأ أثناء استيراد البيانات", "error");
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleSaveDebtor = async (newDebtorData: Omit<Debtor, 'id' | 'userId'>) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const tempId = Date.now();
    const createdAt = newDebtorData.createdAt || new Date().toISOString();

    const initialHistory: DebtorTransaction = {
      id: `tx-init-${tempId}`,
      debtorId: tempId,
      type: 'initial',
      amount: newDebtorData.amount,
      balanceAfter: newDebtorData.amount,
      date: createdAt,
      description: 'فتح حساب وتسجيل الرصيد الأولي',
      notes: newDebtorData.notes || undefined,
    };

    const newDebtor: Debtor = {
      ...newDebtorData,
      id: tempId,
      userId: currentUser.id,
      createdAt,
      lastDebtDate: createdAt,
      history: [initialHistory],
    };

    const datesMap = getLocalDebtorDates(currentUser.id);
    datesMap[tempId] = createdAt;
    setLocalDebtorDates(currentUser.id, datesMap);

    const historyMap = getLocalDebtorHistory(currentUser.id);
    historyMap[tempId] = [initialHistory];
    setLocalDebtorHistory(currentUser.id, historyMap);

    const updated = [newDebtor, ...allDebtors];
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(newDebtor);

    setStats((prev) => {
      const next = { ...prev, totalAdded: prev.totalAdded + newDebtorData.amount };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });

    showToast(`تمت إضافة ${newDebtor.name} بنجاح`, "success");

    if (!isTrialMode) {
      try {
        setIsSavingCloud(true);
        const historyJson = JSON.stringify([initialHistory]);
        const res = await queryTurso(
          "INSERT INTO debtors (name, phone, amount, status, user_id, created_at, history) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id;",
          [
            newDebtor.name,
            newDebtor.phone,
            newDebtor.amount,
            newDebtor.status,
            currentUser.id,
            createdAt,
            historyJson,
          ]
        );

        if (res.results && res.results[0] && res.results[0].response?.result?.rows?.length > 0) {
          const realId = parseInt(res.results[0].response.result.rows[0][0].value);
          if (!isNaN(realId)) {
            const finalUpdated = updated.map((d) =>
              d.id === tempId ? { ...d, id: realId, history: [{ ...initialHistory, debtorId: realId }] } : d
            );
            setAllDebtors(finalUpdated);
            setLocalDebtors(currentUser.id, finalUpdated);
            await deleteIdbDebtor(tempId);
            await putIdbDebtor({ ...newDebtor, id: realId });
          }
        }
        broadcastDebtorsChange(currentUser.id, 'add');
      } catch (err: any) {
        console.warn("تنبيه المزامنة السحابية أثناء الإضافة:", err?.message || err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleOpenPayModal = (debtor: Debtor) => {
    setTransactionState({
      isOpen: true,
      type: 'pay',
      debtor,
    });
  };

  const handleConfirmPay = async (
    debtorId: number,
    payVal: number,
    customDate?: string,
    notes?: string
  ) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const newAmount = Math.max(0, target.amount - payVal);
    const newStatus =
      newAmount <= 0
        ? 'خالي من الدين'
        : newAmount >= settings.highDebtThreshold
        ? 'دين مرتفع'
        : target.status;
    const txDate = customDate || new Date().toISOString();

    const payTx: DebtorTransaction = {
      id: `tx-pay-${debtorId}-${Date.now()}`,
      debtorId,
      type: 'pay',
      amount: payVal,
      balanceAfter: newAmount,
      date: txDate,
      description: notes ? notes : 'تسديد دفعة نقدية',
      notes: notes || undefined,
    };

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const existingHistory =
      historyMap[debtorId] ||
      target.history ||
      (target.createdAt
        ? [
            {
              id: `tx-init-${target.id}`,
              debtorId: target.id,
              type: 'initial' as const,
              amount: target.amount,
              balanceAfter: target.amount,
              date: target.createdAt,
              description: 'فتح حساب وتسجيل الرصيد الأولي',
            },
          ]
        : []);
    const updatedHistory = [payTx, ...existingHistory];
    historyMap[debtorId] = updatedHistory;
    setLocalDebtorHistory(currentUser.id, historyMap);

    const updatedDebtor = {
      ...target,
      amount: newAmount,
      status: newStatus,
      history: updatedHistory,
    };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    setHistoryModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: updatedDebtor };
      }
      return prev;
    });

    setStats((prev) => {
      const next = { ...prev, totalPaid: prev.totalPaid + payVal };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });
    showToast(
      `تم تسديد ${payVal.toLocaleString('en-US')} د.ع من حساب ${target.name}`,
      "success"
    );

    if (newAmount <= 0) {
      setSettleCompleteState({
        isOpen: true,
        debtor: updatedDebtor,
      });
    }

    if (debtorId > 0 && !updatedDebtor.isDemo && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        await queryTurso(
          "UPDATE debtors SET amount = ?, status = ?, history = ? WHERE id = ? AND user_id = ?;",
          [newAmount, newStatus, JSON.stringify(updatedHistory), debtorId, currentUser.id]
        );
        broadcastDebtorsChange(currentUser.id, 'pay');
      } catch (err: any) {
        console.warn("تنبيه المزامنة السحابية أثناء التسديد:", err?.message || err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleOpenAddDebtModal = (debtor: Debtor) => {
    setTransactionState({
      isOpen: true,
      type: 'add',
      debtor,
    });
  };

  const handleConfirmAddDebt = async (
    debtorId: number,
    addVal: number,
    customDate?: string,
    notes?: string
  ) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const newAmount = target.amount + addVal;
    const newStatus =
      newAmount >= settings.highDebtThreshold ? 'دين مرتفع' : target.status;
    const txDate = customDate || new Date().toISOString();

    const addTx: DebtorTransaction = {
      id: `tx-add-${debtorId}-${Date.now()}`,
      debtorId,
      type: 'add',
      amount: addVal,
      balanceAfter: newAmount,
      date: txDate,
      description: notes ? notes : 'إضافة دين جديد',
      notes: notes || undefined,
    };

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const existingHistory =
      historyMap[debtorId] ||
      target.history ||
      (target.createdAt
        ? [
            {
              id: `tx-init-${target.id}`,
              debtorId: target.id,
              type: 'initial' as const,
              amount: target.amount,
              balanceAfter: target.amount,
              date: target.createdAt,
              description: 'فتح حساب وتسجيل الرصيد الأولي',
            },
          ]
        : []);
    const updatedHistory = [addTx, ...existingHistory];
    historyMap[debtorId] = updatedHistory;
    setLocalDebtorHistory(currentUser.id, historyMap);

    const updatedDebtor = {
      ...target,
      amount: newAmount,
      status: newStatus,
      lastDebtDate: txDate,
      history: updatedHistory,
    };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    setHistoryModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: updatedDebtor };
      }
      return prev;
    });

    setStats((prev) => {
      const next = { ...prev, totalAdded: prev.totalAdded + addVal };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });
    showToast(
      `تمت إضافة ${addVal.toLocaleString('en-US')} د.ع إلى دين ${target.name}`,
      "success"
    );

    if (debtorId > 0 && !target.isDemo && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        await queryTurso(
          "UPDATE debtors SET amount = amount + ?, status = ?, history = ? WHERE id = ? AND user_id = ?;",
          [addVal, newStatus, JSON.stringify(updatedHistory), debtorId, currentUser.id]
        );
        broadcastDebtorsChange(currentUser.id, 'add_debt');
      } catch (err: any) {
        console.warn("تنبيه المزامنة السحابية أثناء إضافة الدين:", err?.message || err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleOpenEditNameModal = (debtor: Debtor) => {
    setEditingNameDebtor(debtor);
    setIsEditNameModalOpen(true);
  };

  const handleSaveDebtorName = async (id: number, newName: string, newPhone: string) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const updated = allDebtors.map((d) =>
      d.id === id ? { ...d, name: newName, phone: newPhone } : d
    );
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);

    const editedDebtor = updated.find((d) => d.id === id);
    if (editedDebtor) {
      await putIdbDebtor(editedDebtor);
    }

    showToast(`تم تعديل بيانات ${newName} بنجاح`, "success");

    const target = allDebtors.find((d) => d.id === id);
    if (id > 0 && target && !target.isDemo && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        await queryTurso(
          "UPDATE debtors SET name = ?, phone = ? WHERE id = ? AND user_id = ?;",
          [newName, newPhone, id, currentUser.id]
        );
        broadcastDebtorsChange(currentUser.id, 'edit');
      } catch (err: any) {
        console.warn("تنبيه تحديث الاسم في السحابة:", err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleToggleOverdueStatus = async (debtorId: number) => {
    if (!currentUser) return;
    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const isCurrentlyOverdue =
      target.status === 'متأخر' ||
      (settings.enableDebtAlerts && calculateDaysElapsed(target.createdAt) >= settings.alertDaysThreshold);

    const newStatus = isCurrentlyOverdue
      ? target.amount >= settings.highDebtThreshold
        ? 'دين مرتفع'
        : 'دين عادي'
      : 'متأخر';

    const updatedDebtor = { ...target, status: newStatus };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    showToast(
      newStatus === 'متأخر'
        ? `تم تصنيف "${target.name}" كمتأخر عن السداد`
        : `تمت إزالة حالة التأخير عن "${target.name}"`,
      newStatus === 'متأخر' ? 'info' : 'success'
    );

    if (debtorId > 0 && !target.isDemo && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        await queryTurso(
          "UPDATE debtors SET status = ? WHERE id = ? AND user_id = ?;",
          [newStatus, debtorId, currentUser.id]
        );
        broadcastDebtorsChange(currentUser.id, 'overdue');
      } catch (err: any) {
        console.warn("تنبيه تحديث حالة المتأخر في السحابة:", err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleKeepSettledDebtor = () => {
    setSettleCompleteState({ isOpen: false, debtor: null });
    showToast("تم الاحتفاظ بالمدين في القائمة برصيد 0 د.ع", "info");
  };

  const handleDeleteSettledDebtor = async (debtor: Debtor) => {
    setSettleCompleteState({ isOpen: false, debtor: null });
    await handleDeleteDebtor(debtor.id);
  };

  const handleOpenHistoryModal = (debtor: Debtor) => {
    const historyMap = currentUser ? getLocalDebtorHistory(currentUser.id) : {};
    const effectiveHistory = historyMap[debtor.id] || debtor.history;
    setHistoryModalState({
      isOpen: true,
      debtor: { ...debtor, history: effectiveHistory },
    });
  };

  const handleOpenShareModal = (debtor: Debtor) => {
    setShareModalState({
      isOpen: true,
      debtor,
    });
  };

  const handleDeleteDebtor = async (id: number) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const debtor = allDebtors.find((d) => d.id === id);
    if (!debtor) return;

    setConfirmState({
      isOpen: true,
      title: "تأكيد الحذف",
      message: `هل أنت متأكد من حذف المدين "${debtor.name}" نهائياً من القائمة وقاعدة البيانات؟`,
      onConfirm: async () => {
        const updated = allDebtors.filter((d) => d.id !== id);
        setAllDebtors(updated);
        setLocalDebtors(currentUser.id, updated);
        await deleteIdbDebtor(id);

        const datesMap = getLocalDebtorDates(currentUser.id);
        delete datesMap[id];
        setLocalDebtorDates(currentUser.id, datesMap);

        const historyMap = getLocalDebtorHistory(currentUser.id);
        delete historyMap[id];
        setLocalDebtorHistory(currentUser.id, historyMap);

        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast(`تم حذف ${debtor.name} بنجاح`, "info");

        if (id > 0 && !debtor.isDemo && !isTrialMode) {
          try {
            setIsSavingCloud(true);
            await queryTurso(
              "DELETE FROM debtors WHERE id = ? AND user_id = ?;",
              [id, currentUser.id]
            );
            broadcastDebtorsChange(currentUser.id, 'delete');
          } catch (err: any) {
            console.warn("تنبيه حذف المدين من السحابة:", err);
          } finally {
            setIsSavingCloud(false);
          }
        }
      },
    });
  };

  // Demo Debtors
  const handleAddDemoDebtors = () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const realDebtors = allDebtors.filter((d) => !isDemoDebtor(d));
    const demoList = generate100DemoDebtors(currentUser.id, settings.highDebtThreshold);

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const datesMap = getLocalDebtorDates(currentUser.id);

    demoList.forEach((d) => {
      if (d.history) {
        historyMap[d.id] = d.history;
      }
      if (d.createdAt) {
        datesMap[d.id] = d.createdAt;
      }
    });

    const combined = [...demoList, ...realDebtors];
    setAllDebtors(combined);
    setLocalDebtors(currentUser.id, combined);
    setLocalDebtorHistory(currentUser.id, historyMap);
    setLocalDebtorDates(currentUser.id, datesMap);

    showToast(
      "تمت إضافة 100 مدين تجريبي بنجاح للاختبار (محلية فقط دون التأثير على السحابة)",
      "success"
    );
  };

  const handleClearDemoDebtors = async () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const demoDebtorsToRemove = allDebtors.filter(isDemoDebtor);
    const remainingReal = allDebtors.filter((d) => !isDemoDebtor(d));
    const demoCount = demoDebtorsToRemove.length;

    if (demoCount === 0) {
      showToast("لا يوجد أي مدينين تجريبيين في القائمة حالياً", "info");
      return;
    }

    setAllDebtors(remainingReal);
    setLocalDebtors(currentUser.id, remainingReal);

    try {
      await saveIdbDebtors(currentUser.id, remainingReal);
      for (const d of demoDebtorsToRemove) {
        await deleteIdbDebtor(d.id).catch(() => {});
      }
    } catch (err) {
      console.warn("IndexedDB clear demo error:", err);
    }

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const datesMap = getLocalDebtorDates(currentUser.id);
    demoDebtorsToRemove.forEach((d) => {
      delete historyMap[d.id];
      delete datesMap[d.id];
    });
    setLocalDebtorHistory(currentUser.id, historyMap);
    setLocalDebtorDates(currentUser.id, datesMap);

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "DELETE FROM debtors WHERE user_id = ? AND (phone LIKE '%*%' OR phone LIKE '%X%' OR phone = '077********' OR id < 0);",
        [currentUser.id]
      );
    } catch (err: any) {
      console.warn("Turso cloud demo cleanup notice:", err);
    } finally {
      setIsSavingCloud(false);
    }

    const remainingDebtsTotal = remainingReal.reduce(
      (s, d) => s + (Number(d.amount) || 0),
      0
    );
    setStats((prev) => {
      const nextAdded = Math.max(remainingDebtsTotal + prev.totalPaid, 0);
      const next = { ...prev, totalAdded: nextAdded };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });

    showToast(
      `تم حذف كافة البيانات التجريبية بنجاح (${demoCount} مدين) من كافة التبويبات وقاعدة البيانات`,
      "success"
    );
  };

  // Managers Management (Admin Only)
  const handleCreateManager = async (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType = 'permanent',
    subscriptionMonths: number = 1,
    allowedModules: ManagerModuleAccess = 'both'
  ) => {
    try {
      setIsSavingCloud(true);
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(pass, salt);

      let expiresAt: string | null = null;
      if (subscriptionType === 'monthly') {
        const exp = new Date();
        exp.setMonth(exp.getMonth() + (subscriptionMonths || 1));
        expiresAt = exp.toISOString().split('T')[0];
      }

      let res;
      try {
        res = await queryTurso(
          "INSERT INTO users (username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at, allowed_modules) VALUES (?, ?, ?, 'manager', ?, 1, ?, ?, ?) RETURNING id;",
          [user, hashedPassword, pass, branch, subscriptionType, expiresAt, allowedModules]
        );
      } catch {
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
        res = await queryTurso(
          "INSERT INTO users (username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at, allowed_modules) VALUES (?, ?, ?, 'manager', ?, 1, ?, ?, ?) RETURNING id;",
          [user, hashedPassword, pass, branch, subscriptionType, expiresAt, allowedModules]
        );
      }

      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        const newManagerId = parseInt(res.results[0].response.result.rows[0][0].value);
        if (!isNaN(newManagerId)) {
          setLocalStats(newManagerId, { totalAdded: 0, totalPaid: 0 });
          saveIdbStats(newManagerId, { totalAdded: 0, totalPaid: 0 });
          setLocalDebtors(newManagerId, []);
          saveIdbDebtors(newManagerId, []);
          setLocalSettings(newManagerId, DEFAULT_SETTINGS);
          saveIdbSettings(newManagerId, DEFAULT_SETTINGS);

          localStorage.setItem(`user_pwd_${newManagerId}`, pass);
          localStorage.setItem(`user_pwd_${user}`, pass);

          const newManager: Manager = {
            id: newManagerId,
            username: user,
            branch,
            isActive: true,
            subscriptionType,
            subscriptionExpiresAt: expiresAt,
            plainPassword: pass,
            allowedModules,
          };

          const updated = [...managers, newManager];
          setManagers(updated);
          setLocalManagers(updated);
          await saveIdbManagers(updated);

          const accessLabel =
            allowedModules === 'debts'
              ? ' (فقط دفتر الديون)'
              : allowedModules === 'installments'
              ? ' (فقط نظام الأقساط)'
              : ' (ديون + أقساط)';
          showToast(`تم إنشاء حساب المدير "${user}" بنجاح${accessLabel}!`, "success");
        }
      }
    } catch (err: any) {
      showToast("فشل إنشاء المدير: " + (err.message || 'خطأ غير معروف'), "error");
      throw err;
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleChangeManagerModules = async (
    id: number,
    newAllowedModules: ManagerModuleAccess
  ) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    const updated = managers.map((m) =>
      m.id === id ? { ...m, allowedModules: newAllowedModules } : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    if (currentUser && currentUser.id === id) {
      const updatedUser = { ...currentUser, allowedModules: newAllowedModules };
      setCurrentUser(updatedUser);
      setLocalSession(updatedUser);
      if (newAllowedModules === 'debts') setHeaderMode('debts');
      if (newAllowedModules === 'installments') setHeaderMode('installments');
    }

    const label =
      newAllowedModules === 'debts'
        ? 'فقط دفتر الديون (إخفاء المنسدلة)'
        : newAllowedModules === 'installments'
        ? 'فقط نظام الأقساط (إخفاء المنسدلة)'
        : 'كلاهما (ديون + أقساط مع المنسدلة)';

    showToast(`تم تعديل صلاحية المدير "${target.username}" إلى: ${label}`, "success");

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET allowed_modules = ? WHERE id = ?;",
        [newAllowedModules, id]
      );
    } catch (err: any) {
      await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
      await queryTurso(
        "UPDATE users SET allowed_modules = ? WHERE id = ?;",
        [newAllowedModules, id]
      ).catch(() => {});
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleChangeSubscriptionType = async (
    id: number,
    newType: SubscriptionType,
    months: number = 1
  ) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    let expiresAt: string | null = null;
    if (newType === 'monthly') {
      const exp = new Date();
      exp.setMonth(exp.getMonth() + (months || 1));
      expiresAt = exp.toISOString().split('T')[0];
    }

    const updated = managers.map((m) =>
      m.id === id
        ? {
            ...m,
            subscriptionType: newType,
            subscriptionExpiresAt: expiresAt,
            isActive: true,
          }
        : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    broadcastManagerStatusChange(id, true);

    showToast(
      newType === 'permanent'
        ? `تم تحويل اشتراك المدير "${target.username}" إلى دائم (مدى الحياة)`
        : `تم تحويل اشتراك المدير "${target.username}" إلى شهري حتى ${expiresAt}`,
      'success'
    );

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET subscription_type = ?, subscription_expires_at = ?, is_active = 1 WHERE id = ?;",
        [newType, expiresAt, id]
      );
    } catch (err: any) {
      console.warn("تنبيه تحديث نوع الاشتراك في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleUpdateManagerPassword = async (managerId: number, newPass: string) => {
    try {
      setIsSavingCloud(true);
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(newPass, salt);

      await queryTurso(
        "UPDATE users SET password = ?, plain_password = ? WHERE id = ?;",
        [hashedPassword, newPass, managerId]
      );

      localStorage.setItem(`user_pwd_${managerId}`, newPass);
      const mgr = managers.find((m) => m.id === managerId);
      if (mgr) {
        localStorage.setItem(`user_pwd_${mgr.username}`, newPass);
      }

      const updated = managers.map((m) =>
        m.id === managerId ? { ...m, plainPassword: newPass } : m
      );
      setManagers(updated);
      setLocalManagers(updated);
      await saveIdbManagers(updated);

      showToast("تم تحديث وحفظ كلمة مرور المدير الفرعي بنجاح!", "success");
    } catch (err: any) {
      showToast("فشل تحديث كلمة المرور: " + (err.message || 'خطأ غير معروف'), "error");
      throw err;
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleToggleManagerStatus = async (id: number, currentActive: boolean) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;
    const newActive = !currentActive;

    const updated = managers.map((m) => (m.id === id ? { ...m, isActive: newActive } : m));
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    if (!newActive) {
      broadcastManagerStatusChange(
        id,
        false,
        `تم إيقاف حساب المدير "${target.username}" من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.`
      );
      if (currentUser && currentUser.id === id) {
        handleForceLogout(`تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.`);
        return;
      }
    } else {
      broadcastManagerStatusChange(id, true);
    }

    showToast(
      newActive
        ? `تم تنشيط حساب المدير "${target.username}" فوراً`
        : `تم إيقاف حساب المدير "${target.username}" فوراً وإنهاء جلسته`,
      newActive ? 'success' : 'info'
    );

    try {
      setIsSavingCloud(true);
      await queryTurso("UPDATE users SET is_active = ? WHERE id = ?;", [newActive ? 1 : 0, id]);
    } catch (err: any) {
      console.warn("تنبيه تحديث حالة المدير في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleRenewSubscription = async (id: number, months: number = 1) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    let baseDate = new Date();
    if (target.subscriptionExpiresAt) {
      const existingExp = new Date(target.subscriptionExpiresAt);
      if (existingExp.getTime() > Date.now()) {
        baseDate = existingExp;
      }
    }
    baseDate.setMonth(baseDate.getMonth() + months);
    const newExpiresAt = baseDate.toISOString().split('T')[0];

    const updated = managers.map((m) =>
      m.id === id
        ? {
            ...m,
            subscriptionExpiresAt: newExpiresAt,
            isActive: true,
          }
        : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    broadcastManagerStatusChange(id, true);

    showToast(
      `تم تجديد الاشتراك الشهري للمدير "${target.username}" حتى ${newExpiresAt} وتنشيط حسابه`,
      'success'
    );

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET subscription_expires_at = ?, is_active = 1 WHERE id = ?;",
        [newExpiresAt, id]
      );
    } catch (err: any) {
      console.warn("تنبيه تجديد الاشتراك في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleDeleteManager = async (id: number) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    setConfirmState({
      isOpen: true,
      title: "تأكيد حذف المدير الفرعي",
      message: `هل أنت متأكد من حذف حساب المدير "${target.username}" نهائياً من النظام؟`,
      onConfirm: async () => {
        try {
          setIsSavingCloud(true);
          const updated = managers.filter((m) => m.id !== id);
          setManagers(updated);
          setLocalManagers(updated);
          saveIdbManagers(updated);

          broadcastManagerStatusChange(id, false, "تم حذف هذا الحساب من قبل الإدارة العامة.");
          if (currentUser && currentUser.id === id) {
            handleForceLogout("تم حذف هذا الحساب من قبل الإدارة العامة.");
          }

          setConfirmState((prev) => ({ ...prev, isOpen: false }));
          showToast("تم حذف المدير بنجاح", "info");

          await queryTurso("DELETE FROM users WHERE id = ?;", [id]);
        } catch (err: any) {
          showToast(err.message || "حدث خطأ أثناء الحذف", "error");
        } finally {
          setIsSavingCloud(false);
        }
      },
    });
  };

  // Calculations
  const totalAmount = allDebtors.reduce((sum, d) => sum + (d.amount || 0), 0);
  const debtorsOnlyCount = allDebtors.filter((d) => d.amount > 0).length;
  const paidOnlyCount = allDebtors.filter((d) => d.amount <= 0).length;
  const highDebtorsCount = allDebtors.filter(
    (d) => d.amount >= settings.highDebtThreshold && d.amount > 0
  ).length;
  const demoDebtorsCount = allDebtors.filter(isDemoDebtor).length;
  const alertTriggeredCount = allDebtors.filter((d) => {
    if (!settings.enableDebtAlerts || d.amount <= 0) return false;
    const days = calculateDaysElapsed(d.createdAt);
    return days >= settings.alertDaysThreshold;
  }).length;

  const overdueCount = allDebtors.filter((d) => {
    if (d.amount <= 0 || d.status === 'خالي من الدين') return false;
    if (d.status === 'متأخر') return true;
    if (settings.enableDebtAlerts) {
      const days = calculateDaysElapsed(d.createdAt);
      return days >= settings.alertDaysThreshold;
    }
    return false;
  }).length;

  // Due installments count for badge in BottomNav
  const dueInstallmentsCount = useMemo(() => {
    return installments.filter((i) => i.status === 'due' || i.status === 'overdue').length;
  }, [installments]);

  const totalInstallmentsRemaining = useMemo(() => {
    return installments.reduce((sum, i) => sum + (Number(i.remainingAmount) || 0), 0);
  }, [installments]);

  const filteredDebtors = allDebtors
    .filter((d) => {
      const query = searchTerm.toLowerCase().trim();
      const matchesQuery =
        !query ||
        d.name.toLowerCase().includes(query) ||
        (d.phone && d.phone.includes(query));

      if (!matchesQuery) return false;
      if (filter === 'debtors_only') return d.amount > 0;
      if (filter === 'paid_only') return d.amount <= 0;
      if (filter === 'high_debt') return d.amount >= settings.highDebtThreshold && d.amount > 0;
      return true;
    })
    .sort((a, b) => {
      if (b.amount !== a.amount) {
        return b.amount - a.amount;
      }
      return a.name.localeCompare(b.name, 'ar');
    });

  if (!currentUser) {
    return (
      <div className="min-h-screen w-full bg-[#080f24] text-slate-100 antialiased font-sans" dir="rtl">
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
        <LoginOverlay
          onLoginSuccess={handleLoginSuccess}
          initialErrorMessage={loginErrorMessage}
        />
      </div>
    );
  }

  return (
    <div
      className="h-[100dvh] max-w-[500px] mx-auto flex flex-col bg-slate-50 text-slate-800 relative shadow-2xl overflow-hidden select-none"
      dir="rtl"
    >
      {/* Toast Messages */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Main App Container */}
      <main className="flex-1 flex flex-col overflow-hidden relative" id="appContainer">
        {/* 1. HOME TAB (الرئيسية: تعرض دفتر الديون أو نظام الأقساط حسب القائمة المنسدلة العلوية) */}
        {activeTab === 'home' && (
          <div id="tab-home" className="flex-1 flex flex-col overflow-hidden animate-in fade-in duration-150">
            {/* Fixed Top Header & Filters */}
            <div className="shrink-0 z-30 bg-slate-50 shadow-xs border-b border-slate-200/40">
              <HeaderCard
                currentUser={currentUser}
                debtorsCount={allDebtors.length}
                totalAmount={totalAmount}
                installmentsCount={installments.length}
                totalInstallmentsRemaining={totalInstallmentsRemaining}
                headerMode={headerMode}
                mode={headerMode}
                onHeaderModeChange={(newMode) => {
                  setHeaderMode(newMode);
                }}
                onModeChange={(newMode) => {
                  setHeaderMode(newMode);
                }}
                onLogout={handleLogout}
                isSaving={isSavingCloud}
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                onSecretAdminUnlock={handleSecretAdminUnlock}
              />

              {headerMode === 'debts' && (
                <Controls
                  searchTerm={searchTerm}
                  onSearchChange={setSearchTerm}
                  filter={filter}
                  onFilterChange={setFilter}
                  totalCount={allDebtors.length}
                  debtorsOnlyCount={debtorsOnlyCount}
                  paidOnlyCount={paidOnlyCount}
                  highDebtCount={highDebtorsCount}
                  viewMode={viewMode}
                  onViewModeChange={handleViewModeChange}
                  displayedCount={filteredDebtors.length}
                />
              )}
            </div>

            {/* Scrollable View Content (Debts or Installments) */}
            {headerMode === 'debts' ? (
              <div
                className="flex-1 overflow-y-auto overscroll-contain px-4 pt-2.5 pb-32 sm:pb-36 space-y-2 focus:outline-none"
                id="debtorsListScrollContainer"
              >
                {filteredDebtors.length === 0 ? (
                  <div className="text-center py-10 bg-white rounded-2xl border border-dashed border-slate-200 p-6 shadow-xs">
                    <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mx-auto mb-3 text-lg">
                      {filter === 'paid_only' ? (
                        <i className="fa-solid fa-circle-check text-emerald-500"></i>
                      ) : filter === 'high_debt' ? (
                        <i className="fa-solid fa-arrow-trend-up text-red-500"></i>
                      ) : (
                        <i className="fa-solid fa-users-slash"></i>
                      )}
                    </div>
                    <div className="font-bold text-sm text-slate-700 mb-1">
                      {searchTerm
                        ? 'لم يتم العثور على نتائج مطابقة'
                        : filter === 'paid_only'
                        ? 'لا يوجد مدينين خاليين من الدين حالياً'
                        : filter === 'high_debt'
                        ? 'لا يوجد عملاء بذمم تتجاوز سقف الدين المرتفع'
                        : filter === 'debtors_only'
                        ? 'لا يوجد مدينين بذمم قائمة حالياً'
                        : 'لا يوجد مدينين مسجلين بعد'}
                    </div>
                    <p className="text-xs text-slate-400 mb-4">
                      {searchTerm
                        ? 'تأكد من كتابة الاسم أو رقم الهاتف بشكل صحيح'
                        : filter === 'paid_only'
                        ? 'عند قيام أحد المدينين بتسديد رصيده كاملاً سيظهر هنا'
                        : filter === 'high_debt'
                        ? `سقف الدين المرتفع محدد حالياً بـ (${settings.highDebtThreshold.toLocaleString()} د.ع)`
                        : 'يمكنك إضافة مدين جديد عبر زر (+) في الشريط السفلي'}
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2" id="debtorsListContainer">
                    {filteredDebtors.map((debtor) => (
                      <DebtorListItem
                        key={debtor.id}
                        debtor={debtor}
                        settings={settings}
                        onPay={handleOpenPayModal}
                        onAddDebt={handleOpenAddDebtModal}
                        onDelete={handleDeleteDebtor}
                        onShowToast={showToast}
                        onViewHistory={handleOpenHistoryModal}
                        onShare={handleOpenShareModal}
                        onEditName={handleOpenEditNameModal}
                      />
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex-1 flex flex-col overflow-hidden px-4 pt-2.5" id="installmentsViewContainer">
                <InstallmentsTab
                  installments={installments}
                  onAddInstallment={handleAddInstallment}
                  onUpdateInstallment={handleUpdateInstallment}
                  onSettlePayment={handleSettleInstallmentPayment}
                  onDeleteInstallment={handleDeleteInstallment}
                  userId={currentUser.id}
                />
              </div>
            )}
          </div>
        )}

        {/* 2. INSTALLMENTS TAB FALLBACK (نظام الأقساط مع الهيدر الكامل) */}
        {activeTab === 'installments' && (
          <div id="tab-installments" className="flex-1 flex flex-col overflow-hidden animate-in fade-in duration-150">
            <div className="shrink-0 z-30 bg-slate-50 shadow-xs border-b border-slate-200/40">
              <HeaderCard
                currentUser={currentUser}
                debtorsCount={allDebtors.length}
                totalAmount={totalAmount}
                installmentsCount={installments.length}
                totalInstallmentsRemaining={totalInstallmentsRemaining}
                headerMode="installments"
                mode="installments"
                onHeaderModeChange={(newMode) => {
                  setHeaderMode(newMode);
                  if (newMode === 'debts') {
                    setActiveTab('home');
                  }
                }}
                onModeChange={(newMode) => {
                  setHeaderMode(newMode);
                  if (newMode === 'debts') {
                    setActiveTab('home');
                  }
                }}
                onLogout={handleLogout}
                isSaving={isSavingCloud}
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                onSecretAdminUnlock={handleSecretAdminUnlock}
              />
            </div>
            <div className="flex-1 flex flex-col overflow-hidden px-4 pt-2.5" id="installmentsViewContainer">
              <InstallmentsTab
                installments={installments}
                onAddInstallment={handleAddInstallment}
                onUpdateInstallment={handleUpdateInstallment}
                onSettlePayment={handleSettleInstallmentPayment}
                onDeleteInstallment={handleDeleteInstallment}
                userId={currentUser.id}
              />
            </div>
          </div>
        )}

        {/* 3. REPORTS TAB (التقارير) */}
        {activeTab === 'reports' && (
          <div className="flex-1 overflow-y-auto overscroll-contain">
            <ReportsTab
              currentUser={currentUser}
              debtors={allDebtors}
              installments={installments}
              stats={stats}
              settings={settings}
              mode={headerMode}
              onUpdateStats={handleUpdateStats}
              onResetStats={handleResetStats}
              onShowToast={showToast}
            />
          </div>
        )}

        {/* 4. OVERDUE TAB (المتأخرون) */}
        {activeTab === 'overdue' && (
          <div className="flex-1 overflow-y-auto overscroll-contain">
            <OverdueTab
              currentUser={currentUser}
              debtors={allDebtors}
              installments={installments}
              mode={headerMode}
              onSettleInstallmentPayment={handleSettleInstallmentPayment}
              settings={settings}
              onOpenPayModal={handleOpenPayModal}
              onToggleOverdueStatus={handleToggleOverdueStatus}
              onShowToast={showToast}
              onViewHistory={handleOpenHistoryModal}
              onShare={handleOpenShareModal}
              onDeleteInstallment={handleDeleteInstallment}
            />
          </div>
        )}

        {/* 5. SETTINGS TAB (الإعدادات) */}
        {activeTab === 'settings' && (
          <div className="flex-1 overflow-y-auto overscroll-contain">
            <SettingsTab
              currentUser={currentUser}
              managers={managers}
              stats={stats}
              currentDebts={totalAmount}
              onUpdateStats={handleUpdateStats}
              onCreateManager={handleCreateManager}
              onToggleManagerStatus={handleToggleManagerStatus}
              onRenewSubscription={handleRenewSubscription}
              onChangeSubscriptionType={handleChangeSubscriptionType}
              onChangeManagerModules={handleChangeManagerModules}
              onDeleteManager={handleDeleteManager}
              onLogout={handleLogout}
              isManagersLoading={isManagersLoading}
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              totalDebtorsCount={allDebtors.length}
              highDebtorsCount={highDebtorsCount}
              alertTriggeredCount={alertTriggeredCount}
              allDebtors={allDebtors}
              installments={installments}
              onImportBackup={handleImportBackup}
              onShowToast={showToast}
              onAddDemoDebtors={handleAddDemoDebtors}
              onClearDemoDebtors={handleClearDemoDebtors}
              demoDebtorsCount={demoDebtorsCount}
              onUpdateManagerPassword={handleUpdateManagerPassword}
              onRefreshManagers={loadManagersFromCloud}
            />
          </div>
        )}

        {/* 6. MANAGERS TAB (لوحة تحكم المدراء للمسؤول) */}
        {activeTab === 'managers' && currentUser.role === 'admin' && (
          <div className="flex-1 overflow-y-auto overscroll-contain p-4">
            <ManagersTab
              managers={managers}
              onCreateManager={handleCreateManager}
              onToggleManagerStatus={handleToggleManagerStatus}
              onRenewSubscription={handleRenewSubscription}
              onChangeSubscriptionType={handleChangeSubscriptionType}
              onChangeManagerModules={handleChangeManagerModules}
              onDeleteManager={handleDeleteManager}
              onUpdateManagerPassword={handleUpdateManagerPassword}
              onRefreshManagers={loadManagersFromCloud}
              isLoading={isManagersLoading}
            />
          </div>
        )}
      </main>

      {/* DEBTOR HISTORY MODAL */}
      <DebtorHistoryModal
        isOpen={historyModalState.isOpen}
        debtor={historyModalState.debtor}
        onClose={() => setHistoryModalState({ isOpen: false, debtor: null })}
        onShowToast={showToast}
      />

      {/* DEBTOR SHARE MODAL */}
      {shareModalState.isOpen && shareModalState.debtor && (
        <DebtorShareModal
          isOpen={shareModalState.isOpen}
          debtor={shareModalState.debtor}
          storeName={currentUser.branch_name || 'دفتر الديون'}
          onClose={() => setShareModalState({ isOpen: false, debtor: null })}
          onShowToast={showToast}
        />
      )}

      {/* ADD DEBTOR MODAL (Pure Debts Mode) */}
      <AddDebtorModal
        isOpen={isAddDebtorModalOpen}
        onClose={() => setIsAddDebtorModalOpen(false)}
        onSave={handleSaveDebtor}
      />

      {/* ADD INSTALLMENT MODAL (Pure Installments Mode) */}
      <AddInstallmentModal
        isOpen={isAddInstallmentModalOpen}
        onClose={() => setIsAddInstallmentModalOpen(false)}
        onAdd={handleAddInstallment}
        userId={currentUser.id}
      />

      {/* TRANSACTION MODAL (Pay / Add Debt) */}
      <TransactionModal
        isOpen={transactionState.isOpen}
        type={transactionState.type}
        debtor={transactionState.debtor}
        onClose={() =>
          setTransactionState({ isOpen: false, type: 'pay', debtor: null })
        }
        onConfirm={
          transactionState.type === 'pay'
            ? handleConfirmPay
            : handleConfirmAddDebt
        }
      />

      {/* CONFIRM MODAL */}
      <ConfirmModal
        isOpen={confirmState.isOpen}
        title={confirmState.title}
        message={confirmState.message}
        onConfirm={confirmState.onConfirm}
        onCancel={() => setConfirmState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* SETTLE COMPLETE MODAL */}
      <SettleCompleteModal
        isOpen={settleCompleteState.isOpen}
        debtor={settleCompleteState.debtor}
        onKeep={handleKeepSettledDebtor}
        onDelete={handleDeleteSettledDebtor}
      />

      {/* EDIT DEBTOR NAME MODAL */}
      <EditDebtorNameModal
        isOpen={isEditNameModalOpen}
        debtor={editingNameDebtor}
        onClose={() => {
          setIsEditNameModalOpen(false);
          setEditingNameDebtor(null);
        }}
        onSave={handleSaveDebtorName}
      />

      {/* TRIAL LIMIT MODAL */}
      <TrialLimitModal
        isOpen={isTrialLimitModalOpen}
        onClose={() => setIsTrialLimitModalOpen(false)}
        debtorsCount={allDebtors.length}
      />

      {/* SECRET ADMIN MODAL */}
      <SecretAdminModal
        isOpen={isSecretAdminModalOpen}
        onClose={() => setIsSecretAdminModalOpen(false)}
        currentUser={currentUser}
        onOpenManagersModal={() => setActiveTab('managers')}
        onOpenSettingsTab={() => setActiveTab('settings')}
        onShowToast={showToast}
      />

      {/* BOTTOM NAVIGATION */}
      <BottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenAddModal={handleOpenAddModal}
        isAdmin={currentUser.role === 'admin'}
        overdueCount={overdueCount}
        dueInstallmentsCount={dueInstallmentsCount}
        mode={headerMode}
      />
    </div>
  );
}
