package com.example.utils

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.Invoice
import com.example.data.InvoiceItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReceiptPrinterHelper {

    fun printReceipt(context: Context, invoice: Invoice, items: List<InvoiceItem>) {
        val activity = context as? android.app.Activity ?: return
        activity.runOnUiThread {
            val webView = WebView(context)
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val printAdapter = webView.createPrintDocumentAdapter("وصل_رقم_${invoice.invoiceNumber}")
                    val jobName = "طباعة_وصل_رقم_${invoice.invoiceNumber}"
                    
                    val builder = PrintAttributes.Builder()
                    // Standard media sizes
                    builder.setMediaSize(PrintAttributes.MediaSize.ISO_A6)
                    
                    printManager.print(jobName, printAdapter, builder.build())
                }
            }

            val htmlContent = generateReceiptHtml(invoice, items)
            webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
        }
    }

    private fun generateReceiptHtml(invoice: Invoice, items: List<InvoiceItem>): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale("ar"))
        val formattedDate = sdf.format(Date(invoice.orderTime))
        
        val itemsHtml = StringBuilder()
        items.forEach { item ->
            itemsHtml.append("""
                <tr>
                    <td style="text-align: right; padding: 4px 0;">${item.productName}</td>
                    <td style="text-align: center; padding: 4px 0;">${item.quantity}</td>
                    <td style="text-align: left; padding: 4px 0;">${String.format("%,.0f د.ع", item.productPrice)}</td>
                    <td style="text-align: left; padding: 4px 0;">${String.format("%,.0f د.ع", item.productPrice * item.quantity)}</td>
                </tr>
            """.trimIndent())
        }

        return """
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <style>
                    body {
                        font-family: 'Courier New', Courier, monospace, Arial;
                        font-size: 12px;
                        color: #000;
                        margin: 10px;
                        padding: 0;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 15px;
                    }
                    .header h1 {
                        font-size: 18px;
                        margin: 0;
                    }
                    .header p {
                        font-size: 10px;
                        margin: 2px 0;
                    }
                    .divider {
                        border-top: 1px dashed #000;
                        margin: 10px 0;
                    }
                    .info-table, .items-table {
                        width: 100%;
                        border-collapse: collapse;
                    }
                    .info-table td {
                        font-size: 10px;
                        padding: 2px 0;
                    }
                    .items-table th {
                        border-bottom: 1px solid #000;
                        padding: 4px 0;
                        font-size: 11px;
                    }
                    .totals {
                        margin-top: 10px;
                        font-size: 11px;
                    }
                    .totals td {
                        padding: 2px 0;
                    }
                    .footer {
                        text-align: center;
                        margin-top: 20px;
                        font-size: 9px;
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>مطعم وكافيه النخبة</h1>
                    <p>هاتف: 07700000000</p>
                    <p>بغداد - الكرادة</p>
                </div>
                
                <table class="info-table">
                    <tr>
                        <td><b>رقم الوصل:</b> #${invoice.invoiceNumber}</td>
                        <td style="text-align: left;"><b>نوع الطلب:</b> ${invoice.orderType}</td>
                    </tr>
                    <tr>
                        <td><b>التاريخ:</b> $formattedDate</td>
                        <td style="text-align: left;"><b>طريقة الدفع:</b> ${invoice.paymentMethod}</td>
                    </tr>
                </table>
                
                <div class="divider"></div>
                
                <table class="items-table">
                    <thead>
                        <tr>
                            <th style="text-align: right;">المادة</th>
                            <th style="text-align: center; width: 10%;">العدد</th>
                            <th style="text-align: left; width: 20%;">السعر</th>
                            <th style="text-align: left; width: 25%;">الإجمالي</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${itemsHtml.toString()}
                    </tbody>
                </table>
                
                <div class="divider"></div>
                
                <table class="info-table totals">
                    <tr>
                        <td><b>المجموع الفرعي:</b></td>
                        <td style="text-align: left;">${String.format("%,.0f د.ع", invoice.totalAmount)}</td>
                    </tr>
                    <tr>
                        <td><b>الضريبة (0%):</b></td>
                        <td style="text-align: left;">0 د.ع</td>
                    </tr>
                    <tr style="font-size: 13px; font-weight: bold;">
                        <td><b>المجموع الكلي:</b></td>
                        <td style="text-align: left;">${String.format("%,.0f د.ع", invoice.totalAmount)}</td>
                    </tr>
                    <tr style="color: #444;">
                        <td><b>المستلم:</b></td>
                        <td style="text-align: left;">${String.format("%,.0f د.ع", invoice.amountReceived)}</td>
                    </tr>
                    <tr style="color: #444;">
                        <td><b>المتبقي (الفكة):</b></td>
                        <td style="text-align: left;">${String.format("%,.0f د.ع", invoice.amountChange)}</td>
                    </tr>
                </table>
                
                <div class="divider"></div>
                
                <div class="footer">
                    <p>شكراً لزيارتكم! نرجو رؤيتكم مجدداً</p>
                    <p>برمجة وتطوير نظام POS النخبة الذكي</p>
                </div>
            </body>
            </html>
        """.trimIndent()
    }
}
