package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class POSViewModel(private val repository: POSRepository, private val context: Context) : ViewModel() {

    private val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)

    // --- State: Authentication ---
    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("is_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _activeUser = MutableStateFlow(prefs.getString("logged_in_user", "") ?: "")
    val activeUser: StateFlow<String> = _activeUser.asStateFlow()

    private val _isTrialExpired = MutableStateFlow(false)
    val isTrialExpired: StateFlow<Boolean> = _isTrialExpired.asStateFlow()

    init {
        viewModelScope.launch {
            repository.prepopulateIfEmpty()
        }
        checkTrialExpiration()
    }

    fun checkTrialExpiration() {
        val firstLoginTime = prefs.getLong("trial_first_login_time", 0L)
        if (firstLoginTime != 0L) {
            val passedTime = System.currentTimeMillis() - firstLoginTime
            val hours24 = 24 * 60 * 60 * 1000L
            if (passedTime >= hours24) {
                _isTrialExpired.value = true
            }
        }
    }

    fun logout() {
        _isLoggedIn.value = false
        _activeUser.value = ""
        prefs.edit()
            .putBoolean("is_logged_in", false)
            .putString("logged_in_user", "")
            .apply()
    }

    fun login(userName: String, passwordInput: String): Boolean {
        if (userName == "ali" && passwordInput == "19971997") {
            _activeUser.value = "ali"
            _isLoggedIn.value = true
            prefs.edit()
                .putBoolean("is_logged_in", true)
                .putString("logged_in_user", "ali")
                .apply()
            return true
        } else if (userName == "1" && passwordInput == "1") {
            val firstLoginTime = prefs.getLong("trial_first_login_time", 0L)
            if (firstLoginTime == 0L) {
                val now = System.currentTimeMillis()
                prefs.edit().putLong("trial_first_login_time", now).apply()
            } else {
                val passedTime = System.currentTimeMillis() - firstLoginTime
                if (passedTime >= 24 * 60 * 60 * 1000L) {
                    _isTrialExpired.value = true
                    return false
                }
            }
            _activeUser.value = "1"
            _isLoggedIn.value = true
            prefs.edit()
                .putBoolean("is_logged_in", true)
                .putString("logged_in_user", "1")
                .apply()
            return true
        }
        return false
    }

    // --- State: Order Service Type ---
    private val _orderType = MutableStateFlow("صالة") // "صالة" or "سفري"
    val orderType: StateFlow<String> = _orderType.asStateFlow()

    fun setOrderType(type: String) {
        _orderType.value = type
    }

    // --- State: Navigation ---
    private val _currentTab = MutableStateFlow(0) // 0: الرئيسية, 1: الطلبات, 2: المنيو, 3: الإعدادات
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    fun selectTab(index: Int) {
        _currentTab.value = index
    }

    // --- State: Database flows ---
    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val invoices: StateFlow<List<Invoice>> = repository.allInvoices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shiftLogs: StateFlow<List<ShiftLog>> = repository.allShiftLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allInvoiceItems: StateFlow<List<InvoiceItem>> = repository.allInvoiceItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- State: Home POS Selection ---
    private val _selectedCategoryId = MutableStateFlow<Int?>(null)
    val selectedCategoryId: StateFlow<Int?> = _selectedCategoryId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun selectCategory(id: Int?) {
        _selectedCategoryId.value = id
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Filter products reactively based on Category AND Search Query
    val filteredProducts: StateFlow<List<Product>> = combine(
        allProducts,
        _selectedCategoryId,
        _searchQuery
    ) { products, catId, query ->
        var result = products
        if (catId != null) {
            result = result.filter { it.categoryId == catId }
        }
        if (query.isNotBlank()) {
            result = result.filter { it.name.contains(query, ignoreCase = true) }
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- State: Cart / Active Order ---
    private val _cartItems = MutableStateFlow<Map<Product, Int>>(emptyMap())
    val cartItems: StateFlow<Map<Product, Int>> = _cartItems.asStateFlow()

    val cartTotalCount: StateFlow<Int> = _cartItems.map { map ->
        map.values.sum()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val cartTotalAmount: StateFlow<Double> = _cartItems.map { map ->
        map.entries.sumOf { (product, qty) -> product.price * qty }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addProductToCart(product: Product) {
        val currentMap = _cartItems.value.toMutableMap()
        val currentQty = currentMap[product] ?: 0
        currentMap[product] = currentQty + 1
        _cartItems.value = currentMap
    }

    fun decreaseProductQty(product: Product) {
        val currentMap = _cartItems.value.toMutableMap()
        val currentQty = currentMap[product] ?: return
        if (currentQty <= 1) {
            currentMap.remove(product)
        } else {
            currentMap[product] = currentQty - 1
        }
        _cartItems.value = currentMap
    }

    fun removeProductFromCart(product: Product) {
        val currentMap = _cartItems.value.toMutableMap()
        currentMap.remove(product)
        _cartItems.value = currentMap
    }

    fun clearCart() {
        _cartItems.value = emptyMap()
    }


    // --- State: Payment Flow ---
    private val _paymentMethod = MutableStateFlow("نقدي") // "نقدي" or "بطاقة"
    val paymentMethod: StateFlow<String> = _paymentMethod.asStateFlow()

    private val _amountReceivedText = MutableStateFlow("")
    val amountReceivedText: StateFlow<String> = _amountReceivedText.asStateFlow()

    fun updatePaymentMethod(method: String) {
        _paymentMethod.value = method
        if (method == "بطاقة") {
            // Card payment usually receives exact amount
            _amountReceivedText.value = cartTotalAmount.value.toInt().toString()
        } else {
            _amountReceivedText.value = ""
        }
    }

    fun updateAmountReceived(amountStr: String) {
        // Allow numeric inputs
        if (amountStr.isEmpty() || amountStr.all { it.isDigit() }) {
            _amountReceivedText.value = amountStr
        }
    }

    val amountReceived: StateFlow<Double> = _amountReceivedText.map { text ->
        text.toDoubleOrNull() ?: 0.0
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val amountChange: StateFlow<Double> = combine(
        cartTotalAmount,
        amountReceived,
        _paymentMethod
    ) { total, received, method ->
        if (method == "بطاقة") {
            0.0
        } else {
            val change = received - total
            if (change > 0) change else 0.0
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    private val _showPaymentDialog = MutableStateFlow(false)
    val showPaymentDialog: StateFlow<Boolean> = _showPaymentDialog.asStateFlow()

    fun setShowPaymentDialog(show: Boolean) {
        _showPaymentDialog.value = show
        if (show) {
            // Pre-fill amount received with standard suggestions or exact amount
            _amountReceivedText.value = ""
        }
    }

    fun submitOrder(onSuccess: (Long) -> Unit) {
        val total = cartTotalAmount.value
        val method = _paymentMethod.value
        val received = if (method == "بطاقة") total else amountReceived.value
        val change = if (method == "بطاقة") 0.0 else amountChange.value

        viewModelScope.launch {
            val activeShift = shiftLogs.value.firstOrNull { it.status == "مفتوحة" }
            val currentShiftId = activeShift?.id ?: 0

            val invoice = Invoice(
                totalAmount = total,
                paymentMethod = method,
                amountReceived = received,
                amountChange = change,
                status = "مدفوعة",
                shiftId = currentShiftId,
                orderType = _orderType.value
            )

            val items = _cartItems.value.map { (product, qty) ->
                InvoiceItem(
                    invoiceNumber = 0L, // Will be replaced in repository
                    productName = product.name,
                    productPrice = product.price,
                    productCost = product.costPrice,
                    quantity = qty
                )
            }

            val invoiceNo = repository.createInvoice(invoice, items)
            clearCart()
            _showPaymentDialog.value = false
            onSuccess(invoiceNo)
        }
    }


    // --- State: Menu Management CRUD ---
    // Section Management
    fun addCategory(name: String) {
        viewModelScope.launch {
            repository.insertCategory(Category(name = name))
        }
    }

    fun editCategory(category: Category) {
        viewModelScope.launch {
            repository.updateCategory(category)
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
        }
    }

    // Product Management
    fun addProduct(name: String, categoryId: Int, price: Double, costPrice: Double, imageResName: String) {
        viewModelScope.launch {
            repository.insertProduct(Product(
                name = name,
                categoryId = categoryId,
                price = price,
                costPrice = costPrice,
                imageResName = imageResName
            ))
        }
    }

    fun editProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }


    // --- State: Settings Custom Settings ---
    private val _printerName = MutableStateFlow("طابعة الكاشير الافتراضية (Xprinter)")
    val printerName: StateFlow<String> = _printerName.asStateFlow()

    fun updatePrinterName(name: String) {
        _printerName.value = name
    }

    // Active user fields removed to avoid duplicates; defined at the top of the ViewModel.

    fun openShift(name: String, openingCapital: Double) {
        viewModelScope.launch {
            repository.insertShiftLog(ShiftLog(
                shiftName = name,
                status = "مفتوحة",
                openingCapital = openingCapital,
                startTime = System.currentTimeMillis()
            ))
        }
    }

    fun closeShift(shiftId: Int, totalSales: Double, netProfit: Double) {
        viewModelScope.launch {
            val log = shiftLogs.value.find { it.id == shiftId } ?: return@launch
            repository.updateShiftLog(log.copy(
                endTime = System.currentTimeMillis(),
                status = "مغلقة",
                totalSales = totalSales,
                netProfit = netProfit
            ))
        }
    }

    val isPOSOpen: StateFlow<Boolean> = shiftLogs.map { logs ->
        logs.any { it.status == "مفتوحة" }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)


    fun deleteInvoice(invoice: Invoice) {
        viewModelScope.launch {
            repository.deleteInvoice(invoice)
        }
    }

    fun deleteShiftLog(shiftLog: ShiftLog) {
        viewModelScope.launch {
            repository.deleteShiftLog(shiftLog)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            repository.prepopulateIfEmpty()
        }
    }

    // --- State: Expanded Cart Sheet (Salla) ---
    private val _showCartSheet = MutableStateFlow(false)
    val showCartSheet: StateFlow<Boolean> = _showCartSheet.asStateFlow()

    fun setShowCartSheet(show: Boolean) {
        _showCartSheet.value = show
    }
}

class POSViewModelFactory(private val repository: POSRepository, private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(POSViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return POSViewModel(repository, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
