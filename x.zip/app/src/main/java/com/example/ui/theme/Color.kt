package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val POSPrimary = Color(0xFF13294B)
val POSAccent = Color(0xFFD4AF37)
val POSBackground = Color(0xFFF8FAFC)
val POSSurface = Color(0xFFFFFFFF)
val POSBorder = Color(0xFFE5E7EB)
val POSSuccess = Color(0xFF16A34A)
val POSWarning = Color(0xFFF59E0B)
val POSDanger = Color(0xFFDC2626)

val TextDark = Color(0xFF13294B) // Dark Navy
val TextMuted = Color(0xFF64748B) // Muted Gray-Blue
val CardBorder = Color(0xFFE5E7EB)
val LightGrayBg = Color(0xFFF8FAFC)

