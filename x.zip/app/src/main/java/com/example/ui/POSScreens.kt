package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import com.example.utils.ReceiptPrinterHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.input.KeyboardType

// ==========================================
// 1. HOME CASHIER SCREEN (واجهة الكاشير)
// ==========================================
@Composable
fun HomeScreen(viewModel: POSViewModel) {
    val categories by viewModel.categories.collectAsState()
    val filteredProducts by viewModel.filteredProducts.collectAsState()
    val selectedCategoryId by viewModel.selectedCategoryId.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    // Cart summary states
    val cartItems by viewModel.cartItems.collectAsState()
    val totalCount by viewModel.cartTotalCount.collectAsState()
    val totalAmount by viewModel.cartTotalAmount.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightGrayBg)
    ) {
        // Top Header Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp),
            colors = CardDefaults.cardColors(containerColor = POSSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .fillMaxWidth()
            ) {
                // Header details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(POSPrimary.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Restaurant, contentDescription = null, tint = POSPrimary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "مطعم ومطبخ النخبة",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = POSPrimary
                            )
                            Text(
                                text = "نظام كاشير POS محترف",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    // Action buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val activeUser by viewModel.activeUser.collectAsState()
                        Text(
                            text = activeUser,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSPrimary,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        IconButton(onClick = { viewModel.logout() }) {
                            Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = POSDanger)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Big Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("pos_search_bar"),
                    placeholder = { Text("البحث عن وجبة أو مشروب...", fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            focusManager.clearFocus()
                        }
                    ),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = LightGrayBg,
                        unfocusedContainerColor = LightGrayBg,
                        focusedBorderColor = POSPrimary,
                        unfocusedBorderColor = POSBorder
                    )
                )
            }
        }

        // Horizontal Category Tabs
        Spacer(modifier = Modifier.height(12.dp))
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // "All" tab
            item {
                val isSelected = selectedCategoryId == null
                CategoryTab(
                    name = "الكل 🍽️",
                    isSelected = isSelected,
                    onClick = { viewModel.selectCategory(null) }
                )
            }

            items(categories) { category ->
                val isSelected = selectedCategoryId == category.id
                CategoryTab(
                    name = category.name,
                    isSelected = isSelected,
                    onClick = { viewModel.selectCategory(category.id) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Product Grid list (2-columns)
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.SearchOff,
                        contentDescription = null,
                        modifier = Modifier.size(54.dp),
                        tint = TextMuted.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "عذراً، لم نجد أي منتجات تطابق البحث",
                        fontSize = 15.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredProducts) { product ->
                    ProductGridCard(
                        product = product,
                        onAddClick = {
                            viewModel.addProductToCart(product)
                            Toast.makeText(context, "تمت الإضافة: ${product.name}", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }

        // Persistent bottom cart bar (Editorial Aesthetic Styled)
        if (totalCount > 0) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable { viewModel.setShowCartSheet(true) }
                    .testTag("persistent_cart_bar"),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, POSBorder),
                colors = CardDefaults.cardColors(containerColor = POSSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(POSPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$totalCount",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "إجمالي السلة", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.SemiBold)
                            Text(text = formatIraqiDinar(totalAmount), fontSize = 16.sp, fontWeight = FontWeight.Black, color = POSPrimary)
                        }
                    }

                    // Elegant CTA button on right
                    Surface(
                        color = POSPrimary,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(44.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 16.dp)
                                .fillMaxHeight(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(text = "عرض السلة ودفع", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = POSAccent, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        } else {
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun CategoryTab(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag("category_tab_$name"),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (isSelected) POSPrimary else POSBorder),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) POSPrimary else LightGrayBg
        )
    ) {
        Text(
            text = name,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.White else POSPrimary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
        )
    }
}

@Composable
fun ProductGridCard(
    product: Product,
    onAddClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = POSSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, POSBorder)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Large Product Image
            Image(
                painter = getProductImagePainter(product.imageResName),
                contentDescription = product.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
                contentScale = ContentScale.Crop
            )

            // Content
            Column(
                modifier = Modifier
                    .padding(10.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = product.name,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatIraqiDinar(product.price),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = POSPrimary
                    )

                    // Circular Plus Button
                    IconButton(
                        onClick = onAddClick,
                        modifier = Modifier
                            .size(28.dp)
                            .background(POSAccent, CircleShape)
                            .testTag("add_to_cart_btn_${product.id}")
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "إضافة للسلة",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// 2. ORDERS SCREEN (واجهة الطلبات)
// ==========================================
@Composable
fun OrdersScreen(viewModel: POSViewModel) {
    val invoices by viewModel.invoices.collectAsState()
    val allInvoiceItems by viewModel.allInvoiceItems.collectAsState()
    val activeUser by viewModel.activeUser.collectAsState()
    val isDemo = activeUser != "ali"
    val context = LocalContext.current

    var invoiceToDelete by remember { mutableStateOf<Invoice?>(null) }

    if (invoiceToDelete != null) {
        AlertDialog(
            onDismissRequest = { invoiceToDelete = null },
            title = { Text("تأكيد حذف الفاتورة ⚠️", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف الفاتورة رقم #${invoiceToDelete!!.invoiceNumber} نهائياً؟ سيتم تعديل حسابات الوردية فوراً.", fontSize = 15.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        if (isDemo) {
                            Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                        } else {
                            viewModel.deleteInvoice(invoiceToDelete!!)
                            Toast.makeText(context, "تم حذف الفاتورة بنجاح", Toast.LENGTH_SHORT).show()
                        }
                        invoiceToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = POSDanger)
                ) {
                    Text("نعم، احذف", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { invoiceToDelete = null }) {
                    Text("إلغاء", fontWeight = FontWeight.Bold, color = TextMuted)
                }
            },
            containerColor = POSSurface
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightGrayBg)
            .padding(16.dp)
    ) {
        // Screen Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(POSPrimary.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = POSPrimary)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "سجل الطلبات والمبيعات",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = POSPrimary
                )
                Text(
                    text = "الفواتير المسجلة في الوردية الحالية والسابقة",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (invoices.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Receipt,
                        contentDescription = null,
                        modifier = Modifier.size(72.dp),
                        tint = TextMuted.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "لا توجد فواتير مسجلة بعد",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    Text(
                        text = "عند إتمام أي طلب بيع، ستظهر تفاصيل الفاتورة هنا.",
                        fontSize = 13.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp).padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(invoices) { invoice ->
                    InvoiceHistoryCard(
                        invoice = invoice,
                        onPrintClick = {
                            val items = allInvoiceItems.filter { it.invoiceNumber == invoice.invoiceNumber }
                            ReceiptPrinterHelper.printReceipt(context, invoice, items)
                        },
                        onDeleteClick = {
                            invoiceToDelete = invoice
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun InvoiceHistoryCard(
    invoice: Invoice,
    onPrintClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val dateStr = remember(invoice.orderTime) {
        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar"))
        sdf.format(Date(invoice.orderTime))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("invoice_card_${invoice.invoiceNumber}"),
        colors = CardDefaults.cardColors(containerColor = POSSurface),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, POSBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "فاتورة مبيعات ",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark
                    )
                    Text(
                        text = "#${invoice.invoiceNumber}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = POSPrimary
                    )
                }

                // Payment Status Badge
                Card(
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = POSSuccess.copy(alpha = 0.1f)
                    ),
                    border = BorderStroke(0.5.dp, POSSuccess.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "${invoice.status} (${invoice.orderType})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = POSSuccess,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "تاريخ الطلب", fontSize = 11.sp, color = TextMuted)
                    Text(text = dateStr, fontSize = 13.sp, color = TextDark, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "طريقة الدفع", fontSize = 11.sp, color = TextMuted)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Icon(
                            imageVector = if (invoice.paymentMethod == "نقدي") Icons.Default.Payments else Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = POSAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = invoice.paymentMethod, fontSize = 13.sp, color = TextDark, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Divider(color = POSBorder, modifier = Modifier.padding(vertical = 12.dp))

            // Pricing and Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "إجمالي الفاتورة", fontSize = 11.sp, color = TextMuted)
                    Text(
                        text = formatIraqiDinar(invoice.totalAmount),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = POSPrimary
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف الفاتورة", tint = POSDanger)
                    }

                    OutlinedButton(
                        onClick = onPrintClick,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, POSPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = POSPrimary)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إعادة طباعة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}


// ==========================================
// 3. MENU SCREEN (واجهة المنيو)
// ==========================================
@Composable
fun MenuScreen(viewModel: POSViewModel) {
    val categories by viewModel.categories.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()
    val activeUser by viewModel.activeUser.collectAsState()
    val isDemo = activeUser != "ali"

    var showAddCategory by remember { mutableStateOf(false) }
    var showAddProduct by remember { mutableStateOf(false) }

    var editingCategory by remember { mutableStateOf<Category?>(null) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightGrayBg)
            .padding(16.dp)
    ) {
        // Screen Title & Manage Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(POSPrimary.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.RestaurantMenu, contentDescription = null, tint = POSPrimary)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "إدارة المنيو وقائمة الطعام",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = POSPrimary
                    )
                    Text(
                        text = "تعديل، إضافة، وحذف الأقسام والوجبات",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large CTA Cards for fast adding
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable {
                        if (isDemo) {
                            Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                        } else {
                            showAddCategory = true
                        }
                    }
                    .testTag("add_category_quick_card"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = POSPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Category, contentDescription = null, tint = POSAccent, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("إضافة قسم جديد", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable {
                        if (isDemo) {
                            Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                        } else {
                            if (categories.isEmpty()) {
                                Toast.makeText(context, "يجب إضافة قسم واحد على الأقل أولاً!", Toast.LENGTH_LONG).show()
                            } else {
                                showAddProduct = true
                            }
                        }
                    }
                    .testTag("add_product_quick_card"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = POSAccent),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null, tint = POSPrimary, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("إضافة وجبة/منتج", color = POSPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Split lists for sections and foods
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Part 1: Sections Manager
            item {
                Text(
                    text = "الأقسام والتبويبات المتاحة (${categories.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = POSPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, POSBorder),
                    colors = CardDefaults.cardColors(containerColor = POSSurface)
                ) {
                    if (categories.isEmpty()) {
                        Text(
                            text = "لا يوجد أي أقسام مسجلة. اضغط إضافة قسم أعلاه.",
                            fontSize = 13.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(16.dp)
                        )
                    } else {
                        Column {
                            categories.forEachIndexed { index, cat ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = cat.name, color = TextDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(onClick = {
                                            if (isDemo) {
                                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                            } else {
                                                editingCategory = cat
                                            }
                                        }) {
                                            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = POSPrimary, modifier = Modifier.size(18.dp))
                                        }
                                        IconButton(onClick = {
                                            if (isDemo) {
                                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                            } else {
                                                viewModel.deleteCategory(cat)
                                                Toast.makeText(context, "تم حذف القسم: ${cat.name}", Toast.LENGTH_SHORT).show()
                                            }
                                        }) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = POSDanger, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                                if (index < categories.size - 1) {
                                    Divider(color = POSBorder, thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }
            }

            // Part 2: Product Manager
            item {
                Text(
                    text = "قائمة الوجبات والمنتجات (${allProducts.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = POSPrimary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            if (allProducts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, POSBorder),
                        colors = CardDefaults.cardColors(containerColor = POSSurface)
                    ) {
                        Text(
                            text = "لا توجد وجبات مسجلة حالياً.",
                            fontSize = 13.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(allProducts) { product ->
                    val productCategoryName = remember(product.categoryId, categories) {
                        categories.find { it.id == product.categoryId }?.name ?: "غير محدد"
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("manage_product_row_${product.id}"),
                        colors = CardDefaults.cardColors(containerColor = POSSurface),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, POSBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = getProductImagePainter(product.imageResName),
                                contentDescription = product.name,
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = product.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                                Row(
                                    modifier = Modifier.padding(top = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Card(
                                        shape = RoundedCornerShape(4.dp),
                                        colors = CardDefaults.cardColors(containerColor = POSPrimary.copy(alpha = 0.05f))
                                    ) {
                                        Text(
                                            text = productCategoryName,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = POSPrimary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = formatIraqiDinar(product.price), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = POSAccent)
                                }
                            }

                            Row {
                                IconButton(onClick = {
                                    if (isDemo) {
                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                    } else {
                                        editingProduct = product
                                    }
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل الوجبة", tint = POSPrimary, modifier = Modifier.size(20.dp))
                                }
                                IconButton(onClick = {
                                    if (isDemo) {
                                        Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                    } else {
                                        viewModel.deleteProduct(product)
                                        Toast.makeText(context, "تم حذف الوجبة: ${product.name}", Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف الوجبة", tint = POSDanger, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add Category Dialog
        if (showAddCategory) {
            AddEditCategoryDialog(
                category = null,
                onDismiss = { showAddCategory = false },
                onSave = { name ->
                    viewModel.addCategory(name)
                    showAddCategory = false
                    Toast.makeText(context, "تمت إضافة القسم: $name", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Edit Category Dialog
        if (editingCategory != null) {
            AddEditCategoryDialog(
                category = editingCategory,
                onDismiss = { editingCategory = null },
                onSave = { name ->
                    editingCategory?.let { cat ->
                        viewModel.editCategory(cat.copy(name = name))
                    }
                    editingCategory = null
                    Toast.makeText(context, "تم تعديل القسم بنجاح", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Add Product Dialog
        if (showAddProduct) {
            AddEditProductDialog(
                product = null,
                categories = categories,
                onDismiss = { showAddProduct = false },
                onSave = { name, catId, price, costPrice, imgRes ->
                    viewModel.addProduct(name, catId, price, costPrice, imgRes)
                    showAddProduct = false
                    Toast.makeText(context, "تمت إضافة المنتج بنجاح", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Edit Product Dialog
        if (editingProduct != null) {
            AddEditProductDialog(
                product = editingProduct,
                categories = categories,
                onDismiss = { editingProduct = null },
                onSave = { name, catId, price, costPrice, imgRes ->
                    editingProduct?.let { prod ->
                        viewModel.editProduct(prod.copy(name = name, categoryId = catId, price = price, costPrice = costPrice, imageResName = imgRes))
                    }
                    editingProduct = null
                    Toast.makeText(context, "تم تعديل المنتج بنجاح", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}


// ==========================================
// 4. SETTINGS SCREEN (واجهة الإعدادات)
// ==========================================
@Composable
fun SettingsScreen(viewModel: POSViewModel) {
    val isPOSOpen by viewModel.isPOSOpen.collectAsState()
    val printerName by viewModel.printerName.collectAsState()
    val shiftLogs by viewModel.shiftLogs.collectAsState()
    val invoices by viewModel.invoices.collectAsState()
    val allInvoiceItems by viewModel.allInvoiceItems.collectAsState()
    val activeUser by viewModel.activeUser.collectAsState()
    val isDemo = activeUser != "ali"

    var showOpenShiftDialog by remember { mutableStateOf(false) }
    var shiftNameInput by remember { mutableStateOf("") }
    var openingCapitalInput by remember { mutableStateOf("") }

    var showShiftReportDialog by remember { mutableStateOf<ShiftLog?>(null) }
    var showActiveReportDialog by remember { mutableStateOf(false) }

    var isScanningBluetooth by remember { mutableStateOf(false) }
    var scannedPrinters by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedPaperSize by remember { mutableStateOf("80mm") } // "58mm" or "80mm"

    var shiftToDelete by remember { mutableStateOf<ShiftLog?>(null) }
    var showClearDataConfirmation by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    // Find active shift
    val activeShift = remember(shiftLogs) { shiftLogs.firstOrNull { it.status == "مفتوحة" } }

    // Live calculations for active shift
    val liveSalesAndProfit = remember(activeShift, invoices, allInvoiceItems) {
        if (activeShift == null) Pair(0.0, 0.0)
        else {
            val shiftInvoices = invoices.filter { it.shiftId == activeShift.id }
            val sales = shiftInvoices.sumOf { it.totalAmount }
            val invoiceIds = shiftInvoices.map { it.invoiceNumber }.toSet()
            val shiftItems = allInvoiceItems.filter { it.invoiceNumber in invoiceIds }
            val profit = shiftItems.sumOf { (it.productPrice - it.productCost) * it.quantity }
            Pair(sales, profit)
        }
    }
    val liveSales = liveSalesAndProfit.first
    val liveProfit = liveSalesAndProfit.second

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LightGrayBg)
            .padding(16.dp)
    ) {
        // Screen Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(POSPrimary.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = POSPrimary)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "لوحة التحكم وإدارة الـ Shift",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black
                )
                Text(
                    text = "إدارة الورديات، الحسابات المالية، طابعات البلوتوث والأجهزة",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Active Shift Box
            item {
                Text(
                    text = "صندوق الـ Shift والوردية الحالية",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(2.dp, if (activeShift != null) POSSuccess else POSDanger)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .background(if (activeShift != null) POSSuccess else POSDanger, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (activeShift != null) "حالة الوردية: نشطة ومفتوحة" else "حالة الوردية: مغلقة",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = Color.Black
                                )
                            }

                            if (activeShift != null) {
                                Button(
                                    onClick = {
                                        if (isDemo) {
                                            Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                        } else {
                                            showActiveReportDialog = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = POSDanger),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("toggle_shift_button")
                                ) {
                                    Text("إغلاق الوردية", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            } else {
                                Button(
                                    onClick = {
                                        if (isDemo) {
                                            Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                                        } else {
                                            shiftNameInput = "الوردية الصباحية"
                                            openingCapitalInput = "150000"
                                            showOpenShiftDialog = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = POSSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("toggle_shift_button")
                                ) {
                                    Text("فتح وردية جديدة", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }

                        if (activeShift != null) {
                            Divider(modifier = Modifier.padding(vertical = 12.dp), color = POSBorder)

                            Text(
                                text = "الوردية: ${activeShift.shiftName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.Black
                            )

                            val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                            Text(
                                text = "وقت البدء: ${sdf.format(Date(activeShift.startTime))}",
                                fontSize = 12.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(top = 2.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Stats Grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Opening Capital
                                Card(
                                    modifier = Modifier.weight(1f),
                                    colors = CardDefaults.cardColors(containerColor = LightGrayBg),
                                    border = BorderStroke(1.dp, POSBorder)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("الرأسمال الافتتاحي", fontSize = 11.sp, color = TextMuted)
                                        Text(
                                            text = formatIraqiDinar(activeShift.openingCapital),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                    }
                                }

                                // Sales
                                Card(
                                    modifier = Modifier.weight(1f),
                                    colors = CardDefaults.cardColors(containerColor = LightGrayBg),
                                    border = BorderStroke(1.dp, POSBorder)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("إجمالي المبيعات", fontSize = 11.sp, color = TextMuted)
                                        Text(
                                            text = formatIraqiDinar(liveSales),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Black,
                                            color = POSPrimary
                                        )
                                    }
                                }

                                // Net Profit
                                Card(
                                    modifier = Modifier.weight(1f),
                                    colors = CardDefaults.cardColors(containerColor = LightGrayBg),
                                    border = BorderStroke(1.dp, POSBorder)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("صافي الأرباح", fontSize = 11.sp, color = TextMuted)
                                        Text(
                                            text = formatIraqiDinar(liveProfit),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Black,
                                            color = POSSuccess
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 2: Printer settings and Bluetooth scanning
            item {
                Text(
                    text = "إعدادات الطابعة الحرارية وبلوتوث",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, POSBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("الطابعة المتصلة حالياً", fontSize = 11.sp, color = TextMuted)
                                Text(
                                    text = printerName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black
                                )
                            }

                            Button(
                                onClick = {
                                    isScanningBluetooth = true
                                    scannedPrinters = emptyList()
                                    // Simulate bluetooth scanning
                                    val printers = listOf(
                                        "XP-80 Printer (Bluetooth Thermal 80mm)",
                                        "ZJiang-5809 (Bluetooth Thermal 58mm)",
                                        "Sumni POS Printer (Internal)"
                                    )
                                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                        scannedPrinters = printers
                                        isScanningBluetooth = false
                                        Toast.makeText(context, "اكتمل البحث عن طابعات البلوتوث المجاورة", Toast.LENGTH_SHORT).show()
                                    }, 1500)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                shape = RoundedCornerShape(8.dp),
                                enabled = !isScanningBluetooth
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("البحث عن طابعات بلوتوث مجاورة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }

                        if (isScanningBluetooth) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = POSPrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("جاري فحص النطاق والبحث عن طابعات البلوتوث المجاورة...", fontSize = 12.sp, color = TextMuted)
                            }
                        }

                        if (scannedPrinters.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("الأجهزة المكتشفة القابلة للاتصال:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = POSPrimary)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = LightGrayBg),
                                border = BorderStroke(1.dp, POSBorder)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    scannedPrinters.forEach { printer ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.updatePrinterName(printer)
                                                    Toast.makeText(context, "تم الاتصال بنجاح بـ $printer", Toast.LENGTH_SHORT).show()
                                                    scannedPrinters = emptyList()
                                                }
                                                .padding(8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(text = printer, fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                            Text(text = "اتصال 🔗", fontSize = 11.sp, color = POSAccent, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = POSBorder)

                        // Paper Size toggles (58mm / 80mm)
                        Text("عرض ورق الطباعة المعتمد", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = POSPrimary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            listOf("58mm", "80mm").forEach { size ->
                                val isSelected = selectedPaperSize == size
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedPaperSize = size
                                            Toast.makeText(context, "تم تحديد مقاس الورق: $size", Toast.LENGTH_SHORT).show()
                                        },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) POSPrimary else POSSurface
                                    ),
                                    border = BorderStroke(1.dp, if (isSelected) POSPrimary else POSBorder)
                                ) {
                                    Box(modifier = Modifier.padding(10.dp), contentAlignment = Alignment.Center) {
                                        Text(
                                            text = size,
                                            color = if (isSelected) Color.White else Color.Black,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 3: Shift Log History (سجل الورديات السابقة)
            item {
                Text(
                    text = "سجل الورديات السابقة والأرشيف",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, POSBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        val closedShifts = remember(shiftLogs) { shiftLogs.filter { it.status == "مغلقة" } }
                        if (closedShifts.isEmpty()) {
                            Text(text = "لا توجد سجلات ورديات مغلقة سابقة في الأرشيف.", fontSize = 12.sp, color = TextMuted, modifier = Modifier.padding(8.dp))
                        } else {
                            closedShifts.forEachIndexed { idx, log ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showShiftReportDialog = log }
                                        .padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = log.shiftName, fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                        val startSdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                                        Text(text = "تاريخ الوردية: ${startSdf.format(Date(log.startTime))}", fontSize = 11.sp, color = TextMuted)
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "المبيعات: " + formatIraqiDinar(log.totalSales),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = POSPrimary
                                            )
                                            Text(
                                                text = "صافي الربح: " + formatIraqiDinar(log.netProfit),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = POSSuccess
                                            )
                                        }

                                        IconButton(
                                            onClick = {
                                                shiftToDelete = log
                                            }
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف الوردية", tint = POSDanger)
                                        }
                                    }
                                }
                                if (idx < closedShifts.size - 1) {
                                    Divider(color = POSBorder, thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }
            }

            // Section 4: Advanced Actions / System Care
            item {
                Text(
                    text = "الإجراءات المتقدمة وصيانة النظام",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, POSDanger.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "منطقة الخطر ⚠️",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSDanger
                        )
                        Text(
                            text = "مسح جميع البيانات سيقوم بتفريغ الكاشير تماماً وإعادة تهيئة النظام لقيم المصنع الافتراضية للوجبات والأقسام.",
                            fontSize = 12.sp,
                            color = TextMuted,
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )

                        Button(
                            onClick = { showClearDataConfirmation = true },
                            colors = ButtonDefaults.buttonColors(containerColor = POSDanger),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("مسح جميع البيانات بالكامل", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Dialogs
        if (shiftToDelete != null) {
            AlertDialog(
                onDismissRequest = { shiftToDelete = null },
                title = { Text("تأكيد حذف الوردية ⚠️", fontWeight = FontWeight.Bold) },
                text = { Text("هل أنت متأكد من حذف الوردية '${shiftToDelete!!.shiftName}' بالكامل؟ سيتم مسح أرشيف هذه الوردية نهائياً ولا يمكن استرجاعه.", fontSize = 15.sp) },
                confirmButton = {
                    Button(
                        onClick = {
                            if (isDemo) {
                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                            } else {
                                viewModel.deleteShiftLog(shiftToDelete!!)
                                Toast.makeText(context, "تم حذف الوردية بنجاح", Toast.LENGTH_SHORT).show()
                            }
                            shiftToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = POSDanger)
                    ) {
                        Text("نعم، احذف الوردية", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { shiftToDelete = null }) {
                        Text("إلغاء", fontWeight = FontWeight.Bold, color = TextMuted)
                    }
                },
                containerColor = POSSurface
            )
        }

        if (showClearDataConfirmation) {
            AlertDialog(
                onDismissRequest = { showClearDataConfirmation = false },
                title = { Text("⚠️ تحذير أمني هام جداً!", fontWeight = FontWeight.Bold, color = POSDanger) },
                text = { Text("هل أنت متأكد بنسبة 100% من رغبتك في مسح كافة البيانات من فواتير، أقسام، وجبات، وسجلات الورديات والبدء من جديد؟ هذا الإجراء لا يمكن التراجع عنه أبدًا!", fontSize = 15.sp) },
                confirmButton = {
                    Button(
                        onClick = {
                            if (isDemo) {
                                Toast.makeText(context, "عذراً، هذه الصلاحية متوفرة فقط لحساب المدير (ali).", Toast.LENGTH_LONG).show()
                            } else {
                                viewModel.clearAllData()
                                Toast.makeText(context, "تم إعادة تهيئة النظام بنجاح!", Toast.LENGTH_LONG).show()
                            }
                            showClearDataConfirmation = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = POSDanger)
                    ) {
                        Text("نعم، امسح كل شيء", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearDataConfirmation = false }) {
                        Text("إلغاء الإجراء", fontWeight = FontWeight.Bold, color = TextMuted)
                    }
                },
                containerColor = POSSurface
            )
        }
        // 1. Open Shift Dialog
        if (showOpenShiftDialog) {
            Dialog(onDismissRequest = { showOpenShiftDialog = false }) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("فتح وردية جديدة", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = shiftNameInput,
                            onValueChange = { shiftNameInput = it },
                            label = { Text("اسم الوردية") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = openingCapitalInput,
                            onValueChange = {
                                if (it.isEmpty() || it.all { c -> c.isDigit() }) {
                                    openingCapitalInput = it
                                }
                            },
                            label = { Text("رأس المال الافتتاحي د.ع") },
                            trailingIcon = { Text("د.ع", fontWeight = FontWeight.Bold) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { showOpenShiftDialog = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("إلغاء", color = TextMuted)
                            }
                            Button(
                                onClick = {
                                    if (shiftNameInput.isNotBlank() && openingCapitalInput.isNotBlank()) {
                                        viewModel.openShift(shiftNameInput, openingCapitalInput.toDoubleOrNull() ?: 0.0)
                                        showOpenShiftDialog = false
                                        Toast.makeText(context, "تم فتح وردية جديدة بنجاح", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = POSPrimary)
                            ) {
                                Text("فتح الوردية", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 2. Active Shift Summary Close Report Dialog
        if (showActiveReportDialog && activeShift != null) {
            Dialog(onDismissRequest = { showActiveReportDialog = false }) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "تقرير إغلاق الوردية الحالية 📊",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                        Text(text = "اسم الوردية: ${activeShift.shiftName}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        Text(text = "تاريخ البدء: ${sdf.format(Date(activeShift.startTime))}", fontSize = 11.sp, color = TextMuted)
                        Text(text = "تاريخ الإغلاق: ${sdf.format(Date())}", fontSize = 11.sp, color = TextMuted)

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = POSBorder)

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("رأس المال الافتتاحي:", fontSize = 13.sp, color = TextMuted)
                                Text(formatIraqiDinar(activeShift.openingCapital), fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("إجمالي المبيعات:", fontSize = 13.sp, color = TextMuted)
                                Text(formatIraqiDinar(liveSales), fontSize = 13.sp, fontWeight = FontWeight.Black, color = POSPrimary)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("صافي الأرباح المحققة:", fontSize = 13.sp, color = TextMuted)
                                Text(formatIraqiDinar(liveProfit), fontSize = 13.sp, fontWeight = FontWeight.Black, color = POSSuccess)
                            }
                            Divider(color = POSBorder, modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("إجمالي النقدية بالصندوق:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text(formatIraqiDinar(activeShift.openingCapital + liveSales), fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { showActiveReportDialog = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("رجوع", color = TextMuted)
                            }
                            Button(
                                onClick = {
                                    viewModel.closeShift(activeShift.id, liveSales, liveProfit)
                                    showActiveReportDialog = false
                                    Toast.makeText(context, "تم إغلاق الوردية وحفظ التقرير بنجاح", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1.5f),
                                colors = ButtonDefaults.buttonColors(containerColor = POSDanger)
                            ) {
                                Text("تأكيد الإغلاق والطباعة", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 3. Past Shift Summary Archive Report Dialog
        if (showShiftReportDialog != null) {
            val report = showShiftReportDialog!!
            Dialog(onDismissRequest = { showShiftReportDialog = null }) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface),
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "تقرير الوردية المؤرشف 📂",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val sdf = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.US)
                        Text(text = "اسم الوردية: ${report.shiftName}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        Text(text = "تاريخ البدء: ${sdf.format(Date(report.startTime))}", fontSize = 11.sp, color = TextMuted)
                        if (report.endTime != null) {
                            Text(text = "تاريخ الإغلاق: ${sdf.format(Date(report.endTime))}", fontSize = 11.sp, color = TextMuted)
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = POSBorder)

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("رأس المال الافتتاحي:", fontSize = 13.sp, color = TextMuted)
                                Text(formatIraqiDinar(report.openingCapital), fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("إجمالي المبيعات:", fontSize = 13.sp, color = TextMuted)
                                Text(formatIraqiDinar(report.totalSales), fontSize = 13.sp, fontWeight = FontWeight.Black, color = POSPrimary)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("صافي الأرباح:", fontSize = 13.sp, color = TextMuted)
                                Text(formatIraqiDinar(report.netProfit), fontSize = 13.sp, fontWeight = FontWeight.Black, color = POSSuccess)
                            }
                            Divider(color = POSBorder, modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("النقدية عند الإغلاق:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text(formatIraqiDinar(report.openingCapital + report.totalSales), fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = { showShiftReportDialog = null },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = POSPrimary)
                        ) {
                            Text("إغلاق النافذة", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrialExpiredScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .statusBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = POSDanger,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "انتهت المدة التجريبية، يرجى التواصل مع المطور: 07810936407",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
fun LoginScreen(viewModel: POSViewModel) {
    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Block hardware back button on Login screen to prevent bypass or unexpected exits
    androidx.activity.compose.BackHandler {
        (context as? android.app.Activity)?.finish()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)) // SaaS white/gray clean canvas
            .statusBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight()
                .background(Color.White, RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Large Bold Black Title Header (SaaS style)
            Text(
                text = "تسجيل الدخول",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Text(
                text = "نظام إدارة المبيعات والكاشير الذكي",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // Input: Username
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "اسم المستخدم",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black
                )
                OutlinedTextField(
                    value = usernameInput,
                    onValueChange = { usernameInput = it },
                    placeholder = { Text("أدخل اسم المستخدم", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth().testTag("username_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color.Black,
                        unfocusedBorderColor = Color(0xFFCBD5E1),
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black
                    )
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Input: Password
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "كلمة المرور",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.Black
                )
                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = { passwordInput = it },
                    placeholder = { Text("أدخل كلمة المرور", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth().testTag("password_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color.Black,
                        unfocusedBorderColor = Color(0xFFCBD5E1),
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black
                    )
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Login Button - Smooth and formal (10.dp border radius)
            Button(
                onClick = {
                    if (usernameInput.trim().isEmpty() || passwordInput.trim().isEmpty()) {
                        Toast.makeText(context, "يرجى إدخال اسم المستخدم وكلمة المرور", Toast.LENGTH_SHORT).show()
                    } else {
                        val success = viewModel.login(usernameInput.trim(), passwordInput.trim())
                        if (success) {
                            Toast.makeText(context, "تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show()
                        } else {
                            val isExpired = viewModel.isTrialExpired.value
                            if (isExpired) {
                                Toast.makeText(context, "انتهت المدة التجريبية للحساب", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "اسم المستخدم أو كلمة المرور غير صحيحة", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Black, // Sleek black SaaS style
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "دخول",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
