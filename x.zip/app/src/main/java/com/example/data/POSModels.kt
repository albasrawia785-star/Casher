package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String
) : Serializable

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val categoryId: Int,
    val name: String,
    val price: Double, // in Iraqi Dinars
    val costPrice: Double = 0.0, // Cost price in Iraqi Dinars
    val imageResName: String // resource identifier string
) : Serializable

@Entity(tableName = "invoices")
data class Invoice(
    @PrimaryKey(autoGenerate = true) val invoiceNumber: Long = 0L,
    val orderTime: Long = System.currentTimeMillis(),
    val totalAmount: Double,
    val paymentMethod: String, // "نقدي" or "بطاقة"
    val amountReceived: Double,
    val amountChange: Double,
    val status: String, // "مدفوعة" or "معلقة"
    val shiftId: Int = 0, // The shift this invoice belongs to
    val orderType: String = "صالة" // "سفري" or "صالة"
) : Serializable

@Entity(tableName = "invoice_items")
data class InvoiceItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val invoiceNumber: Long,
    val productName: String,
    val productPrice: Double,
    val productCost: Double = 0.0, // Cost price at purchase
    val quantity: Int
) : Serializable

@Entity(tableName = "shift_logs")
data class ShiftLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val shiftName: String,
    val startTime: Long = System.currentTimeMillis(),
    val endTime: Long? = null,
    val status: String, // "مفتوحة" or "مغلقة"
    val openingCapital: Double = 0.0,
    val totalSales: Double = 0.0,
    val netProfit: Double = 0.0
) : Serializable
