package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class POSRepository(private val posDao: POSDao) {

    val allCategories: Flow<List<Category>> = posDao.getAllCategories()
    val allProducts: Flow<List<Product>> = posDao.getAllProducts()
    val allInvoices: Flow<List<Invoice>> = posDao.getAllInvoices()
    val allShiftLogs: Flow<List<ShiftLog>> = posDao.getAllShiftLogs()
    val allInvoiceItems: Flow<List<InvoiceItem>> = posDao.getAllInvoiceItems()

    fun getProductsByCategory(categoryId: Int): Flow<List<Product>> {
        return posDao.getProductsByCategory(categoryId)
    }

    fun searchProducts(query: String): Flow<List<Product>> {
        return posDao.searchProducts("%$query%")
    }

    fun getItemsForInvoice(invoiceNumber: Long): Flow<List<InvoiceItem>> {
        return posDao.getItemsForInvoice(invoiceNumber)
    }

    suspend fun insertCategory(category: Category): Long = posDao.insertCategory(category)
    suspend fun updateCategory(category: Category) = posDao.updateCategory(category)
    suspend fun deleteCategory(category: Category) = posDao.deleteCategory(category)

    suspend fun insertProduct(product: Product): Long = posDao.insertProduct(product)
    suspend fun updateProduct(product: Product) = posDao.updateProduct(product)
    suspend fun deleteProduct(product: Product) = posDao.deleteProduct(product)

    suspend fun createInvoice(invoice: Invoice, items: List<InvoiceItem>): Long {
        val invoiceNumber = posDao.insertInvoice(invoice)
        items.forEach { item ->
            posDao.insertInvoiceItem(item.copy(invoiceNumber = invoiceNumber))
        }
        return invoiceNumber
    }

    suspend fun insertShiftLog(shiftLog: ShiftLog): Long = posDao.insertShiftLog(shiftLog)
    suspend fun updateShiftLog(shiftLog: ShiftLog) = posDao.updateShiftLog(shiftLog)
    suspend fun deleteShiftLog(shiftLog: ShiftLog) = posDao.deleteShiftLog(shiftLog)

    suspend fun deleteInvoice(invoice: Invoice) {
        posDao.deleteInvoice(invoice)
        posDao.deleteInvoiceItemsByInvoiceNo(invoice.invoiceNumber)
    }

    suspend fun clearAllData() {
        posDao.clearCategories()
        posDao.clearProducts()
        posDao.clearInvoices()
        posDao.clearInvoiceItems()
        posDao.clearShiftLogs()
    }

    suspend fun prepopulateIfEmpty() {
        val existingCats = posDao.getAllCategories().first()
        if (existingCats.isEmpty()) {
            // Add default categories
            val catGrills = posDao.insertCategory(Category(name = "مشويات"))
            val catBurger = posDao.insertCategory(Category(name = "بركر"))
            val catPizza = posDao.insertCategory(Category(name = "بيتزا"))
            val catDrinks = posDao.insertCategory(Category(name = "مشروبات"))
            val catSweets = posDao.insertCategory(Category(name = "حلويات"))

            // Add default products using the generated image resources
            // Cat 1: Grills
            posDao.insertProduct(Product(
                categoryId = catGrills.toInt(),
                name = "كباب لحم عراقي فاخر",
                price = 15000.0,
                costPrice = 9000.0,
                imageResName = "img_grill_1784408854318"
            ))
            posDao.insertProduct(Product(
                categoryId = catGrills.toInt(),
                name = "تكة دجاج على الفحم",
                price = 12000.0,
                costPrice = 7000.0,
                imageResName = "img_grill_1784408854318"
            ))
            posDao.insertProduct(Product(
                categoryId = catGrills.toInt(),
                name = "كص لحم عراقي",
                price = 14000.0,
                costPrice = 8500.0,
                imageResName = "img_grill_1784408854318"
            ))

            // Cat 2: Burger
            posDao.insertProduct(Product(
                categoryId = catBurger.toInt(),
                name = "بركر لحم كلاسيك",
                price = 8000.0,
                costPrice = 4500.0,
                imageResName = "img_burger_1784408864721"
            ))
            posDao.insertProduct(Product(
                categoryId = catBurger.toInt(),
                name = "بركر دجاج مقرمش دبل",
                price = 7500.0,
                costPrice = 4000.0,
                imageResName = "img_burger_1784408864721"
            ))

            // Cat 3: Pizza
            posDao.insertProduct(Product(
                categoryId = catPizza.toInt(),
                name = "بيتزا بيبيروني إيطالية",
                price = 10000.0,
                costPrice = 5500.0,
                imageResName = "img_pizza_1784408876158"
            ))
            posDao.insertProduct(Product(
                categoryId = catPizza.toInt(),
                name = "بيتزا الخضار المشكلة",
                price = 9000.0,
                costPrice = 4800.0,
                imageResName = "img_pizza_1784408876158"
            ))
            posDao.insertProduct(Product(
                categoryId = catPizza.toInt(),
                name = "بيتزا الفصول الأربعة",
                price = 11000.0,
                costPrice = 6000.0,
                imageResName = "img_pizza_1784408876158"
            ))

            // Cat 4: Drinks
            posDao.insertProduct(Product(
                categoryId = catDrinks.toInt(),
                name = "ليموناضة بالنعناع الطازج",
                price = 3500.0,
                costPrice = 1200.0,
                imageResName = "img_drink_1784408886919"
            ))
            posDao.insertProduct(Product(
                categoryId = catDrinks.toInt(),
                name = "موهيتو فراولة كولد",
                price = 4500.0,
                costPrice = 1500.0,
                imageResName = "img_drink_1784408886919"
            ))
            posDao.insertProduct(Product(
                categoryId = catDrinks.toInt(),
                name = "بيبسي قوطية بارد",
                price = 1000.0,
                costPrice = 450.0,
                imageResName = "img_drink_1784408886919"
            ))

            // Cat 5: Sweets
            posDao.insertProduct(Product(
                categoryId = catSweets.toInt(),
                name = "كنافة نابلسية بالجبن الفاخر",
                price = 5000.0,
                costPrice = 2800.0,
                imageResName = "img_grill_1784408854318" // Fallback placeholder
            ))
            posDao.insertProduct(Product(
                categoryId = catSweets.toInt(),
                name = "بقلاوة بغدادية بالفستق",
                price = 6000.0,
                costPrice = 3200.0,
                imageResName = "img_grill_1784408854318" // Fallback placeholder
            ))

            // Add an initial active shift
            posDao.insertShiftLog(ShiftLog(
                shiftName = "الوردية الافتتاحية المباشرة",
                status = "مفتوحة",
                openingCapital = 150000.0
            ))
        }
    }
}
