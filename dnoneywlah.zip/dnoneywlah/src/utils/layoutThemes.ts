import { AppLayoutTheme } from '../types';

export interface LayoutThemeDefinition {
  id: AppLayoutTheme;
  title: string;
  englishTitle: string;
  subtitle: string;
  badge: string;
  icon: string;
  accentColor: string;
  borderColor: string;
  bgGradient: string;
  description: string;
  keyFeatures: string[];
  appBgClass: string;
  headerBgClass: string;
  controlsBgClass: string;
  navBgClass: string;
  cardBgClass: string;
}

export const LAYOUT_THEMES: LayoutThemeDefinition[] = [
  {
    id: 'classic',
    title: 'النمط الكلاسيكي الأصلي',
    englishTitle: 'Classic Native Pro',
    subtitle: 'التصميم المعتمد الأصلي الأكثر بساطة وملاءمة',
    badge: 'الأصلي',
    icon: 'fa-solid fa-layer-group',
    accentColor: 'text-blue-600 bg-blue-50 border-blue-200',
    borderColor: 'border-slate-200',
    bgGradient: 'from-blue-50/50 to-white',
    description: 'بطاقات بيضاء ناعمة مع شريط حالة جانبي ملون وعناصر تحكم سريعة وواضحة.',
    keyFeatures: ['شريط ملون للحالة', 'قائمة خيارات منبثقة', 'عرض سريع لبيانات الهاتف والتاريخ'],
    appBgClass: 'bg-slate-100 text-slate-800',
    headerBgClass: 'bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white',
    controlsBgClass: 'bg-slate-50 border-slate-200/60',
    navBgClass: 'bg-white/95 border-slate-200 text-slate-700',
    cardBgClass: 'bg-white border-slate-200/80 shadow-xs',
  }
];

export function getLayoutThemeMeta(_themeId?: AppLayoutTheme | string): LayoutThemeDefinition {
  return LAYOUT_THEMES[0];
}
