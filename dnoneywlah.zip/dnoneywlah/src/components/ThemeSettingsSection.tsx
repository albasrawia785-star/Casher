import React from 'react';
import { AppLayoutTheme, AppSettings } from '../types';
import { LAYOUT_THEMES, getLayoutThemeMeta } from '../utils/layoutThemes';
import { useI18n } from '../i18n/index.tsx';

interface ThemeSettingsSectionProps {
  currentTheme: AppLayoutTheme;
  onSelectTheme: (theme: AppLayoutTheme) => void;
  isAdmin?: boolean;
}

export const ThemeSettingsSection: React.FC<ThemeSettingsSectionProps> = ({
  currentTheme = 'classic',
  onSelectTheme,
  isAdmin = false,
}) => {
  const { t } = useI18n();

  return (
    <div className="space-y-4 text-start">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <i className="fa-solid fa-wand-magic-sparkles text-indigo-600"></i>
            <span>تخصيص شكل وتصميم التطبيق (10 تصاميم متطورة)</span>
          </h4>
          <p className="text-xs text-slate-500 mt-0.5">
            اختر التصميم والشكل الهندسي للبطاقات والقوائم ليناسب نشاطك التجاري بدقة وسلاسة تامة.
          </p>
        </div>

        <div className="shrink-0 bg-indigo-50 border border-indigo-200 text-indigo-700 px-2.5 py-1 rounded-xl text-xs font-bold font-mono">
          {LAYOUT_THEMES.length} مظاهر
        </div>
      </div>

      {/* Grid of 10 Layout Themes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {LAYOUT_THEMES.map((item) => {
          const isSelected = currentTheme === item.id;
          return (
            <div
              key={item.id}
              onClick={() => onSelectTheme(item.id)}
              className={`relative rounded-2xl p-3.5 border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                isSelected
                  ? 'border-indigo-600 bg-indigo-50/40 shadow-sm ring-2 ring-indigo-500/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/50'
              }`}
            >
              {/* Top Row: Icon + Title + Badge + Active Radio */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm shrink-0 border ${item.accentColor}`}>
                    <i className={item.icon}></i>
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-black text-xs sm:text-[13px] text-slate-900 leading-tight">
                        {item.title}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        {item.badge}
                      </span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 mt-0.5 truncate">
                      {item.englishTitle}
                    </div>
                  </div>
                </div>

                <div className="shrink-0">
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-600 text-white'
                      : 'border-slate-300 bg-white'
                  }`}>
                    {isSelected && <i className="fa-solid fa-check text-[10px]"></i>}
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-[11.5px] text-slate-600 leading-relaxed">
                {item.description}
              </p>

              {/* Key Features Tags */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-100">
                {item.keyFeatures.map((feat, idx) => (
                  <span
                    key={idx}
                    className="text-[9.5px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md"
                  >
                    • {feat}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
