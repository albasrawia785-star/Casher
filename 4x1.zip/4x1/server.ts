import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import rateLimit from "express-rate-limit";
import { ALDION_DATABASE_CONFIG, normalizeTursoUrl } from "./aldion";

// Get database credentials from aldion.ts (or environment variable if specified)
const getTursoConfig = () => {
  const rawUrl = process.env.TURSO_URL || ALDION_DATABASE_CONFIG.url;
  const url = normalizeTursoUrl(rawUrl);
  const token = process.env.TURSO_TOKEN || ALDION_DATABASE_CONFIG.token;
  return { url, token };
};

// Ensure database tables and columns exist
async function ensureUsersSchema() {
  const { url, token } = getTursoConfig();
  if (!url || !token) return;

  const createStatements = [
    `CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      text TEXT NOT NULL
    );`,
    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      branch_name TEXT DEFAULT 'الفرع الرئيسي',
      is_active INTEGER DEFAULT 1,
      subscription_type TEXT DEFAULT 'permanent',
      subscription_expires_at TEXT,
      plain_password TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS debtors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      amount REAL DEFAULT 0,
      status TEXT DEFAULT 'دين مرتفع',
      user_id INTEGER DEFAULT 1,
      created_at TEXT,
      history TEXT
    );`,
    "ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1;",
    "ALTER TABLE users ADD COLUMN subscription_type TEXT DEFAULT 'permanent';",
    "ALTER TABLE users ADD COLUMN subscription_expires_at TEXT;",
    "ALTER TABLE users ADD COLUMN plain_password TEXT;",
    "ALTER TABLE debtors ADD COLUMN created_at TEXT;",
    "ALTER TABLE debtors ADD COLUMN history TEXT;",
  ];

  for (const sql of createStatements) {
    try {
      await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql, args: [] } },
            { type: "close" },
          ],
        }),
      });
    } catch {
      // Ignore if table/column already exists
    }
  }
}

async function startServer() {
  ensureUsersSchema().catch((err) => console.warn("Schema initialization notice:", err?.message || err));
  const app = express();
  const PORT = 3000;

  // Trust first proxy (Cloud Run / Nginx reverse proxy)
  app.set("trust proxy", 1);

  // 1. Cross-Origin Resource Sharing (CORS) - Allows mobile APK & web clients to connect safely
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Shield-Client, X-Shield-Timestamp, X-Shield-Nonce, X-Shield-Signature");
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });

  // 2. Security Headers Middleware (prevents MIME sniffing, clickjacking, etc.)
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    next();
  });

  app.use(express.json({ limit: "1mb" }));

  // 2. Rate Limiting (Brute-force protection)
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 600, // max 600 requests per 15 minutes per IP
    standardHeaders: true,
    legacyHeaders: false,
    validate: false,
    message: { error: "تم تجاوز الحد المسموح من الطلبات، يرجى المحاولة لاحقاً بعد عدة دقائق" },
  });

  const dbLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 120, // max 120 database operations per minute per IP
    standardHeaders: true,
    legacyHeaders: false,
    validate: false,
    message: { error: "طلبات متكررة بسرعة كبيرة، يرجى التمهل" },
  });

  app.use("/api/", apiLimiter);

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Test Turso Database Connection (for Admin in Settings)
  app.get("/api/turso/test-connection", async (_req, res) => {
    const { url, token } = getTursoConfig();
    if (!url || !token) {
      return res.status(400).json({
        success: false,
        message: "إعدادات قاعدة البيانات في ملف aldion غير مكتملة (الرابط أو الرمز مفقود)",
      });
    }

    try {
      const startTime = Date.now();
      const testResponse = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql: "SELECT 1 as test_connection;", args: [] } },
            { type: "close" },
          ],
        }),
      });

      const responseTime = Date.now() - startTime;

      if (!testResponse.ok) {
        const errorText = await testResponse.text();
        return res.status(testResponse.status).json({
          success: false,
          statusCode: testResponse.status,
          message: `فشل الاتصال بقاعدة البيانات (${testResponse.status}): ${errorText}`,
        });
      }

      // Also extract hostname for display safely
      let host = "";
      try {
        const urlObj = new URL(url);
        host = urlObj.hostname;
      } catch {
        host = "Turso Cloud";
      }

      return res.json({
        success: true,
        message: "الاتصال بقاعدة البيانات ناجح ومستقر!",
        host,
        responseTimeMs: responseTime,
      });
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        message: `تعذر الوصول إلى خادم قاعدة البيانات: ${err?.message || "خطأ شبكة"}`,
      });
    }
  });

  // 3. SQL Firewall & Proxy endpoint for Turso database queries with Anti-Replay & Client Verification
  const _SEEN_NONCES = new Map<string, number>();

  // Clean stale nonces every 5 minutes
  setInterval(() => {
    const now = Date.now();
    for (const [nonce, ts] of _SEEN_NONCES.entries()) {
      if (now - ts > 60000) {
        _SEEN_NONCES.delete(nonce);
      }
    }
  }, 300000);

  app.post("/api/turso", dbLimiter, async (req, res) => {
    try {
      // Security Check 0: Anti-Replay and Timestamp freshness verification
      const shieldTimestamp = req.headers["x-shield-timestamp"];
      const shieldNonce = req.headers["x-shield-nonce"];

      if (shieldTimestamp && shieldNonce) {
        const reqTime = parseInt(String(shieldTimestamp), 10);
        const now = Date.now();
        // Reject expired or futuristic requests (skew > 2 minutes)
        if (Math.abs(now - reqTime) > 120000) {
          return res.status(403).json({ error: "انتهت صلاحية الطلب الأمني، يرجى إعادة المحاولة" });
        }
        // Reject replayed nonces
        const nonceKey = String(shieldNonce);
        if (_SEEN_NONCES.has(nonceKey)) {
          return res.status(403).json({ error: "تم حظر محاولة إعادة إرسال الطلب (Replay Attack Detected)" });
        }
        _SEEN_NONCES.set(nonceKey, now);
      }

      const { sql, args = [] } = req.body;
      if (!sql || typeof sql !== "string") {
        return res.status(400).json({ error: "Missing or invalid SQL statement" });
      }

      const trimmedSql = sql.trim();

      // Security Check A: Reject dangerous destructive DDL & admin statements
      const forbiddenKeywords = /\b(DROP|TRUNCATE|ALTER|GRANT|REVOKE|PRAGMA|ATTACH|DETACH|EXEC|VACUUM)\b/i;
      if (forbiddenKeywords.test(trimmedSql)) {
        console.warn(`[Security Alert] Blocked suspicious SQL execution attempt: ${trimmedSql}`);
        return res.status(403).json({ error: "العملية محظورة لدواعي أمنية" });
      }

      // Security Check B: Block multi-statement execution injection
      const withoutTrailingSemicolon = trimmedSql.replace(/;\s*$/, "");
      if (withoutTrailingSemicolon.includes(";")) {
        console.warn(`[Security Alert] Blocked multi-statement SQL attempt: ${trimmedSql}`);
        return res.status(403).json({ error: "لا يمكن تنفيذ أكثر من تعليمة واحدة في الطلب" });
      }

      // Security Check C: Strictly enforce allowed DML statements
      if (!/^(SELECT|INSERT|UPDATE|DELETE)\b/i.test(trimmedSql)) {
        return res.status(403).json({ error: "نوع العملية غير مسموح به" });
      }

      // Security Check D: Whitelist allowed tables (debtors, users, messages only)
      if (/\b(FROM|INTO|UPDATE)\b/i.test(trimmedSql)) {
        const allowedTables = /\b(debtors|users|messages)\b/i;
        if (!allowedTables.test(trimmedSql)) {
          return res.status(403).json({ error: "لا يمكن الوصول إلى هذا الجدول لدواعي أمنية" });
        }
      }

      const formattedArgs = args.map((a: any) => {
        if (typeof a === "number") {
          return Number.isInteger(a)
            ? { type: "integer", value: String(a) }
            : { type: "float", value: String(a) };
        }
        return { type: "text", value: String(a ?? "") };
      });

      const { url, token } = getTursoConfig();

      const tursoResponse = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql: trimmedSql, args: formattedArgs } },
            { type: "close" },
          ],
        }),
      });

      if (!tursoResponse.ok) {
        const errText = await tursoResponse.text();
        return res.status(tursoResponse.status).json({
          error: `Turso API error (${tursoResponse.status}): ${errText}`,
        });
      }

      const data = await tursoResponse.json();
      return res.json(data);
    } catch (err: any) {
      console.error("Server Turso proxy error:", err);
      return res.status(500).json({ error: err?.message || "Internal server error connecting to Turso" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
