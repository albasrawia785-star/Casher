import React, { useState } from 'react';
import { AppSettings, Debtor } from '../types';
import {
  formatNumber,
  buildWhatsAppReminderUrl,
  calculateDaysElapsed,
  formatDaysElapsedArabic
} from '../utils/formatters';

interface OverdueTabProps {
  debtors: Debtor[];
  settings?: AppSettings;
  onOpenPayModal: (debtor: Debtor) => void;
  onToggleOverdueStatus: (debtor: Debtor) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onViewHistory?: (debtor: Debtor) => void;
  onShare?: (debtor: Debtor) => void;
}

export const OverdueTab: React.FC<OverdueTabProps> = ({
  debtors,
  settings,
  onOpenPayModal,
  onToggleOverdueStatus,
  onShowToast,
  onViewHistory,
  onShare,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const alertThreshold = settings?.alertDaysThreshold ?? 1;
  const isAlertEnabled = settings?.enableDebtAlerts ?? true;
  const highDebtThreshold = settings?.highDebtThreshold ?? 25000;

  // Debtor is overdue if amount > 0 AND (status === 'متأخر' OR elapsed days >= alertThreshold)
  const overdueDebtors = debtors
    .filter((d) => {
      if (d.amount <= 0 || d.status === 'خالي من الدين') return false;
      if (d.status === 'متأخر') return true;
      if (isAlertEnabled) {
        const days = calculateDaysElapsed(d.createdAt);
        return days >= alertThreshold;
      }
      return false;
    })
    .sort((a, b) => b.amount - a.amount);

  const filteredOverdue = overdueDebtors.filter((d) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase().trim();
    return (
      d.name.toLowerCase().includes(term) ||
      (d.phone && d.phone.includes(term))
    );
  });

  const totalOverdueAmount = overdueDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

  const handleSendWhatsApp = (debtor: Debtor) => {
    if (!debtor.phone || !debtor.phone.trim()) {
      onShowToast("لا يوجد رقم هاتف مسجل لهذا المدين", "error");
      return;
    }

    if (debtor.phone.includes('*')) {
      onShowToast("رقم الهاتف تجريبي (077********) ولا يمكن إرسال رسالة واتساب حقيقية له", "info");
      return;
    }

    const whatsappUrl = buildWhatsAppReminderUrl(debtor.phone, debtor.name, debtor.amount);
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div id="tab-overdue" className="pb-24 space-y-3.5 animate-in fade-in duration-150">
      {/* Sticky Header & Search Bar */}
      <div className="sticky top-0 z-30 bg-slate-50/95 backdrop-blur-md px-4 pt-3.5 pb-2.5 border-b border-slate-200/60 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.05)] text-right space-y-2">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span>المتأخرون عن الدفع</span>
              <span className="text-xs sm:text-sm font-black bg-rose-100 text-rose-600 px-2.5 py-0.5 rounded-full font-mono">
                {overdueDebtors.length}
              </span>
            </h1>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              إجمالي الديون المتأخرة: <span className="font-bold text-rose-600 font-mono">{formatNumber(totalOverdueAmount)} د.ع</span>
            </p>
          </div>
        </div>

        {/* Search Filter if there are multiple overdue debtors */}
        {overdueDebtors.length > 5 && (
          <div className="relative pt-0.5">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="بحث بالاسم أو الهاتف بين المتأخرين..."
              className="w-full bg-white border border-slate-200/80 rounded-2xl py-2 pr-10 pl-9 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-rose-400 focus:ring-2 focus:ring-rose-100 shadow-2xs transition-all"
            />
            <i className="fa-solid fa-magnifying-glass absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs p-1"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Overdue Debtors List */}
      <div className="px-4 space-y-3">
        {filteredOverdue.length === 0 ? (
          <div className="bg-white rounded-3xl p-6 text-center border border-dashed border-slate-200 shadow-2xs">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center mx-auto mb-2 text-xl">
              <i className="fa-solid fa-check-double"></i>
            </div>
            <div className="font-bold text-sm text-slate-800 mb-1">
              {searchTerm ? "لا توجد نتائج مطابقة لبحثك" : "لا يوجد مدينين متأخرين حالياً"}
            </div>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              {searchTerm
                ? "جرب كتابة اسم آخر أو مسح حقل البحث"
                : `يتم إدراج المدينين هنا تلقائياً عند تجاوز دينهم ${alertThreshold} ${alertThreshold === 1 ? 'يوم' : alertThreshold === 2 ? 'يومين' : 'أيام'} أو بتحديدهم يدوياً`}
            </p>
          </div>
        ) : (
          filteredOverdue.map((debtor) => {
            const daysElapsed = calculateDaysElapsed(debtor.createdAt);
            const isHighDebt = debtor.amount >= highDebtThreshold;

            return (
              <div
                key={debtor.id}
                className="bg-white rounded-3xl p-4 border border-rose-100/80 shadow-xs flex flex-col gap-3 transition-all hover:border-rose-200"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-100 text-rose-600 flex items-center justify-center text-sm font-black shrink-0 shadow-2xs">
                      {debtor.name.trim().charAt(0) || 'م'}
                    </div>
                    <div className="text-right min-w-0">
                      <div className="font-bold text-sm text-slate-900 truncate">
                        {debtor.name}
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                        <span className="text-[11px] text-slate-400 font-mono" dir="ltr">
                          {debtor.phone || 'لا يوجد هاتف'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-left shrink-0">
                    <div className="text-base font-black text-rose-600 font-mono" dir="ltr">
                      {formatNumber(debtor.amount)} د.ع
                    </div>
                    <div className="flex items-center justify-end gap-1 mt-1">
                      <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-200/80 text-[10px] font-bold px-2 py-0.5 rounded-md shadow-2xs">
                        <i className="fa-solid fa-clock-rotate-left text-[8.5px] text-rose-500"></i>
                        <span>متأخر عن دفع</span>
                        {daysElapsed > 0 && (
                          <span className="text-rose-500 font-medium text-[9px]">
                            ({formatDaysElapsedArabic(daysElapsed)})
                          </span>
                        )}
                      </span>
                      {isHighDebt && (
                        <span className="text-[9.5px] font-black bg-red-50 text-red-700 border border-red-200/80 px-1.5 py-0.5 rounded-md">
                          مرتفع
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-50">
                  <button
                    type="button"
                    onClick={() => handleSendWhatsApp(debtor)}
                    className="flex-1 bg-emerald-50 hover:bg-emerald-100 active:scale-98 text-emerald-700 font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <i className="fa-brands fa-whatsapp text-sm"></i>
                    <span>تذكير واتساب</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onOpenPayModal(debtor)}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <i className="fa-solid fa-arrow-down text-xs"></i>
                    <span>تسديد مبلغ</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onViewHistory?.(debtor)}
                    title="عرض سجل العمليات"
                    className="w-8 h-8 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                  >
                    <i className="fa-solid fa-clock-rotate-left"></i>
                  </button>

                  <button
                    type="button"
                    onClick={() => onShare?.(debtor)}
                    title="مشاركة كشف الحساب وتفاصيل الدين"
                    className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                  >
                    <i className="fa-solid fa-share-nodes text-xs"></i>
                  </button>

                  <button
                    type="button"
                    onClick={() => onToggleOverdueStatus(debtor)}
                    title="تبديل حالة التأخير"
                    className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                  >
                    <i className="fa-solid fa-check"></i>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

