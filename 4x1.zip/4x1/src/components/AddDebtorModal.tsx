import React, { useState } from 'react';
import { formatAmountInput, parseFormattedNumber } from '../utils/formatters';

interface AddDebtorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string, phone: string, amount: number, debtDate?: string, notes?: string) => Promise<void>;
}

export const AddDebtorModal: React.FC<AddDebtorModalProps> = ({
  isOpen,
  onClose,
  onSave
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [amountStr, setAmountStr] = useState('0');
  const [debtDate, setDebtDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmountStr(formatAmountInput(e.target.value));
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (error) setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError("يرجى كتابة اسم المدين أولاً");
      return;
    }

    const trimmedPhone = phone.trim();
    if (trimmedPhone && trimmedPhone.length !== 11) {
      setError("رقم الهاتف يجب أن يتكون من 11 رقماً فقط (أو اتركه فارغاً)");
      return;
    }

    const numericAmount = parseFormattedNumber(amountStr);

    try {
      setIsSubmitting(true);
      await onSave(
        trimmedName,
        trimmedPhone,
        numericAmount,
        debtDate ? new Date(debtDate).toISOString() : undefined,
        notes.trim() || undefined
      );
      setName('');
      setPhone('');
      setAmountStr('0');
      setDebtDate(new Date().toISOString().split('T')[0]);
      setNotes('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء الحفظ');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="addModal"
      className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150"
    >
      <div className="bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl relative border border-slate-100 max-h-[95vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-5 pb-3 border-b border-slate-100">
          <div className="font-bold text-base text-slate-800 flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-xs">
              <i className="fa-solid fa-user-plus"></i>
            </div>
            <span>إضافة مدين جديد</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-2.5 bg-red-50 border border-red-200 text-red-600 text-xs rounded-xl flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation shrink-0"></i>
            <span>{error}</span>
          </div>
        )}

        <form id="addDebtorForm" onSubmit={handleSubmit} className="flex flex-col gap-3.5">
          {/* Debtor Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              اسم المدين <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="modalName"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all"
              placeholder="أدخل الاسم الثلاثي أو اللقب..."
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              required
              autoFocus
            />
          </div>

          {/* Phone Number */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-700">
                رقم الهاتف <span className="text-slate-400 font-normal">(اختياري - 11 رقم)</span>
              </label>
              {phone && (
                <span className={`text-[10.5px] font-mono font-bold ${
                  phone.length === 11 ? 'text-emerald-600' : 'text-amber-600'
                }`}>
                  {phone.length}/11
                </span>
              )}
            </div>
            <div className="relative">
              <input
                type="tel"
                id="modalPhone"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all font-mono dir-ltr text-right"
                placeholder="07XXXXXXXXX"
                maxLength={11}
                value={phone}
                onChange={handlePhoneChange}
              />
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                <i className="fa-solid fa-phone"></i>
              </div>
            </div>
          </div>

          {/* Initial Debt Amount */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              الدين الأولي (د.ع)
            </label>
            <div className="relative">
              <input
                type="text"
                id="modalAmount"
                className="w-full pl-12 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all font-semibold font-mono"
                placeholder="0"
                value={amountStr}
                onChange={handleAmountChange}
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold pointer-events-none">
                د.ع
              </span>
            </div>
          </div>

          {/* Notes Field (Optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              ملاحظات <span className="text-slate-400 font-normal">(اختياري)</span>
            </label>
            <textarea
              id="modalNotes"
              rows={2}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all resize-none"
              placeholder="أي تفاصيل أو ملاحظات إضافية حول المدين..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={250}
            />
          </div>

          {/* Debt Date */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              تاريخ تسجيل الدين (اختياري)
            </label>
            <input
              type="date"
              id="modalDate"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all font-mono"
              value={debtDate}
              onChange={(e) => setDebtDate(e.target.value)}
            />
          </div>

          <div className="flex gap-2 mt-2 pt-2">
            <button
              type="submit"
              id="btnSaveSubmit"
              disabled={isSubmitting}
              className="flex-1 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white py-2.5 rounded-xl font-bold text-sm shadow-md shadow-blue-500/20 cursor-pointer transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>جاري الحفظ...</span>
                </>
              ) : (
                <span>حفظ المدين</span>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 py-2.5 rounded-xl font-bold text-sm cursor-pointer transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
