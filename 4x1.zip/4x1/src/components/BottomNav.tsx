import React, { useState, useEffect } from 'react';
import { TabType } from '../types';

interface BottomNavProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenAddModal?: () => void;
  isAdmin?: boolean;
  overdueCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  onOpenAddModal,
  overdueCount = 0,
}) => {
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);

  useEffect(() => {
    // Detect mobile virtual keyboard or input focus to prevent BottomNav from rising
    const checkKeyboard = () => {
      const activeEl = document.activeElement;
      const isInputFocused =
        activeEl &&
        (activeEl.tagName === 'INPUT' ||
          activeEl.tagName === 'TEXTAREA' ||
          (activeEl as HTMLElement).isContentEditable);

      if (window.visualViewport) {
        // If viewport height shrank significantly, virtual keyboard is open
        const heightDiff = window.innerHeight - window.visualViewport.height;
        if (heightDiff > 100 || isInputFocused) {
          setIsKeyboardOpen(true);
          return;
        }
      } else if (isInputFocused) {
        setIsKeyboardOpen(true);
        return;
      }

      setIsKeyboardOpen(false);
    };

    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable)
      ) {
        setIsKeyboardOpen(true);
      }
    };

    const handleFocusOut = () => {
      setTimeout(() => {
        checkKeyboard();
      }, 120);
    };

    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', checkKeyboard);
      window.visualViewport.addEventListener('scroll', checkKeyboard);
    }
    window.addEventListener('resize', checkKeyboard);
    document.addEventListener('focusin', handleFocusIn);
    document.addEventListener('focusout', handleFocusOut);

    return () => {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', checkKeyboard);
        window.visualViewport.removeEventListener('scroll', checkKeyboard);
      }
      window.removeEventListener('resize', checkKeyboard);
      document.removeEventListener('focusin', handleFocusIn);
      document.removeEventListener('focusout', handleFocusOut);
    };
  }, []);

  return (
    <nav
      aria-label="التنقل الرئيسي"
      className={`fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-white/85 backdrop-blur-xl flex justify-between items-center px-3 py-1.5 border-t border-slate-200/70 z-40 shadow-[0_-8px_30px_rgba(0,0,0,0.04)] select-none transition-all duration-200 ease-in-out ${
        isKeyboardOpen
          ? 'translate-y-full opacity-0 pointer-events-none invisible'
          : 'translate-y-0 opacity-100 pointer-events-auto visible'
      }`}
    >
      {/* 1. Home */}
      <button
        type="button"
        onClick={() => onSelectTab('home')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all ${
            activeTab === 'home'
              ? 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-house text-[15px]"></i>
        </div>
        <span
          className={`text-[10.5px] mt-0.5 transition-colors ${
            activeTab === 'home' ? 'text-blue-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          الرئيسية
        </span>
      </button>

      {/* 2. Reports */}
      <button
        type="button"
        onClick={() => onSelectTab('reports')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all ${
            activeTab === 'reports'
              ? 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-chart-simple text-[15px]"></i>
        </div>
        <span
          className={`text-[10.5px] mt-0.5 transition-colors ${
            activeTab === 'reports' ? 'text-blue-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          التقارير
        </span>
      </button>

      {/* 3. CENTER ADD BUTTON */}
      <button
        id="btnAddDebtorBottom"
        type="button"
        onClick={onOpenAddModal}
        className="flex flex-col items-center justify-center -translate-y-3.5 group cursor-pointer focus:outline-none shrink-0 px-2"
        title="إضافة مدين جديد"
      >
        <div className="w-[50px] h-[50px] rounded-full bg-gradient-to-tr from-blue-600 via-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 active:scale-90 text-white flex items-center justify-center shadow-[0_10px_25px_-5px_rgba(37,99,235,0.45)] transition-all border-[3.5px] border-white">
          <i className="fa-solid fa-plus text-lg"></i>
        </div>
        <span className="text-[10.5px] font-extrabold text-blue-600 mt-0.5 tracking-tight">
          إضافة مدين
        </span>
      </button>

      {/* 4. Overdue */}
      <button
        type="button"
        onClick={() => onSelectTab('overdue')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all relative ${
            activeTab === 'overdue'
              ? 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-hourglass-half text-[15px]"></i>
          {overdueCount > 0 && (
            <span className="absolute -top-1 -right-0.5 bg-rose-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full min-w-[17px] h-[17px] flex items-center justify-center shadow-xs border border-white font-mono animate-in zoom-in-50 duration-150">
              {overdueCount > 99 ? '99+' : overdueCount}
            </span>
          )}
        </div>
        <span
          className={`text-[10.5px] mt-0.5 transition-colors ${
            activeTab === 'overdue' ? 'text-blue-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          المتأخرون
        </span>
      </button>

      {/* 5. Settings */}
      <button
        type="button"
        onClick={() => onSelectTab('settings')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all ${
            activeTab === 'settings'
              ? 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-gear text-[15px]"></i>
        </div>
        <span
          className={`text-[10.5px] mt-0.5 transition-colors ${
            activeTab === 'settings' ? 'text-blue-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          الإعدادات
        </span>
      </button>
    </nav>
  );
};
