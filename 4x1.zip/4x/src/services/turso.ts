import { AppSettings, Debtor, DebtorTransaction, Manager, User } from '../types';
import { generateShieldHeaders } from '../utils/securityShield';

/**
 * Returns the backend API server base URL.
 * Supports:
 * 1. Custom URL set in settings / APK config (localStorage: aldion_backend_server_url)
 * 2. Current origin in web browser (window.location.origin)
 * 3. Default production Cloud Run backend host
 */
export function getBackendBaseUrl(): string {
  if (typeof window === 'undefined') return '';

  const saved = localStorage.getItem('aldion_backend_server_url');
  if (saved && saved.trim()) {
    return saved.trim().replace(/\/+$/, '');
  }

  // If in browser and not a local file system or local capacitor scheme
  if (
    window.location &&
    window.location.origin &&
    window.location.origin.startsWith('http') &&
    !window.location.origin.includes('capacitor://') &&
    !window.location.origin.includes('file://')
  ) {
    return window.location.origin;
  }

  // Fallback production backend server URL
  return 'https://ais-dev-3qeeb6jl5bktm64omzuibv-349740974703.europe-west2.run.app';
}

export function setBackendBaseUrl(url: string) {
  if (url && url.trim()) {
    localStorage.setItem('aldion_backend_server_url', url.trim().replace(/\/+$/, ''));
  } else {
    localStorage.removeItem('aldion_backend_server_url');
  }
}

/**
 * Enterprise Zero-Secret Shield Query Proxy:
 * The frontend (web or APK) NEVER has the database token or direct Turso URL.
 * All requests are cryptographically verified and handled by the protected server proxy.
 */
export async function queryTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();
  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!res.ok) {
      const errorData = await res.json().catch(() => null);
      throw new Error(errorData?.error || `خطأ في الاتصال بالخادم المحمي (${res.status})`);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في تنفيذ استعلام القاعدة');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('انتهت مهلة الاتصال بالخادم، يرجى التحقق من اتصال الإنترنت');
    }
    throw err;
  }
}

// Local Storage helpers
export function getLocalDebtors(userId: number): Debtor[] | null {
  const data = localStorage.getItem(`debtors_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalDebtors(userId: number, debtors: Debtor[]) {
  localStorage.setItem(`debtors_user_${userId}`, JSON.stringify(debtors));
}

export function getLocalUsers(): User[] | null {
  const data = localStorage.getItem("local_users");
  return data ? JSON.parse(data) : null;
}

export function setLocalUsers(users: User[]) {
  // Strip sensitive passwords before saving in localStorage
  const safeUsers = users.map(({ password: _, ...u }) => u as User);
  localStorage.setItem("local_users", JSON.stringify(safeUsers));
}

export const DEFAULT_USER: User = {
  id: 1,
  username: 'admin',
  role: 'admin',
  branch_name: 'الفرع الرئيسي',
  isActive: true,
  subscriptionType: 'permanent',
};

export function getLocalSession(): User | null {
  try {
    const data = localStorage.getItem("session_user");
    if (!data) return null;
    const user: User = JSON.parse(data);
    if (!user || !user.id) return null;

    // If sub-manager, verify if flagged for forced suspension
    if (user.role !== 'admin' && user.id) {
      const forceLogout = localStorage.getItem(`force_logout_user_${user.id}`);
      if (forceLogout) {
        localStorage.removeItem("session_user");
        return null;
      }
      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        const managers: Manager[] = JSON.parse(managersData);
        const found = managers.find((m) => m.id === user.id);
        if (found && found.isActive === false) {
          localStorage.removeItem("session_user");
          return null;
        }
      }
    }
    // Ensure password is reconstructed from cached storage if available
    if (!user.password) {
      const cachedPass = localStorage.getItem(`user_pwd_${user.id}`) || localStorage.getItem(`user_pwd_${user.username}`);
      if (cachedPass) {
        user.password = cachedPass;
      }
    }
    return user;
  } catch {
    return null;
  }
}

export function setLocalSession(user: User | null) {
  if (user) {
    localStorage.setItem("session_user", JSON.stringify(user));
    if (user.password) {
      localStorage.setItem(`user_pwd_${user.id}`, user.password);
      localStorage.setItem(`user_pwd_${user.username}`, user.password);
    }
  } else {
    localStorage.removeItem("session_user");
  }
}

// Multi-tab synchronization for instant logout
export const sessionBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('submanager_auth_sync')
    : null;

// Multi-tab synchronization for real-time debtors sync
export const debtorsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('debtors_realtime_sync')
    : null;

export function broadcastDebtorsChange(userId: number, actionType?: string) {
  try {
    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.postMessage({
        type: 'DEBTORS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastManagerStatusChange(targetUserId: number, isActive: boolean, reason?: string) {
  try {
    if (!isActive) {
      localStorage.setItem(
        `force_logout_user_${targetUserId}`,
        JSON.stringify({
          timestamp: Date.now(),
          reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
        })
      );
      // If current saved session belongs to target, drop it immediately
      const current = getLocalSession();
      if (current && current.id === targetUserId) {
        localStorage.removeItem("session_user");
      }
    } else {
      localStorage.removeItem(`force_logout_user_${targetUserId}`);
    }

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.postMessage({
        type: isActive ? 'MANAGER_ACTIVATED' : 'FORCE_LOGOUT',
        targetUserId,
        reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
      });
    }
  } catch (e) {
    console.warn('Broadcast error:', e);
  }
}

export function getLocalManagers(): Manager[] | null {
  const data = localStorage.getItem("local_managers_list");
  return data ? JSON.parse(data) : null;
}

export function setLocalManagers(managers: Manager[]) {
  localStorage.setItem("local_managers_list", JSON.stringify(managers));
}

export const DEFAULT_SETTINGS: AppSettings = {
  enableDebtAlerts: true,
  alertDaysThreshold: 1, // Alerts trigger if debt age >= 1 day
  highDebtThreshold: 25000, // Default 25,000 IQD
};

export function getLocalSettings(userId: number): AppSettings {
  try {
    const raw = localStorage.getItem(`app_settings_user_${userId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enableDebtAlerts: parsed.enableDebtAlerts ?? true,
        alertDaysThreshold: parsed.alertDaysThreshold ?? 1,
        highDebtThreshold: parsed.highDebtThreshold ?? 25000,
      };
    }
  } catch (e) {
    console.error("Error reading local settings:", e);
  }
  return { ...DEFAULT_SETTINGS };
}

export function setLocalSettings(userId: number, settings: AppSettings) {
  try {
    localStorage.setItem(`app_settings_user_${userId}`, JSON.stringify(settings));
  } catch (e) {
    console.error("Error saving local settings:", e);
  }
}

export function getLocalDebtorDates(userId: number): Record<number, string> {
  try {
    const raw = localStorage.getItem(`debtor_dates_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorDates(userId: number, dates: Record<number, string>) {
  try {
    localStorage.setItem(`debtor_dates_user_${userId}`, JSON.stringify(dates));
  } catch (e) {
    console.error("Error saving debtor dates:", e);
  }
}

export function getLocalDebtorHistory(userId: number): Record<number, DebtorTransaction[]> {
  try {
    const raw = localStorage.getItem(`debtor_history_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorHistory(userId: number, historyMap: Record<number, DebtorTransaction[]>) {
  try {
    localStorage.setItem(`debtor_history_user_${userId}`, JSON.stringify(historyMap));
  } catch (e) {
    console.error("Error saving debtor history:", e);
  }
}

