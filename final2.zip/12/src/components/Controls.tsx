import React from 'react';
import { FilterType, ViewMode } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';

interface ControlsProps {
  searchTerm?: string;
  onSearchChange?: (val: string) => void;
  onOpenAddModal?: () => void;
  filter: FilterType;
  onFilterChange: (f: FilterType) => void;
  totalCount: number;
  debtorsOnlyCount: number;
  paidOnlyCount: number;
  highDebtCount: number;
  viewMode?: ViewMode;
  onViewModeChange?: (mode: ViewMode) => void;
  displayedCount?: number;
}

export const Controls: React.FC<ControlsProps> = ({
  searchTerm,
  filter,
  onFilterChange,
  totalCount,
  debtorsOnlyCount,
  paidOnlyCount,
  highDebtCount,
  displayedCount,
}) => {
  const { t, numberFormat } = useI18n();

  const filterTabs: {
    id: FilterType;
    label: string;
    count: number;
    icon: string;
    activeIconColor: string;
    badgeActiveColor: string;
  }[] = [
    {
      id: 'all',
      label: t('debts.filterAll', 'الكل'),
      count: totalCount,
      icon: 'fa-solid fa-layer-group',
      activeIconColor: 'text-blue-600',
      badgeActiveColor: 'bg-blue-50 text-blue-700',
    },
    {
      id: 'debtors_only',
      label: t('debts.filterDebtorsOnly', 'عليهم دين'),
      count: debtorsOnlyCount,
      icon: 'fa-solid fa-user-clock',
      activeIconColor: 'text-amber-600',
      badgeActiveColor: 'bg-amber-50 text-amber-700',
    },
    {
      id: 'paid_only',
      label: t('debts.filterPaidOnly', 'خالي من الدين'),
      count: paidOnlyCount,
      icon: 'fa-solid fa-circle-check',
      activeIconColor: 'text-emerald-600',
      badgeActiveColor: 'bg-emerald-50 text-emerald-700',
    },
    {
      id: 'high_debt',
      label: t('debts.filterHighDebt', 'دين مرتفع'),
      count: highDebtCount,
      icon: 'fa-solid fa-arrow-trend-up',
      activeIconColor: 'text-rose-600',
      badgeActiveColor: 'bg-rose-50 text-rose-700',
    },
  ];

  return (
    <div className="bg-slate-50/95 backdrop-blur-md px-4 pt-2.5 pb-2.5 flex flex-col gap-2 select-none shadow-[0_4px_12px_-4px_rgba(0,0,0,0.05)] border-b border-slate-200/60 transition-all">
      {/* Segmented Filter Bar with Smooth Horizontal Scroll */}
      <div className="w-full bg-slate-200/70 p-1.5 rounded-2xl flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth border border-slate-200/90 touch-pan-x">
        {filterTabs.map((tab) => {
          const isActive = filter === tab.id;
          return (
            <button
              key={tab.id}
              id={`filter-${tab.id}`}
              type="button"
              onClick={() => onFilterChange(tab.id)}
              className={`shrink-0 py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-white text-slate-900 shadow-[0_2px_8px_rgba(0,0,0,0.08)] border border-slate-200/80 scale-[1.02]'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <i className={`${tab.icon} text-xs ${isActive ? tab.activeIconColor : 'text-slate-400'}`}></i>
              <span className="text-xs font-bold tracking-tight">{tab.label}</span>
              <span
                className={`text-[11px] font-mono px-2 py-0.5 rounded-full font-bold transition-colors ${
                  isActive ? tab.badgeActiveColor : 'bg-slate-300/60 text-slate-700'
                }`}
              >
                {formatNumber(tab.count, numberFormat)}
              </span>
            </button>
          );
        })}
      </div>

      {/* Optional Search Results Indicator */}
      {searchTerm && displayedCount !== undefined && (
        <div className="flex items-center gap-1.5 px-1 text-xs text-slate-500 font-medium select-none">
          <i className="fa-solid fa-magnifying-glass text-[11px] text-blue-500"></i>
          <span className="text-[11.5px] text-slate-600">
            {t('common.search', 'نتائج البحث')}: <span className="font-mono font-extrabold text-slate-900">{formatNumber(displayedCount, numberFormat)}</span>
          </span>
        </div>
      )}
    </div>
  );
};
