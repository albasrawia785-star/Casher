import React, { useState } from 'react';
import { InstallmentRecord } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatAmountInput, parseFormattedNumber, formatNumber } from '../utils/formatters';
import { calculateNextMonthDueDate, computeInstallmentStatus } from '../utils/installmentHelpers';

interface UnifiedAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'debt' | 'installment';
  initialMode?: 'debt' | 'installment';
  onSaveDebtor: (name: string, phone: string, amount: number, debtDate?: string, notes?: string) => Promise<void>;
  onSaveInstallment: (inst: Omit<InstallmentRecord, 'id'>) => Promise<void>;
  userId: number;
}

export const UnifiedAddModal: React.FC<UnifiedAddModalProps> = ({
  isOpen,
  onClose,
  initialType,
  initialMode,
  onSaveDebtor,
  onSaveInstallment,
  userId,
}) => {
  const { t, currency } = useI18n();
  const effectiveInitial = initialType || initialMode || 'debt';
  const [entryType, setEntryType] = useState<'debt' | 'installment'>(effectiveInitial);

  // Common Fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Debt Specific Fields
  const [debtAmountStr, setDebtAmountStr] = useState('0');

  // Installment Specific Fields
  const [item, setItem] = useState('');
  const [totalInstallmentAmountStr, setTotalInstallmentAmountStr] = useState('');
  const [downPaymentStr, setDownPaymentStr] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [address, setAddress] = useState('');

  // Guarantor Fields
  const [guarantorEnabled, setGuarantorEnabled] = useState(false);
  const [guarantorName, setGuarantorName] = useState('');
  const [guarantorAddress, setGuarantorAddress] = useState('');
  const [guarantorJob, setGuarantorJob] = useState('');
  const [guarantorRelation, setGuarantorRelation] = useState('');
  const [guarantorPhone, setGuarantorPhone] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Sync entryType if initialType/initialMode changes upon opening
  React.useEffect(() => {
    if (isOpen) {
      setEntryType(initialType || initialMode || 'debt');
      setError(null);
    }
  }, [isOpen, initialType, initialMode]);

  if (!isOpen) return null;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (error) setError(null);
  };

  const handleNationalIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 12);
    setNationalId(cleanNumbers);
    if (error) setError(null);
  };

  const handleGuarantorPhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setGuarantorPhone(cleanNumbers);
    if (error) setError(null);
  };

  const parsedTotalInst = parseFormattedNumber(totalInstallmentAmountStr);
  const parsedDownPayment = parseFormattedNumber(downPaymentStr);
  const calculatedRemaining = Math.max(0, parsedTotalInst - parsedDownPayment);
  const calculatedNextDueDate = calculateNextMonthDueDate(date);

  const resetForm = () => {
    setName('');
    setPhone('');
    setNotes('');
    setDate(new Date().toISOString().split('T')[0]);
    setDebtAmountStr('0');
    setItem('');
    setTotalInstallmentAmountStr('');
    setDownPaymentStr('');
    setNationalId('');
    setAddress('');
    setGuarantorEnabled(false);
    setGuarantorName('');
    setGuarantorAddress('');
    setGuarantorJob('');
    setGuarantorRelation('');
    setGuarantorPhone('');
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError(t('modals.enterDebtorNameError', 'يرجى كتابة الاسم أولاً'));
      return;
    }

    const trimmedPhone = phone.trim();
    if (trimmedPhone && trimmedPhone.length !== 11) {
      setError(t('modals.phone11DigitsError', 'رقم الهاتف يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)'));
      return;
    }

    try {
      setIsSubmitting(true);

      if (entryType === 'debt') {
        const numericAmount = parseFormattedNumber(debtAmountStr);
        await onSaveDebtor(
          trimmedName,
          trimmedPhone,
          numericAmount,
          date ? new Date(date).toISOString() : undefined,
          notes.trim() || undefined
        );
      } else {
        const trimmedItem = item.trim();
        if (!trimmedItem) {
          setError(t('modals.enterItemNameError', 'يرجى كتابة اسم السلعة أو الغرض المقسط'));
          setIsSubmitting(false);
          return;
        }
        if (parsedTotalInst <= 0) {
          setError(t('modals.enterTotalAmountError', 'يرجى إدخال مبلغ الأقساط الإجمالي'));
          setIsSubmitting(false);
          return;
        }
        if (parsedDownPayment > parsedTotalInst) {
          setError(t('modals.downPaymentTooLargeError', 'لا يمكن أن تكون الدفعة المقدمة أكبر من المبلغ الإجمالي'));
          setIsSubmitting(false);
          return;
        }

        const trimmedNatId = nationalId.trim();
        if (trimmedNatId && trimmedNatId.length !== 12) {
          setError(t('modals.nationalId12DigitsError', 'رقم البطاقة الوطنية يجب أن يتكون من 12 رقماً (أو اتركه فارغاً)'));
          setIsSubmitting(false);
          return;
        }

        const trimmedGPhone = guarantorPhone.trim();
        if (guarantorEnabled && trimmedGPhone && trimmedGPhone.length !== 11) {
          setError(t('modals.guarantorPhone11DigitsError', 'رقم هاتف الكفيل يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)'));
          setIsSubmitting(false);
          return;
        }

        const initialPayments = parsedDownPayment > 0 ? [
          {
            id: `down-${Date.now()}`,
            installmentId: 0,
            amount: parsedDownPayment,
            date: date,
            remainingAfter: calculatedRemaining,
            notes: t('installments.downPaymentNote', 'دفعة مقدمة عند تسجيل القسط'),
          }
        ] : [];

        const status = computeInstallmentStatus({
          remainingAmount: calculatedRemaining,
          nextDueDate: calculatedNextDueDate,
          registrationDate: date,
        });

        await onSaveInstallment({
          name: trimmedName,
          phone: trimmedPhone,
          item: trimmedItem,
          totalAmount: parsedTotalInst,
          downPayment: parsedDownPayment,
          remainingAmount: calculatedRemaining,
          registrationDate: date,
          nextDueDate: calculatedNextDueDate,
          userId,
          status,
          nationalId: trimmedNatId || undefined,
          address: address.trim() || undefined,
          guarantorEnabled: guarantorEnabled || undefined,
          guarantorName: guarantorEnabled ? guarantorName.trim() || undefined : undefined,
          guarantorAddress: guarantorEnabled ? guarantorAddress.trim() || undefined : undefined,
          guarantorJob: guarantorEnabled ? guarantorJob.trim() || undefined : undefined,
          guarantorRelation: guarantorEnabled ? guarantorRelation.trim() || undefined : undefined,
          guarantorPhone: guarantorEnabled ? trimmedGPhone || undefined : undefined,
          notes: notes.trim() || undefined,
          payments: initialPayments,
          createdAt: new Date().toISOString(),
        });
      }

      resetForm();
      onClose();
    } catch (err: any) {
      setError(err?.message || t('common.errorOccurred', 'حدث خطأ أثناء الحفظ'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="unifiedAddModal"
      className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex justify-center items-end sm:items-center z-50 p-0 sm:p-4 animate-in fade-in duration-150 text-start"
    >
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg p-5 sm:p-6 shadow-2xl relative border border-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Top Header */}
        <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-100">
          <div className="font-extrabold text-base text-slate-800 flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs ${
              entryType === 'debt' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'
            }`}>
              <i className={`fa-solid ${entryType === 'debt' ? 'fa-user-plus' : 'fa-file-invoice-dollar'}`}></i>
            </div>
            <span>{entryType === 'debt' ? t('debtors.addDebtor', 'إضافة مدين جديد') : t('installments.addInstallment', 'تسجيل معاملة قسط جديدة')}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Segmented Switcher */}
        <div className="mb-4 bg-slate-100 p-1 rounded-2xl grid grid-cols-2 gap-1 select-none">
          <button
            type="button"
            onClick={() => {
              setEntryType('debt');
              setError(null);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              entryType === 'debt'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
            <span>{t('common.regularDebt', 'دين عادي')}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setEntryType('installment');
              setError(null);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              entryType === 'installment'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <i className="fa-solid fa-clock-rotate-left text-xs"></i>
            <span>{t('common.installments', 'أقساط شهرية')}</span>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation shrink-0"></i>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
          {/* 1. Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {entryType === 'debt' ? t('debts.debtorName', 'اسم المدين') : t('installments.debtorName', 'اسم صاحب الأقساط')} <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              autoFocus
              className={`w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm outline-none text-slate-800 transition-all ${
                entryType === 'debt'
                  ? 'border-slate-200 focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-500/10'
                  : 'border-slate-200 focus:border-emerald-600 focus:bg-white focus:ring-2 focus:ring-emerald-500/10'
              }`}
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
            />
          </div>

          {/* 2. Phone */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('debts.phoneNumber', 'رقم الهاتف')} <span className="text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <div className="relative">
              <input
                type="tel"
                dir="ltr"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none text-slate-800 transition-all font-mono"
                maxLength={11}
                value={phone}
                onChange={handlePhoneChange}
              />
              <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                <i className="fa-solid fa-phone"></i>
              </div>
            </div>
          </div>

          {/* DYNAMIC: DEBT VS INSTALLMENT FIELDS */}
          {entryType === 'debt' ? (
            /* DEBT FIELDS */
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {t('debts.initialDebtAmount', 'مبلغ الدين الأولي')} ({currency})
              </label>
              <div className="relative">
                <input
                  type="text"
                  dir="ltr"
                  inputMode="numeric"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all font-bold font-mono"
                  value={debtAmountStr}
                  onChange={(e) => setDebtAmountStr(formatAmountInput(e.target.value))}
                />
              </div>
            </div>
          ) : (
            /* INSTALLMENT FIELDS */
            <>
              {/* 3. Item Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('installments.itemName', 'اسم السلعة / الغرض المقسط')} <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-emerald-600 focus:bg-white text-slate-800 transition-all"
                  value={item}
                  onChange={(e) => {
                    setItem(e.target.value);
                    if (error) setError(null);
                  }}
                />
              </div>

              {/* 4. Total Installment Amount & Down Payment */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('installments.totalAmount', 'مبلغ الأقساط الكلي')} <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      dir="ltr"
                      inputMode="numeric"
                      required
                      value={totalInstallmentAmountStr}
                      onChange={(e) => setTotalInstallmentAmountStr(formatAmountInput(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black font-mono focus:border-emerald-600 focus:bg-white outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('installments.downPayment', 'الدفعة المقدمة (المقدم)')}
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      dir="ltr"
                      inputMode="numeric"
                      value={downPaymentStr}
                      onChange={(e) => setDownPaymentStr(formatAmountInput(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black font-mono focus:border-emerald-600 focus:bg-white outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Installment Summary Badge */}
              {parsedTotalInst > 0 && (
                <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 space-y-1 text-xs">
                  <div className="flex items-center justify-between font-bold text-emerald-950">
                    <span>{t('installments.remainingToPay', 'المتبقي المطلوب تقسيطه')}:</span>
                    <span className="font-mono text-emerald-700 text-sm font-black">
                      {formatNumber(calculatedRemaining)} {currency}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-emerald-800">
                    <span>{t('installments.firstDueDate', 'تاريخ الاستحقاق الأول (بعد شهر)')}:</span>
                    <span className="font-mono font-bold bg-white px-2 py-0.5 rounded-lg border border-emerald-200">
                      {calculatedNextDueDate}
                    </span>
                  </div>
                </div>
              )}

              {/* البطاقة الوطنية (اختياري) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('installments.nationalId', 'رقم البطاقة الوطنية')} <span className="text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    dir="ltr"
                    inputMode="numeric"
                    maxLength={12}
                    value={nationalId}
                    onChange={handleNationalIdChange}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold outline-none focus:border-emerald-600 focus:bg-white text-slate-800 transition-all"
                  />
                  <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                    <i className="fa-solid fa-id-card"></i>
                  </div>
                </div>
              </div>

              {/* عنوان السكن وأقرب نقطة دالة */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('installments.address', 'عنوان السكن وأقرب نقطة دالة')} <span className="text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 focus:bg-white text-slate-800 transition-all"
                  />
                  <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                    <i className="fa-solid fa-location-dot"></i>
                  </div>
                </div>
              </div>

              {/* قائمة بيانات الكفيل */}
              <div className="border border-slate-200 rounded-2xl p-3 bg-slate-50/70 space-y-3">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={guarantorEnabled}
                    onChange={(e) => setGuarantorEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer accent-emerald-600"
                  />
                  <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                    <i className="fa-solid fa-user-shield text-emerald-600"></i>
                    <span>{t('installments.guarantorInfo', 'بيانات الكفيل')}</span>
                    <span className="text-[10.5px] font-normal text-slate-500">({t('common.clickToEnable', 'اضغط للتفعيل')})</span>
                  </span>
                </label>

                {guarantorEnabled && (
                  <div className="pt-2 border-t border-slate-200/80 space-y-2.5 animate-in fade-in duration-150">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {t('installments.guarantorName', 'اسم الكفيل')}
                      </label>
                      <input
                        type="text"
                        value={guarantorName}
                        onChange={(e) => setGuarantorName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          {t('installments.guarantorRelation', 'صلة القرابة')}
                        </label>
                        <input
                          type="text"
                          value={guarantorRelation}
                          onChange={(e) => setGuarantorRelation(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          {t('installments.guarantorJob', 'مهنة الكفيل')}
                        </label>
                        <input
                          type="text"
                          value={guarantorJob}
                          onChange={(e) => setGuarantorJob(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {t('installments.guarantorAddress', 'عنوان الكفيل')}
                      </label>
                      <input
                        type="text"
                        value={guarantorAddress}
                        onChange={(e) => setGuarantorAddress(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {t('installments.guarantorPhone', 'رقم هاتف الكفيل')} ({t('common.optional', 'اختياري')})
                      </label>
                      <input
                        type="tel"
                        dir="ltr"
                        maxLength={11}
                        value={guarantorPhone}
                        onChange={handleGuarantorPhoneChange}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono outline-none focus:border-emerald-600 text-slate-800"
                      />
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Date Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('common.date', 'تاريخ التسجيل')} {entryType === 'installment' ? `(${t('installments.setsMonthlyDueDate', 'يحدد موعد الاستحقاق الشهري')})` : ''}
            </label>
            <input
              type="date"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none text-slate-800 transition-all font-mono"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          {/* Notes Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('common.notes', 'ملاحظات')} <span className="text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <input
              type="text"
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none text-slate-800 transition-all"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={250}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 mt-2 pt-2 border-t border-slate-100">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex-1 text-white py-2.5 rounded-xl font-bold text-sm shadow-md active:scale-95 cursor-pointer transition-all flex items-center justify-center gap-2 disabled:opacity-50 ${
                entryType === 'debt'
                  ? 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20'
                  : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20'
              }`}
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري الحفظ...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{entryType === 'debt' ? t('debtors.saveDebtor', 'حفظ المدين') : t('installments.saveInstallment', 'حفظ وتسجيل القسط')}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 py-2.5 rounded-xl font-bold text-sm cursor-pointer transition-all"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
