import { Debtor, DebtorTransaction } from '../types';

const FIRST_NAMES = [
  'محمد', 'أحمد', 'علي', 'حسين', 'كرار', 'عباس', 'مصطفى', 'يوسف', 'عمر', 'حسن',
  'حيدر', 'سجاد', 'مهدي', 'مرتضى', 'إبراهيم', 'زيد', 'سيف', 'عمار', 'جعفر', 'بلال',
  'بشير', 'خالد', 'طه', 'أمير', 'ضرغام', 'وسام', 'حمزة', 'قاسم', 'فاضل', 'صادق'
];

const FATHER_NAMES = [
  'علي', 'حسن', 'حسين', 'كاظم', 'جاسم', 'كريم', 'شاكر', 'هادي', 'جواد', 'صادق',
  'نعمة', 'عبدالله', 'فاضل', 'سلمان', 'حميد', 'طاهر', 'ماجد', 'رحيم', 'ناظم', 'محسن'
];

const FAMILY_NAMES = [
  'الشمري', 'الساعدي', 'الجبوري', 'الخفاجي', 'البصراوي', 'المالكي', 'الكعبي', 'العامري',
  'التميمي', 'الزبيدي', 'المحمداوي', 'الحسناوي', 'العتابي', 'السعدي', 'الدراجي', 'الموسوي',
  'العكيلي', 'الفرطوسي', 'اللامي', 'الوائلي', 'الجنابي', 'العبيدي', 'المعموري', 'الصالحي'
];

// 100 uniquely diverse and realistic Iraqi Dinar amounts summing up to exactly 1,300,000 IQD (مليون وثلاثمائة)
const DIVERSE_AMOUNTS_100: number[] = [
  // Group 1 (Sum = 60,000)
  0, 2250, 3500, 4750, 5000, 6250, 7500, 8750, 10000, 12000,
  // Group 2 (Sum = 70,000)
  2500, 3750, 4500, 5500, 6500, 7750, 8500, 9500, 10500, 11000,
  // Group 3 (Sum = 75,000)
  0, 4250, 5250, 6750, 7250, 8250, 9250, 10250, 11750, 12000,
  // Group 4 (Sum = 90,000)
  3250, 5750, 6000, 7000, 8000, 9000, 11500, 12500, 13000, 14000,
  // Group 5 (Sum = 105,000)
  0, 6250, 7500, 8500, 9750, 11000, 12500, 14500, 15000, 20000,
  // Group 6 (Sum = 145,000)
  7250, 8750, 10000, 11250, 13500, 15500, 16750, 18000, 21000, 23000,
  // Group 7 (Sum = 155,000)
  0, 9250, 10500, 12000, 14000, 16000, 18500, 22000, 25750, 27000,
  // Group 8 (Sum = 200,000)
  8500, 10750, 12750, 15000, 17500, 20500, 24000, 27500, 31000, 32500,
  // Group 9 (Sum = 210,000)
  0, 11500, 13750, 16500, 19500, 22500, 26500, 30500, 34250, 35000,
  // Group 10 (Sum = 190,000)
  10000, 12500, 15000, 16000, 18000, 21000, 23500, 24000, 25000, 25000
];

/**
 * Helper to identify whether a debtor is a demo record.
 * Checks the isDemo flag, negative ID, masked demo phone ('077********' or containing '*'), or demo marker.
 */
export function isDemoDebtor(d: Debtor | null | undefined): boolean {
  if (!d) return false;
  if (d.isDemo === true) return true;
  if (typeof d.id === 'number' && d.id < 0) return true;
  if (typeof d.phone === 'string' && (d.phone.includes('*') || d.phone.includes('X') || d.phone === '077********')) return true;
  if (typeof d.name === 'string' && (d.name.includes('(تجريبي)') || d.name.includes('تجريبي'))) return true;
  return false;
}

/**
 * Generates 100 realistic Iraqi demo debtors for testing purposes.
 * These are marked with isDemo: true and must NOT be saved to Turso cloud database.
 * Phone numbers are masked as '077********' because they are demo accounts.
 * Exactly 4 demo debtors are configured as overdue (متأخر) according to user requirement.
 */
export function generate100DemoDebtors(userId: number, highDebtThreshold: number = 25000): Debtor[] {
  const debtors: Debtor[] = [];
  const now = Date.now();

  // Exactly 4 demo debtors configured to be overdue
  const OVERDUE_INDICES = new Set([1, 9, 33, 77]);

  for (let i = 0; i < 100; i++) {
    const fName = FIRST_NAMES[i % FIRST_NAMES.length];
    const mName = FATHER_NAMES[(i * 3) % FATHER_NAMES.length];
    const lName = FAMILY_NAMES[(i * 7) % FAMILY_NAMES.length];
    const fullName = `${fName} ${mName} ${lName}`;

    // Masked demo phone: 077 followed by 8 asterisks (077********) so no real number is exposed
    const phone = '077********';

    // Truly varied amounts across different ranges summing to 1,300,000
    const amount = DIVERSE_AMOUNTS_100[i] ?? 13000;
    const isHigh = amount >= highDebtThreshold;
    const isOverdue = OVERDUE_INDICES.has(i);

    // If among the 4 designated overdue debtors, assign status 'متأخر' (or 'دين مرتفع') and past date (40 days ago)
    const status = amount === 0
      ? 'خالي من الدين'
      : isOverdue
      ? 'متأخر'
      : isHigh
      ? 'دين مرتفع'
      : 'دين عادي';

    // Exactly 4 overdue debtors are set to 40 days ago; all others are set to today (0 days ago)
    const daysAgo = isOverdue ? 40 : 0;
    const dateObj = new Date(now - daysAgo * 24 * 60 * 60 * 1000);
    const dateStr = dateObj.toISOString();

    const debtorId = -1000 - i; // Negative IDs clearly denote local demo records

    const tx: DebtorTransaction = {
      id: `demo-tx-${i}-${now}`,
      debtorId,
      type: 'initial',
      amount,
      balanceAfter: amount,
      date: dateStr,
      description: amount > 0 ? 'دين أولي تجريبي (للاختبار)' : 'تسجيل حساب تجريبي خالي من الدين',
    };

    debtors.push({
      id: debtorId,
      name: fullName,
      phone,
      amount,
      status,
      userId,
      createdAt: dateStr,
      lastDebtDate: dateStr,
      history: [tx],
      isDemo: true,
    });
  }

  return debtors;
}
