import { AppSettings, Debtor, DebtorTransaction, Manager, User, InstallmentRecord } from '../types';
import { generateShieldHeaders } from '../utils/securityShield';
import { ALDION_DATABASE_CONFIG } from '../../aldion';

/**
 * Returns the backend API server base URL.
 * Supports:
 * 1. Custom URL set in settings / APK config (localStorage: aldion_backend_server_url)
 * 2. Current origin in web browser (window.location.origin)
 * 3. Default production Cloud Run backend host
 */
export function getBackendBaseUrl(): string {
  if (typeof window === 'undefined') return '';

  const saved = localStorage.getItem('aldion_backend_server_url');
  if (saved && saved.trim()) {
    return saved.trim().replace(/\/+$/, '');
  }

  // If in browser and not a local file system or local capacitor scheme
  if (
    window.location &&
    window.location.origin &&
    window.location.origin.startsWith('http') &&
    !window.location.origin.includes('capacitor://') &&
    !window.location.origin.includes('file://')
  ) {
    return window.location.origin;
  }

  // Fallback production backend server URL
  return 'https://ais-dev-3qeeb6jl5bktm64omzuibv-349740974703.europe-west2.run.app';
}

export function setBackendBaseUrl(url: string) {
  if (url && url.trim()) {
    localStorage.setItem('aldion_backend_server_url', url.trim().replace(/\/+$/, ''));
  } else {
    localStorage.removeItem('aldion_backend_server_url');
  }
}

/**
 * محرك استعلام مدمج مشفر (Embedded Encrypted Engine)
 * يعمل تلقائياً عند تحويل المشروع إلى PWA أو تطبيق هاتف أو استضافة ثابتة،
 * بحيث يستخرج الرابط والتوكن المشفرين بالبايتات ويتصل بالقاعدة مباشرة دون الحاجة لأي خادم خارجي.
 */
async function queryEmbeddedEncryptedTurso(trimmedSql: string, args: (string | number | null | undefined)[]) {
  const { url, token } = ALDION_DATABASE_CONFIG;
  if (!url || !token) {
    throw new Error('بيانات الاتصال المشفرة غير مهيأة');
  }

  const formattedArgs = args.map((a) => {
    if (typeof a === 'number') {
      return Number.isInteger(a)
        ? { type: 'integer', value: String(a) }
        : { type: 'float', value: String(a) };
    }
    return { type: 'text', value: String(a ?? '') };
  });

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          { type: 'execute', stmt: { sql: trimmedSql, args: formattedArgs } },
          { type: 'close' },
        ],
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`خطأ في قاعدة البيانات السحابية (${res.status}): ${errText.slice(0, 100)}`);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في استعلام قاعدة البيانات');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('انتهت مهلة الاتصال بقاعدة البيانات السحابية');
    }
    throw err;
  }
}

/**
 * Enterprise Resilient Database Proxy:
 * 1. يحاول أولاً الاتصال عبر الخادم المحمي (API Proxy) لضمان حماية الطبقة الأولى.
 * 2. إذا كان التطبيق يعمل كـ PWA أو APK أو استضافة سكونية والخادم أعاد صفحة HTML أو فشل،
 *    يتحول تلقائياً وسلساً إلى المحرك المشفر المدمج داخل المشروع لضمان استمرار عمل الـ PWA 100%.
 */
export async function queryTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();
  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    // إذا أعاد الخادم صفحة HTML أو خطأ توجيه (302/404/PWA Standalone redirect)
    const contentType = res.headers.get('content-type') || '';
    if (!res.ok || !contentType.includes('application/json')) {
      // التحول التلقائي للمحرك المدمج المشفر
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في تنفيذ استعلام القاعدة');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    // إذا تعذر الوصول للخادم بسبب CORS أو انقطاع أو تشغيل في بيئة PWA مستقلة
    try {
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    } catch (fallbackErr: any) {
      if (err.name === 'AbortError' || fallbackErr.name === 'AbortError') {
        throw new Error('انتهت مهلة الاتصال بالخادم، يرجى التحقق من اتصال الإنترنت');
      }
      throw fallbackErr || err;
    }
  }
}

// ---------------------- LOCAL STORAGE HELPERS ----------------------

export function getLocalDebtors(userId: number): Debtor[] | null {
  const data = localStorage.getItem(`debtors_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalDebtors(userId: number, debtors: Debtor[]) {
  localStorage.setItem(`debtors_user_${userId}`, JSON.stringify(debtors));
}

// Local Storage for Installments (نظام الأقساط المنفصل)
export function getLocalInstallments(userId: number): InstallmentRecord[] | null {
  const data = localStorage.getItem(`installments_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalInstallments(userId: number, installments: InstallmentRecord[]) {
  localStorage.setItem(`installments_user_${userId}`, JSON.stringify(installments));
}

export function getLocalUsers(): User[] | null {
  const data = localStorage.getItem("local_users");
  return data ? JSON.parse(data) : null;
}

export function setLocalUsers(users: User[]) {
  const safeUsers = users.map(({ password: _, ...u }) => u as User);
  localStorage.setItem("local_users", JSON.stringify(safeUsers));
}

export const DEFAULT_USER: User = {
  id: 1,
  username: 'admin',
  role: 'admin',
  branch_name: 'الفرع الرئيسي',
  isActive: true,
  subscriptionType: 'permanent',
};

export function getLocalSession(): User | null {
  try {
    const data = localStorage.getItem("session_user");
    if (!data) return null;
    const user: User = JSON.parse(data);
    if (!user || !user.id) return null;

    if (user.role !== 'admin' && user.id) {
      const forceLogout = localStorage.getItem(`force_logout_user_${user.id}`);
      if (forceLogout) {
        localStorage.removeItem("session_user");
        return null;
      }
      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        const managers: Manager[] = JSON.parse(managersData);
        const found = managers.find((m) => m.id === user.id);
        if (found && found.isActive === false) {
          localStorage.removeItem("session_user");
          return null;
        }
      }
    }
    if (!user.password) {
      const cachedPass = localStorage.getItem(`user_pwd_${user.id}`) || localStorage.getItem(`user_pwd_${user.username}`);
      if (cachedPass) {
        user.password = cachedPass;
      }
    }
    return user;
  } catch {
    return null;
  }
}

export function setLocalSession(user: User | null) {
  if (user) {
    localStorage.setItem("session_user", JSON.stringify(user));
    if (user.password) {
      localStorage.setItem(`user_pwd_${user.id}`, user.password);
      localStorage.setItem(`user_pwd_${user.username}`, user.password);
    }
  } else {
    localStorage.removeItem("session_user");
  }
}

// Multi-tab synchronization
export const sessionBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('submanager_auth_sync')
    : null;

export const debtorsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('debtors_realtime_sync')
    : null;

export const installmentsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('installments_realtime_sync')
    : null;

export const settingsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('settings_realtime_sync')
    : null;

export function broadcastDebtorsChange(userId: number, actionType?: string) {
  try {
    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.postMessage({
        type: 'DEBTORS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastInstallmentsChange(userId: number, actionType?: string) {
  try {
    if (installmentsBroadcastChannel) {
      installmentsBroadcastChannel.postMessage({
        type: 'INSTALLMENTS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastSettingsChange(userId: number, settings: AppSettings) {
  try {
    if (settingsBroadcastChannel) {
      settingsBroadcastChannel.postMessage({
        type: 'SETTINGS_UPDATED',
        userId,
        settings,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastManagerStatusChange(targetUserId: number, isActive: boolean, reason?: string) {
  try {
    if (!isActive) {
      localStorage.setItem(
        `force_logout_user_${targetUserId}`,
        JSON.stringify({
          timestamp: Date.now(),
          reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
        })
      );
      const current = getLocalSession();
      if (current && current.id === targetUserId) {
        localStorage.removeItem("session_user");
      }
    } else {
      localStorage.removeItem(`force_logout_user_${targetUserId}`);
    }

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.postMessage({
        type: isActive ? 'MANAGER_ACTIVATED' : 'FORCE_LOGOUT',
        targetUserId,
        reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
      });
    }
  } catch (e) {
    console.warn('Broadcast error:', e);
  }
}

export function getLocalManagers(): Manager[] | null {
  const data = localStorage.getItem("local_managers_list");
  return data ? JSON.parse(data) : null;
}

export function setLocalManagers(managers: Manager[]) {
  localStorage.setItem("local_managers_list", JSON.stringify(managers));
}

export const DEFAULT_SETTINGS: AppSettings = {
  enableDebtAlerts: true,
  alertDaysThreshold: 1,
  highDebtThreshold: 25000,
  numberFormat: 'english',
  language: 'ar',
  currency: 'IQD',
};

export function getLocalSettings(userId: number): AppSettings {
  try {
    const raw = localStorage.getItem(`app_settings_user_${userId}`);
    const globalLang = (localStorage.getItem('dftr_app_language') as any) || 'ar';
    const globalCurr = (localStorage.getItem('dftr_app_currency') as any) || 'IQD';
    const globalNumF = (localStorage.getItem('dftr_app_number_format') as any) || 'english';

    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enableDebtAlerts: parsed.enableDebtAlerts ?? true,
        alertDaysThreshold: parsed.alertDaysThreshold ?? 1,
        highDebtThreshold: parsed.highDebtThreshold ?? 25000,
        numberFormat: parsed.numberFormat ?? globalNumF,
        language: parsed.language ?? globalLang,
        currency: parsed.currency ?? globalCurr,
      };
    }
  } catch (e) {
    console.error("Error reading local settings:", e);
  }
  return { ...DEFAULT_SETTINGS };
}

export function setLocalSettings(userId: number, settings: AppSettings) {
  try {
    localStorage.setItem(`app_settings_user_${userId}`, JSON.stringify(settings));
  } catch (e) {
    console.error("Error saving local settings:", e);
  }
}

export function getLocalDebtorDates(userId: number): Record<number, string> {
  try {
    const raw = localStorage.getItem(`debtor_dates_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorDates(userId: number, dates: Record<number, string>) {
  try {
    localStorage.setItem(`debtor_dates_user_${userId}`, JSON.stringify(dates));
  } catch (e) {
    console.error("Error saving debtor dates:", e);
  }
}

export function getLocalDebtorHistory(userId: number): Record<number, DebtorTransaction[]> {
  try {
    const raw = localStorage.getItem(`debtor_history_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorHistory(userId: number, historyMap: Record<number, DebtorTransaction[]>) {
  try {
    localStorage.setItem(`debtor_history_user_${userId}`, JSON.stringify(historyMap));
  } catch (e) {
    console.error("Error saving debtor history:", e);
  }
}

/**
 * مزامنة الإعدادات (اللغة، العملة، الأرقام، التنبيهات، السقف) سحابياً لكل مستخدم/مدير فرعي
 */
export async function syncSettingsToCloud(userId: number, settings: AppSettings): Promise<void> {
  if (!userId || userId === 999999) return; // الحساب التجريبي محلي فقط
  try {
    const json = JSON.stringify(settings);
    const now = new Date().toISOString();
    await queryTurso(
      `INSERT INTO user_settings (user_id, settings_json, updated_at) 
       VALUES (?, ?, ?) 
       ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
      [userId, json, now]
    );
  } catch (err: any) {
    try {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`);
      const json = JSON.stringify(settings);
      const now = new Date().toISOString();
      await queryTurso(
        `INSERT INTO user_settings (user_id, settings_json, updated_at) 
         VALUES (?, ?, ?) 
         ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
        [userId, json, now]
      );
    } catch (e) {
      console.warn("Could not sync settings to cloud:", e);
    }
  }
}

/**
 * جلب الإعدادات السحابية للمستخدم عند تسجيل الدخول أو فتح الحساب من جهاز آخر
 */
export async function fetchSettingsFromCloud(userId: number): Promise<AppSettings | null> {
  if (!userId || userId === 999999) return null;
  try {
    let res;
    try {
      res = await queryTurso(
        `SELECT settings_json FROM user_settings WHERE user_id = ? LIMIT 1;`,
        [userId]
      );
    } catch {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`).catch(() => {});
      return null;
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }
    if (rows.length > 0 && rows[0][0]) {
      const val = rows[0][0]?.value ?? rows[0][0];
      if (typeof val === 'string') {
        return JSON.parse(val) as AppSettings;
      }
    }
  } catch (err) {
    console.warn("Could not fetch settings from cloud:", err);
  }
  return null;
}

