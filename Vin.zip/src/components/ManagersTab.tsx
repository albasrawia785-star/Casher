import React, { useState } from 'react';
import { Manager, SubscriptionType, ManagerModuleAccess, DatabaseAccount } from '../types';
import { formatDateDigits, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import { testDatabaseConnection, syncDatabasesToCloud } from '../services/turso';

interface ManagersTabProps {
  managers: Manager[];
  databases?: DatabaseAccount[];
  onRefreshDatabases?: () => Promise<void> | void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
  onCreateManager: (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType,
    subscriptionMonths?: number,
    allowedModules?: ManagerModuleAccess,
    databaseId?: string | null
  ) => Promise<void>;
  onToggleManagerStatus: (id: number, currentActive: boolean) => Promise<void>;
  onRenewSubscription: (id: number, months?: number) => Promise<void>;
  onChangeSubscriptionType?: (id: number, newType: SubscriptionType, months?: number) => Promise<void>;
  onChangeManagerModules?: (id: number, newAllowedModules: ManagerModuleAccess) => Promise<void>;
  onChangeManagerDatabase?: (id: number, databaseId: string | null) => Promise<void>;
  onDeleteManager: (id: number) => void;
  onUpdateManagerPassword?: (id: number, newPass: string) => Promise<void>;
  onUpgradeNewRegistration?: (
    id: number,
    subscriptionType: SubscriptionType,
    months?: number,
    allowedModules?: ManagerModuleAccess,
    databaseId?: string | null
  ) => Promise<void>;
  onRefreshManagers?: () => Promise<void> | void;
  isLoading?: boolean;
}

export const ManagersTab: React.FC<ManagersTabProps> = ({
  managers,
  databases = [],
  onRefreshDatabases,
  onShowToast,
  onCreateManager,
  onToggleManagerStatus,
  onRenewSubscription,
  onChangeSubscriptionType,
  onChangeManagerModules,
  onChangeManagerDatabase,
  onDeleteManager,
  onUpdateManagerPassword,
  onUpgradeNewRegistration,
  onRefreshManagers,
  isLoading = false,
}) => {
  const { t, numberFormat, dir } = useI18n();

  // Active top-level sub-tab: 'active_managers' | 'new_accounts'
  const [activeTab, setActiveTab] = useState<'active_managers' | 'new_accounts'>('active_managers');

  // Form states for creating manager manually
  const [branchName, setBranchName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [subscriptionType, setSubscriptionType] = useState<SubscriptionType>('permanent');
  const [subscriptionMonths, setSubscriptionMonths] = useState<number>(1);
  const [allowedModules, setAllowedModules] = useState<ManagerModuleAccess>('both');
  const [selectedDatabaseId, setSelectedDatabaseId] = useState<string>('default');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionInProgressId, setActionInProgressId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [revealedPasswords, setRevealedPasswords] = useState<Record<number, boolean>>({});
  const [copiedManagerId, setCopiedManagerId] = useState<number | null>(null);
  const [shareSuccessManagerId, setShareSuccessManagerId] = useState<number | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Upgrade Modal State (for New Registrations)
  const [upgradingAccount, setUpgradingAccount] = useState<Manager | null>(null);
  const [upgradeSubType, setUpgradeSubType] = useState<SubscriptionType>('monthly');
  const [upgradeMonths, setUpgradeMonths] = useState<number>(1);
  const [upgradeModules, setUpgradeModules] = useState<ManagerModuleAccess>('both');
  const [upgradeDatabaseId, setUpgradeDatabaseId] = useState<string>('default');
  const [isUpgrading, setIsUpgrading] = useState(false);

  // Inline "Add New Database" states inside modal or form
  const [showAddDbModal, setShowAddDbModal] = useState(false);
  const [newDbName, setNewDbName] = useState('');
  const [newDbUrl, setNewDbUrl] = useState('');
  const [newDbToken, setNewDbToken] = useState('');
  const [newDbDesc, setNewDbDesc] = useState('');
  const [isTestingNewDb, setIsTestingNewDb] = useState(false);
  const [isSavingNewDb, setIsSavingNewDb] = useState(false);
  const [newDbTestResult, setNewDbTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [newDbError, setNewDbError] = useState<string | null>(null);

  // Password editing state for Admin
  const [editingPasswordManagerId, setEditingPasswordManagerId] = useState<number | null>(null);
  const [editingPasswordInput, setEditingPasswordInput] = useState('');
  const [isSavingPasswordId, setIsSavingPasswordId] = useState<number | null>(null);

  const [filterDbId, setFilterDbId] = useState<string>('all');
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});

  // Split managers into:
  // 1. New Registrations (pending approval / trial registered)
  // 2. Approved Active Managers
  const newAccounts = React.useMemo(() => {
    return managers.filter((m) => m.isNewRegistration || m.subscriptionType === 'trial');
  }, [managers]);

  const activeManagers = React.useMemo(() => {
    return managers.filter((m) => !m.isNewRegistration && m.subscriptionType !== 'trial');
  }, [managers]);

  const toggleGroup = (groupId: string) => {
    setCollapsedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  // Group active managers by Database
  const databaseGroups = React.useMemo(() => {
    const validDbIds = new Set(databases.map((d) => d.id));

    const groups: {
      id: string;
      name: string;
      url?: string;
      isMain: boolean;
      managers: Manager[];
    }[] = [
      {
        id: 'default',
        name: 'القاعدة الرئيسية (الافتراضية)',
        isMain: true,
        managers: activeManagers.filter((m) => !m.databaseId || m.databaseId === 'default' || !validDbIds.has(m.databaseId)),
      },
    ];

    databases.forEach((db) => {
      groups.push({
        id: db.id,
        name: db.name,
        url: db.url,
        isMain: false,
        managers: activeManagers.filter((m) => m.databaseId === db.id),
      });
    });

    return groups;
  }, [activeManagers, databases]);

  const displayedGroups = React.useMemo(() => {
    if (filterDbId === 'all') {
      return databaseGroups;
    }
    return databaseGroups.filter((g) => g.id === filterDbId);
  }, [databaseGroups, filterDbId]);

  const togglePasswordVisibility = (id: number) => {
    setRevealedPasswords((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyManagerPassword = (id: number, pwd: string) => {
    try {
      navigator.clipboard.writeText(pwd);
      setCopiedManagerId(id);
      setTimeout(() => setCopiedManagerId(null), 2000);
    } catch {
      // Fallback
    }
  };

  // Share login credentials via WhatsApp without emojis
  const handleShareCredentials = (mgr: Manager, pwd: string) => {
    const bName = mgr.branch || t('common.branch', 'الفرع');
    const message = `مرحبا بك (${bName})\nاسم المستخدم: ${mgr.username}\nالرمز السري: ${pwd}\n`;

    try {
      navigator.clipboard.writeText(message);
    } catch {}

    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');

    setShareSuccessManagerId(mgr.id);
    setTimeout(() => setShareSuccessManagerId(null), 3000);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedBranch = branchName.trim();
    const trimmedUser = username.trim();
    const trimmedPass = password.trim();

    if (!trimmedBranch || !trimmedUser || !trimmedPass) {
      setError(t('managers.enterAllFieldsError', 'يرجى ملء جميع الحقول المطلوبة بشكل صحيح'));
      return;
    }

    if (trimmedPass.length < 3) {
      setError(t('managers.passwordMinLength', 'كلمة المرور يجب أن لا تقل عن 3 خانات'));
      return;
    }

    try {
      setIsSubmitting(true);
      await onCreateManager(
        trimmedBranch,
        trimmedUser,
        trimmedPass,
        subscriptionType,
        subscriptionType === 'monthly' ? subscriptionMonths : undefined,
        allowedModules,
        selectedDatabaseId === 'default' ? null : selectedDatabaseId
      );

      setBranchName('');
      setUsername('');
      setPassword('');
      setSubscriptionType('permanent');
      setSubscriptionMonths(1);
      setAllowedModules('both');
      setSelectedDatabaseId('default');
    } catch (err: any) {
      setError(err.message || t('toast.backupError', 'حدث خطأ أثناء إضافة الحساب'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveManagerPassword = async (managerId: number) => {
    const trimmed = editingPasswordInput.trim();
    if (!trimmed) {
      setError(t('settings.enterNewPassword', 'يرجى إدخال كلمة المرور الجديدة'));
      return;
    }
    if (trimmed.length < 3) {
      setError(t('settings.passwordMin3', 'كلمة المرور يجب ألا تقل عن 3 خانات'));
      return;
    }

    try {
      setIsSavingPasswordId(managerId);
      setError(null);
      if (onUpdateManagerPassword) {
        await onUpdateManagerPassword(managerId, trimmed);
      }
      setEditingPasswordManagerId(null);
      setEditingPasswordInput('');
    } catch (err: any) {
      setError(err.message || t('settings.passwordSaveFailed', 'فشل حفظ كلمة المرور'));
    } finally {
      setIsSavingPasswordId(null);
    }
  };

  // Open Upgrade Modal for New Account
  const handleOpenUpgradeModal = (account: Manager) => {
    setUpgradingAccount(account);
    setUpgradeSubType('monthly');
    setUpgradeMonths(1);
    setUpgradeModules(account.allowedModules || 'both');
    setUpgradeDatabaseId(account.databaseId || 'default');
  };

  // Submit Account Upgrade
  const handleConfirmUpgrade = async () => {
    if (!upgradingAccount) return;
    try {
      setIsUpgrading(true);
      if (onUpgradeNewRegistration) {
        await onUpgradeNewRegistration(
          upgradingAccount.id,
          upgradeSubType,
          upgradeSubType === 'monthly' ? upgradeMonths : undefined,
          upgradeModules,
          upgradeDatabaseId === 'default' ? null : upgradeDatabaseId
        );
      }
      setUpgradingAccount(null);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء تحويل وتفعيل الحساب');
    } finally {
      setIsUpgrading(false);
    }
  };

  // Test new database connection helper
  const handleTestNewDb = async () => {
    if (!newDbUrl.trim() || !newDbToken.trim()) {
      setNewDbTestResult({
        ok: false,
        message: 'يرجى كتابة رابط القاعدة ومفتاح التوكن أولاً لفحص الاتصال وتهيئتها',
      });
      return;
    }
    setIsTestingNewDb(true);
    setNewDbTestResult(null);
    setNewDbError(null);
    try {
      const res = await testDatabaseConnection(newDbUrl.trim(), newDbToken.trim(), true);
      setNewDbTestResult(res);
    } catch (err: any) {
      setNewDbTestResult({
        ok: false,
        message: err?.message || 'فشل الاتصال بالقاعدة أو تهيئتها',
      });
    } finally {
      setIsTestingNewDb(false);
    }
  };

  // Save new database helper
  const handleSaveNewDb = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewDbError(null);
    const name = newDbName.trim();
    const url = newDbUrl.trim();
    const token = newDbToken.trim();

    if (!name || !url || !token) {
      setNewDbError('يرجى كتابة اسم القاعدة، رابط القاعدة (libsql://...)، ومفتاح التوكن (JWT)');
      return;
    }

    try {
      setIsSavingNewDb(true);
      const testRes = await testDatabaseConnection(url, token, true);
      if (!testRes.ok) {
        throw new Error(testRes.message || 'تعذر الاتصال بالقاعدة أو تهيئتها');
      }

      const newAcc: DatabaseAccount = {
        id: 'db_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        name,
        url,
        token,
        description: newDbDesc.trim(),
        createdAt: new Date().toISOString(),
      };

      const updated = [...databases, newAcc];
      await syncDatabasesToCloud(updated);

      if (onRefreshDatabases) {
        await onRefreshDatabases();
      }

      // Auto-select this newly created database in the active flow
      if (upgradingAccount) {
        setUpgradeDatabaseId(newAcc.id);
      } else {
        setSelectedDatabaseId(newAcc.id);
      }

      if (onShowToast) {
        onShowToast(`تمت إضافة وتهيئة قاعدة البيانات "${newAcc.name}" بنجاح!`, 'success');
      }

      // Reset and close submodal
      setNewDbName('');
      setNewDbUrl('');
      setNewDbToken('');
      setNewDbDesc('');
      setNewDbTestResult(null);
      setNewDbError(null);
      setShowAddDbModal(false);
    } catch (err: any) {
      setNewDbError(err?.message || 'حدث خطأ أثناء حفظ قاعدة البيانات');
    } finally {
      setIsSavingNewDb(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300" dir={dir}>
      {/* Top Header & Section Switcher */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm shadow-xs">
              <i className="fa-solid fa-users-gear"></i>
            </div>
            <span>إدارة الحسابات والمدراء</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            إدارة صلاحيات المدراء الفرعيين، اعتماد الحسابات الجديدة، وتخصيص قواعد البيانات
          </p>
        </div>

        {/* Top Tab Switcher */}
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('active_managers')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'active_managers'
                ? 'bg-white text-blue-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <i className="fa-solid fa-user-shield text-xs"></i>
            <span>قائمة المدراء</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100/70 text-blue-700 font-extrabold">
              {activeManagers.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('new_accounts')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 relative ${
              activeTab === 'new_accounts'
                ? 'bg-white text-emerald-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <i className="fa-solid fa-user-plus text-xs"></i>
            <span>الحسابات الجديدة</span>
            {newAccounts.length > 0 && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500 text-white font-extrabold animate-pulse">
                {newAccounts.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Global Error Banner */}
      {error && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold rounded-2xl flex items-center justify-between gap-2 animate-in fade-in duration-200">
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation text-rose-500 text-sm shrink-0"></i>
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-rose-500 hover:text-rose-700 cursor-pointer p-1"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SECTION 1: الحسابات الجديدة (New Registrations Approval) */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'new_accounts' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="p-4 bg-emerald-50/70 border border-emerald-200/70 rounded-2xl flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <i className="fa-solid fa-info text-sm"></i>
            </div>
            <div className="text-xs text-emerald-900 leading-relaxed">
              <span className="font-bold block text-sm mb-0.5">الحسابات المسجلة حديثاً:</span>
              تظهر هنا الحسابات التي أنشأها المستخدمون من شاشة التسجيل. هذه الحسابات مقيدة بـ (2) مدينين أو عقود أقساط.
              يمكنك ترقية أي حساب وتفعيله كـ <strong>اشتراك شهري</strong> أو <strong>دائمي</strong>، ونقله فوراً إلى قائمة المدراء المعتمدين.
            </div>
          </div>

          {newAccounts.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 border border-slate-200/80 text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-200 text-slate-400 flex items-center justify-center mx-auto text-xl">
                <i className="fa-solid fa-user-check"></i>
              </div>
              <h3 className="font-bold text-slate-800 text-base">لا توجد حسابات جديدة معلقة</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                عند قيام مستخدم بإنشاء حساب جديد، سيظهر حسابه هنا لتتمكن من ترقيته وتفعيله.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {newAccounts.map((account) => {
                const pass = account.plainPassword || localStorage.getItem(`user_pwd_${account.id}`) || '';
                const isRevealed = !!revealedPasswords[account.id];
                const isCopied = copiedManagerId === account.id;

                return (
                  <div
                    key={account.id}
                    className="bg-white rounded-3xl p-5 border border-emerald-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative overflow-hidden"
                  >
                    <div className="space-y-3">
                      {/* Top status bar */}
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1.5">
                          <i className="fa-solid fa-clock text-amber-600"></i>
                          <span>حساب جديد (مقيد 2 فقط)</span>
                        </span>

                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                          {account.allowedModules === 'debts' ? 'دفتر ديون' : account.allowedModules === 'installments' ? 'نظام أقساط' : 'ديون + أقساط'}
                        </span>
                      </div>

                      {/* User Info */}
                      <div className="space-y-1.5 pt-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-500 font-medium">اسم المستخدم:</span>
                          <span className="font-bold text-slate-900 font-mono text-sm">{account.username}</span>
                        </div>

                        {account.phoneOrEmail && (
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-500 font-medium">البريد / الهاتف:</span>
                            <span className="font-semibold text-blue-700 select-all" dir="ltr">{account.phoneOrEmail}</span>
                          </div>
                        )}

                        {(account.securityAnswer || account.birthDate) && (
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-500 font-medium flex items-center gap-1">
                              <i className="fa-solid fa-paw text-amber-600 text-[11px]"></i>
                              <span>الحيوان المفضل:</span>
                            </span>
                            <span className="font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/80">
                              {account.securityAnswer || account.birthDate}
                            </span>
                          </div>
                        )}

                        {account.createdAt && (
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-500 font-medium">تاريخ التسجيل:</span>
                            <span className="text-slate-600 font-mono text-[11px]">
                              {formatDateDigits(account.createdAt)}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Password Box */}
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500 font-medium">كلمة السر:</span>
                          <span className="font-mono font-bold text-slate-900">
                            {pass ? (isRevealed ? pass : '••••••••') : 'مسجلة'}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          {pass && (
                            <>
                              <button
                                type="button"
                                onClick={() => togglePasswordVisibility(account.id)}
                                className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-600 cursor-pointer transition-colors"
                                title={isRevealed ? 'إخفاء' : 'إظهار'}
                              >
                                <i className={`fa-solid ${isRevealed ? 'fa-eye-slash' : 'fa-eye'} text-xs`}></i>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleCopyManagerPassword(account.id, pass)}
                                className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-600 cursor-pointer transition-colors"
                                title="نسخ"
                              >
                                <i className={`fa-solid ${isCopied ? 'fa-check text-emerald-600' : 'fa-copy'} text-xs`}></i>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleShareCredentials(account, pass)}
                                className="p-1.5 rounded-lg hover:bg-emerald-100 text-emerald-700 cursor-pointer transition-colors"
                                title="مشاركة عبر واتساب"
                              >
                                <i className="fa-brands fa-whatsapp text-sm"></i>
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="pt-4 mt-3 border-t border-slate-100 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleOpenUpgradeModal(account)}
                        className="flex-1 py-2.5 px-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                      >
                        <i className="fa-solid fa-circle-check text-xs"></i>
                        <span>تحويل وتفعيل الحساب</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteManager(account.id)}
                        className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                        title="حذف الحساب"
                      >
                        <i className="fa-solid fa-trash text-xs"></i>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* SECTION 2: قائمة المدراء المعتمدين (Active Managers) */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'active_managers' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Add Manager Form Card */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 mb-4">
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm font-bold shrink-0">
                <i className="fa-solid fa-user-plus"></i>
              </div>
              <h3 className="font-bold text-sm text-slate-900">
                {t('managers.addManagerTitle', 'إضافة مدير فرعي جديد يدوياً')}
              </h3>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Branch Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('managers.branchName', 'اسم الفرع / المتجر')} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={branchName}
                    onChange={(e) => setBranchName(e.target.value)}
                    placeholder="مثال: فرع الكرادة"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                    required
                  />
                </div>

                {/* Username */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('managers.username', 'اسم المستخدم')} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="مثال: manager_karada"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                    required
                  />
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {t('managers.password', 'كلمة المرور')} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="اكتب كلمة المرور..."
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white text-xs font-mono font-medium px-3.5 py-2.5 rounded-xl outline-none text-slate-900 transition-all"
                    required
                  />
                </div>
              </div>

              {/* Subscriptions & Permissions & Database row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                {/* Subscription Type */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    نوع الاشتراك
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={subscriptionType}
                      onChange={(e) => setSubscriptionType(e.target.value as SubscriptionType)}
                      className="flex-1 bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                    >
                      <option value="permanent">دائمي (غير محدود)</option>
                      <option value="monthly">شهري (محدد بالمدة)</option>
                    </select>

                    {subscriptionType === 'monthly' && (
                      <select
                        value={subscriptionMonths}
                        onChange={(e) => setSubscriptionMonths(Number(e.target.value))}
                        className="w-24 bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                      >
                        <option value={1}>شهر 1</option>
                        <option value={3}>3 أشهر</option>
                        <option value={6}>6 أشهر</option>
                        <option value={12}>سنة كاملة</option>
                      </select>
                    )}
                  </div>
                </div>

                {/* Permissions Module */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الأنظمة المصرح بها
                  </label>
                  <select
                    value={allowedModules}
                    onChange={(e) => setAllowedModules(e.target.value as ManagerModuleAccess)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                  >
                    <option value="both">كلاهما (دفتر ديون + نظام أقساط)</option>
                    <option value="debts">دفتر الديون فقط</option>
                    <option value="installments">نظام الأقساط فقط</option>
                  </select>
                </div>

                {/* Database Assignment */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      قاعدة البيانات المخصصة
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowAddDbModal(true)}
                      className="text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <i className="fa-solid fa-plus text-[10px]"></i>
                      <span>إضافة سيرفر جديد</span>
                    </button>
                  </div>
                  <select
                    value={selectedDatabaseId}
                    onChange={(e) => setSelectedDatabaseId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs font-bold p-2.5 rounded-xl outline-none text-slate-800"
                  >
                    <option value="default">القاعدة الرئيسية (الافتراضية)</option>
                    {databases.map((db) => (
                      <option key={db.id} value={db.id}>
                        {db.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Submit button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-2.5 px-6 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-all cursor-pointer flex items-center gap-2 shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>جاري الإضافة...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-plus text-xs"></i>
                      <span>حفظ وإضافة المدير</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Database Groups Filter Bar */}
          {databases.length > 0 && (
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">تصفية حسب القاعدة:</span>
                <select
                  value={filterDbId}
                  onChange={(e) => setFilterDbId(e.target.value)}
                  className="bg-white border border-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl outline-none text-slate-800"
                >
                  <option value="all">جميع القواعد ({activeManagers.length} مدير)</option>
                  <option value="default">القاعدة الرئيسية</option>
                  {databases.map((db) => (
                    <option key={db.id} value={db.id}>
                      {db.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Managers List by Groups */}
          <div className="space-y-4">
            {displayedGroups.map((group) => {
              const isCollapsed = !!collapsedGroups[group.id];

              return (
                <div key={group.id} className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
                  {/* Group Header */}
                  <div
                    onClick={() => toggleGroup(group.id)}
                    className="p-4 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between cursor-pointer select-none hover:bg-slate-100/70 transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold">
                        <i className="fa-solid fa-database"></i>
                      </div>
                      <div>
                        <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                          <span>{group.name}</span>
                          <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-blue-100/70 text-blue-700">
                            {group.managers.length} {t('managers.managerPlural', 'مدراء')}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="w-6 h-6 rounded-lg flex items-center justify-center text-slate-400">
                      <i className={`fa-solid fa-chevron-down text-xs transition-transform ${isCollapsed ? '' : 'rotate-180'}`}></i>
                    </div>
                  </div>

                  {/* Group Body */}
                  {!isCollapsed && (
                    <div className="p-4">
                      {group.managers.length === 0 ? (
                        <div className="text-center py-6 text-slate-400 text-xs">
                          لا يوجد مدراء معينين في هذه القاعدة
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                          {group.managers.map((mgr) => {
                            const pass = mgr.plainPassword || localStorage.getItem(`user_pwd_${mgr.id}`) || '';
                            const isRevealed = !!revealedPasswords[mgr.id];
                            const isCopied = copiedManagerId === mgr.id;
                            const isEditingPwd = editingPasswordManagerId === mgr.id;
                            const isExpired = isSubscriptionExpired(mgr.subscriptionExpiresAt);

                            return (
                              <div
                                key={mgr.id}
                                className={`rounded-2xl p-4 border transition-all space-y-3 ${
                                  !mgr.isActive
                                    ? 'bg-rose-50/30 border-rose-200/80'
                                    : isExpired && mgr.subscriptionType === 'monthly'
                                    ? 'bg-amber-50/30 border-amber-200/80'
                                    : 'bg-white border-slate-200/90 shadow-2xs hover:shadow-xs'
                                }`}
                              >
                                {/* Header: Branch name & status */}
                                <div className="flex items-center justify-between gap-2">
                                  <div>
                                    <div className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                                      <span>{mgr.branch}</span>
                                    </div>
                                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                                      @{mgr.username}
                                    </div>
                                  </div>

                                  <div className="flex items-center gap-1.5">
                                    <span
                                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                        mgr.subscriptionType === 'permanent'
                                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                          : isExpired
                                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                                          : 'bg-purple-50 text-purple-700 border-purple-200'
                                      }`}
                                    >
                                      {mgr.subscriptionType === 'permanent'
                                        ? 'دائم'
                                        : isExpired
                                        ? 'منتهي'
                                        : `شهري (${getSubscriptionDaysRemaining(mgr.subscriptionExpiresAt)} يوم)`}
                                    </span>

                                    <button
                                      type="button"
                                      onClick={() => onToggleManagerStatus(mgr.id, mgr.isActive)}
                                      className={`text-[10px] font-bold px-2.5 py-1 rounded-xl transition-all cursor-pointer ${
                                        mgr.isActive
                                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                          : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                                      }`}
                                    >
                                      {mgr.isActive ? 'مفعل' : 'معطل'}
                                    </button>
                                  </div>
                                </div>

                                {/* Details Box */}
                                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/60 text-xs space-y-2">
                                  {/* Phone / Email if available */}
                                  {mgr.phoneOrEmail && (
                                    <div className="flex items-center justify-between">
                                      <span className="text-slate-500">البريد / الهاتف:</span>
                                      <span className="font-semibold text-blue-700 select-all font-mono" dir="ltr">
                                        {mgr.phoneOrEmail}
                                      </span>
                                    </div>
                                  )}

                                  {/* Security Answer / Favorite Animal */}
                                  {(mgr.securityAnswer || mgr.birthDate) && (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500 flex items-center gap-1">
                                        <i className="fa-solid fa-paw text-amber-600 text-[11px]"></i>
                                        <span>الحيوان المفضل:</span>
                                      </span>
                                      <span className="font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/80">
                                        {mgr.securityAnswer || mgr.birthDate}
                                      </span>
                                    </div>
                                  )}

                                  {/* Creation Date if available */}
                                  {mgr.createdAt && (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500">تاريخ الإنشاء:</span>
                                      <span className="text-slate-600 font-mono text-[11px]">
                                        {formatDateDigits(mgr.createdAt)}
                                      </span>
                                    </div>
                                  )}

                                  {/* Modules Allowed */}
                                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                    <span className="text-slate-500">النظام المصرح:</span>
                                    <select
                                      value={mgr.allowedModules || 'both'}
                                      onChange={(e) => {
                                        if (onChangeManagerModules) {
                                          onChangeManagerModules(mgr.id, e.target.value as ManagerModuleAccess);
                                        }
                                      }}
                                      className="bg-white border border-slate-200 text-[11px] font-bold rounded-lg px-2 py-0.5 text-slate-800 outline-none"
                                    >
                                      <option value="both">كلاهما (ديون + أقساط)</option>
                                      <option value="debts">دفتر ديون فقط</option>
                                      <option value="installments">نظام أقساط فقط</option>
                                    </select>
                                  </div>

                                  {/* Database assignment dropdown */}
                                  {databases.length > 0 && (
                                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                      <span className="text-slate-500">القاعدة:</span>
                                      <select
                                        value={mgr.databaseId || 'default'}
                                        onChange={(e) => {
                                          if (onChangeManagerDatabase) {
                                            onChangeManagerDatabase(mgr.id, e.target.value === 'default' ? null : e.target.value);
                                          }
                                        }}
                                        className="bg-white border border-slate-200 text-[11px] font-bold rounded-lg px-2 py-0.5 text-slate-800 outline-none"
                                      >
                                        <option value="default">الرئيسية</option>
                                        {databases.map((db) => (
                                          <option key={db.id} value={db.id}>
                                            {db.name}
                                          </option>
                                        ))}
                                      </select>
                                    </div>
                                  )}

                                  {/* Password Row */}
                                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/40">
                                    <span className="text-slate-500">الرمز السري:</span>
                                    {!isEditingPwd ? (
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-mono font-bold text-slate-800">
                                          {pass ? (isRevealed ? pass : '••••••••') : 'محمي'}
                                        </span>

                                        {pass && (
                                          <>
                                            <button
                                              type="button"
                                              onClick={() => togglePasswordVisibility(mgr.id)}
                                              className="p-1 text-slate-500 hover:text-slate-800 cursor-pointer"
                                              title="إظهار"
                                            >
                                              <i className={`fa-solid ${isRevealed ? 'fa-eye-slash' : 'fa-eye'} text-[11px]`}></i>
                                            </button>

                                            <button
                                              type="button"
                                              onClick={() => handleCopyManagerPassword(mgr.id, pass)}
                                              className="p-1 text-slate-500 hover:text-slate-800 cursor-pointer"
                                              title="نسخ"
                                            >
                                              <i className={`fa-solid ${isCopied ? 'fa-check text-emerald-600' : 'fa-copy'} text-[11px]`}></i>
                                            </button>

                                            <button
                                              type="button"
                                              onClick={() => handleShareCredentials(mgr, pass)}
                                              className="p-1 text-emerald-600 hover:text-emerald-800 cursor-pointer"
                                              title="مشاركة عبر واتساب"
                                            >
                                              <i className="fa-brands fa-whatsapp text-xs"></i>
                                            </button>
                                          </>
                                        )}

                                        <button
                                          type="button"
                                          onClick={() => {
                                            setEditingPasswordManagerId(mgr.id);
                                            setEditingPasswordInput(pass || '');
                                          }}
                                          className="p-1 text-blue-600 hover:text-blue-800 cursor-pointer text-[11px]"
                                          title="تعديل الرمز"
                                        >
                                          <i className="fa-solid fa-pen-to-square"></i>
                                        </button>
                                      </div>
                                    ) : (
                                      <div className="flex items-center gap-1">
                                        <input
                                          type="text"
                                          value={editingPasswordInput}
                                          onChange={(e) => setEditingPasswordInput(e.target.value)}
                                          placeholder="رمز جديد..."
                                          className="w-24 bg-white border border-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded-md outline-none"
                                          autoFocus
                                        />
                                        <button
                                          type="button"
                                          onClick={() => handleSaveManagerPassword(mgr.id)}
                                          disabled={isSavingPasswordId === mgr.id}
                                          className="bg-blue-600 text-white px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer hover:bg-blue-700"
                                        >
                                          حفظ
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => setEditingPasswordManagerId(null)}
                                          className="bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded-md text-[11px] font-bold cursor-pointer"
                                        >
                                          إلغاء
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                </div>

                                {/* Actions Row */}
                                <div className="flex items-center justify-between gap-2 pt-1">
                                  {/* Subscription renewal if monthly */}
                                  {mgr.subscriptionType === 'monthly' && (
                                    <button
                                      type="button"
                                      onClick={() => onRenewSubscription(mgr.id, 1)}
                                      className="py-1.5 px-3 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                                    >
                                      <i className="fa-solid fa-arrows-rotate text-[10px]"></i>
                                      <span>تجديد شهر</span>
                                    </button>
                                  )}

                                  {/* Switch to Permanent / Monthly */}
                                  {onChangeSubscriptionType && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const newType = mgr.subscriptionType === 'permanent' ? 'monthly' : 'permanent';
                                        onChangeSubscriptionType(mgr.id, newType, 1);
                                      }}
                                      className="text-slate-500 hover:text-slate-800 text-[11px] font-medium underline cursor-pointer"
                                    >
                                      {mgr.subscriptionType === 'permanent' ? 'تحويل إلى شهري' : 'تحويل إلى دائمي'}
                                    </button>
                                  )}

                                  {/* Delete Manager */}
                                  <button
                                    type="button"
                                    onClick={() => onDeleteManager(mgr.id)}
                                    className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg text-xs font-bold transition-colors cursor-pointer mr-auto"
                                    title="حذف المدير"
                                  >
                                    <i className="fa-solid fa-trash"></i>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* UPGRADE MODAL FOR NEW REGISTRATIONS */}
      {/* ---------------------------------------------------- */}
      {upgradingAccount && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setUpgradingAccount(null)}
        >
          <div
            className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-base font-bold shadow-xs">
                  <i className="fa-solid fa-user-check"></i>
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">تحويل وتفعيل الحساب الجديد</h3>
                  <p className="text-[11px] text-slate-500">حساب: @{upgradingAccount.username}</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setUpgradingAccount(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              {/* Subscription Type Selection */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  نوع الاشتراك المطلوب تفعيله:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setUpgradeSubType('monthly')}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer text-center ${
                      upgradeSubType === 'monthly'
                        ? 'bg-purple-50 border-purple-500 text-purple-900 ring-2 ring-purple-500/20 shadow-xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    اشتراك شهري
                  </button>

                  <button
                    type="button"
                    onClick={() => setUpgradeSubType('permanent')}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer text-center ${
                      upgradeSubType === 'permanent'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-900 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    اشتراك دائمي (مدى الحياة)
                  </button>
                </div>
              </div>

              {/* If monthly, select months */}
              {upgradeSubType === 'monthly' && (
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    عدد أشهر الاشتراك:
                  </label>
                  <select
                    value={upgradeMonths}
                    onChange={(e) => setUpgradeMonths(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 font-bold p-2.5 rounded-xl outline-none text-slate-800"
                  >
                    <option value={1}>شهر واحد (1 شهر)</option>
                    <option value={2}>شهران (2 شهر)</option>
                    <option value={3}>3 أشهر</option>
                    <option value={6}>6 أشهر</option>
                    <option value={12}>سنة كاملة (12 شهر)</option>
                  </select>
                </div>
              )}

              {/* Module selection */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  الأنظمة المصرح بها:
                </label>
                <select
                  value={upgradeModules}
                  onChange={(e) => setUpgradeModules(e.target.value as ManagerModuleAccess)}
                  className="w-full bg-slate-50 border border-slate-200 font-bold p-2.5 rounded-xl outline-none text-slate-800"
                >
                  <option value="both">كلاهما (دفتر ديون + نظام أقساط)</option>
                  <option value="debts">دفتر الديون فقط</option>
                  <option value="installments">نظام الأقساط فقط</option>
                </select>
              </div>

              {/* Database assignment */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-slate-700">
                    قاعدة البيانات (السيرفر):
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowAddDbModal(true)}
                    className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <i className="fa-solid fa-plus text-[10px]"></i>
                    <span>إضافة سيرفر جديد</span>
                  </button>
                </div>
                <select
                  value={upgradeDatabaseId}
                  onChange={(e) => setUpgradeDatabaseId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-bold p-2.5 rounded-xl outline-none text-slate-800"
                >
                  <option value="default">القاعدة الرئيسية (الافتراضية)</option>
                  {databases.map((db) => (
                    <option key={db.id} value={db.id}>
                      {db.name}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">
                  يمكنك اختيار السيرفر الرئيسي أو تحديد سيرفر مخصص/إضافة سيرفر جديد لهذا المشترك
                </p>
              </div>
            </div>

            {/* Modal Buttons */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setUpgradingAccount(null)}
                className="py-2.5 px-4 rounded-xl text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 cursor-pointer transition-colors"
              >
                إلغاء
              </button>

              <button
                type="button"
                onClick={handleConfirmUpgrade}
                disabled={isUpgrading}
                className="py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-xs cursor-pointer flex items-center gap-1.5 transition-all disabled:opacity-50"
              >
                {isUpgrading ? (
                  <>
                    <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                    <span>جاري التفعيل...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-check text-xs"></i>
                    <span>تأكيد التحويل إلى قائمة المدراء</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD NEW DATABASE / SERVER */}
      {showAddDbModal && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200"
          onClick={() => setShowAddDbModal(false)}
        >
          <div
            className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-base font-bold shadow-xs">
                  <i className="fa-solid fa-server"></i>
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">إضافة سيرفر / قاعدة بيانات جديدة</h3>
                  <p className="text-[11px] text-slate-500">ربط سيرفر Turso LibSQL وتجهيز الجداول فوراً</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowAddDbModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {newDbError && (
              <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl border border-red-200/80 flex items-center gap-2">
                <i className="fa-solid fa-circle-exclamation shrink-0"></i>
                <span>{newDbError}</span>
              </div>
            )}

            {newDbTestResult && (
              <div
                className={`p-3 text-xs rounded-xl border flex items-center gap-2 ${
                  newDbTestResult.ok
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-red-50 text-red-700 border-red-200'
                }`}
              >
                <i
                  className={`fa-solid ${
                    newDbTestResult.ok ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-red-600'
                  } shrink-0`}
                ></i>
                <span>{newDbTestResult.message}</span>
              </div>
            )}

            <form onSubmit={handleSaveNewDb} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  اسم السيرفر / الفرع:
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: سيرفر فرع المنصور / بغداد"
                  value={newDbName}
                  onChange={(e) => setNewDbName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-bold p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  رابط السيرفر (Database URL):
                </label>
                <input
                  type="text"
                  required
                  dir="ltr"
                  placeholder="libsql://your-db-name.turso.io"
                  value={newDbUrl}
                  onChange={(e) => setNewDbUrl(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-mono text-[11px] p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  مفتاح التوكن (Auth Token):
                </label>
                <input
                  type="password"
                  required
                  dir="ltr"
                  placeholder="eyJh..."
                  value={newDbToken}
                  onChange={(e) => setNewDbToken(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-mono text-[11px] p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  ملاحظات أو وصف (اختياري):
                </label>
                <input
                  type="text"
                  placeholder="وصف مختصر للسيرفر..."
                  value={newDbDesc}
                  onChange={(e) => setNewDbDesc(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 font-bold p-2.5 rounded-xl outline-none text-slate-800 focus:border-blue-500 focus:bg-white transition-all"
                />
              </div>

              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={handleTestNewDb}
                  disabled={isTestingNewDb || isSavingNewDb}
                  className="py-2.5 px-3 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  {isTestingNewDb ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>جاري الفحص...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-bolt text-xs text-amber-500"></i>
                      <span>فحص الاتصال</span>
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddDbModal(false)}
                    className="py-2.5 px-3 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 cursor-pointer transition-colors"
                  >
                    إلغاء
                  </button>

                  <button
                    type="submit"
                    disabled={isSavingNewDb || isTestingNewDb}
                    className="py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs cursor-pointer flex items-center gap-1.5 transition-all disabled:opacity-50"
                  >
                    {isSavingNewDb ? (
                      <>
                        <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                        <span>جاري الحفظ والتهيئة...</span>
                      </>
                    ) : (
                      <>
                        <i className="fa-solid fa-check text-xs"></i>
                        <span>حفظ واختيار السيرفر</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
