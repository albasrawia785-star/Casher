import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';

interface ResponsiveColumns {
  default: number;
  sm?: number; // >= 640px
  md?: number; // >= 768px
  lg?: number; // >= 1024px
  xl?: number; // >= 1280px
}

export interface VirtualGridProps<T> {
  items: T[];
  itemHeight: number; // approximate height per card in px
  gap?: number; // gap between items in px (default: 10px)
  columns?: number | ResponsiveColumns;
  overscan?: number; // number of buffer rows above and below visible area (default: 4)
  renderItem: (item: T, index: number) => React.ReactNode;
  keyExtractor?: (item: T, index: number) => string | number;
  emptyComponent?: React.ReactNode;
  scrollContainerRef?: React.RefObject<HTMLElement | null>;
  className?: string;
  gridClassName?: string;
}

export function VirtualGrid<T>({
  items,
  itemHeight,
  gap = 10,
  columns = { default: 1, md: 2, lg: 3 },
  overscan = 4,
  renderItem,
  keyExtractor,
  emptyComponent,
  scrollContainerRef,
  className = '',
  gridClassName = '',
}: VirtualGridProps<T>) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [containerHeight, setContainerHeight] = useState(800);
  const [containerWidth, setContainerWidth] = useState(1024);
  const rafIdRef = useRef<number | null>(null);

  // Compute active column count based on container width
  const columnCount = useMemo(() => {
    if (typeof columns === 'number') {
      return Math.max(1, columns);
    }
    const width = containerWidth;
    if (columns.xl && width >= 1280) return columns.xl;
    if (columns.lg && width >= 1024) return columns.lg;
    if (columns.md && width >= 768) return columns.md;
    if (columns.sm && width >= 640) return columns.sm;
    return Math.max(1, columns.default || 1);
  }, [columns, containerWidth]);

  // Find the actual scrollable ancestor
  const getScrollContainer = useCallback((): HTMLElement | Window => {
    if (scrollContainerRef && scrollContainerRef.current) {
      return scrollContainerRef.current;
    }
    let el = containerRef.current?.parentElement;
    while (el) {
      const overflowY = window.getComputedStyle(el).overflowY;
      if (overflowY === 'auto' || overflowY === 'scroll') {
        return el;
      }
      el = el.parentElement;
    }
    return window;
  }, [scrollContainerRef]);

  // Setup scroll and resize observers
  useEffect(() => {
    const scrollTarget = getScrollContainer();
    const isWin = scrollTarget === window;

    const handleScroll = () => {
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
      }
      rafIdRef.current = requestAnimationFrame(() => {
        if (isWin) {
          const containerTop = containerRef.current?.getBoundingClientRect().top ?? 0;
          setScrollTop(Math.max(0, -containerTop));
          setContainerHeight(window.innerHeight);
        } else {
          const target = scrollTarget as HTMLElement;
          setScrollTop(target.scrollTop);
          setContainerHeight(target.clientHeight);
        }
      });
    };

    // Initial measurement
    if (isWin) {
      setContainerHeight(window.innerHeight);
      if (containerRef.current) {
        setContainerWidth(containerRef.current.clientWidth || window.innerWidth);
      }
    } else {
      const target = scrollTarget as HTMLElement;
      setScrollTop(target.scrollTop);
      setContainerHeight(target.clientHeight || 800);
      setContainerWidth(target.clientWidth || 1024);
    }

    // Resize observer
    let resizeObs: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && containerRef.current) {
      resizeObs = new ResizeObserver((entries) => {
        for (const entry of entries) {
          const w = entry.contentRect.width;
          if (w > 0) setContainerWidth(w);
        }
      });
      resizeObs.observe(containerRef.current);
    }

    scrollTarget.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll, { passive: true });

    return () => {
      scrollTarget.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
      if (resizeObs) resizeObs.disconnect();
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
      }
    };
  }, [getScrollContainer]);

  if (items.length === 0) {
    return <>{emptyComponent || null}</>;
  }

  // Virtual math calculations
  const totalRows = Math.ceil(items.length / columnCount);
  const rowStride = itemHeight + gap;
  const totalHeight = totalRows > 0 ? totalRows * rowStride - gap : 0;

  const startRow = Math.max(0, Math.floor(scrollTop / rowStride) - overscan);
  const endRow = Math.min(totalRows, Math.ceil((scrollTop + containerHeight) / rowStride) + overscan);

  const startIndex = startRow * columnCount;
  const endIndex = Math.min(items.length, endRow * columnCount);

  const visibleItems = items.slice(startIndex, endIndex);
  const topSpacerHeight = startRow * rowStride;
  const bottomSpacerHeight = Math.max(0, (totalRows - endRow) * rowStride);

  return (
    <div ref={containerRef} className={`w-full relative ${className}`} style={{ minHeight: totalHeight }}>
      {topSpacerHeight > 0 && (
        <div style={{ height: topSpacerHeight, width: '100%' }} aria-hidden="true" />
      )}

      <div
        className={`grid gap-2.5 ${gridClassName}`}
        style={{
          gridTemplateColumns: `repeat(${columnCount}, minmax(0, 1fr))`,
        }}
      >
        {visibleItems.map((item, idx) => {
          const actualIndex = startIndex + idx;
          const key = keyExtractor ? keyExtractor(item, actualIndex) : actualIndex;
          return <React.Fragment key={key}>{renderItem(item, actualIndex)}</React.Fragment>;
        })}
      </div>

      {bottomSpacerHeight > 0 && (
        <div style={{ height: bottomSpacerHeight, width: '100%' }} aria-hidden="true" />
      )}
    </div>
  );
}
