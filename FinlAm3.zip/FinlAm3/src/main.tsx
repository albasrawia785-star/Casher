import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initializeCyberShield } from './utils/securityShield';
import { I18nProvider } from './i18n/index.tsx';
import { ErrorBoundary } from './components/ErrorBoundary';

// تفعيل درع الحماية الفوري الآمن
try {
  initializeCyberShield();
} catch (e) {
  console.warn('Security shield init skipped:', e);
}

const rootElement = document.getElementById('root');

if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <ErrorBoundary>
        <I18nProvider>
          <App />
        </I18nProvider>
      </ErrorBoundary>
    </StrictMode>,
  );
}


