import { AppLayoutTheme } from '../types';

export interface LayoutThemeDefinition {
  id: AppLayoutTheme;
  title: string;
  englishTitle: string;
  subtitle: string;
  badge: string;
  icon: string;
  accentColor: string;
  borderColor: string;
  bgGradient: string;
  description: string;
  keyFeatures: string[];
  appBgClass: string;
  headerBgClass: string;
  controlsBgClass: string;
  navBgClass: string;
  cardBgClass: string;
}

export const LAYOUT_THEMES: LayoutThemeDefinition[] = [
  {
    id: 'fintech',
    title: 'المنصة المالية المصرفية',
    englishTitle: 'Neo-Banking Clean Flow (تصميم 1 الحديث)',
    subtitle: 'واجهة بنكية حديثة بألوان كحلي وأخضر زمردي راقية مع شريط عائم',
    badge: 'تصميم 1 (الحديث)',
    icon: 'fa-solid fa-building-columns',
    accentColor: 'text-emerald-700 bg-emerald-50 border-emerald-200',
    borderColor: 'border-emerald-300',
    bgGradient: 'from-slate-900 via-blue-950 to-slate-950',
    description: 'محفظة مالية عريضة بمؤشر سيولة أخضر، بطاقات بيضاء ناصعة بمبالغ زرقاء داكنة وأزرار سداد زمردية سريعة بلمسة واحدة، وشريط عائم.',
    keyFeatures: ['محفظة رصيد بنكية', 'أزرار سداد زمردية مريحة', 'شريط تنقل سفلي عائم Dock'],
    appBgClass: 'bg-slate-100 text-slate-800',
    headerBgClass: 'bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white',
    controlsBgClass: 'bg-slate-50 border-slate-200/80',
    navBgClass: 'bg-white/95 backdrop-blur-md border-slate-200 text-slate-700',
    cardBgClass: 'bg-white border-slate-200/80 shadow-xs',
  },
  {
    id: 'classic',
    title: 'التصميم الكلاسيكي الأصلي',
    englishTitle: 'Classic Native Pro (التصميم الأصلي)',
    subtitle: 'التصميم المعتمد الأصلي الأكثر بساطة وملاءمة',
    badge: 'الأصلي',
    icon: 'fa-solid fa-layer-group',
    accentColor: 'text-blue-600 bg-blue-50 border-blue-200',
    borderColor: 'border-slate-200',
    bgGradient: 'from-blue-50/50 to-white',
    description: 'بطاقات بيضاء مع شريط حالة جانبي ملون وعناصر تحكم سريعة وواضحة.',
    keyFeatures: ['شريط ملون للحالة', 'قائمة خيارات منبثقة', 'عرض سريع لبيانات الهاتف والتاريخ'],
    appBgClass: 'bg-slate-100 text-slate-800',
    headerBgClass: 'bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white',
    controlsBgClass: 'bg-slate-50 border-slate-200/60',
    navBgClass: 'bg-white/95 border-slate-200 text-slate-700',
    cardBgClass: 'bg-white border-slate-200/80 shadow-xs',
  }
];

export function getLayoutThemeMeta(themeId?: AppLayoutTheme | string): LayoutThemeDefinition {
  const found = LAYOUT_THEMES.find(t => t.id === themeId);
  return found || LAYOUT_THEMES[0];
}
