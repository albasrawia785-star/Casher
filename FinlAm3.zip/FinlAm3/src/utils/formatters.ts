export function toEnglishDigits(str: string | number | null | undefined): string {
  if (str === null || str === undefined) return '';
  const arabicToEnglishMap: Record<string, string> = {
    '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
    '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
    '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
    '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
  };
  return String(str).replace(/[٠-٩۰-۹]/g, (d) => arabicToEnglishMap[d] || d);
}

export function toArabicDigits(str: string | number | null | undefined): string {
  if (str === null || str === undefined) return '';
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(str).replace(/[0-9]/g, (d) => arabicDigits[parseInt(d, 10)]);
}

export function formatNumber(
  num: number | string | null | undefined,
  format: 'english' | 'arabic' | string = 'english'
): string {
  if (num === null || num === undefined) return format === 'arabic' ? '٠' : '0';
  const clean = toEnglishDigits(num);
  if (isNaN(Number(clean))) return format === 'arabic' ? '٠' : '0';
  const formatted = Number(clean).toLocaleString('en-US');
  return format === 'arabic' ? toArabicDigits(formatted) : formatted;
}

export function parseFormattedNumber(val: string | number | null | undefined): number {
  if (!val) return 0;
  const englishVal = toEnglishDigits(val);
  return parseFloat(String(englishVal).replace(/,/g, '')) || 0;
}

export function formatAmountInput(value: string): string {
  const englishVal = toEnglishDigits(value);
  const rawValue = englishVal.replace(/[^0-9]/g, '');
  if (rawValue === '') return '';
  return parseInt(rawValue, 10).toLocaleString('en-US');
}

export function formatDateDigits(
  dateStr?: string | null,
  format: 'english' | 'arabic' | string = 'english'
): string {
  if (!dateStr) return '';
  const normalized = toEnglishDigits(dateStr);
  if (format === 'arabic') {
    return toArabicDigits(normalized);
  }
  return normalized;
}

export function formatIraqiPhoneNumber(phone: string): string {
  if (!phone) return "";
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('07') && cleaned.length === 11) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.startsWith('00964')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.length === 10 && (cleaned.startsWith('77') || cleaned.startsWith('78') || cleaned.startsWith('75') || cleaned.startsWith('79'))) {
    cleaned = '964' + cleaned;
  }
  return cleaned;
}

export function buildWhatsAppReminderUrl(phone: string, debtorName?: string, amount?: number): string {
  const formattedPhone = formatIraqiPhoneNumber(phone);
  const text = amount && amount > 0 && debtorName
    ? `السلام عليكم ورحمة الله، أخي الكريم ${debtorName}، يرجى التكرم بمراجعة الحساب القائم بذمتكم وقدره (${formatNumber(amount)} د.ع) لغرض التسديد. مع الشكر والتقدير.`
    : "تذكير: يرجى مراجعة الحساب والتسديد.";
  return `https://wa.me/${formattedPhone}?text=${encodeURIComponent(text)}`;
}

/**
 * Calculates number of full elapsed days from a date string to now
 */
export function calculateDaysElapsed(dateStr?: string | null): number {
  if (!dateStr) return 0;
  const parsed = new Date(dateStr).getTime();
  if (isNaN(parsed)) return 0;
  const diffMs = Date.now() - parsed;
  if (diffMs <= 0) return 0;
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Formats elapsed days count into natural Arabic text
 */
export function formatDaysElapsedArabic(days: number): string {
  if (days <= 0) return "أقل من يوم";
  if (days === 1) return "يوم واحد";
  if (days === 2) return "يومان";
  if (days >= 3 && days <= 10) return `${days} أيام`;
  return `${days} يوماً`;
}

/**
 * Formats ISO date into readable short date (YYYY/MM/DD)
 */
export function formatDateArabic(dateStr?: string | null): string {
  if (!dateStr) return "";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "";
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}/${m}/${day}`;
  } catch {
    return "";
  }
}

/**
 * Calculates remaining days until subscription expires
 */
export function getSubscriptionDaysRemaining(expiresAt?: string | null): number {
  if (!expiresAt) return 0;
  const parsed = new Date(expiresAt).getTime();
  if (isNaN(parsed)) return 0;
  const diffMs = parsed - Date.now();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Checks if a monthly subscription has expired
 */
export function isSubscriptionExpired(subscriptionType?: string, expiresAt?: string | null): boolean {
  if (subscriptionType !== 'monthly') return false;
  if (!expiresAt) return true; // Monthly with no expiry is expired
  const parsed = new Date(expiresAt).getTime();
  if (isNaN(parsed)) return true;
  return parsed <= Date.now();
}

/**
 * Formats ISO date into readable Arabic date and time (e.g. 9 أيلول 2026، 01:25 م)
 */
export function formatDateTimeArabic(dateStr?: string | null): string {
  if (!dateStr) return "";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "";
    return d.toLocaleString('ar-IQ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return dateStr || "";
  }
}

