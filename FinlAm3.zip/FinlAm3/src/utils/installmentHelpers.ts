import { InstallmentRecord, InstallmentStatus } from '../types';
import { formatNumber, toEnglishDigits } from './formatters';

/**
 * Calculates the next due date by adding 1 month (or N months) to a base date.
 * Handles month overflows cleanly (e.g. Jan 31 -> Feb 28).
 */
export function calculateNextMonthDueDate(baseDateStr: string, monthsToAdd: number = 1): string {
  try {
    const cleanDateStr = toEnglishDigits(baseDateStr).replace(/\//g, '-');
    const d = new Date(cleanDateStr);
    if (isNaN(d.getTime())) {
      const now = new Date();
      now.setMonth(now.getMonth() + monthsToAdd);
      return now.toISOString().split('T')[0];
    }
    
    const day = d.getDate();
    d.setMonth(d.getMonth() + monthsToAdd);
    
    // If the day changed due to overflow (e.g., Feb 30 -> Mar 2), set to last day of target month
    if (d.getDate() !== day) {
      d.setDate(0);
    }
    
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const dayStr = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${dayStr}`;
  } catch {
    const now = new Date();
    return now.toISOString().split('T')[0];
  }
}

/**
 * Computes the dynamic status of an installment based on remaining balance and dates.
 * - If remainingAmount <= 0 => 'completed' (مسدد بالكامل)
 * - If nextDueDate <= today => 'due' (مستحق اليوم أو سابقاً)
 * - If nextDueDate < today by more than 3 days => 'overdue' (متأخر)
 * - Otherwise => 'active' (ساري / قادم)
 */
export function computeInstallmentStatus(installment: {
  remainingAmount: number;
  nextDueDate: string;
  registrationDate: string;
}): InstallmentStatus {
  if (installment.remainingAmount <= 0) {
    return 'completed';
  }

  const todayStr = new Date().toISOString().split('T')[0];
  const dueDateStr = installment.nextDueDate || calculateNextMonthDueDate(installment.registrationDate);

  if (dueDateStr < todayStr) {
    // Check how many days passed
    const diffDays = calculateDateDiffDays(dueDateStr, todayStr);
    return diffDays >= 2 ? 'overdue' : 'due';
  } else if (dueDateStr === todayStr) {
    return 'due';
  }

  return 'active';
}

/**
 * Helper to calculate difference in days between two YYYY-MM-DD dates
 */
export function calculateDateDiffDays(fromStr: string, toStr: string): number {
  try {
    const f = new Date(fromStr).getTime();
    const t = new Date(toStr).getTime();
    if (isNaN(f) || isNaN(t)) return 0;
    return Math.floor((t - f) / (1000 * 60 * 60 * 24));
  } catch {
    return 0;
  }
}

/**
 * Formats due date status into human Arabic text
 */
export function formatDueDateBadge(dueDateStr: string, status: InstallmentStatus): {
  label: string;
  badgeClass: string;
  icon: string;
  daysDiff: number;
} {
  const todayStr = new Date().toISOString().split('T')[0];
  const diff = calculateDateDiffDays(dueDateStr, todayStr);

  if (status === 'completed') {
    return {
      label: 'مسدد بالكامل',
      badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      icon: 'fa-circle-check',
      daysDiff: 0,
    };
  }

  if (diff > 0) {
    // Past due
    return {
      label: `متأخر منذ ${diff === 1 ? 'يوم' : diff === 2 ? 'يومين' : diff <= 10 ? `${diff} أيام` : `${diff} يوماً`}`,
      badgeClass: 'bg-rose-50 text-rose-700 border-rose-200 font-bold',
      icon: 'fa-triangle-exclamation',
      daysDiff: diff,
    };
  } else if (diff === 0) {
    // Due today
    return {
      label: 'مستحق الدفع اليوم!',
      badgeClass: 'bg-amber-50 text-amber-800 border-amber-300 font-extrabold animate-pulse',
      icon: 'fa-bell',
      daysDiff: 0,
    };
  } else {
    // Upcoming in future
    const upcomingDays = Math.abs(diff);
    return {
      label: `مستحق بعد ${upcomingDays === 1 ? 'يوم' : upcomingDays === 2 ? 'يومين' : upcomingDays <= 10 ? `${upcomingDays} أيام` : `${upcomingDays} يوماً`}`,
      badgeClass: 'bg-blue-50 text-blue-700 border-blue-200',
      icon: 'fa-calendar-clock',
      daysDiff: diff,
    };
  }
}

/**
 * Builds WhatsApp reminder message tailored for installments
 */
export function buildInstallmentWhatsAppUrl(
  phone: string,
  name: string,
  item: string,
  remainingAmount: number,
  dueDate: string
): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('07') && cleaned.length === 11) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.startsWith('00964')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.length === 10 && (cleaned.startsWith('77') || cleaned.startsWith('78') || cleaned.startsWith('75') || cleaned.startsWith('79'))) {
    cleaned = '964' + cleaned;
  }

  const text = `السلام عليكم ورحمة الله، أخي الكريم ${name} المحترم،\nنود تذكيركم بموعد استحقاق قسط (${item})، المتبقي بذمتكم: (${formatNumber(remainingAmount)} د.ع)، وتاريخ الاستحقاق هو: ${dueDate}.\nيرجى التكرم بالمراجعة والتسديد. شاكرين حسن تعاونكم.`;
  return `https://wa.me/${cleaned}?text=${encodeURIComponent(text)}`;
}
