import { OutboxAction } from '../types';
import { addOutboxAction, getOutboxActions, removeOutboxAction } from './idb';
import { queryTurso } from './turso';

let isFlushing = false;

/**
 * Queue a new transaction action into the local outbox.
 */
export async function queueOutboxAction(
  userId: number,
  type: OutboxAction['type'],
  payload: any
): Promise<OutboxAction> {
  const action: OutboxAction = {
    id: `action_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    userId,
    type,
    payload,
    timestamp: Date.now(),
  };

  await addOutboxAction(action);
  // Attempt background flush immediately
  flushOutbox(userId).catch(() => {});
  return action;
}

/**
 * Process all queued outbox actions sequentially for the user.
 * Returns true if all actions were successfully flushed (or outbox is empty), false if network error occurred.
 */
export async function flushOutbox(userId: number): Promise<boolean> {
  if (isFlushing || typeof navigator !== 'undefined' && !navigator.onLine) {
    return false;
  }

  isFlushing = true;
  try {
    const actions = await getOutboxActions(userId);
    if (actions.length === 0) {
      return true;
    }

    for (const action of actions) {
      try {
        await executeOutboxAction(action);
        await removeOutboxAction(action.id);
      } catch (err: any) {
        console.warn(`[OutboxSync] Failed to process action ${action.type} (${action.id}):`, err?.message || err);
        // Stop flushing remaining items if network is down or query failed
        return false;
      }
    }

    return true;
  } finally {
    isFlushing = false;
  }
}

async function executeOutboxAction(action: OutboxAction): Promise<void> {
  const { userId, type, payload } = action;

  switch (type) {
    case 'ADD_DEBTOR': {
      const historyJson = JSON.stringify(payload.history || []);
      try {
        await queryTurso(
          "INSERT INTO debtors (id, name, phone, amount, status, user_id, created_at, history) VALUES (?, ?, ?, ?, ?, ?, ?, ?);",
          [
            payload.id,
            payload.name,
            payload.phone || '',
            payload.amount || 0,
            payload.status || 'مستمر',
            userId,
            payload.createdAt || new Date().toISOString(),
            historyJson,
          ]
        );
      } catch {
        // If row with ID already exists, update it
        await queryTurso(
          "UPDATE debtors SET name = ?, phone = ?, amount = ?, status = ?, history = ? WHERE id = ? AND user_id = ?;",
          [
            payload.name,
            payload.phone || '',
            payload.amount || 0,
            payload.status || 'مستمر',
            historyJson,
            payload.id,
            userId,
          ]
        );
      }
      break;
    }

    case 'UPDATE_DEBTOR': {
      await queryTurso(
        "UPDATE debtors SET name = ?, phone = ? WHERE id = ? AND user_id = ?;",
        [payload.name, payload.phone || '', payload.id, userId]
      );
      break;
    }

    case 'TRANSACTION_DEBT': {
      const historyJson = JSON.stringify(payload.history || []);
      await queryTurso(
        "UPDATE debtors SET amount = ?, status = ?, history = ?, last_debt_date = ? WHERE id = ? AND user_id = ?;",
        [
          payload.amount,
          payload.status,
          historyJson,
          payload.lastDebtDate || null,
          payload.id,
          userId,
        ]
      );
      break;
    }

    case 'DELETE_DEBTOR': {
      await queryTurso("DELETE FROM debtors WHERE id = ? AND user_id = ?;", [payload.id, userId]);
      break;
    }

    case 'ADD_INSTALLMENT': {
      const paymentsJson = JSON.stringify(payload.payments || []);
      try {
        await queryTurso(
          "INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
          [
            payload.id,
            payload.name,
            payload.phone || '',
            payload.item,
            payload.totalAmount,
            payload.downPayment,
            payload.remainingAmount,
            payload.registrationDate,
            payload.nextDueDate,
            userId,
            payload.status,
            payload.notes || '',
            paymentsJson,
            payload.createdAt || new Date().toISOString(),
            payload.nationalId || null,
            payload.address || null,
            payload.guarantorEnabled ? 1 : 0,
            payload.guarantorName || null,
            payload.guarantorAddress || null,
            payload.guarantorJob || null,
            payload.guarantorRelation || null,
            payload.guarantorPhone || null,
          ]
        );
      } catch {
        await queryTurso(
          `UPDATE installments SET 
            name = ?, phone = ?, item = ?, total_amount = ?, down_payment = ?, remaining_amount = ?, registration_date = ?, next_due_date = ?, status = ?, notes = ?, payments = ?, national_id = ?, address = ?, guarantor_enabled = ?, guarantor_name = ?, guarantor_address = ?, guarantor_job = ?, guarantor_relation = ?, guarantor_phone = ?
          WHERE id = ? AND user_id = ?;`,
          [
            payload.name,
            payload.phone || '',
            payload.item,
            payload.totalAmount,
            payload.downPayment,
            payload.remainingAmount,
            payload.registrationDate,
            payload.nextDueDate,
            payload.status,
            payload.notes || '',
            paymentsJson,
            payload.nationalId || null,
            payload.address || null,
            payload.guarantorEnabled ? 1 : 0,
            payload.guarantorName || null,
            payload.guarantorAddress || null,
            payload.guarantorJob || null,
            payload.guarantorRelation || null,
            payload.guarantorPhone || null,
            payload.id,
            userId,
          ]
        );
      }
      break;
    }

    case 'UPDATE_INSTALLMENT': {
      const paymentsJson = JSON.stringify(payload.payments || []);
      await queryTurso(
        `UPDATE installments SET 
          name = ?, phone = ?, item = ?, total_amount = ?, down_payment = ?, remaining_amount = ?, registration_date = ?, next_due_date = ?, status = ?, notes = ?, payments = ?, national_id = ?, address = ?, guarantor_enabled = ?, guarantor_name = ?, guarantor_address = ?, guarantor_job = ?, guarantor_relation = ?, guarantor_phone = ?
        WHERE id = ? AND user_id = ?;`,
        [
          payload.name,
          payload.phone || '',
          payload.item,
          payload.totalAmount,
          payload.downPayment,
          payload.remainingAmount,
          payload.registrationDate,
          payload.nextDueDate,
          payload.status,
          payload.notes || '',
          paymentsJson,
          payload.nationalId || null,
          payload.address || null,
          payload.guarantorEnabled ? 1 : 0,
          payload.guarantorName || null,
          payload.guarantorAddress || null,
          payload.guarantorJob || null,
          payload.guarantorRelation || null,
          payload.guarantorPhone || null,
          payload.id,
          userId,
        ]
      );
      break;
    }

    case 'SETTLE_INSTALLMENT_PAYMENT': {
      const paymentsJson = JSON.stringify(payload.payments || []);
      await queryTurso(
        "UPDATE installments SET remaining_amount = ?, next_due_date = ?, status = ?, payments = ? WHERE id = ? AND user_id = ?;",
        [payload.remainingAmount, payload.nextDueDate, payload.status, paymentsJson, payload.id, userId]
      );
      break;
    }

    case 'DELETE_INSTALLMENT': {
      await queryTurso("DELETE FROM installments WHERE id = ? AND user_id = ?;", [payload.id, userId]);
      break;
    }

    default:
      console.warn(`[OutboxSync] Unknown action type: ${type}`);
  }
}

/**
 * Direct real-time cloud sync helper for a single debtor
 * Guarantees record existence in cloud DB when sharing or generating QR links.
 */
export async function syncSingleDebtorToCloud(userId: number, debtor: any): Promise<boolean> {
  if (!debtor || !debtor.id) return false;

  const effectiveUserId = userId && userId > 0 ? userId : 1;
  const historyJson = JSON.stringify(debtor.history || []);
  const amount = Number(debtor.amount || debtor.remainingAmount || 0);

  try {
    await queryTurso(
      "INSERT INTO debtors (id, name, phone, amount, status, user_id, created_at, history) VALUES (?, ?, ?, ?, ?, ?, ?, ?);",
      [
        debtor.id,
        debtor.name || '',
        debtor.phone || '',
        amount,
        debtor.status || 'مستمر',
        effectiveUserId,
        debtor.createdAt || debtor.debtDate || new Date().toISOString(),
        historyJson,
      ]
    );
    return true;
  } catch {
    try {
      await queryTurso(
        "UPDATE debtors SET name = ?, phone = ?, amount = ?, status = ?, history = ?, user_id = ? WHERE id = ?;",
        [
          debtor.name || '',
          debtor.phone || '',
          amount,
          debtor.status || 'مستمر',
          historyJson,
          effectiveUserId,
          debtor.id,
        ]
      );
      return true;
    } catch (err) {
      console.error('[CloudSync] Failed to sync debtor to cloud:', err);
      return false;
    }
  }
}

/**
 * Direct real-time cloud sync helper for a single installment
 * Guarantees record existence in cloud DB when sharing or generating QR links.
 */
export async function syncSingleInstallmentToCloud(userId: number, inst: any): Promise<boolean> {
  if (!inst || !inst.id) return false;

  const effectiveUserId = userId && userId > 0 ? userId : 1;
  const paymentsJson = JSON.stringify(inst.payments || []);

  try {
    await queryTurso(
      "INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, guarantor_name, guarantor_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
      [
        inst.id,
        inst.name || inst.debtorName || '',
        inst.phone || inst.phoneNumber || '',
        inst.item || inst.itemName || '',
        Number(inst.totalAmount || 0),
        Number(inst.downPayment || 0),
        Number(inst.remainingAmount || 0),
        Number(inst.monthlyInstallmentAmount || inst.monthlyInstallment || 0),
        inst.registrationDate || new Date().toISOString(),
        inst.nextDueDate || '',
        effectiveUserId,
        inst.status || 'active',
        inst.notes || '',
        paymentsJson,
        inst.createdAt || new Date().toISOString(),
        inst.guarantorName || '',
        inst.guarantorPhone || '',
      ]
    );
    return true;
  } catch {
    try {
      await queryTurso(
        "UPDATE installments SET name = ?, phone = ?, item = ?, total_amount = ?, down_payment = ?, remaining_amount = ?, monthly_installment_amount = ?, registration_date = ?, next_due_date = ?, status = ?, notes = ?, payments = ?, guarantor_name = ?, guarantor_phone = ?, user_id = ? WHERE id = ?;",
        [
          inst.name || inst.debtorName || '',
          inst.phone || inst.phoneNumber || '',
          inst.item || inst.itemName || '',
          Number(inst.totalAmount || 0),
          Number(inst.downPayment || 0),
          Number(inst.remainingAmount || 0),
          Number(inst.monthlyInstallmentAmount || inst.monthlyInstallment || 0),
          inst.registrationDate || '',
          inst.nextDueDate || '',
          inst.status || 'active',
          inst.notes || '',
          paymentsJson,
          inst.guarantorName || '',
          inst.guarantorPhone || '',
          effectiveUserId,
          inst.id,
        ]
      );
      return true;
    } catch (err) {
      console.error('[CloudSync] Failed to sync installment to cloud:', err);
      return false;
    }
  }
}
