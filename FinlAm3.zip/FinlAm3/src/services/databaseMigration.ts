import { Debtor, InstallmentRecord, Manager, User, AppSettings, DebtorTransaction, SubscriptionType, ManagerModuleAccess } from '../types';
import { queryTurso, setLocalDebtors, setLocalInstallments, setLocalManagers, setLocalDebtorDates, setLocalDebtorHistory, setLocalSettings, DEFAULT_SETTINGS, broadcastDebtorsChange, broadcastInstallmentsChange } from './turso';
import { saveIdbDebtors, saveIdbInstallments, saveIdbManagers, saveIdbSettings, saveIdbStats } from './idb';
import bcrypt from 'bcryptjs';

export interface FullDatabaseMigrationPackage {
  system: string;
  version: string;
  isMigrationPackage: boolean;
  exportTimestamp: number;
  exportDate: string;
  exportedBy: string;
  branchName?: string;
  summary: {
    totalManagers: number;
    totalDebtors: number;
    totalInstallments: number;
    totalDebtAmount: number;
  };
  managers: {
    id: number;
    username: string;
    password?: string;
    plainPassword?: string;
    role: string;
    branch: string;
    isActive: boolean;
    subscriptionType: SubscriptionType;
    subscriptionExpiresAt: string | null;
    allowedModules: ManagerModuleAccess;
    createdAt?: string;
  }[];
  debtors: (Debtor & { userId: number })[];
  installments: (InstallmentRecord & { userId: number })[];
  settings?: Record<number, AppSettings>;
}

export interface BranchDataBreakdown {
  managerId: number;
  managerUsername: string;
  branchName: string;
  subscriptionType: string;
  allowedModules: string;
  hasPlainPassword: boolean;
  debtorsCount: number;
  totalDebt: number;
  installmentsCount: number;
  totalInstallmentsRemaining: number;
}

export interface MigrationPreviewData {
  fileName: string;
  exportDate?: string;
  exportedBy?: string;
  isOfficialMigrationFormat: boolean;
  totalManagersCount: number;
  totalDebtorsCount: number;
  totalInstallmentsCount: number;
  totalDebtAmount: number;
  managersList: Manager[];
  debtorsList: (Debtor & { userId: number })[];
  installmentsList: (InstallmentRecord & { userId: number })[];
  branchBreakdown: BranchDataBreakdown[];
}

export interface MigrationProgressStatus {
  step: number;
  totalSteps: number;
  title: string;
  message: string;
  percent: number;
  isFinished?: boolean;
  isError?: boolean;
  errorMessage?: string;
}

/**
 * 1. تصدير حزمة ترحيل قاعدة البيانات الشاملة (Full Database Migration Export)
 * يستعلم عن كل شيء في القاعدة السحابية أو المحلية:
 * - جميع المدراء الفرعيين وحساباتهم وكلمات المرور والفروع
 * - جميع المدينين لجميع الفروع وسجلات العمليات وتواريخهم
 * - جميع عقود الأقساط لجميع الفروع والدفعات والضامنين
 */
export async function exportFullDatabasePackage(
  currentUser: User,
  cachedManagers: Manager[],
  cachedDebtors: Debtor[],
  cachedInstallments: InstallmentRecord[],
  cachedSettings: AppSettings
): Promise<{ fileName: string; sizeBytes: number; summary: any }> {
  let allManagers: Manager[] = [...cachedManagers];
  let allDebtors: (Debtor & { userId: number })[] = [];
  let allInstallments: (InstallmentRecord & { userId: number })[] = [];

  // Try querying Turso cloud for COMPLETE records across all users
  try {
    // 1. Fetch all managers from users table
    const usersRes = await queryTurso(
      "SELECT id, username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at, allowed_modules FROM users WHERE role = 'manager';"
    ).catch(() => null);

    if (usersRes?.results?.[0]?.response?.result?.rows) {
      const rows = usersRes.results[0].response.result.rows;
      allManagers = rows.map((r: any) => {
        const id = parseInt(r[0]?.value || '0', 10);
        const username = r[1]?.value || '';
        const plainPassword =
          r[3]?.value ||
          localStorage.getItem(`user_pwd_${id}`) ||
          localStorage.getItem(`user_pwd_${username}`) ||
          '';
        const isActiveVal = r[6]?.value;
        const isActive = isActiveVal === 0 || isActiveVal === '0' ? false : true;
        const subscriptionType = (r[7]?.value as SubscriptionType) || 'permanent';
        const subscriptionExpiresAt = r[8]?.value || null;
        const allowedModules = (r[9]?.value as ManagerModuleAccess) || 'both';

        return {
          id,
          username,
          branch: r[5]?.value || 'فرع',
          isActive,
          subscriptionType,
          subscriptionExpiresAt,
          plainPassword,
          allowedModules,
        };
      });
    }

    // 2. Fetch all debtors across ALL users
    const debtorsRes = await queryTurso(
      "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors ORDER BY id ASC;"
    ).catch(() => null);

    if (debtorsRes?.results?.[0]?.response?.result?.rows) {
      const rows = debtorsRes.results[0].response.result.rows;
      allDebtors = rows.map((r: any) => {
        const id = parseInt(r[0]?.value || '0', 10);
        const name = r[1]?.value || '';
        const phone = r[2]?.value || '';
        const amount = parseFloat(r[3]?.value || '0');
        const status = r[4]?.value || 'دين مرتفع';
        const userId = parseInt(r[5]?.value || '1', 10);
        const createdAt = r[6]?.value || new Date().toISOString();
        let history: DebtorTransaction[] | undefined = undefined;
        if (r[7]?.value) {
          try {
            const parsed = JSON.parse(r[7].value);
            if (Array.isArray(parsed)) history = parsed;
          } catch {}
        }
        return {
          id,
          name,
          phone,
          amount,
          status,
          userId,
          createdAt,
          lastDebtDate: createdAt,
          history,
        };
      });
    }

    // 3. Fetch all installments across ALL users
    const installmentsRes = await queryTurso(
      "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone FROM installments ORDER BY id DESC;"
    ).catch(() => null);

    if (installmentsRes?.results?.[0]?.response?.result?.rows) {
      const rows = installmentsRes.results[0].response.result.rows;
      allInstallments = rows.map((r: any) => {
        const id = parseInt(r[0]?.value || '0', 10);
        const name = r[1]?.value || '';
        const phone = r[2]?.value || '';
        const item = r[3]?.value || '';
        const totalAmount = parseFloat(r[4]?.value || '0');
        const downPayment = parseFloat(r[5]?.value || '0');
        const remainingAmount = parseFloat(r[6]?.value || '0');
        const monthlyInstallment = parseFloat(r[7]?.value || '0');
        const registrationDate = r[8]?.value || new Date().toISOString().slice(0, 10);
        const nextDueDate = r[9]?.value || '';
        const userId = parseInt(r[10]?.value || '1', 10);
        const status = r[11]?.value || 'active';
        const notes = r[12]?.value || '';
        let payments: any[] = [];
        if (r[13]?.value) {
          try {
            const parsed = JSON.parse(r[13].value);
            if (Array.isArray(parsed)) payments = parsed;
          } catch {}
        }
        const createdAt = r[14]?.value || new Date().toISOString();
        const nationalId = r[15]?.value || '';
        const address = r[16]?.value || '';
        const guarantorEnabled = r[17]?.value === 1 || r[17]?.value === '1';
        const guarantorName = r[18]?.value || '';
        const guarantorAddress = r[19]?.value || '';
        const guarantorJob = r[20]?.value || '';
        const guarantorRelation = r[21]?.value || '';
        const guarantorPhone = r[22]?.value || '';

        return {
          id,
          name,
          phone,
          item,
          totalAmount,
          downPayment,
          remainingAmount,
          monthlyInstallment,
          registrationDate,
          nextDueDate,
          userId,
          status,
          notes,
          payments,
          createdAt,
          nationalId,
          address,
          guarantorEnabled,
          guarantorName,
          guarantorAddress,
          guarantorJob,
          guarantorRelation,
          guarantorPhone,
        };
      });
    }
  } catch (err) {
    console.warn('Notice while pulling full cloud tables for migration:', err);
  }

  // Fallback to local cache if cloud was empty or unreachable
  if (allDebtors.length === 0 && cachedDebtors.length > 0) {
    allDebtors = cachedDebtors.map((d) => ({
      ...d,
      userId: d.userId || currentUser.id,
    }));
  }
  if (allInstallments.length === 0 && cachedInstallments.length > 0) {
    allInstallments = cachedInstallments.map((i) => ({
      ...i,
      userId: (i as any).userId || currentUser.id,
    }));
  }

  // Format enriched managers with passwords
  const enrichedManagers = allManagers.map((m) => {
    const plain =
      m.plainPassword ||
      localStorage.getItem(`user_pwd_${m.id}`) ||
      localStorage.getItem(`user_pwd_${m.username}`) ||
      '';
    return {
      id: m.id,
      username: m.username,
      plainPassword: plain,
      role: 'manager',
      branch: m.branch,
      isActive: m.isActive,
      subscriptionType: m.subscriptionType || 'permanent',
      subscriptionExpiresAt: m.subscriptionExpiresAt || null,
      allowedModules: m.allowedModules || 'both',
      createdAt: (m as any).createdAt || new Date().toISOString(),
    };
  });

  const totalDebt = allDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10);
  const fileName = `aldion_full_database_migration_${dateStr}.json`;

  const migrationPackage: FullDatabaseMigrationPackage = {
    system: 'Aldion Full Database Migration Package',
    version: '2.0',
    isMigrationPackage: true,
    exportTimestamp: Date.now(),
    exportDate: now.toISOString(),
    exportedBy: currentUser.username,
    branchName: currentUser.branch_name || 'الفرع الرئيسي',
    summary: {
      totalManagers: enrichedManagers.length,
      totalDebtors: allDebtors.length,
      totalInstallments: allInstallments.length,
      totalDebtAmount: totalDebt,
    },
    managers: enrichedManagers,
    debtors: allDebtors,
    installments: allInstallments,
    settings: {
      [currentUser.id]: cachedSettings,
    },
  };

  const jsonStr = JSON.stringify(migrationPackage, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  return {
    fileName,
    sizeBytes: blob.size,
    summary: migrationPackage.summary,
  };
}

/**
 * 2. قراءة وتحليل ملف الترحيل والتحقق من محتواه مع تصنيف تفصيلي لكل فرع
 */
export function parseMigrationFile(
  jsonText: string,
  fileName: string,
  currentUserId: number
): MigrationPreviewData {
  let parsed: any;
  try {
    parsed = JSON.parse(jsonText);
  } catch (err: any) {
    throw new Error('الملف المرفوع ليس بصيغة JSON صالحة أو تعرض للتلف.');
  }

  const isOfficialMigration = Boolean(parsed.isMigrationPackage || parsed.version === '2.0');
  const exportDate = parsed.exportDate || parsed.exportDateFormatted || parsed.exportTimestamp;
  const exportedBy = parsed.exportedBy || parsed.username;

  let rawManagers: any[] = [];
  if (Array.isArray(parsed.managers)) {
    rawManagers = parsed.managers;
  }

  let rawDebtors: any[] = [];
  if (Array.isArray(parsed.debtors)) {
    rawDebtors = parsed.debtors;
  } else if (Array.isArray(parsed)) {
    rawDebtors = parsed;
  }

  let rawInstallments: any[] = [];
  if (Array.isArray(parsed.installments)) {
    rawInstallments = parsed.installments;
  }

  if (rawManagers.length === 0 && rawDebtors.length === 0 && rawInstallments.length === 0) {
    throw new Error('الملف المرفوع فارغ ولا يحتوي على بيانات مدراء أو ديون أو أقساط صالحة للترحيل.');
  }

  // Clean & Normalize Managers
  const cleanedManagers: Manager[] = rawManagers.map((m: any, index: number) => {
    const id = Number(m.id) || Date.now() + index + 1000;
    const username = String(m.username || '').trim() || `manager_${index + 1}`;
    const branch = String(m.branch || m.branch_name || '').trim() || `فرع ${index + 1}`;
    const isActive = m.isActive !== undefined ? Boolean(m.isActive) : true;
    const subscriptionType = (m.subscriptionType as SubscriptionType) || 'permanent';
    const subscriptionExpiresAt = m.subscriptionExpiresAt || null;
    const allowedModules = (m.allowedModules as ManagerModuleAccess) || 'both';
    const plainPassword = String(m.plainPassword || m.password || '').trim();

    return {
      id,
      username,
      branch,
      isActive,
      subscriptionType,
      subscriptionExpiresAt,
      allowedModules,
      plainPassword,
      createdAt: m.createdAt || new Date().toISOString(),
    };
  });

  // Clean & Normalize Debtors
  const cleanedDebtors: (Debtor & { userId: number })[] = rawDebtors.map((d: any, index: number) => {
    const id = Number(d.id) || Date.now() + index;
    const name = String(d.name || '').trim() || `مدين #${id}`;
    const phone = String(d.phone || '').trim();
    const amount = Number(d.amount) || 0;
    const status = String(d.status || 'دين مرتفع');
    const userId = Number(d.userId || d.user_id) || currentUserId;
    const createdAt = d.createdAt || d.created_at || new Date().toISOString();
    const lastDebtDate = d.lastDebtDate || d.last_debt_date || createdAt;

    let history: DebtorTransaction[] | undefined = undefined;
    if (Array.isArray(d.history)) {
      history = d.history.map((tx: any, tIdx: number) => ({
        id: Number(tx.id) || Date.now() + tIdx,
        debtorId: id,
        type: tx.type === 'pay' ? 'pay' : 'add',
        amount: Number(tx.amount) || 0,
        balanceAfter: Number(tx.balanceAfter) || 0,
        date: tx.date || new Date().toISOString(),
        note: tx.note ? String(tx.note) : undefined,
      }));
    }

    return {
      id,
      name,
      phone,
      amount,
      status,
      userId,
      createdAt,
      lastDebtDate,
      history,
    };
  });

  // Clean & Normalize Installments
  const cleanedInstallments: (InstallmentRecord & { userId: number })[] = rawInstallments.map((inst: any, index: number) => {
    const id = Number(inst.id) || Date.now() + index;
    const name = String(inst.name || '').trim() || `عميل قسط #${id}`;
    const phone = String(inst.phone || '').trim();
    const item = String(inst.item || inst.item_name || 'سلعة').trim();
    const totalAmount = Number(inst.totalAmount || inst.total_amount) || 0;
    const downPayment = Number(inst.downPayment || inst.down_payment) || 0;
    const remainingAmount = Number(inst.remainingAmount || inst.remaining_amount) || 0;
    const monthlyInstallment = Number(inst.monthlyInstallment || inst.monthly_installment_amount) || 0;
    const registrationDate = inst.registrationDate || inst.registration_date || new Date().toISOString().slice(0, 10);
    const nextDueDate = inst.nextDueDate || inst.next_due_date || '';
    const userId = Number(inst.userId || inst.user_id) || currentUserId;
    const status = (inst.status as any) || 'active';
    const notes = inst.notes ? String(inst.notes) : '';
    const payments = Array.isArray(inst.payments) ? inst.payments : [];
    const createdAt = inst.createdAt || inst.created_at || new Date().toISOString();

    return {
      id,
      name,
      phone,
      item,
      totalAmount,
      downPayment,
      remainingAmount,
      monthlyInstallment,
      registrationDate,
      nextDueDate,
      userId,
      status,
      notes,
      payments,
      createdAt,
      nationalId: inst.nationalId || inst.national_id || '',
      address: inst.address || '',
      guarantorEnabled: Boolean(inst.guarantorEnabled ?? inst.guarantor_enabled),
      guarantorName: inst.guarantorName || inst.guarantor_name || '',
      guarantorAddress: inst.guarantorAddress || inst.guarantor_address || '',
      guarantorJob: inst.guarantorJob || inst.guarantor_job || '',
      guarantorRelation: inst.guarantorRelation || inst.guarantor_relation || '',
      guarantorPhone: inst.guarantorPhone || inst.guarantor_phone || '',
    };
  });

  const totalDebt = cleanedDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

  // Group breakdown by branch/manager
  const managerMap = new Map<number, Manager>();
  cleanedManagers.forEach((m) => managerMap.set(m.id, m));

  const branchMap = new Map<number, BranchDataBreakdown>();

  // Add default branch for current admin/main branch
  branchMap.set(currentUserId, {
    managerId: currentUserId,
    managerUsername: 'الإدارة العامة (الرئيسي)',
    branchName: 'الفرع الرئيسي',
    subscriptionType: 'permanent',
    allowedModules: 'both',
    hasPlainPassword: true,
    debtorsCount: 0,
    totalDebt: 0,
    installmentsCount: 0,
    totalInstallmentsRemaining: 0,
  });

  cleanedManagers.forEach((m) => {
    branchMap.set(m.id, {
      managerId: m.id,
      managerUsername: m.username,
      branchName: m.branch,
      subscriptionType: m.subscriptionType,
      allowedModules: m.allowedModules,
      hasPlainPassword: Boolean(m.plainPassword),
      debtorsCount: 0,
      totalDebt: 0,
      installmentsCount: 0,
      totalInstallmentsRemaining: 0,
    });
  });

  cleanedDebtors.forEach((d) => {
    let entry = branchMap.get(d.userId);
    if (!entry) {
      entry = {
        managerId: d.userId,
        managerUsername: `فرع / مستخدم #${d.userId}`,
        branchName: `فرع #${d.userId}`,
        subscriptionType: 'permanent',
        allowedModules: 'both',
        hasPlainPassword: false,
        debtorsCount: 0,
        totalDebt: 0,
        installmentsCount: 0,
        totalInstallmentsRemaining: 0,
      };
      branchMap.set(d.userId, entry);
    }
    entry.debtorsCount += 1;
    entry.totalDebt += d.amount;
  });

  cleanedInstallments.forEach((inst) => {
    let entry = branchMap.get(inst.userId);
    if (!entry) {
      entry = {
        managerId: inst.userId,
        managerUsername: `فرع / مستخدم #${inst.userId}`,
        branchName: `فرع #${inst.userId}`,
        subscriptionType: 'permanent',
        allowedModules: 'both',
        hasPlainPassword: false,
        debtorsCount: 0,
        totalDebt: 0,
        installmentsCount: 0,
        totalInstallmentsRemaining: 0,
      };
      branchMap.set(inst.userId, entry);
    }
    entry.installmentsCount += 1;
    entry.totalInstallmentsRemaining += inst.remainingAmount;
  });

  return {
    fileName,
    exportDate,
    exportedBy,
    isOfficialMigrationFormat: isOfficialMigration,
    totalManagersCount: cleanedManagers.length,
    totalDebtorsCount: cleanedDebtors.length,
    totalInstallmentsCount: cleanedInstallments.length,
    totalDebtAmount: totalDebt,
    managersList: cleanedManagers,
    debtorsList: cleanedDebtors,
    installmentsList: cleanedInstallments,
    branchBreakdown: Array.from(branchMap.values()).filter(
      (b) => b.debtorsCount > 0 || b.installmentsCount > 0 || b.managerId !== currentUserId
    ),
  };
}

/**
 * 3. تنفيذ عملية الترحيل الشاملة لقاعدة البيانات الجديدة
 * (Full Migration Execution with Batch Inserts, Passwords & Branch Binding)
 */
export async function executeDatabaseMigration(
  preview: MigrationPreviewData,
  mode: 'replace' | 'merge',
  currentUser: User,
  existingManagers: Manager[],
  onProgress: (status: MigrationProgressStatus) => void
): Promise<{ success: boolean; managersCount: number; debtorsCount: number; installmentsCount: number }> {
  const startTime = Date.now();

  try {
    // ------------------------------------------------------------------
    // الخطوة 1: فحص وتهيئة هيكلية جداول قاعدة البيانات الجديدة
    // ------------------------------------------------------------------
    onProgress({
      step: 1,
      totalSteps: 5,
      title: 'تهيئة وفحص قاعدة البيانات الجديدة',
      message: 'جاري التحقق من وجود الجداول والأعمدة في قاعدة البيانات السحابية والمحلية...',
      percent: 15,
    });

    try {
      await queryTurso(
        `CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          role TEXT DEFAULT 'user',
          branch_name TEXT DEFAULT 'الفرع الرئيسي',
          is_active INTEGER DEFAULT 1,
          subscription_type TEXT DEFAULT 'permanent',
          subscription_expires_at TEXT,
          plain_password TEXT,
          allowed_modules TEXT DEFAULT 'both'
        );`
      ).catch(() => {});

      await queryTurso(
        `CREATE TABLE IF NOT EXISTS debtors (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          phone TEXT,
          amount REAL DEFAULT 0,
          status TEXT DEFAULT 'دين مرتفع',
          user_id INTEGER DEFAULT 1,
          created_at TEXT,
          history TEXT
        );`
      ).catch(() => {});

      await queryTurso(
        `CREATE TABLE IF NOT EXISTS installments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          phone TEXT,
          item TEXT NOT NULL,
          total_amount REAL DEFAULT 0,
          down_payment REAL DEFAULT 0,
          remaining_amount REAL DEFAULT 0,
          monthly_installment_amount REAL DEFAULT 0,
          registration_date TEXT,
          next_due_date TEXT,
          user_id INTEGER DEFAULT 1,
          status TEXT DEFAULT 'active',
          notes TEXT,
          payments TEXT,
          created_at TEXT,
          national_id TEXT,
          address TEXT,
          guarantor_enabled INTEGER DEFAULT 0,
          guarantor_name TEXT,
          guarantor_address TEXT,
          guarantor_job TEXT,
          guarantor_relation TEXT,
          guarantor_phone TEXT
        );`
      ).catch(() => {});
    } catch (e) {
      console.warn('Notice while ensuring schema during migration:', e);
    }

    // إذا كان الوضع "استبدال شامل" (Replace): نقوم بمسح البيانات السابقة في الجداول لنقل قاعدة نظيفة 100%
    if (mode === 'replace') {
      try {
        await queryTurso("DELETE FROM users WHERE role = 'manager';").catch(() => {});
        await queryTurso("DELETE FROM debtors;").catch(() => {});
        await queryTurso("DELETE FROM installments;").catch(() => {});
      } catch (e) {
        console.warn('Notice while clearing tables for full replace migration:', e);
      }
    }

    // ------------------------------------------------------------------
    // الخطوة 2: ترحيل وزراعة حسابات المدراء الفرعيين والفروع
    // ------------------------------------------------------------------
    onProgress({
      step: 2,
      totalSteps: 5,
      title: 'ترحيل حسابات المدراء الفرعيين',
      message: `جاري زراعة وحفظ ${preview.managersList.length} مدير فرعي مع كلمات المرور والصلاحيات...`,
      percent: 35,
    });

    let finalManagers: Manager[] = [];
    if (mode === 'replace') {
      finalManagers = preview.managersList;
    } else {
      const mgrMap = new Map<string, Manager>();
      existingManagers.forEach((m) => mgrMap.set(m.username.trim().toLowerCase(), m));
      preview.managersList.forEach((m) => mgrMap.set(m.username.trim().toLowerCase(), m));
      finalManagers = Array.from(mgrMap.values());
    }

    // كتابة كل مدير فرعي في جدول users السحابي والمحلي
    for (const mgr of preview.managersList) {
      try {
        const plain = mgr.plainPassword || '123456';
        const salt = bcrypt.genSaltSync(10);
        const hashedPassword = bcrypt.hashSync(plain, salt);

        // نحفظ أو نحدث المستخدم في جدول users
        await queryTurso(
          `INSERT OR REPLACE INTO users (id, username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at, allowed_modules)
           VALUES (?, ?, ?, ?, 'manager', ?, ?, ?, ?, ?);`,
          [
            mgr.id,
            mgr.username,
            hashedPassword,
            plain,
            mgr.branch,
            mgr.isActive ? 1 : 0,
            mgr.subscriptionType || 'permanent',
            mgr.subscriptionExpiresAt || null,
            mgr.allowedModules || 'both',
          ]
        ).catch(async () => {
          // محاولة بدون id إذا كان التعارض على auto-increment
          await queryTurso(
            `INSERT INTO users (username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at, allowed_modules)
             VALUES (?, ?, ?, 'manager', ?, ?, ?, ?, ?);`,
            [
              mgr.username,
              hashedPassword,
              plain,
              mgr.branch,
              mgr.isActive ? 1 : 0,
              mgr.subscriptionType || 'permanent',
              mgr.subscriptionExpiresAt || null,
              mgr.allowedModules || 'both',
            ]
          ).catch(() => {});
        });

        // حفظ كلمة المرور محلياً فوراً للبحث السريع والتسجيل
        if (plain) {
          localStorage.setItem(`user_pwd_${mgr.id}`, plain);
          localStorage.setItem(`user_pwd_${mgr.username}`, plain);
        }
      } catch (err) {
        console.warn(`Error inserting manager ${mgr.username}:`, err);
      }
    }

    setLocalManagers(finalManagers);
    await saveIdbManagers(finalManagers);

    // ------------------------------------------------------------------
    // الخطوة 3: ترحيل وزراعة سجلات المدينين والديون لكل مدير فرعي
    // ------------------------------------------------------------------
    onProgress({
      step: 3,
      totalSteps: 5,
      title: 'ترحيل سجلات المدينين والديون',
      message: `جاري كتابة وتوزيع ${preview.debtorsList.length} مدين على فروعهم الخاصة...`,
      percent: 60,
    });

    // تقسيم المدينين إلى دفعات صغيرة (Chunks) لسرعة النقل وتجنب تجاوز حدود الاستعلام
    const DEBTOR_CHUNK_SIZE = 25;
    for (let i = 0; i < preview.debtorsList.length; i += DEBTOR_CHUNK_SIZE) {
      const chunk = preview.debtorsList.slice(i, i + DEBTOR_CHUNK_SIZE);

      for (const d of chunk) {
        try {
          const historyJson = d.history ? JSON.stringify(d.history) : null;
          await queryTurso(
            `INSERT INTO debtors (id, name, phone, amount, status, user_id, created_at, history)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?);`,
            [
              d.id,
              d.name,
              d.phone || '',
              d.amount || 0,
              d.status || 'دين مرتفع',
              d.userId || currentUser.id,
              d.createdAt || new Date().toISOString(),
              historyJson,
            ]
          ).catch(async () => {
            // محاولة بدون إجبار id
            await queryTurso(
              `INSERT INTO debtors (name, phone, amount, status, user_id, created_at, history)
               VALUES (?, ?, ?, ?, ?, ?, ?);`,
              [
                d.name,
                d.phone || '',
                d.amount || 0,
                d.status || 'دين مرتفع',
                d.userId || currentUser.id,
                d.createdAt || new Date().toISOString(),
                historyJson,
              ]
            ).catch(() => {});
          });
        } catch (e) {
          console.warn('Debtor insert error:', e);
        }
      }

      const progressPercent = 60 + Math.floor((i / preview.debtorsList.length) * 15);
      onProgress({
        step: 3,
        totalSteps: 5,
        title: 'ترحيل سجلات المدينين والديون',
        message: `تم ترحيل ${Math.min(i + DEBTOR_CHUNK_SIZE, preview.debtorsList.length)} من أصل ${preview.debtorsList.length} مدين...`,
        percent: progressPercent,
      });
    }

    // ------------------------------------------------------------------
    // الخطوة 4: ترحيل وزراعة عقود الأقساط والدفعات والضامنين
    // ------------------------------------------------------------------
    onProgress({
      step: 4,
      totalSteps: 5,
      title: 'ترحيل عقود الأقساط والدفعات',
      message: `جاري كتابة وتوزيع ${preview.installmentsList.length} عقد قسط مع سجلات الدفعات والضامنين...`,
      percent: 78,
    });

    const INSTALLMENT_CHUNK_SIZE = 20;
    for (let i = 0; i < preview.installmentsList.length; i += INSTALLMENT_CHUNK_SIZE) {
      const chunk = preview.installmentsList.slice(i, i + INSTALLMENT_CHUNK_SIZE);

      for (const inst of chunk) {
        try {
          const paymentsJson = inst.payments ? JSON.stringify(inst.payments) : '[]';
          await queryTurso(
            `INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
            [
              inst.id,
              inst.name,
              inst.phone || '',
              inst.item || '',
              inst.totalAmount || 0,
              inst.downPayment || 0,
              inst.remainingAmount || 0,
              (inst as any).monthlyInstallmentAmount || (inst as any).monthlyInstallment || 0,
              inst.registrationDate || new Date().toISOString().slice(0, 10),
              inst.nextDueDate || '',
              inst.userId || currentUser.id,
              inst.status || 'active',
              inst.notes || '',
              paymentsJson,
              inst.createdAt || new Date().toISOString(),
              inst.nationalId || '',
              inst.address || '',
              inst.guarantorEnabled ? 1 : 0,
              inst.guarantorName || '',
              inst.guarantorAddress || '',
              inst.guarantorJob || '',
              inst.guarantorRelation || '',
              inst.guarantorPhone || '',
            ]
          ).catch(async () => {
            // محاولة بدون id
            await queryTurso(
              `INSERT INTO installments (name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
              [
                inst.name,
                inst.phone || '',
                inst.item || '',
                inst.totalAmount || 0,
                inst.downPayment || 0,
                inst.remainingAmount || 0,
                (inst as any).monthlyInstallmentAmount || (inst as any).monthlyInstallment || 0,
                inst.registrationDate || new Date().toISOString().slice(0, 10),
                inst.nextDueDate || '',
                inst.userId || currentUser.id,
                inst.status || 'active',
                inst.notes || '',
                paymentsJson,
                inst.createdAt || new Date().toISOString(),
                inst.nationalId || '',
                inst.address || '',
                inst.guarantorEnabled ? 1 : 0,
                inst.guarantorName || '',
                inst.guarantorAddress || '',
                inst.guarantorJob || '',
                inst.guarantorRelation || '',
                inst.guarantorPhone || '',
              ]
            ).catch(() => {});
          });
        } catch (e) {
          console.warn('Installment insert error:', e);
        }
      }

      const progressPercent = 78 + Math.floor((i / preview.installmentsList.length) * 15);
      onProgress({
        step: 4,
        totalSteps: 5,
        title: 'ترحيل عقود الأقساط والدفعات',
        message: `تم ترحيل ${Math.min(i + INSTALLMENT_CHUNK_SIZE, preview.installmentsList.length)} من أصل ${preview.installmentsList.length} عقد...`,
        percent: progressPercent,
      });
    }

    // ------------------------------------------------------------------
    // الخطوة 5: مزامنة التخزين المحلي السريع والـ IndexedDB لكل فرع
    // ------------------------------------------------------------------
    onProgress({
      step: 5,
      totalSteps: 5,
      title: 'مزامنة التخزين المحلي السريع والـ IndexedDB',
      message: 'جاري تهيئة الذاكرة المحلية وتوزيع السجلات لكل مدير فرعي...',
      percent: 95,
    });

    // تجميع المدينين حسب userId وحفظهم في الـ IndexedDB و localStorage
    const debtorsByUser = new Map<number, Debtor[]>();
    preview.debtorsList.forEach((d) => {
      const list = debtorsByUser.get(d.userId) || [];
      list.push(d);
      debtorsByUser.set(d.userId, list);
    });

    for (const [userId, dList] of debtorsByUser.entries()) {
      setLocalDebtors(userId, dList);
      await saveIdbDebtors(userId, dList);

      const datesMap: Record<number, string> = {};
      const historyMap: Record<number, DebtorTransaction[]> = {};
      dList.forEach((d) => {
        if (d.createdAt) datesMap[d.id] = d.createdAt;
        if (d.history && d.history.length > 0) historyMap[d.id] = d.history;
      });
      setLocalDebtorDates(userId, datesMap);
      setLocalDebtorHistory(userId, historyMap);

      const totalDebts = dList.reduce((s, d) => s + (Number(d.amount) || 0), 0);
      saveIdbStats(userId, { totalAdded: totalDebts, totalPaid: 0 });
    }

    // تجميع الأقساط حسب userId وحفظها
    const installmentsByUser = new Map<number, InstallmentRecord[]>();
    preview.installmentsList.forEach((inst) => {
      const list = installmentsByUser.get(inst.userId) || [];
      list.push(inst);
      installmentsByUser.set(inst.userId, list);
    });

    for (const [userId, iList] of installmentsByUser.entries()) {
      setLocalInstallments(userId, iList);
      await saveIdbInstallments(userId, iList);
    }

    // Broadcast synchronization
    broadcastDebtorsChange(currentUser.id, 'FULL_MIGRATION_COMPLETE');
    broadcastInstallmentsChange(currentUser.id, 'FULL_MIGRATION_COMPLETE');

    onProgress({
      step: 5,
      totalSteps: 5,
      title: 'اكتمل ترحيل قاعدة البيانات بنجاح!',
      message: `تم بنجاح ترحيل ${preview.managersList.length} مدير فرعي، و${preview.debtorsList.length} مدين، و${preview.installmentsList.length} عقد قسط بالكامل.`,
      percent: 100,
      isFinished: true,
    });

    return {
      success: true,
      managersCount: preview.managersList.length,
      debtorsCount: preview.debtorsList.length,
      installmentsCount: preview.installmentsList.length,
    };
  } catch (err: any) {
    onProgress({
      step: 0,
      totalSteps: 5,
      title: 'حدث خطأ أثناء ترحيل قاعدة البيانات',
      message: err.message || 'فشلت عملية الترحيل لسبب غير متوقع',
      percent: 0,
      isError: true,
      errorMessage: err.message,
    });
    throw err;
  }
}
