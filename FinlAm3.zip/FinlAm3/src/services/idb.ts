import { Debtor, DebtStats, AppSettings, Manager, InstallmentRecord, OutboxAction } from '../types';
import { DEFAULT_SETTINGS } from './turso';

const DB_NAME = 'DaftarAldionDB';
const DB_VERSION = 3; // Incremented for sync_outbox store

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB غير مدعوم في هذا المتصفح'));
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Object store for debtors
      if (!db.objectStoreNames.contains('debtors')) {
        const debtorStore = db.createObjectStore('debtors', { keyPath: 'id' });
        debtorStore.createIndex('userId', 'userId', { unique: false });
      }

      // Object store for installments (نظام الأقساط المنفصل)
      if (!db.objectStoreNames.contains('installments')) {
        const installmentStore = db.createObjectStore('installments', { keyPath: 'id' });
        installmentStore.createIndex('userId', 'userId', { unique: false });
        installmentStore.createIndex('status', 'status', { unique: false });
        installmentStore.createIndex('nextDueDate', 'nextDueDate', { unique: false });
      }

      // Key-Value store for user settings, stats, managers, metadata
      if (!db.objectStoreNames.contains('keyval')) {
        db.createObjectStore('keyval', { keyPath: 'key' });
      }

      // Object store for offline transaction queue (Outbox)
      if (!db.objectStoreNames.contains('sync_outbox')) {
        const outboxStore = db.createObjectStore('sync_outbox', { keyPath: 'id' });
        outboxStore.createIndex('userId', 'userId', { unique: false });
        outboxStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });

  return dbPromise;
}

// ---------------------- DEBTORS CRUD ----------------------

export async function getIdbDebtors(userId: number): Promise<Debtor[] | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('debtors', 'readonly');
      const store = tx.objectStore('debtors');
      const index = store.index('userId');
      const request = index.getAll(userId);

      request.onsuccess = () => {
        const result = request.result;
        resolve(result && result.length > 0 ? result : null);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('IDB read error (falling back):', err);
    return null;
  }
}

export async function saveIdbDebtors(userId: number, debtors: Debtor[]): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('debtors', 'readwrite');
    const store = tx.objectStore('debtors');

    const index = store.index('userId');
    const getKeysReq = index.getAllKeys(userId);

    getKeysReq.onsuccess = () => {
      const keys = getKeysReq.result;
      keys.forEach((k) => store.delete(k));
      debtors.forEach((d) => {
        store.put({ ...d, userId });
      });
    };

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB save debtors error:', err);
  }
}

export async function putIdbDebtor(debtor: Debtor): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('debtors', 'readwrite');
    const store = tx.objectStore('debtors');
    store.put(debtor);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB put debtor error:', err);
  }
}

export async function deleteIdbDebtor(debtorId: number): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('debtors', 'readwrite');
    const store = tx.objectStore('debtors');
    store.delete(debtorId);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB delete debtor error:', err);
  }
}

// ---------------------- INSTALLMENTS CRUD (نظام الأقساط) ----------------------

export async function getIdbInstallments(userId: number): Promise<InstallmentRecord[] | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('installments', 'readonly');
      const store = tx.objectStore('installments');
      const index = store.index('userId');
      const request = index.getAll(userId);

      request.onsuccess = () => {
        const result = request.result;
        resolve(result && result.length > 0 ? result : null);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('IDB read installments error:', err);
    return null;
  }
}

export async function saveIdbInstallments(userId: number, installments: InstallmentRecord[]): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('installments', 'readwrite');
    const store = tx.objectStore('installments');

    const index = store.index('userId');
    const getKeysReq = index.getAllKeys(userId);

    getKeysReq.onsuccess = () => {
      const keys = getKeysReq.result;
      keys.forEach((k) => store.delete(k));
      installments.forEach((inst) => {
        store.put({ ...inst, userId });
      });
    };

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB save installments error:', err);
  }
}

export async function putIdbInstallment(installment: InstallmentRecord): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('installments', 'readwrite');
    const store = tx.objectStore('installments');
    store.put(installment);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB put installment error:', err);
  }
}

export async function deleteIdbInstallment(installmentId: number): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('installments', 'readwrite');
    const store = tx.objectStore('installments');
    store.delete(installmentId);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB delete installment error:', err);
  }
}

// ---------------------- KEY-VALUE (STATS, SETTINGS, MANAGERS) ----------------------

async function getIdbKeyVal<T>(key: string): Promise<T | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('keyval', 'readonly');
      const store = tx.objectStore('keyval');
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ? req.result.value : null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

async function setIdbKeyVal<T>(key: string, value: T): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('keyval', 'readwrite');
    const store = tx.objectStore('keyval');
    store.put({ key, value });
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB set keyval error:', err);
  }
}

export async function getIdbStats(userId: number): Promise<DebtStats | null> {
  return getIdbKeyVal<DebtStats>(`stats_user_${userId}`);
}

export async function saveIdbStats(userId: number, stats: DebtStats): Promise<void> {
  return setIdbKeyVal(`stats_user_${userId}`, stats);
}

export async function getIdbSettings(userId: number): Promise<AppSettings | null> {
  return getIdbKeyVal<AppSettings>(`settings_user_${userId}`);
}

export async function saveIdbSettings(userId: number, settings: AppSettings): Promise<void> {
  return setIdbKeyVal(`settings_user_${userId}`, settings);
}

export async function getIdbManagers(): Promise<Manager[] | null> {
  return getIdbKeyVal<Manager[]>('managers_list');
}

export async function saveIdbManagers(managers: Manager[]): Promise<void> {
  return setIdbKeyVal('managers_list', managers);
}

// ---------------------- OUTBOX QUEUE (طابور العمليات المعلقة) ----------------------

export async function addOutboxAction(action: OutboxAction): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('sync_outbox', 'readwrite');
    const store = tx.objectStore('sync_outbox');
    store.put(action);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB add outbox action error:', err);
  }
}

export async function getOutboxActions(userId: number): Promise<OutboxAction[]> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('sync_outbox', 'readonly');
      const store = tx.objectStore('sync_outbox');
      const index = store.index('userId');
      const request = index.getAll(userId);

      request.onsuccess = () => {
        const result = request.result || [];
        // Return sorted by timestamp ascending (FIFO order)
        result.sort((a: OutboxAction, b: OutboxAction) => a.timestamp - b.timestamp);
        resolve(result);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('IDB get outbox error:', err);
    return [];
  }
}

export async function removeOutboxAction(actionId: string): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('sync_outbox', 'readwrite');
    const store = tx.objectStore('sync_outbox');
    store.delete(actionId);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB remove outbox action error:', err);
  }
}

export async function clearOutboxActions(userId: number): Promise<void> {
  try {
    const actions = await getOutboxActions(userId);
    const db = await getDB();
    const tx = db.transaction('sync_outbox', 'readwrite');
    const store = tx.objectStore('sync_outbox');
    actions.forEach((a) => store.delete(a.id));
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB clear outbox error:', err);
  }
}
