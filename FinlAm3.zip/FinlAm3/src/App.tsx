import React, { useState, useEffect, useCallback, useMemo, useDeferredValue } from 'react';
import bcrypt from 'bcryptjs';
import {
  AppSettings,
  Debtor,
  DebtorTransaction,
  DebtStats,
  FilterType,
  InstallmentRecord,
  Manager,
  ManagerModuleAccess,
  SubscriptionType,
  TabType,
  User,
  ViewMode,
  DatabaseAccount,
  AppLayoutTheme,
} from './types';
import { getLayoutThemeMeta } from './utils/layoutThemes';
import {
  DEFAULT_SETTINGS,
  broadcastManagerStatusChange,
  broadcastDebtorsChange,
  broadcastInstallmentsChange,
  broadcastSettingsChange,
  sessionBroadcastChannel,
  debtorsBroadcastChannel,
  installmentsBroadcastChannel,
  settingsBroadcastChannel,
  getLocalDebtorDates,
  getLocalDebtors,
  getLocalDebtorHistory,
  getLocalInstallments,
  getLocalManagers,
  getLocalSession,
  getLocalSettings,
  queryTurso,
  queryMainTurso,
  testDatabaseConnection,
  setLocalDebtorDates,
  setLocalDebtors,
  setLocalDebtorHistory,
  setLocalInstallments,
  setLocalManagers,
  setLocalSession,
  setLocalSettings,
  syncSettingsToCloud,
  fetchSettingsFromCloud,
  fetchDatabasesFromCloud,
  getLocalDatabases,
  DEFAULT_USER,
} from './services/turso';
import {
  getIdbDebtors,
  saveIdbDebtors,
  putIdbDebtor,
  deleteIdbDebtor,
  getIdbInstallments,
  saveIdbInstallments,
  putIdbInstallment,
  deleteIdbInstallment,
  getIdbStats,
  saveIdbStats,
  getIdbSettings,
  saveIdbSettings,
  getIdbManagers,
  saveIdbManagers,
  getOutboxActions,
} from './services/idb';
import { queueOutboxAction, flushOutbox, syncSingleDebtorToCloud, syncSingleInstallmentToCloud } from './services/outboxSync';
import { calculateDaysElapsed, formatNumber } from './utils/formatters';
import { getUserBranchDisplayName } from './utils/userUtils';
import { useI18n } from './i18n/index.tsx';
import { calculateNextMonthDueDate, computeInstallmentStatus } from './utils/installmentHelpers';
import { LoginOverlay } from './components/LoginOverlay';
import { HeaderCard, HeaderMode } from './components/HeaderCard';
import { SecretAdminModal } from './components/SecretAdminModal';
import { Controls } from './components/Controls';
import { VirtualGrid } from './components/VirtualGrid';
import { DebtorListItem } from './components/DebtorListItem';
import { DebtorHistoryModal } from './components/DebtorHistoryModal';
import { DebtorShareModal } from './components/DebtorShareModal';
import { AddDebtorModal } from './components/AddDebtorModal';
import { AddInstallmentModal } from './components/AddInstallmentModal';
import { EditDebtorNameModal } from './components/EditDebtorNameModal';
import { TransactionModal } from './components/TransactionModal';
import { ConfirmModal } from './components/ConfirmModal';
import { SettleCompleteModal } from './components/SettleCompleteModal';
import { WhatsAppConfirmModal } from './components/WhatsAppConfirmModal';
import {
  WhatsAppNotificationData,
  openWhatsAppDirect,
  createNewDebtorWhatsAppNotice,
  createAddDebtWhatsAppNotice,
  createPayDebtWhatsAppNotice,
  createNewInstallmentWhatsAppNotice,
  createPayInstallmentWhatsAppNotice,
} from './utils/whatsapp';
import { InstallmentsTab } from './components/InstallmentsTab';
import { ManagersTab } from './components/ManagersTab';
import { ReportsTab } from './components/ReportsTab';
import { OverdueTab } from './components/OverdueTab';
import { SettingsTab } from './components/SettingsTab';
import { BottomNav } from './components/BottomNav';
import { SidebarNav } from './components/SidebarNav';
import { ToastContainer, ToastMessage } from './components/Toast';
import { TrialLimitModal } from './components/TrialLimitModal';
import { CustomerPortalView } from './components/CustomerPortalView';
import { parsePortalParams, PortalType } from './utils/qrUtils';
import {
  generate100DemoDebtors,
  generateMillionDemoDebtors,
  createBillionDebtorsProxy,
  isBillionDebtorsProxy,
  isDemoDebtor,
  generate20DemoInstallments,
  generateMillionDemoInstallments,
  isDemoInstallment,
} from './utils/mockDebtors';

const getLocalStats = (userId: number): DebtStats | null => {
  try {
    const raw = localStorage.getItem(`debts_stats_${userId}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

const setLocalStats = (userId: number, stats: DebtStats) => {
  try {
    localStorage.setItem(`debts_stats_${userId}`, JSON.stringify(stats));
  } catch (e) {
    console.error(e);
  }
};

export default function App() {
  const { t, dir, numberFormat, getCurrencySymbol, language, setLanguage, currency, setCurrency, setNumberFormat } = useI18n();

  // Public Customer Portal Detection
  const [customerPortalTarget, setCustomerPortalTarget] = useState<{ type: PortalType; id: number } | null>(() => {
    return parsePortalParams(window.location.search);
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => getLocalSession());
  const [loginErrorMessage, setLoginErrorMessage] = useState<string | null>(null);
  const [allDebtors, setAllDebtors] = useState<Debtor[]>(() => {
    const session = getLocalSession();
    if (!session) return [];
    const cached = getLocalDebtors(session.id);
    return cached && cached.length > 0 ? cached : [];
  });
  const [installments, setInstallments] = useState<InstallmentRecord[]>(() => {
    const session = getLocalSession();
    if (!session) return [];
    const cached = getLocalInstallments(session.id);
    return cached && cached.length > 0 ? cached : [];
  });
  const [managers, setManagers] = useState<Manager[]>(() => {
    const cached = getLocalManagers();
    return cached && cached.length > 0 ? cached : [];
  });
  const [databases, setDatabases] = useState<DatabaseAccount[]>(() => getLocalDatabases());

  const loadDatabasesFromCloud = useCallback(async () => {
    try {
      const cloudDbs = await fetchDatabasesFromCloud();
      setDatabases(cloudDbs);
      return cloudDbs;
    } catch (e) {
      console.warn("Could not load databases from cloud:", e);
      const local = getLocalDatabases();
      setDatabases(local);
      return local;
    }
  }, []);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [visitedTabs, setVisitedTabs] = useState<Set<TabType>>(() => new Set(['home']));

  const handleSelectTab = useCallback((tab: TabType) => {
    React.startTransition(() => {
      setActiveTab(tab);
    });
  }, []);

  useEffect(() => {
    setVisitedTabs((prev) => {
      if (prev.has(activeTab)) return prev;
      const next = new Set(prev);
      next.add(activeTab);
      return next;
    });
  }, [activeTab]);
  const [headerMode, setHeaderMode] = useState<HeaderMode>(() => {
    const session = getLocalSession();
    if (session?.allowedModules === 'installments') return 'installments';
    return 'debts';
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    try {
      const saved = localStorage.getItem('aldion_debtors_view_mode');
      return saved === 'list' ? 'list' : 'cards';
    } catch {
      return 'cards';
    }
  });

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    try {
      localStorage.setItem('aldion_debtors_view_mode', mode);
    } catch (e) {
      console.error(e);
    }
  };

  const [isAddDebtorModalOpen, setIsAddDebtorModalOpen] = useState(false);
  const [isAddInstallmentModalOpen, setIsAddInstallmentModalOpen] = useState(false);
  const [isSecretAdminModalOpen, setIsSecretAdminModalOpen] = useState(false);
  const [isTrialLimitModalOpen, setIsTrialLimitModalOpen] = useState(false);
  const [isBillionDemoActive, setIsBillionDemoActive] = useState(false);
  const isTrialMode = Boolean(
    currentUser &&
      (currentUser.subscriptionType === 'trial' ||
        currentUser.role === 'trial' ||
        currentUser.isNewRegistration ||
        currentUser.id === 999999)
  );

  const handleOpenAddModal = () => {
    const isInstallmentsView =
      activeTab === 'installments' || (activeTab === 'home' && headerMode === 'installments');

    if (isInstallmentsView) {
      if (isTrialMode && installments.length >= 2) {
        setIsTrialLimitModalOpen(true);
        return;
      }
      setIsAddInstallmentModalOpen(true);
    } else {
      if (isTrialMode && allDebtors.length >= 2) {
        setIsTrialLimitModalOpen(true);
        return;
      }
      setIsAddDebtorModalOpen(true);
    }
  };

  const [isSavingCloud, setIsSavingCloud] = useState(false);
  const [isManagersLoading, setIsManagersLoading] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [settings, setSettings] = useState<AppSettings>(() => {
    const session = getLocalSession();
    return session ? getLocalSettings(session.id) : DEFAULT_SETTINGS;
  });
  const [stats, setStats] = useState<DebtStats>(() => {
    const session = getLocalSession();
    if (session) {
      const cached = getLocalStats(session.id);
      if (cached && !(cached.totalAdded === 70000 && cached.totalPaid === 25000)) {
        return cached;
      }
    }
    return { totalAdded: 0, totalPaid: 0 };
  });

  // Ensure local storage uses the new domain https://aldion2-dafterappp.netlify.app
  useEffect(() => {
    try {
      const saved = localStorage.getItem('aldion_custom_portal_domain');
      if (!saved || saved.includes('aldionapp.netlify.app') || saved.includes('aldion-app.iq') || saved.includes('aldionapp')) {
        localStorage.setItem('aldion_custom_portal_domain', 'https://aldion2-dafterappp.netlify.app');
      }
    } catch {}

    // Check URL query parameters on mount & popstate to bypass LoginOverlay directly for public links
    const handleCheckPortalUrl = () => {
      const parsed = parsePortalParams(window.location.search);
      if (parsed) {
        setCustomerPortalTarget(parsed);
      }
    };

    handleCheckPortalUrl();
    window.addEventListener('popstate', handleCheckPortalUrl);
    window.addEventListener('hashchange', handleCheckPortalUrl);
    return () => {
      window.removeEventListener('popstate', handleCheckPortalUrl);
      window.removeEventListener('hashchange', handleCheckPortalUrl);
    };
  }, []);
  const [transactionState, setTransactionState] = useState<{
    isOpen: boolean;
    type: 'pay' | 'add';
    debtor: Debtor | null;
  }>({
    isOpen: false,
    type: 'pay',
    debtor: null,
  });

  // Confirm Modal State
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Debtor History Modal State
  const [historyModalState, setHistoryModalState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Debtor Share Modal State
  const [shareModalState, setShareModalState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Settle Complete Modal State (when debtor balance reaches 0)
  const [settleCompleteState, setSettleCompleteState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Edit Debtor Name Modal State
  const [isEditNameModalOpen, setIsEditNameModalOpen] = useState(false);
  const [editingNameDebtor, setEditingNameDebtor] = useState<Debtor | null>(null);

  // WhatsApp Confirmation Modal State
  const [whatsappNoticeToConfirm, setWhatsappNoticeToConfirm] = useState<WhatsAppNotificationData | null>(null);

  const triggerWhatsAppNotification = useCallback((notice: WhatsAppNotificationData | null) => {
    if (!notice) return;
    setWhatsappNoticeToConfirm(notice);
  }, []);

  const handleConfirmWhatsAppSend = useCallback((notice: WhatsAppNotificationData) => {
    openWhatsAppDirect(notice.phone, notice.message);
    setWhatsappNoticeToConfirm(null);
  }, []);

  const handleCancelWhatsAppSend = useCallback(() => {
    setWhatsappNoticeToConfirm(null);
  }, []);

  const showToast = useCallback(
    (message: string, type: 'success' | 'error' | 'info' = 'info') => {
      const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
      setToasts((prev) => [...prev, { id, message, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 1000);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // ----------------------------------------------------
  // CLOUD SYNC & FINGERPRINTING FOR DEBTORS
  // ----------------------------------------------------

  const fetchAndCacheCloudData = useCallback(
    async (userId: number, isSilent = true) => {
      try {
        setIsSavingCloud(true);
        // 1. Flush local outbox actions first before pulling remote state
        await flushOutbox(userId);
        const pendingOutbox = await getOutboxActions(userId);
        if (pendingOutbox.length > 0) {
          // Un-synced local changes exist; prevent overwriting local state with stale cloud data
          return;
        }

        let res;
        try {
          res = await queryTurso(
            "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE user_id = ? ORDER BY id ASC;",
            [userId]
          );
        } catch {
          await queryTurso("ALTER TABLE debtors ADD COLUMN created_at TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE debtors ADD COLUMN history TEXT;").catch(() => {});
          res = await queryTurso(
            "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE user_id = ? ORDER BY id ASC;",
            [userId]
          );
        }

        let rows: any[] = [];
        if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
          rows = res.results[0].response.result.rows;
        }

        const datesMap = getLocalDebtorDates(userId);
        const historyMap = getLocalDebtorHistory(userId);
        let datesModified = false;
        let historyModified = false;

        const cloudDebtors: Debtor[] = rows.map((r) => {
          const id = parseInt(r[0]?.value || '0', 10);
          const name = r[1]?.value || '';
          const phone = r[2]?.value || '';
          const amount = parseFloat(r[3]?.value || '0');
          const status = r[4]?.value || 'دين مرتفع';
          const uId = parseInt(r[5]?.value || String(userId), 10);
          const cloudCreatedAt = r[6]?.value;
          const cloudHistoryRaw = r[7]?.value;

          let createdAt = cloudCreatedAt || datesMap[id];
          if (!createdAt) {
            createdAt = new Date().toISOString();
            datesModified = true;
          } else if (cloudCreatedAt && datesMap[id] !== cloudCreatedAt) {
            datesModified = true;
          }
          datesMap[id] = createdAt;

          let debtorHistory: DebtorTransaction[] | undefined = undefined;
          if (cloudHistoryRaw) {
            try {
              const parsed = JSON.parse(cloudHistoryRaw);
              if (Array.isArray(parsed) && parsed.length > 0) {
                debtorHistory = parsed;
                historyMap[id] = parsed;
                historyModified = true;
              }
            } catch {}
          }
          if (!debtorHistory && historyMap[id]) {
            debtorHistory = historyMap[id];
          }

          return {
            id,
            name,
            phone,
            amount,
            status,
            userId: uId,
            createdAt,
            lastDebtDate: createdAt,
            history: debtorHistory,
          };
        });

        if (datesModified) {
          setLocalDebtorDates(userId, datesMap);
        }
        if (historyModified) {
          setLocalDebtorHistory(userId, historyMap);
        }

        setAllDebtors((prev) => {
          const demoDebtors = prev.filter(isDemoDebtor);
          const cleanCloudDebtors = cloudDebtors.filter((d) => !isDemoDebtor(d));
          const combined = [...demoDebtors, ...cleanCloudDebtors];
          setLocalDebtors(userId, combined);
          saveIdbDebtors(userId, cleanCloudDebtors).catch(() => {});
          return combined;
        });

        if (!isSilent) {
          showToast(t('toast.cloudSyncSuccess', 'تمت المزامنة اللحظية مع السحابة بنجاح'), 'success');
        }
      } catch (err: any) {
        console.warn("تنبيه جلب البيانات السحابية:", err?.message || err);
        if (!isSilent) {
          const cached = getLocalDebtors(userId);
          if (!cached || cached.length === 0) {
            showToast(t('toast.offlineMode', 'تعذر الاتصال بالسحابة، يعمل التطبيق في الوضع المحلي'), 'info');
          }
        }
      } finally {
        setIsSavingCloud(false);
      }
    },
    [showToast, t]
  );

  const syncCloudDataIfChanged = useCallback(
    async (userId: number, force = false, isSilent = true) => {
      try {
        const cached = getLocalDebtors(userId) || [];
        const realLocal = cached.filter((d) => !isDemoDebtor(d));

        if (realLocal.length === 0 || force) {
          await fetchAndCacheCloudData(userId, isSilent);
          return;
        }

        let fpRes;
        try {
          fpRes = await queryTurso(
            "SELECT COUNT(*), COALESCE(MAX(id), 0), COALESCE(SUM(amount), 0) FROM debtors WHERE user_id = ?;",
            [userId]
          );
        } catch {
          await fetchAndCacheCloudData(userId, isSilent);
          return;
        }

        if (fpRes.results && fpRes.results[0] && fpRes.results[0].response?.result?.rows) {
          const row = fpRes.results[0].response.result.rows[0];
          const cloudCount = parseInt(row[0]?.value || 0);
          const cloudMaxId = parseInt(row[1]?.value || 0);
          const cloudSum = parseFloat(row[2]?.value || 0);

          const localCount = realLocal.length;
          const localMaxId = realLocal.reduce((max, d) => (d.id > max ? d.id : max), 0);
          const localSum = realLocal.reduce((sum, d) => sum + (d.amount || 0), 0);

          if (cloudCount === localCount && cloudMaxId === localMaxId && Math.abs(cloudSum - localSum) < 0.01) {
            if (!isSilent) {
              showToast(t('toast.cloudSynced', 'البيانات متطابقة ومحدثة مع السحابة بدون استهلاك بيانات'), 'success');
            }
            return;
          }
        }

        await fetchAndCacheCloudData(userId, isSilent);
      } catch (err: any) {
        console.warn("فحص البصمة السحابية:", err?.message || err);
      }
    },
    [fetchAndCacheCloudData, showToast, t]
  );

  // ----------------------------------------------------
  // CLOUD SYNC FOR INSTALLMENTS (نظام الأقساط المنفصل)
  // ----------------------------------------------------

  const fetchAndCacheInstallments = useCallback(
    async (userId: number, isSilent = true) => {
      try {
        await flushOutbox(userId);
        const pendingOutbox = await getOutboxActions(userId);
        if (pendingOutbox.length > 0) {
          return;
        }

        let res;
        try {
          res = await queryTurso(
            "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone, monthly_installment_amount FROM installments WHERE user_id = ? ORDER BY id DESC;",
            [userId]
          );
        } catch {
          // In case new columns need to be added
          await queryTurso("ALTER TABLE installments ADD COLUMN national_id TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_name TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_address TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_job TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;").catch(() => {});
          await queryTurso("ALTER TABLE installments ADD COLUMN monthly_installment_amount REAL DEFAULT 0;").catch(() => {});
          
          res = await queryTurso(
            "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone, monthly_installment_amount FROM installments WHERE user_id = ? ORDER BY id DESC;",
            [userId]
          );
        }

        let rows: any[] = [];
        if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
          rows = res.results[0].response.result.rows;
        }

        const cloudInsts: InstallmentRecord[] = rows.map((r) => {
          const id = parseInt(r[0].value);
          const name = r[1].value;
          const phone = r[2]?.value || '';
          const item = r[3]?.value || '';
          const totalAmount = parseFloat(r[4]?.value || 0);
          const downPayment = parseFloat(r[5]?.value || 0);
          const remainingAmount = parseFloat(r[6]?.value || 0);
          const registrationDate = r[7]?.value || new Date().toISOString().split('T')[0];
          const nextDueDate = r[8]?.value || calculateNextMonthDueDate(registrationDate);
          const uId = parseInt(r[9]?.value);
          const notes = r[11]?.value || undefined;
          const paymentsRaw = r[12]?.value;
          const createdAt = r[13]?.value || undefined;
          const nationalId = r[14]?.value || undefined;
          const address = r[15]?.value || undefined;
          const guarantorEnabledVal = r[16]?.value;
          const guarantorEnabled = guarantorEnabledVal === 1 || guarantorEnabledVal === '1' || guarantorEnabledVal === true;
          const guarantorName = r[17]?.value || undefined;
          const guarantorAddress = r[18]?.value || undefined;
          const guarantorJob = r[19]?.value || undefined;
          const guarantorRelation = r[20]?.value || undefined;
          const guarantorPhone = r[21]?.value || undefined;
          const parsedMonthlyInst = parseFloat(r[22]?.value || 0);
          const monthlyAmountVal = parsedMonthlyInst || (remainingAmount > 0 ? remainingAmount : totalAmount - downPayment);

          let payments = [];
          if (paymentsRaw) {
            try {
              payments = JSON.parse(paymentsRaw);
            } catch {}
          }

          const dynamicStatus = computeInstallmentStatus({
            remainingAmount,
            nextDueDate,
            registrationDate,
          });

          return {
            id,
            name,
            phone,
            item,
            totalAmount,
            downPayment,
            remainingAmount,
            monthlyAmount: monthlyAmountVal,
            monthlyInstallmentAmount: monthlyAmountVal,
            registrationDate,
            nextDueDate,
            userId: uId,
            status: dynamicStatus,
            nationalId,
            address,
            guarantorEnabled: guarantorEnabled || undefined,
            guarantorName,
            guarantorAddress,
            guarantorJob,
            guarantorRelation,
            guarantorPhone,
            notes,
            payments,
            createdAt,
          };
        });

        setInstallments(cloudInsts);
        setLocalInstallments(userId, cloudInsts);
        saveIdbInstallments(userId, cloudInsts).catch(() => {});
      } catch (err: any) {
        console.warn("تنبيه جلب بيانات الأقساط من السحابة:", err?.message || err);
      }
    },
    []
  );

  // Load managers from cloud (for admin)
  const loadManagersFromCloud = useCallback(async (isSilent = true) => {
    try {
      setIsManagersLoading(true);
      let res;
      try {
        res = await queryTurso(
          "SELECT id, username, branch_name, is_active, subscription_type, subscription_expires_at, plain_password, allowed_modules, database_id, phone_or_email, birth_date, is_new_registration, created_at, layout_theme FROM users WHERE role = 'manager';"
        );
      } catch {
        await queryTurso("ALTER TABLE users ADD COLUMN phone_or_email TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN birth_date TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN created_at TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN database_id TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN layout_theme TEXT DEFAULT 'classic';").catch(() => {});
        res = await queryTurso(
          "SELECT id, username, branch_name, is_active, subscription_type, subscription_expires_at, plain_password, allowed_modules, database_id, phone_or_email, birth_date, is_new_registration, created_at, layout_theme FROM users WHERE role = 'manager';"
        );
      }

      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      const cloudManagers: Manager[] = rows.map((r) => {
        const id = parseInt(r[0].value);
        const username = r[1].value;
        const isActiveVal = r[3]?.value;
        const isActive = isActiveVal === 0 || isActiveVal === '0' ? false : true;
        const subscriptionType = (r[4]?.value as SubscriptionType) || 'permanent';
        const subscriptionExpiresAt = r[5]?.value || null;
        const plainPassword = r[6]?.value || '';
        const allowedModules = (r[7]?.value as ManagerModuleAccess) || 'both';
        const databaseId = r[8]?.value || null;
        const phoneOrEmail = r[9]?.value || '';
        const birthDate = r[10]?.value || '';
        const isNewRegVal = r[11]?.value;
        const isNewRegistration = isNewRegVal === 1 || isNewRegVal === '1';
        const createdAt = r[12]?.value || undefined;
        const layoutTheme = (r[13]?.value as AppLayoutTheme) || 'classic';

        if (plainPassword) {
          localStorage.setItem(`user_pwd_${id}`, plainPassword);
          localStorage.setItem(`user_pwd_${username}`, plainPassword);
        }

        const effectivePassword =
          plainPassword ||
          localStorage.getItem(`user_pwd_${id}`) ||
          localStorage.getItem(`user_pwd_${username}`) ||
          undefined;

        return {
          id,
          username,
          branch: r[2]?.value || 'فرع بدون اسم',
          isActive,
          subscriptionType,
          subscriptionExpiresAt,
          plainPassword: effectivePassword,
          allowedModules,
          databaseId,
          phoneOrEmail: phoneOrEmail || undefined,
          securityAnswer: birthDate || undefined,
          birthDate: birthDate || undefined,
          isNewRegistration,
          createdAt,
          layoutTheme,
        };
      });

      setLocalManagers(cloudManagers);
      setManagers(cloudManagers);
      await saveIdbManagers(cloudManagers);
    } catch (err: any) {
      if (!isSilent) {
        console.warn("تنبيه جلب قائمة المدراء:", err?.message || err);
      }
    } finally {
      setIsManagersLoading(false);
    }
  }, []);

  const handleRefreshDatabasesAndManagers = useCallback(async () => {
    try {
      const cloudDbs = await fetchDatabasesFromCloud();
      setDatabases(cloudDbs);
      await loadManagersFromCloud(true);
    } catch (e) {
      console.warn("Could not refresh databases & managers:", e);
    }
  }, [loadManagersFromCloud]);

  // Initialize session data from IndexedDB & LocalStorage
  useEffect(() => {
    if (!currentUser) {
      setStats({ totalAdded: 0, totalPaid: 0 });
      return;
    }

    let isMounted = true;

    async function loadData() {
      if (!currentUser) return;

      // 1. Settings (IDB first for instant rendering)
      const idbSettings = await getIdbSettings(currentUser.id);
      const initialSettings = idbSettings || getLocalSettings(currentUser.id);
      if (initialSettings && isMounted) {
        setSettings(initialSettings);
        if (initialSettings.language && initialSettings.language !== language) {
          setLanguage(initialSettings.language);
        }
        if (initialSettings.currency && initialSettings.currency !== currency) {
          setCurrency(initialSettings.currency);
        }
        if (initialSettings.numberFormat && initialSettings.numberFormat !== numberFormat) {
          setNumberFormat(initialSettings.numberFormat);
        }
      }

      // 2. Stats (IDB first)
      const idbStats = await getIdbStats(currentUser.id);
      if (idbStats && !(idbStats.totalAdded === 70000 && idbStats.totalPaid === 25000) && isMounted) {
        setStats(idbStats);
      } else {
        const cachedStats = getLocalStats(currentUser.id);
        if (cachedStats && !(cachedStats.totalAdded === 70000 && cachedStats.totalPaid === 25000)) {
          if (isMounted) setStats(cachedStats);
          saveIdbStats(currentUser.id, cachedStats);
        } else {
          const initialStats = { totalAdded: 0, totalPaid: 0 };
          if (isMounted) setStats(initialStats);
          setLocalStats(currentUser.id, initialStats);
          saveIdbStats(currentUser.id, initialStats);
        }
      }

      // 3. Debtors: Render local data first
      const idbDebtors = await getIdbDebtors(currentUser.id);
      if (idbDebtors && idbDebtors.length > 0) {
        const hasDemo = idbDebtors.some(isDemoDebtor);
        let enriched = idbDebtors.map((d) => (isDemoDebtor(d) ? { ...d, isDemo: true } : d));
        if (hasDemo && currentUser.role === 'admin') {
          const realOnly = enriched.filter((d) => !isDemoDebtor(d));
          const newDemo = generate100DemoDebtors(currentUser.id, idbSettings?.highDebtThreshold || 25000);
          enriched = [...newDemo, ...realOnly];
        }
        if (isMounted) setAllDebtors(enriched);
      } else {
        const cachedDebtors = getLocalDebtors(currentUser.id);
        if (cachedDebtors !== null && cachedDebtors.length > 0) {
          const datesMap = getLocalDebtorDates(currentUser.id);
          let datesModified = false;
          let debtorsWithDates = cachedDebtors.map((d, idx) => {
            const isDemo = isDemoDebtor(d);
            if (!d.createdAt) {
              if (datesMap[d.id]) {
                d.createdAt = datesMap[d.id];
              } else {
                const pastDays = (idx % 3) + 1;
                d.createdAt = new Date(Date.now() - pastDays * 24 * 60 * 60 * 1000).toISOString();
                datesMap[d.id] = d.createdAt;
                datesModified = true;
              }
            }
            return isDemo ? { ...d, isDemo: true } : d;
          });

          if (debtorsWithDates.some(isDemoDebtor) && currentUser.role === 'admin') {
            const realOnly = debtorsWithDates.filter((d) => !isDemoDebtor(d));
            const newDemo = generate100DemoDebtors(currentUser.id, idbSettings?.highDebtThreshold || 25000);
            debtorsWithDates = [...newDemo, ...realOnly];
          }

          if (datesModified) {
            setLocalDebtorDates(currentUser.id, datesMap);
          }

          if (isMounted) setAllDebtors(debtorsWithDates);
        }
      }

      // 4. Installments (نظام الأقساط المنفصل) - IDB and LocalStorage first
      const idbInsts = await getIdbInstallments(currentUser.id);
      if (idbInsts && idbInsts.length > 0) {
        // Recompute dynamic status with today's date
        const refreshed = idbInsts.map((inst) => ({
          ...inst,
          status: computeInstallmentStatus(inst),
        }));
        if (isMounted) setInstallments(refreshed);
      } else {
        const cachedInsts = getLocalInstallments(currentUser.id);
        if (cachedInsts && cachedInsts.length > 0 && isMounted) {
          const refreshed = cachedInsts.map((inst) => ({
            ...inst,
            status: computeInstallmentStatus(inst),
          }));
          setInstallments(refreshed);
        }
      }

      // 5. Managers & Databases if admin
      if (currentUser.role === 'admin') {
        const idbManagers = await getIdbManagers();
        if (idbManagers && idbManagers.length > 0) {
          if (isMounted) setManagers(idbManagers);
        } else {
          const cachedManagers = getLocalManagers();
          if (cachedManagers !== null && isMounted) {
            setManagers(cachedManagers);
            saveIdbManagers(cachedManagers);
          }
        }
        loadDatabasesFromCloud();
        loadManagersFromCloud(true);
      }

      // 6. Cloud Sync (تزامن سحابي للإعدادات والبيانات)
      if (isMounted && !isTrialMode) {
        fetchSettingsFromCloud(currentUser.id)
          .then((cloudSettings) => {
            if (cloudSettings && isMounted) {
              setSettings(cloudSettings);
              saveIdbSettings(currentUser.id, cloudSettings);
              setLocalSettings(currentUser.id, cloudSettings);

              if (cloudSettings.language && cloudSettings.language !== language) {
                setLanguage(cloudSettings.language);
              }
              if (cloudSettings.currency && cloudSettings.currency !== currency) {
                setCurrency(cloudSettings.currency);
              }
              if (cloudSettings.numberFormat && cloudSettings.numberFormat !== numberFormat) {
                setNumberFormat(cloudSettings.numberFormat);
              }
            }
          })
          .catch((e) => console.warn("Cloud settings sync:", e));

        await syncCloudDataIfChanged(currentUser.id, false, true);
        await fetchAndCacheInstallments(currentUser.id, true);
        if (currentUser.role === 'admin') {
          await loadManagersFromCloud(true);
        }
      }
    }

    loadData();

    return () => {
      isMounted = false;
    };
  }, [currentUser, syncCloudDataIfChanged, fetchAndCacheInstallments, loadManagersFromCloud]);

  // Event-Driven Sync & Local Autonomy
  useEffect(() => {
    if (!currentUser || isTrialMode) return;

    const handleBroadcastDebtors = (event: MessageEvent) => {
      if (event.data?.type === 'DEBTORS_UPDATED' && event.data?.userId === currentUser.id) {
        fetchAndCacheCloudData(currentUser.id, true);
      }
    };

    const handleBroadcastInstallments = (event: MessageEvent) => {
      if (event.data?.type === 'INSTALLMENTS_UPDATED' && event.data?.userId === currentUser.id) {
        fetchAndCacheInstallments(currentUser.id, true);
      }
    };

    const handleBroadcastSettings = (event: MessageEvent) => {
      if (event.data?.type === 'SETTINGS_UPDATED' && event.data?.userId === currentUser.id) {
        const updated = event.data.settings as AppSettings;
        if (updated) {
          setSettings(updated);
          if (updated.language && updated.language !== language) {
            setLanguage(updated.language);
          }
          if (updated.currency && updated.currency !== currency) {
            setCurrency(updated.currency);
          }
          if (updated.numberFormat && updated.numberFormat !== numberFormat) {
            setNumberFormat(updated.numberFormat);
          }
        }
      }
    };

    const handleOnline = async () => {
      if (!currentUser || isTrialMode) return;
      await flushOutbox(currentUser.id);
    };

    window.addEventListener('online', handleOnline);

    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.addEventListener('message', handleBroadcastDebtors);
    }
    if (installmentsBroadcastChannel) {
      installmentsBroadcastChannel.addEventListener('message', handleBroadcastInstallments);
    }
    if (settingsBroadcastChannel) {
      settingsBroadcastChannel.addEventListener('message', handleBroadcastSettings);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      if (debtorsBroadcastChannel) {
        debtorsBroadcastChannel.removeEventListener('message', handleBroadcastDebtors);
      }
      if (installmentsBroadcastChannel) {
        installmentsBroadcastChannel.removeEventListener('message', handleBroadcastInstallments);
      }
      if (settingsBroadcastChannel) {
        settingsBroadcastChannel.removeEventListener('message', handleBroadcastSettings);
      }
    };
  }, [currentUser, fetchAndCacheCloudData, fetchAndCacheInstallments, loadManagersFromCloud, language, currency, numberFormat, setLanguage, setCurrency, setNumberFormat]);

  const handleForceLogout = useCallback(
    (reason: string) => {
      setCurrentUser(null);
      setLocalSession(null);
      setActiveTab('home');
      setAllDebtors([]);
      setInstallments([]);
      setStats({ totalAdded: 0, totalPaid: 0 });
      setLoginErrorMessage(reason);
      showToast(reason, "error");
    },
    [showToast]
  );

  useEffect(() => {
    if (currentUser) {
      if (currentUser.allowedModules === 'installments') {
        setHeaderMode('installments');
      } else if (currentUser.allowedModules === 'debts') {
        setHeaderMode('debts');
      }
    }
  }, [currentUser]);

  const handleLoginSuccess = async (user: User) => {
    setLoginErrorMessage(null);
    setCurrentUser(user);
    if (user.allowedModules === 'installments') {
      setHeaderMode('installments');
    } else if (user.allowedModules === 'debts') {
      setHeaderMode('debts');
    }

    // Load local settings first
    const localSt = getLocalSettings(user.id);
    setSettings(localSt);
    if (localSt.language) setLanguage(localSt.language);
    if (localSt.currency) setCurrency(localSt.currency);
    if (localSt.numberFormat) setNumberFormat(localSt.numberFormat);

    // Fetch cloud settings immediately if not trial mode
    if (user.id !== 999999) {
      fetchSettingsFromCloud(user.id)
        .then((cloudSettings) => {
          if (cloudSettings) {
            setSettings(cloudSettings);
            saveIdbSettings(user.id, cloudSettings);
            setLocalSettings(user.id, cloudSettings);
            if (cloudSettings.language) setLanguage(cloudSettings.language);
            if (cloudSettings.currency) setCurrency(cloudSettings.currency);
            if (cloudSettings.numberFormat) setNumberFormat(cloudSettings.numberFormat);
          } else {
            // Upload current local settings to cloud as initial seed
            syncSettingsToCloud(user.id, localSt).catch(() => {});
          }
        })
        .catch(() => {});
    }

    const cachedStats = getLocalStats(user.id);
    if (cachedStats && !(cachedStats.totalAdded === 70000 && cachedStats.totalPaid === 25000)) {
      setStats(cachedStats);
    } else {
      const freshStats = { totalAdded: 0, totalPaid: 0 };
      setStats(freshStats);
      setLocalStats(user.id, freshStats);
      saveIdbStats(user.id, freshStats);
    }
    setActiveTab('home');
    showToast(t('toast.welcomeBranch', 'مرحباً بك! فرع: {branch}').replace('{branch}', getUserBranchDisplayName(user, t)), "success");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setLocalSession(null);
    setActiveTab('home');
    setAllDebtors([]);
    setInstallments([]);
    setStats({ totalAdded: 0, totalPaid: 0 });
    setLoginErrorMessage(null);
    showToast(t('toast.loggedOut', 'تم تسجيل الخروج بنجاح'), "info");
  };

  const handleSecretAdminUnlock = useCallback(() => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([40, 60, 40]);
      } catch {}
    }
    showToast(t('toast.adminUnlocked', 'تم فتح لوحة التحكم والإدارة السرية'), "success");
    setIsSecretAdminModalOpen(true);
  }, [showToast, t]);

  const checkManagerActiveStatus = useCallback(
    async (user: User): Promise<boolean> => {
      if (
        !user ||
        user.role === 'admin' ||
        user.role === 'trial' ||
        user.subscriptionType === 'trial' ||
        user.id === 999999
      )
        return true;

      const localFlag = localStorage.getItem(`force_logout_user_${user.id}`);
      if (localFlag) {
        let reason = t('toast.accountSuspendedByAdmin', 'تم إيقاف هذا الحساب من قبل الإدارة العامة.');
        try {
          const parsed = JSON.parse(localFlag);
          if (parsed.reason) reason = parsed.reason;
        } catch {}
        handleForceLogout(reason);
        return false;
      }

      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        try {
          const managersList: Manager[] = JSON.parse(managersData);
          const found = managersList.find((m) => m.id === user.id);
          if (found && found.isActive === false) {
            handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
            return false;
          }
        } catch {}
      }

      try {
        const res = await queryMainTurso(
          "SELECT is_active, subscription_type, subscription_expires_at FROM users WHERE id = ?;",
          [Number(user.id)]
        );
        if (res.results && res.results[0] && res.results[0].response?.result?.rows?.length > 0) {
          const row = res.results[0].response.result.rows[0];
          const isActiveVal = row[0]?.value ?? row[0];
          const isActive = isActiveVal === 0 || isActiveVal === '0' || isActiveVal === false ? false : true;

          if (!isActive) {
            handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
            return false;
          }
        }
      } catch (err: any) {
        console.warn("Could not check manager active status from cloud main DB:", err);
      }

      return true;
    },
    [handleForceLogout]
  );

  // Sub-Manager Session Security Watcher
  useEffect(() => {
    if (
      !currentUser ||
      currentUser.role === 'admin' ||
      currentUser.role === 'trial' ||
      currentUser.subscriptionType === 'trial' ||
      currentUser.id === 999999
    ) {
      return;
    }

    let isCancelled = false;

    const handleBroadcastMessage = (event: MessageEvent) => {
      const data = event.data;
      if (data && data.type === 'FORCE_LOGOUT' && data.targetUserId === currentUser.id) {
        handleForceLogout(data.reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً.');
      }
    };

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.addEventListener('message', handleBroadcastMessage);
    }

    const handleStorageEvent = (e: StorageEvent) => {
      if (e.key === `force_logout_user_${currentUser.id}` && e.newValue) {
        let reason = t('toast.accountSuspendedByAdmin', 'تم إيقاف هذا الحساب من قبل الإدارة العامة.');
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed.reason) reason = parsed.reason;
        } catch {}
        handleForceLogout(reason);
      } else if (e.key === 'local_managers_list' && e.newValue) {
        try {
          const list: Manager[] = JSON.parse(e.newValue);
          const found = list.find((m) => m.id === currentUser.id);
          if (found && found.isActive === false) {
            handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
          }
        } catch {}
      } else if (e.key === 'session_user' && !e.newValue) {
        handleForceLogout('تم تسجيل الخروج من هذا الحساب.');
      }
    };
    window.addEventListener('storage', handleStorageEvent);

    const intervalId = setInterval(() => {
      if (!isCancelled && document.visibilityState === 'visible') {
        checkManagerActiveStatus(currentUser);
      }
    }, 3500);

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && !isCancelled) {
        checkManagerActiveStatus(currentUser);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleVisibilityChange);

    return () => {
      isCancelled = true;
      if (sessionBroadcastChannel) {
        sessionBroadcastChannel.removeEventListener('message', handleBroadcastMessage);
      }
      window.removeEventListener('storage', handleStorageEvent);
      clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleVisibilityChange);
    };
  }, [currentUser, checkManagerActiveStatus, handleForceLogout]);

  // ----------------------------------------------------
  // INSTALLMENTS CRUD ACTIONS (إدارة الأقساط)
  // ----------------------------------------------------

  const handleAddInstallment = async (instData: Omit<InstallmentRecord, 'id'>) => {
    if (!currentUser) return;
    if (isTrialMode && installments.length >= 2) {
      setIsTrialLimitModalOpen(true);
      return;
    }
    const tempId = Date.now();
    const newInst: InstallmentRecord = {
      ...instData,
      id: tempId,
      userId: currentUser.id,
    };

    // 1. Instant Optimistic Update
    const updated = [newInst, ...installments];
    setInstallments(updated);
    setLocalInstallments(currentUser.id, updated);
    await putIdbInstallment(newInst);

    showToast(t('toast.installmentRecorded', 'تم تسجيل معاملة القسط لـ ({name}) بنجاح').replace('{name}', newInst.name), "success");

    // Real-time cloud sync for live customer portal access
    syncSingleInstallmentToCloud(currentUser?.id || 1, newInst).catch(() => {});

    // 2. Outbox Queue & Cloud Sync
    if (!isTrialMode) {
      await queueOutboxAction(currentUser.id, 'ADD_INSTALLMENT', newInst);
      broadcastInstallmentsChange(currentUser.id, 'add');
    }

    // 3. Auto WhatsApp Notification if customer has phone
    if (newInst.phone && newInst.phone.trim()) {
      const notice = createNewInstallmentWhatsAppNotice(
        newInst,
        getCurrencySymbol(),
        getUserBranchDisplayName(currentUser, t) || 'نظام الأقساط'
      );
      triggerWhatsAppNotification(notice);
    }
  };

  const handleUpdateInstallment = async (updatedInst: InstallmentRecord) => {
    if (!currentUser) return;
    const target = installments.find((i) => i.id === updatedInst.id);
    if (!target) return;

    // Recalculate status based on new values
    const newStatus = computeInstallmentStatus({
      remainingAmount: updatedInst.remainingAmount,
      nextDueDate: updatedInst.nextDueDate,
      registrationDate: updatedInst.registrationDate,
    });

    const finalInst: InstallmentRecord = {
      ...updatedInst,
      status: newStatus,
    };

    const updated = installments.map((i) => (i.id === updatedInst.id ? finalInst : i));
    setInstallments(updated);
    setLocalInstallments(currentUser.id, updated);
    await putIdbInstallment(finalInst);

    showToast(t('toast.installmentSaved', 'تم تعديل وحفظ بيانات قسط ({name}) بنجاح').replace('{name}', finalInst.name), "success");

    // Sync to cloud for live statement access
    syncSingleInstallmentToCloud(currentUser?.id || 1, finalInst).catch(() => {});

    // Outbox Queue & Cloud Sync
    if (!isTrialMode && updatedInst.id > 0) {
      await queueOutboxAction(currentUser.id, 'UPDATE_INSTALLMENT', finalInst);
      broadcastInstallmentsChange(currentUser.id, 'edit');
    }
  };

  const handleSettleInstallmentPayment = async (
    installmentId: number,
    paidAmount: number,
    paymentDate: string,
    notes?: string
  ) => {
    if (!currentUser) return;
    const target = installments.find((i) => i.id === installmentId);
    if (!target) return;

    const newRemaining = Math.max(0, target.remainingAmount - paidAmount);
    // When payment is recorded, next due date moves forward 1 month from payment date (or previous due date)
    const nextDueDate = newRemaining <= 0
      ? target.nextDueDate
      : calculateNextMonthDueDate(target.nextDueDate || paymentDate, 1);

    const newStatus = computeInstallmentStatus({
      remainingAmount: newRemaining,
      nextDueDate,
      registrationDate: target.registrationDate,
    });

    const newPayment = {
      id: `pay-${Date.now()}`,
      installmentId,
      amount: paidAmount,
      date: paymentDate,
      remainingAfter: newRemaining,
      notes: notes || 'تسديد قسط',
    };

    const updatedPayments = [newPayment, ...(target.payments || [])];
    const updatedInst: InstallmentRecord = {
      ...target,
      remainingAmount: newRemaining,
      nextDueDate,
      status: newStatus,
      payments: updatedPayments,
    };

    // Optimistic local update
    const updated = installments.map((i) => (i.id === installmentId ? updatedInst : i));
    setInstallments(updated);
    setLocalInstallments(currentUser.id, updated);
    await putIdbInstallment(updatedInst);

    showToast(
      `${t('toast.installmentPaymentSuccess', 'تم استلام وتسجيل')} ${formatNumber(paidAmount, numberFormat)} ${getCurrencySymbol()} (${target.name})`,
      "success"
    );

    // Sync to cloud for live statement access
    syncSingleInstallmentToCloud(currentUser?.id || 1, updatedInst).catch(() => {});

    // Outbox Queue & Cloud Sync
    if (!isTrialMode && installmentId > 0) {
      await queueOutboxAction(currentUser.id, 'SETTLE_INSTALLMENT_PAYMENT', {
        id: installmentId,
        remainingAmount: newRemaining,
        nextDueDate,
        status: newStatus,
        payments: updatedPayments,
      });
      broadcastInstallmentsChange(currentUser.id, 'settle');
    }

    // Auto WhatsApp Notification for paying installment if customer has phone
    if (target.phone && target.phone.trim()) {
      const notice = createPayInstallmentWhatsAppNotice(
        target,
        paidAmount,
        newRemaining,
        nextDueDate,
        getCurrencySymbol(),
        paymentDate,
        notes,
        getUserBranchDisplayName(currentUser, t) || 'نظام الأقساط'
      );
      triggerWhatsAppNotification(notice);
    }
  };

  const handleDeleteInstallment = async (id: number) => {
    if (!currentUser) return;
    const target = installments.find((i) => i.id === id);
    if (!target) return;

    setConfirmState({
      isOpen: true,
      title: t('modals.confirmDeleteInstallmentTitle', 'تأكيد حذف معاملة القسط'),
      message: t('modals.confirmDeleteInstallmentMessage', 'هل أنت متأكد من حذف معاملة القسط لـ "{name}" ({item}) نهائياً؟ لا يمكن التراجع عن هذا الإجراء.')
        .replace('{name}', target.name)
        .replace('{item}', target.item),
      onConfirm: async () => {
        const updated = installments.filter((i) => i.id !== id);
        setInstallments(updated);
        setLocalInstallments(currentUser.id, updated);
        await deleteIdbInstallment(id);

        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast(t('toast.installmentDeleted', 'تم حذف معاملة القسط ({name}) بنجاح').replace('{name}', target.name), "info");

        if (!isTrialMode && id > 0) {
          await queueOutboxAction(currentUser.id, 'DELETE_INSTALLMENT', { id });
          broadcastInstallmentsChange(currentUser.id, 'delete');
        }
      },
    });
  };

  // ----------------------------------------------------
  // DEBTORS CRUD ACTIONS (دفتر الديون)
  // ----------------------------------------------------

  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    if (currentUser) {
      setLocalSettings(currentUser.id, newSettings);
      saveIdbSettings(currentUser.id, newSettings);
      if (currentUser.id !== 999999) {
        syncSettingsToCloud(currentUser.id, newSettings).catch((err) => {
          console.warn("Cloud settings sync warning:", err);
        });
      }
      broadcastSettingsChange(currentUser.id, newSettings);
    }
    showToast(t('toast.settingsSaved', 'تم حفظ وتطبيق الإعدادات سحابياً ومحلياً بنجاح'), 'success');
  };

  const handleToggleLayoutTheme = () => {
    const currentTheme = settings.layoutTheme || 'fintech';
    const nextTheme: AppLayoutTheme = currentTheme === 'fintech' ? 'classic' : 'fintech';
    const updatedSettings: AppSettings = {
      ...settings,
      layoutTheme: nextTheme,
    };
    handleUpdateSettings(updatedSettings);
  };

  const handleUpdateStats = (newStats: DebtStats) => {
    if (!currentUser) return;
    setStats(newStats);
    setLocalStats(currentUser.id, newStats);
    saveIdbStats(currentUser.id, newStats);
    showToast(t('toast.reportsUpdated', 'تم تحديث أرقام التقارير بنجاح'), 'success');
  };

  const handleResetStats = () => {
    if (!currentUser) return;
    setConfirmState({
      isOpen: true,
      title: t('modals.resetStatsTitle', 'تصفير سجل التقارير'),
      message: t('modals.resetStatsMessage', 'هل أنت متأكد من تصفير إحصائيات الديون التراكمية في صفحة التقارير لبدء دورة محاسبية جديدة؟'),
      onConfirm: async () => {
        const zeroStats = { totalAdded: 0, totalPaid: 0 };
        setStats(zeroStats);
        setLocalStats(currentUser.id, zeroStats);
        await saveIdbStats(currentUser.id, zeroStats);
        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast(t('toast.reportsReset', 'تم تصفير سجل التقارير والإحصائيات بنجاح'), 'info');
      },
    });
  };

  const handleImportBackup = async (
    importedDebtors: Debtor[],
    importedInstallments: InstallmentRecord[],
    mode: 'merge' | 'replace',
    importedManagers?: Manager[]
  ) => {
    if (!currentUser) return;
    setIsSavingCloud(true);
    try {
      // ----------------------------------------------------
      // 0. IMPORT & PROCESS MANAGERS (IF PROVIDED & ADMIN)
      // ----------------------------------------------------
      if (importedManagers && importedManagers.length > 0 && currentUser.role === 'admin') {
        let finalManagers: Manager[] = [];
        if (mode === 'replace') {
          finalManagers = importedManagers;
        } else {
          const mgrMap = new Map<string, Manager>();
          managers.forEach((m) => mgrMap.set(m.username.trim().toLowerCase(), m));
          importedManagers.forEach((m) => {
            mgrMap.set(m.username.trim().toLowerCase(), m);
          });
          finalManagers = Array.from(mgrMap.values());
        }

        setManagers(finalManagers);
        setLocalManagers(finalManagers);
        await saveIdbManagers(finalManagers);

        // Store passwords locally for quick lookup
        finalManagers.forEach((m) => {
          if (m.plainPassword) {
            localStorage.setItem(`user_pwd_${m.id}`, m.plainPassword);
            localStorage.setItem(`user_pwd_${m.username}`, m.plainPassword);
          }
        });
      }

      // ----------------------------------------------------
      // 1. IMPORT & PROCESS DEBTORS
      // ----------------------------------------------------
      let finalDebtors: Debtor[] = [];
      const currentHistoryMap = getLocalDebtorHistory(currentUser.id);
      const updatedHistoryMap = { ...currentHistoryMap };
      const currentDatesMap = getLocalDebtorDates(currentUser.id);
      const updatedDatesMap = { ...currentDatesMap };

      if (mode === 'replace') {
        finalDebtors = importedDebtors.map((d, index) => {
          const debtorId = d.id || Date.now() + index;
          if (d.history && d.history.length > 0) {
            updatedHistoryMap[debtorId] = d.history;
          }
          if (d.createdAt || d.lastDebtDate) {
            updatedDatesMap[debtorId] = d.lastDebtDate || d.createdAt || new Date().toISOString();
          }
          return {
            ...d,
            id: debtorId,
            userId: currentUser.id,
          };
        });
      } else {
        const existingMap = new Map<string, Debtor>();
        allDebtors.forEach((d) => {
          if (!d) return;
          existingMap.set((d.name || '').trim().toLowerCase(), d);
        });

        const mergedList = [...allDebtors];
        importedDebtors.forEach((imp, index) => {
          if (!imp) return;
          const key = (imp.name || '').trim().toLowerCase();
          if (existingMap.has(key)) {
            const exist = existingMap.get(key)!;
            const newAmount = exist.amount + imp.amount;
            const updatedHistory = [
              ...(imp.history || []),
              ...(updatedHistoryMap[exist.id] || []),
            ];
            updatedHistoryMap[exist.id] = updatedHistory;
            const idx = mergedList.findIndex((m) => m.id === exist.id);
            if (idx >= 0) {
              mergedList[idx] = {
                ...exist,
                amount: newAmount,
                phone: imp.phone || exist.phone,
                status: newAmount >= settings.highDebtThreshold ? 'دين مرتفع' : exist.status,
                history: updatedHistory,
              };
            }
          } else {
            const newId = imp.id || Date.now() + index;
            if (imp.history && imp.history.length > 0) {
              updatedHistoryMap[newId] = imp.history;
            }
            if (imp.createdAt || imp.lastDebtDate) {
              updatedDatesMap[newId] = imp.lastDebtDate || imp.createdAt || new Date().toISOString();
            }
            mergedList.push({
              ...imp,
              id: newId,
              userId: currentUser.id,
            });
          }
        });
        finalDebtors = mergedList;
      }

      setAllDebtors(finalDebtors);
      setLocalDebtors(currentUser.id, finalDebtors);
      setLocalDebtorHistory(currentUser.id, updatedHistoryMap);
      setLocalDebtorDates(currentUser.id, updatedDatesMap);
      await saveIdbDebtors(currentUser.id, finalDebtors);

      // ----------------------------------------------------
      // 2. IMPORT & PROCESS INSTALLMENTS (الأقساط)
      // ----------------------------------------------------
      let finalInstallments: InstallmentRecord[] = [];

      if (mode === 'replace') {
        finalInstallments = importedInstallments.map((inst, index) => ({
          ...inst,
          id: inst.id || Date.now() + 2000 + index,
          userId: currentUser.id,
          payments: Array.isArray(inst.payments) ? inst.payments : [],
        }));
      } else {
        const existingInstMap = new Map<string, InstallmentRecord>();
        installments.forEach((inst) => {
          if (!inst) return;
          const key = `${(inst.name || '').trim().toLowerCase()}___${(inst.item || '').trim().toLowerCase()}`;
          existingInstMap.set(key, inst);
        });

        const mergedInstallments = [...installments];
        importedInstallments.forEach((imp, index) => {
          if (!imp) return;
          const key = `${(imp.name || '').trim().toLowerCase()}___${(imp.item || '').trim().toLowerCase()}`;
          if (existingInstMap.has(key)) {
            const exist = existingInstMap.get(key)!;
            const existPayments = Array.isArray(exist.payments) ? exist.payments : [];
            const impPayments = Array.isArray(imp.payments) ? imp.payments : [];
            // Merge payments uniquely by id
            const payMap = new Map<string | number, any>();
            existPayments.forEach((p) => payMap.set(p.id, p));
            impPayments.forEach((p) => payMap.set(p.id, p));
            const mergedPayments = Array.from(payMap.values());

            const totalPaid = mergedPayments.reduce((s, p) => s + (Number(p.amount) || 0), 0);
            const remainingAmount = Math.max(0, exist.totalAmount - exist.downPayment - totalPaid);
            const status = remainingAmount <= 0 ? 'completed' : exist.status;

            const idx = mergedInstallments.findIndex((m) => m.id === exist.id);
            if (idx >= 0) {
              mergedInstallments[idx] = {
                ...exist,
                phone: imp.phone || exist.phone,
                remainingAmount,
                status,
                payments: mergedPayments,
                notes: imp.notes ? (exist.notes ? `${exist.notes} | ${imp.notes}` : imp.notes) : exist.notes,
              };
            }
          } else {
            const newInstId = imp.id || Date.now() + 2000 + index;
            mergedInstallments.push({
              ...imp,
              id: newInstId,
              userId: currentUser.id,
              payments: Array.isArray(imp.payments) ? imp.payments : [],
            });
          }
        });
        finalInstallments = mergedInstallments;
      }

      setInstallments(finalInstallments);
      setLocalInstallments(currentUser.id, finalInstallments);
      await saveIdbInstallments(currentUser.id, finalInstallments);

      // Cloud Turso sync if active account
      if (!isTrialMode && currentUser.id > 0) {
        try {
          if (mode === 'replace') {
            await queryTurso("DELETE FROM debtors WHERE user_id = ?;", [currentUser.id]);
            for (const d of finalDebtors) {
              await queryTurso(
                "INSERT INTO debtors (id, name, phone, amount, status, user_id, last_debt_date, history, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);",
                [
                  d.id,
                  d.name,
                  d.phone || '',
                  d.amount || 0,
                  d.status || 'مستمر',
                  currentUser.id,
                  d.lastDebtDate || d.createdAt || null,
                  JSON.stringify(updatedHistoryMap[d.id] || []),
                  d.createdAt || new Date().toISOString(),
                ]
              );
            }

            await queryTurso("DELETE FROM installments WHERE user_id = ?;", [currentUser.id]);
            for (const inst of finalInstallments) {
              await queryTurso(
                "INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
                [
                  inst.id,
                  inst.name,
                  inst.phone || '',
                  inst.item || '',
                  inst.totalAmount || 0,
                  inst.downPayment || 0,
                  inst.remainingAmount || 0,
                  inst.registrationDate || new Date().toISOString().slice(0, 10),
                  inst.nextDueDate || new Date().toISOString().slice(0, 10),
                  currentUser.id,
                  inst.status || 'active',
                  inst.notes || '',
                  JSON.stringify(inst.payments || []),
                  inst.createdAt || new Date().toISOString(),
                ]
              );
            }
          }
        } catch (cloudErr) {
          console.warn("Cloud restore sync warning:", cloudErr);
        }
      }

      broadcastDebtorsChange(currentUser.id, 'import');
      broadcastInstallmentsChange(currentUser.id, 'import');

      const totalDebtsSum = finalDebtors.reduce((sum, d) => sum + (d.amount || 0), 0);
      setStats((prev) => {
        const next = { ...prev, totalAdded: Math.max(prev.totalAdded, totalDebtsSum + prev.totalPaid) };
        setLocalStats(currentUser.id, next);
        saveIdbStats(currentUser.id, next);
        return next;
      });

      const mgrCount = importedManagers ? importedManagers.length : 0;
      showToast(
        `${t('toast.dataRestored', 'تم استرجاع وتحديث البيانات بنجاح')} (${mgrCount > 0 ? `${formatNumber(mgrCount, numberFormat)} مدراء • ` : ''}${formatNumber(importedDebtors.length, numberFormat)} مدينين • ${formatNumber(importedInstallments.length, numberFormat)} أقساط)`,
        "success"
      );
    } catch (err: any) {
      showToast(err.message || t('toast.backupError', 'حدث خطأ أثناء استيراد البيانات'), "error");
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleSaveDebtor = async (
    nameOrData: string | Omit<Debtor, 'id' | 'userId'>,
    phoneArg?: string,
    amountArg?: number,
    debtDateArg?: string,
    notesArg?: string
  ) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    if (isTrialMode && allDebtors.length >= 2) {
      setIsTrialLimitModalOpen(true);
      return;
    }

    let debtorName = '';
    let debtorPhone = '';
    let debtorAmount = 0;
    let createdAt = new Date().toISOString();
    let debtorNotes: string | undefined = undefined;

    if (typeof nameOrData === 'object' && nameOrData !== null) {
      debtorName = (nameOrData.name || '').trim();
      debtorPhone = (nameOrData.phone || '').trim();
      debtorAmount = typeof nameOrData.amount === 'number' ? nameOrData.amount : parseFloat(String(nameOrData.amount || 0)) || 0;
      createdAt = nameOrData.createdAt || (debtDateArg ? new Date(debtDateArg).toISOString() : new Date().toISOString());
      debtorNotes = nameOrData.notes || notesArg || undefined;
    } else {
      debtorName = String(nameOrData || '').trim();
      debtorPhone = String(phoneArg || '').trim();
      debtorAmount = typeof amountArg === 'number' ? amountArg : parseFloat(String(amountArg || 0)) || 0;
      if (debtDateArg) {
        try {
          createdAt = new Date(debtDateArg).toISOString();
        } catch {
          createdAt = debtDateArg;
        }
      }
      debtorNotes = notesArg ? String(notesArg).trim() || undefined : undefined;
    }

    if (!debtorName) {
      showToast(t('modals.enterDebtorNameError', 'يرجى كتابة اسم المدين أولاً'), 'error');
      return;
    }

    const tempId = Date.now();
    const initialStatus = debtorAmount >= (settings.highDebtThreshold ?? 25000) ? 'دين مرتفع' : 'دين عادي';

    const initialHistory: DebtorTransaction = {
      id: `tx-init-${tempId}`,
      debtorId: tempId,
      type: 'initial',
      amount: debtorAmount,
      balanceAfter: debtorAmount,
      date: createdAt,
      description: 'فتح حساب وتسجيل الرصيد الأولي',
      notes: debtorNotes,
    };

    const newDebtor: Debtor = {
      id: tempId,
      userId: currentUser.id,
      name: debtorName,
      phone: debtorPhone,
      amount: debtorAmount,
      status: initialStatus,
      notes: debtorNotes,
      createdAt,
      lastDebtDate: createdAt,
      history: [initialHistory],
    };

    const datesMap = getLocalDebtorDates(currentUser.id);
    datesMap[tempId] = createdAt;
    setLocalDebtorDates(currentUser.id, datesMap);

    const historyMap = getLocalDebtorHistory(currentUser.id);
    historyMap[tempId] = [initialHistory];
    setLocalDebtorHistory(currentUser.id, historyMap);

    const updated = [newDebtor, ...allDebtors];
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(newDebtor);

    if (debtorAmount > 0) {
      setStats((prev) => {
        const next = { ...prev, totalAdded: prev.totalAdded + debtorAmount };
        setLocalStats(currentUser.id, next);
        saveIdbStats(currentUser.id, next);
        return next;
      });
    }

    showToast(t('toast.debtorAdded', 'تمت إضافة {name} بنجاح').replace('{name}', newDebtor.name), "success");

    // Real-time cloud sync to ensure customer portal works immediately
    syncSingleDebtorToCloud(currentUser?.id || 1, newDebtor).catch(() => {});

    if (!isTrialMode) {
      await queueOutboxAction(currentUser.id, 'ADD_DEBTOR', newDebtor);
      broadcastDebtorsChange(currentUser.id, 'add');
    }

    // Auto WhatsApp Notification for new debtor/debt if customer has phone
    if (newDebtor.phone && newDebtor.phone.trim()) {
      const notice = createNewDebtorWhatsAppNotice(
        newDebtor,
        getCurrencySymbol(),
        getUserBranchDisplayName(currentUser, t) || 'دفتر الديون'
      );
      triggerWhatsAppNotification(notice);
    }
  };

  const handleOpenPayModal = useCallback((debtor: Debtor) => {
    setTransactionState({
      isOpen: true,
      type: 'pay',
      debtor,
    });
  }, []);

  const handleOpenAddDebtModal = useCallback((debtor: Debtor) => {
    setTransactionState({
      isOpen: true,
      type: 'add',
      debtor,
    });
  }, []);

  const handleOpenEditNameModal = useCallback((debtor: Debtor) => {
    setEditingNameDebtor(debtor);
    setIsEditNameModalOpen(true);
  }, []);

  const handleOpenHistoryModal = useCallback((debtor: Debtor) => {
    const historyMap = currentUser ? getLocalDebtorHistory(currentUser.id) : {};
    const effectiveHistory = historyMap[debtor.id] || debtor.history;
    setHistoryModalState({
      isOpen: true,
      debtor: { ...debtor, history: effectiveHistory },
    });
  }, [currentUser]);

  const handleOpenShareModal = useCallback((debtor: Debtor) => {
    setShareModalState({
      isOpen: true,
      debtor,
    });
    syncSingleDebtorToCloud(currentUser?.id || 1, debtor).catch(() => {});
  }, [currentUser]);

  const handleDeleteDebtor = useCallback(async (target: number | Debtor) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const debtorId = typeof target === 'number' ? target : target?.id;
    if (!debtorId) return;

    const debtor = allDebtors.find((d) => d.id === debtorId) || (typeof target !== 'number' ? target : null);
    if (!debtor) return;

    setConfirmState({
      isOpen: true,
      title: t('modals.confirmDeleteDebtorTitle', 'تأكيد الحذف'),
      message: t('modals.confirmDeleteDebtorMessage', 'هل أنت متأكد من حذف المدين "{name}" نهائياً من القائمة وقاعدة البيانات؟')
        .replace('{name}', debtor.name || ''),
      onConfirm: async () => {
        const updated = allDebtors.filter((d) => d.id !== debtorId);
        setAllDebtors(updated);
        setLocalDebtors(currentUser.id, updated);
        await deleteIdbDebtor(debtorId);

        const datesMap = getLocalDebtorDates(currentUser.id);
        delete datesMap[debtorId];
        setLocalDebtorDates(currentUser.id, datesMap);

        const historyMap = getLocalDebtorHistory(currentUser.id);
        delete historyMap[debtorId];
        setLocalDebtorHistory(currentUser.id, historyMap);

        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast(t('toast.debtorDeleted', 'تم حذف {name} بنجاح').replace('{name}', debtor.name || ''), "info");

        if (debtorId > 0 && !debtor.isDemo && !isTrialMode) {
          await queueOutboxAction(currentUser.id, 'DELETE_DEBTOR', { id: debtorId });
          broadcastDebtorsChange(currentUser.id, 'delete');
        }
      },
    });
  }, [currentUser, allDebtors, t, isTrialMode, showToast]);

  const handleConfirmPay = async (
    debtorId: number,
    payVal: number,
    customDate?: string,
    notes?: string
  ) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const newAmount = Math.max(0, target.amount - payVal);
    const newStatus =
      newAmount <= 0
        ? 'خالي من الدين'
        : newAmount >= settings.highDebtThreshold
        ? 'دين مرتفع'
        : target.status;
    const txDate = customDate || new Date().toISOString();

    const payTx: DebtorTransaction = {
      id: `tx-pay-${debtorId}-${Date.now()}`,
      debtorId,
      type: 'pay',
      amount: payVal,
      balanceAfter: newAmount,
      date: txDate,
      description: notes ? notes : 'تسديد دفعة نقدية',
      notes: notes || undefined,
    };

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const existingHistory =
      historyMap[debtorId] ||
      target.history ||
      (target.createdAt
        ? [
            {
              id: `tx-init-${target.id}`,
              debtorId: target.id,
              type: 'initial' as const,
              amount: target.amount,
              balanceAfter: target.amount,
              date: target.createdAt,
              description: 'فتح حساب وتسجيل الرصيد الأولي',
            },
          ]
        : []);
    const updatedHistory = [payTx, ...existingHistory];
    historyMap[debtorId] = updatedHistory;
    setLocalDebtorHistory(currentUser.id, historyMap);

    const updatedDebtor = {
      ...target,
      amount: newAmount,
      status: newStatus,
      history: updatedHistory,
    };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    setHistoryModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: updatedDebtor };
      }
      return prev;
    });

    setStats((prev) => {
      const next = { ...prev, totalPaid: prev.totalPaid + payVal };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });
    showToast(
      `${t('debts.paymentRecorded', 'تم تسديد')} ${formatNumber(payVal, numberFormat)} ${getCurrencySymbol()} (${target.name})`,
      "success"
    );

    if (newAmount <= 0) {
      setSettleCompleteState({
        isOpen: true,
        debtor: updatedDebtor,
      });
    }

    // Sync to cloud for live statement access
    syncSingleDebtorToCloud(currentUser?.id || 1, updatedDebtor).catch(() => {});

    if (debtorId > 0 && !updatedDebtor.isDemo && !isTrialMode) {
      await queueOutboxAction(currentUser.id, 'TRANSACTION_DEBT', {
        id: debtorId,
        amount: newAmount,
        status: newStatus,
        history: updatedHistory,
        lastDebtDate: txDate,
      });
      broadcastDebtorsChange(currentUser.id, 'pay');
    }

    // Auto WhatsApp Notification for paying debt if customer has phone
    if (target.phone && target.phone.trim()) {
      const notice = createPayDebtWhatsAppNotice(
        target,
        payVal,
        newAmount,
        getCurrencySymbol(),
        txDate,
        notes,
        getUserBranchDisplayName(currentUser, t) || 'دفتر الديون'
      );
      triggerWhatsAppNotification(notice);
    }
  };

  const handleConfirmAddDebt = async (
    debtorId: number,
    addVal: number,
    customDate?: string,
    notes?: string
  ) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const newAmount = target.amount + addVal;
    const newStatus =
      newAmount >= settings.highDebtThreshold ? 'دين مرتفع' : target.status;
    const txDate = customDate || new Date().toISOString();

    const addTx: DebtorTransaction = {
      id: `tx-add-${debtorId}-${Date.now()}`,
      debtorId,
      type: 'add',
      amount: addVal,
      balanceAfter: newAmount,
      date: txDate,
      description: notes ? notes : 'إضافة دين جديد',
      notes: notes || undefined,
    };

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const existingHistory =
      historyMap[debtorId] ||
      target.history ||
      (target.createdAt
        ? [
            {
              id: `tx-init-${target.id}`,
              debtorId: target.id,
              type: 'initial' as const,
              amount: target.amount,
              balanceAfter: target.amount,
              date: target.createdAt,
              description: 'فتح حساب وتسجيل الرصيد الأولي',
            },
          ]
        : []);
    const updatedHistory = [addTx, ...existingHistory];
    historyMap[debtorId] = updatedHistory;
    setLocalDebtorHistory(currentUser.id, historyMap);

    const updatedDebtor = {
      ...target,
      amount: newAmount,
      status: newStatus,
      lastDebtDate: txDate,
      history: updatedHistory,
    };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    setHistoryModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: updatedDebtor };
      }
      return prev;
    });

    setStats((prev) => {
      const next = { ...prev, totalAdded: prev.totalAdded + addVal };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });
    showToast(
      `${t('debts.newDebtAdded', 'تمت إضافة')} ${formatNumber(addVal, numberFormat)} ${getCurrencySymbol()} (${target.name})`,
      "success"
    );

    // Sync to cloud for live statement access
    syncSingleDebtorToCloud(currentUser?.id || 1, updatedDebtor).catch(() => {});

    if (debtorId > 0 && !target.isDemo && !isTrialMode) {
      await queueOutboxAction(currentUser.id, 'TRANSACTION_DEBT', {
        id: debtorId,
        amount: newAmount,
        status: newStatus,
        history: updatedHistory,
        lastDebtDate: txDate,
      });
      broadcastDebtorsChange(currentUser.id, 'add_debt');
    }

    // Auto WhatsApp Notification for adding debt if customer has phone
    if (target.phone && target.phone.trim()) {
      const notice = createAddDebtWhatsAppNotice(
        target,
        addVal,
        newAmount,
        getCurrencySymbol(),
        txDate,
        notes,
        getUserBranchDisplayName(currentUser, t) || 'دفتر الديون'
      );
      triggerWhatsAppNotification(notice);
    }
  };

  const handleSaveDebtorName = async (id: number, newName: string, newPhone: string) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const updated = allDebtors.map((d) =>
      d.id === id ? { ...d, name: newName, phone: newPhone } : d
    );
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);

    const editedDebtor = updated.find((d) => d.id === id);
    if (editedDebtor) {
      await putIdbDebtor(editedDebtor);
      syncSingleDebtorToCloud(currentUser.id, editedDebtor).catch(() => {});
    }

    showToast(t('toast.debtorUpdated', 'تم تعديل بيانات {name} بنجاح').replace('{name}', newName), "success");

    const target = allDebtors.find((d) => d.id === id);
    if (id > 0 && target && !target.isDemo && !isTrialMode) {
      await queueOutboxAction(currentUser.id, 'UPDATE_DEBTOR', {
        id,
        name: newName,
        phone: newPhone,
      });
      broadcastDebtorsChange(currentUser.id, 'edit');
    }
  };

  const handleToggleOverdueStatus = async (debtorId: number) => {
    if (!currentUser) return;
    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const isCurrentlyOverdue =
      target.status === 'متأخر' ||
      (settings.enableDebtAlerts && calculateDaysElapsed(target.createdAt) >= settings.alertDaysThreshold);

    const newStatus = isCurrentlyOverdue
      ? target.amount >= settings.highDebtThreshold
        ? 'دين مرتفع'
        : 'دين عادي'
      : 'متأخر';

    const updatedDebtor = { ...target, status: newStatus };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    showToast(
      newStatus === 'متأخر'
        ? `${t('toast.markedOverdue', 'تم تصنيف')} "${target.name}" ${t('overdue.statusLate', 'كمتأخر عن السداد')}`
        : `${t('toast.removedOverdue', 'تمت إزالة حالة التأخير عن')} "${target.name}"`,
      newStatus === 'متأخر' ? 'info' : 'success'
    );

    if (debtorId > 0 && !target.isDemo && !isTrialMode) {
      await queueOutboxAction(currentUser.id, 'TRANSACTION_DEBT', {
        id: debtorId,
        amount: target.amount,
        status: newStatus,
        history: target.history || [],
        lastDebtDate: target.lastDebtDate,
      });
      broadcastDebtorsChange(currentUser.id, 'overdue');
    }
  };

  const handleKeepSettledDebtor = () => {
    setSettleCompleteState({ isOpen: false, debtor: null });
    showToast(`${t('toast.debtorRetained', 'تم الاحتفاظ بالمدين في القائمة برصيد 0')} ${getCurrencySymbol()}`, "info");
  };

  const handleDeleteSettledDebtor = async (debtor: Debtor) => {
    setSettleCompleteState({ isOpen: false, debtor: null });
    await handleDeleteDebtor(debtor.id);
  };

  // Demo Debtors
  const handleAddDemoDebtors = () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const realDebtors = allDebtors.filter((d) => !isDemoDebtor(d));
    const demoList = generate100DemoDebtors(currentUser.id, settings.highDebtThreshold);

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const datesMap = getLocalDebtorDates(currentUser.id);

    demoList.forEach((d) => {
      if (d.history) {
        historyMap[d.id] = d.history;
      }
      if (d.createdAt) {
        datesMap[d.id] = d.createdAt;
      }
    });

    const combined = [...demoList, ...realDebtors];
    setAllDebtors(combined);
    setLocalDebtors(currentUser.id, combined);
    setLocalDebtorHistory(currentUser.id, historyMap);
    setLocalDebtorDates(currentUser.id, datesMap);

    showToast(
      t('toast.demoAdded', "تمت إضافة 100 مدين تجريبي بنجاح للاختبار (محلية فقط دون التأثير على السحابة)"),
      "success"
    );
  };

  const handleAddMillionDemoDebtors = () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const realDebtors = allDebtors.filter((d) => !isDemoDebtor(d) && Number(d.id) > 0);
    const demoList = generateMillionDemoDebtors(currentUser.id, 10000, settings.highDebtThreshold);

    const combined = [...demoList, ...realDebtors];
    setAllDebtors(combined);
    setIsBillionDemoActive(false);

    showToast(
      "تمت إضافة 10,000 عميل تجريبي بنجاح للاختبار (محلية فقط دون رفعها للسيرفر)",
      "success"
    );
  };

  const handleAddBillionDemoDebtors = () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const realDebtors = allDebtors.filter((d) => !isDemoDebtor(d) && Number(d.id) > 0);
    const billionProxy = createBillionDebtorsProxy(currentUser.id, settings.highDebtThreshold, realDebtors);

    setAllDebtors(billionProxy);
    setIsBillionDemoActive(true);

    showToast(
      "⚡ تم تفعيل محاكي المليار عميل (1,000,000,000) فائق السرعة! اختبر التمرير والبحث الفوري بدون أي تعليق.",
      "success"
    );
  };

  const handleClearDemoDebtors = async () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    if (isBillionDemoActive || isBillionDebtorsProxy(allDebtors)) {
      setIsBillionDemoActive(false);
      const remainingReal = allDebtors.filter((d) => !isDemoDebtor(d) && Number(d.id) > 0);
      setAllDebtors(remainingReal);
      setLocalDebtors(currentUser.id, remainingReal);
      showToast("تم إيقاف وحذف محاكي المليار عميل التجريبي بنجاح، وسجلاتك الحقيقية سليمة ومحفوظة.", "success");
      return;
    }

    const demoDebtorsToRemove = allDebtors.filter(isDemoDebtor);
    const remainingReal = allDebtors.filter((d) => !isDemoDebtor(d));
    const demoCount = demoDebtorsToRemove.length;

    if (demoCount === 0) {
      showToast(t('toast.noDemoDebtors', "لا يوجد أي مدينين تجريبيين في القائمة حالياً"), "info");
      return;
    }

    setAllDebtors(remainingReal);
    setLocalDebtors(currentUser.id, remainingReal);

    try {
      await saveIdbDebtors(currentUser.id, remainingReal);
      for (const d of demoDebtorsToRemove) {
        await deleteIdbDebtor(d.id).catch(() => {});
      }
    } catch (err) {
      console.warn("IndexedDB clear demo error:", err);
    }

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const datesMap = getLocalDebtorDates(currentUser.id);
    demoDebtorsToRemove.forEach((d) => {
      delete historyMap[d.id];
      delete datesMap[d.id];
    });
    setLocalDebtorHistory(currentUser.id, historyMap);
    setLocalDebtorDates(currentUser.id, datesMap);

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "DELETE FROM debtors WHERE user_id = ? AND (phone LIKE '%*%' OR phone LIKE '%X%' OR phone = '077********' OR id < 0);",
        [currentUser.id]
      );
    } catch (err: any) {
      console.warn("Turso cloud demo cleanup notice:", err);
    } finally {
      setIsSavingCloud(false);
    }

    const remainingDebtsTotal = remainingReal.reduce(
      (s, d) => s + (Number(d.amount) || 0),
      0
    );
    setStats((prev) => {
      const nextAdded = Math.max(remainingDebtsTotal + prev.totalPaid, 0);
      const next = { ...prev, totalAdded: nextAdded };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });

    showToast(
      `${t('toast.demoCleared', 'تم حذف كافة البيانات التجريبية بنجاح')} (${formatNumber(demoCount, numberFormat)})`,
      "success"
    );
  };

  // Demo Installments
  const handleAddDemoInstallments = () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const realInstallments = installments.filter((i) => !isDemoInstallment(i));
    const demoList = generate20DemoInstallments(currentUser.id);

    const combined = [...demoList, ...realInstallments];
    setInstallments(combined);
    setLocalInstallments(currentUser.id, combined);
    saveIdbInstallments(currentUser.id, combined);

    showToast(
      "تمت إضافة 20 قسط تجريبي بنجاح للاختبار بمتبقي إجمالي 17,000,000 د.ع (محلية دون التأثير على السحابة)",
      "success"
    );
  };

  const handleClearDemoInstallments = async () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const demoInstallmentsToRemove = installments.filter(isDemoInstallment);
    const remainingReal = installments.filter((i) => !isDemoInstallment(i));
    const demoCount = demoInstallmentsToRemove.length;

    if (demoCount === 0) {
      showToast("لا توجد أقساط تجريبية في القائمة حالياً", "info");
      return;
    }

    setInstallments(remainingReal);
    setLocalInstallments(currentUser.id, remainingReal);

    try {
      await saveIdbInstallments(currentUser.id, remainingReal);
      for (const inst of demoInstallmentsToRemove) {
        await deleteIdbInstallment(inst.id).catch(() => {});
      }
    } catch (err) {
      console.warn("IndexedDB clear demo installments error:", err);
    }

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "DELETE FROM installments WHERE user_id = ? AND (phone LIKE '%*%' OR phone LIKE '%X%' OR phone = '077********' OR id < 0);",
        [currentUser.id]
      );
    } catch (err: any) {
      console.warn("Turso cloud demo installments cleanup notice:", err);
    } finally {
      setIsSavingCloud(false);
    }

    showToast(
      `تم حذف كافة الأقساط التجريبية بنجاح (${formatNumber(demoCount, numberFormat)})`,
      "success"
    );
  };

  // Managers Management (Admin Only)
  const handleCreateManager = async (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType = 'permanent',
    subscriptionMonths: number = 1,
    allowedModules: ManagerModuleAccess = 'both',
    databaseId?: string | null,
    layoutTheme: AppLayoutTheme = 'classic'
  ) => {
    try {
      setIsSavingCloud(true);
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(pass, salt);

      let expiresAt: string | null = null;
      if (subscriptionType === 'monthly') {
        const exp = new Date();
        exp.setMonth(exp.getMonth() + (subscriptionMonths || 1));
        expiresAt = exp.toISOString().split('T')[0];
      }

      let res;
      try {
        res = await queryTurso(
          "INSERT INTO users (username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at, allowed_modules, database_id, layout_theme) VALUES (?, ?, ?, 'manager', ?, 1, ?, ?, ?, ?, ?) RETURNING id;",
          [user, hashedPassword, pass, branch, subscriptionType, expiresAt, allowedModules, databaseId || null, layoutTheme]
        );
      } catch {
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN database_id TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN layout_theme TEXT DEFAULT 'classic';").catch(() => {});
        res = await queryTurso(
          "INSERT INTO users (username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at, allowed_modules, database_id, layout_theme) VALUES (?, ?, ?, 'manager', ?, 1, ?, ?, ?, ?, ?) RETURNING id;",
          [user, hashedPassword, pass, branch, subscriptionType, expiresAt, allowedModules, databaseId || null, layoutTheme]
        );
      }

      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        const newManagerId = parseInt(res.results[0].response.result.rows[0][0].value);
        if (!isNaN(newManagerId)) {
          const initSettings = { ...DEFAULT_SETTINGS, layoutTheme };
          setLocalStats(newManagerId, { totalAdded: 0, totalPaid: 0 });
          saveIdbStats(newManagerId, { totalAdded: 0, totalPaid: 0 });
          setLocalDebtors(newManagerId, []);
          saveIdbDebtors(newManagerId, []);
          setLocalSettings(newManagerId, initSettings);
          saveIdbSettings(newManagerId, initSettings);

          localStorage.setItem(`user_pwd_${newManagerId}`, pass);
          localStorage.setItem(`user_pwd_${user}`, pass);

          const newManager: Manager = {
            id: newManagerId,
            username: user,
            branch,
            isActive: true,
            subscriptionType,
            subscriptionExpiresAt: expiresAt,
            plainPassword: pass,
            allowedModules,
            databaseId: databaseId || null,
            layoutTheme,
          };

          const updated = [...managers, newManager];
          setManagers(updated);
          setLocalManagers(updated);
          await saveIdbManagers(updated);

          const accessLabel =
            allowedModules === 'debts'
              ? ` (${t('managers.moduleDebtsShort', 'فقط دفتر الديون')})`
              : allowedModules === 'installments'
              ? ` (${t('managers.moduleInstallmentsShort', 'فقط نظام الأقساط')})`
              : ` (${t('managers.moduleBothShort', 'ديون + أقساط')})`;
          showToast(t('toast.managerCreated', 'تم إنشاء حساب المدير "{name}" بنجاح!').replace('{name}', user) + accessLabel, "success");
        }
      }
    } catch (err: any) {
      const errMsg = err?.message || '';
      let friendlyMsg = errMsg;
      if (errMsg.includes('UNIQUE constraint failed: users.username') || errMsg.includes('users.username')) {
        friendlyMsg = `اسم المستخدم "${user}" مسجل وموجود مسبقاً بالنظام، يرجى اختيار اسم مستخدم مختلف.`;
      } else if (!friendlyMsg) {
        friendlyMsg = t('managers.requiredFields', 'حدث خطأ أثناء إنشاء الحساب');
      }
      showToast(friendlyMsg, "error");
      throw new Error(friendlyMsg);
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleChangeManagerTheme = async (
    id: number,
    newTheme: AppLayoutTheme
  ) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    const updated = managers.map((m) =>
      m.id === id ? { ...m, layoutTheme: newTheme } : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    if (currentUser && currentUser.id === id) {
      const updatedUser = { ...currentUser, layoutTheme: newTheme };
      setCurrentUser(updatedUser);
      setLocalSession(updatedUser);
      setSettings((prev) => ({ ...prev, layoutTheme: newTheme }));
    }

    const themeMeta = getLayoutThemeMeta(newTheme);
    showToast(`تم تغيير مظهر وتصميم واجهة المدير "${target.username}" إلى (${themeMeta.title}) بنجاح`, "success");

    try {
      setIsSavingCloud(true);
      await queryMainTurso(
        "UPDATE users SET layout_theme = ? WHERE id = ?;",
        [newTheme, id]
      );
    } catch {
      try {
        await queryMainTurso("ALTER TABLE users ADD COLUMN layout_theme TEXT DEFAULT 'classic';").catch(() => {});
        await queryMainTurso(
          "UPDATE users SET layout_theme = ? WHERE id = ?;",
          [newTheme, id]
        );
      } catch (err: any) {
        showToast("فشل تحديث المظهر في السحابة: " + (err?.message || "خطأ اتصال"), "error");
      }
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleChangeManagerDatabase = async (id: number, databaseId: string | null) => {
    // 1. Validate connection if a databaseId is provided
    if (databaseId) {
      const dbAcc = databases.find((d) => d.id === databaseId);
      if (dbAcc) {
        try {
          const testRes = await testDatabaseConnection(dbAcc.url, dbAcc.token);
          if (!testRes.ok) {
            showToast(`تنبيه: فشل فحص الاتصال بالقاعدة المحددة (${testRes.message})`, "error");
          } else {
            showToast(`تم التحقق من الاتصال بالقاعدة بنجاح (${testRes.latencyMs}ms)`, "success");
          }
        } catch (e: any) {
          showToast("تعذر فحص اتصال قاعدة البيانات: " + (e?.message || "خطأ غير معروف"), "error");
        }
      }
    }

    const updated = managers.map((m) =>
      m.id === id ? { ...m, databaseId } : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    if (currentUser && currentUser.id === id) {
      const updatedUser = { ...currentUser, databaseId };
      setCurrentUser(updatedUser);
      setLocalSession(updatedUser);
    }

    showToast("تم تحديث ربط قاعدة البيانات للمدير بنجاح", "success");

    try {
      setIsSavingCloud(true);
      await queryMainTurso(
        "UPDATE users SET database_id = ? WHERE id = ?;",
        [databaseId ? String(databaseId) : null, Number(id)]
      );
    } catch {
      try {
        await queryMainTurso("ALTER TABLE users ADD COLUMN database_id TEXT;").catch(() => {});
        await queryMainTurso(
          "UPDATE users SET database_id = ? WHERE id = ?;",
          [databaseId ? String(databaseId) : null, Number(id)]
        );
      } catch (err: any) {
        showToast("فشل تحديث قاعدة البيانات في السحابة: " + (err?.message || "خطأ في الاتصال"), "error");
      }
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleChangeManagerModules = async (
    id: number,
    newAllowedModules: ManagerModuleAccess
  ) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    const updated = managers.map((m) =>
      m.id === id ? { ...m, allowedModules: newAllowedModules } : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    if (currentUser && currentUser.id === id) {
      const updatedUser = { ...currentUser, allowedModules: newAllowedModules };
      setCurrentUser(updatedUser);
      setLocalSession(updatedUser);
      if (newAllowedModules === 'debts') setHeaderMode('debts');
      if (newAllowedModules === 'installments') setHeaderMode('installments');
    }

    const label =
      newAllowedModules === 'debts'
        ? t('managers.moduleDebtsShort', 'فقط دفتر الديون')
        : newAllowedModules === 'installments'
        ? t('managers.moduleInstallmentsShort', 'فقط نظام الأقساط')
        : t('managers.moduleBothShort', 'ديون + أقساط');

    showToast(t('toast.managerUpdated', 'تم تعديل بيانات المدير بنجاح') + `: ${label}`, "success");

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET allowed_modules = ? WHERE id = ?;",
        [newAllowedModules, id]
      );
    } catch (err: any) {
      await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
      await queryTurso(
        "UPDATE users SET allowed_modules = ? WHERE id = ?;",
        [newAllowedModules, id]
      ).catch(() => {});
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleChangeSubscriptionType = async (
    id: number,
    newType: SubscriptionType,
    months: number = 1
  ) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    let expiresAt: string | null = null;
    if (newType === 'monthly') {
      const exp = new Date();
      exp.setMonth(exp.getMonth() + (months || 1));
      expiresAt = exp.toISOString().split('T')[0];
    }

    const updated = managers.map((m) =>
      m.id === id
        ? {
            ...m,
            subscriptionType: newType,
            subscriptionExpiresAt: expiresAt,
            isActive: true,
          }
        : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    broadcastManagerStatusChange(id, true);

    showToast(
      newType === 'permanent'
        ? t('managers.subPermanentDesc', 'تم تفعيل الاشتراك الدائم')
        : `${t('managers.expiresOn', 'ينتهي في')} ${expiresAt}`,
      'success'
    );

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET subscription_type = ?, subscription_expires_at = ?, is_active = 1 WHERE id = ?;",
        [newType, expiresAt, id]
      );
    } catch (err: any) {
      console.warn("تنبيه تحديث نوع الاشتراك في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleUpdateManagerPassword = async (managerId: number, newPass: string) => {
    try {
      setIsSavingCloud(true);
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(newPass, salt);

      await queryTurso(
        "UPDATE users SET password = ?, plain_password = ? WHERE id = ?;",
        [hashedPassword, newPass, managerId]
      );

      localStorage.setItem(`user_pwd_${managerId}`, newPass);
      const mgr = managers.find((m) => m.id === managerId);
      if (mgr) {
        localStorage.setItem(`user_pwd_${mgr.username}`, newPass);
      }

      const updated = managers.map((m) =>
        m.id === managerId ? { ...m, plainPassword: newPass } : m
      );
      setManagers(updated);
      setLocalManagers(updated);
      await saveIdbManagers(updated);

      showToast(t('toast.managerPasswordUpdated', 'تم تحديث وحفظ كلمة مرور المدير الفرعي بنجاح!'), "success");
    } catch (err: any) {
      showToast(err.message || t('toast.backupError', 'خطأ في العملية'), "error");
      throw err;
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleToggleManagerStatus = async (id: number, currentActive: boolean) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;
    const newActive = !currentActive;

    const updated = managers.map((m) => (m.id === id ? { ...m, isActive: newActive } : m));
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    if (!newActive) {
      broadcastManagerStatusChange(
        id,
        false,
        t('toast.accountSuspendedByAdmin', 'تم إيقاف هذا الحساب من قبل الإدارة العامة.')
      );
      if (currentUser && currentUser.id === id) {
        handleForceLogout(t('toast.accountSuspendedByAdmin', 'تم إيقاف هذا الحساب من قبل الإدارة العامة.'));
        return;
      }
    } else {
      broadcastManagerStatusChange(id, true);
    }

    showToast(
      newActive
        ? t('toast.managerActivated', 'تم تنشيط حساب المدير فوراً')
        : t('toast.managerDeactivated', 'تم إيقاف حساب المدير فوراً'),
      newActive ? 'success' : 'info'
    );

    try {
      setIsSavingCloud(true);
      await queryTurso("UPDATE users SET is_active = ? WHERE id = ?;", [newActive ? 1 : 0, id]);
    } catch (err: any) {
      console.warn("تنبيه تحديث حالة المدير في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleRenewSubscription = async (id: number, months: number = 1) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    let baseDate = new Date();
    if (target.subscriptionExpiresAt) {
      const existingExp = new Date(target.subscriptionExpiresAt);
      if (existingExp.getTime() > Date.now()) {
        baseDate = existingExp;
      }
    }
    baseDate.setMonth(baseDate.getMonth() + months);
    const newExpiresAt = baseDate.toISOString().split('T')[0];

    const updated = managers.map((m) =>
      m.id === id
        ? {
            ...m,
            subscriptionExpiresAt: newExpiresAt,
            isActive: true,
          }
        : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    broadcastManagerStatusChange(id, true);

    showToast(
      t('toast.subscriptionRenewed', 'تم تجديد الاشتراك وتنشيط الحساب بنجاح'),
      'success'
    );

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET subscription_expires_at = ?, is_active = 1 WHERE id = ?;",
        [newExpiresAt, id]
      );
    } catch (err: any) {
      console.warn("تنبيه تجديد الاشتراك في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleDeleteManager = async (id: number) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    setConfirmState({
      isOpen: true,
      title: t('managers.confirmDeleteTitle', 'تأكيد حذف المدير الفرعي'),
      message: t('managers.confirmDeleteMessage', 'هل أنت متأكد من حذف حساب المدير "{name}" نهائياً من النظام؟').replace('{name}', target.username),
      onConfirm: async () => {
        try {
          setIsSavingCloud(true);
          const updated = managers.filter((m) => m.id !== id);
          setManagers(updated);
          setLocalManagers(updated);
          saveIdbManagers(updated);

          broadcastManagerStatusChange(id, false, t('toast.accountSuspendedByAdmin', 'تم حذف هذا الحساب من قبل الإدارة العامة.'));
          if (currentUser && currentUser.id === id) {
            handleForceLogout(t('toast.accountSuspendedByAdmin', 'تم حذف هذا الحساب من قبل الإدارة العامة.'));
          }

          setConfirmState((prev) => ({ ...prev, isOpen: false }));
          showToast(t('toast.managerDeleted', 'تم حذف المدير بنجاح'), "info");

          await queryTurso("DELETE FROM users WHERE id = ?;", [id]);
        } catch (err: any) {
          showToast(err.message || t('toast.backupError', 'حدث خطأ أثناء الحذف'), "error");
        } finally {
          setIsSavingCloud(false);
        }
      },
    });
  };

  const handleUpgradeNewRegistration = async (
    id: number,
    subscriptionType: SubscriptionType,
    months: number = 1,
    allowedModules: ManagerModuleAccess = 'both',
    databaseId: string | null = null,
    layoutTheme: AppLayoutTheme = 'classic'
  ) => {
    let expiresAt: string | null = null;
    if (subscriptionType === 'monthly') {
      const exp = new Date();
      exp.setMonth(exp.getMonth() + (months || 1));
      expiresAt = exp.toISOString().split('T')[0];
    }

    const updated = managers.map((m) =>
      m.id === id
        ? {
            ...m,
            role: 'manager' as const,
            subscriptionType,
            subscriptionExpiresAt: expiresAt,
            allowedModules,
            databaseId,
            layoutTheme,
            isNewRegistration: false,
            isActive: true,
          }
        : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    showToast(t('managers.upgradeSuccess', 'تمت ترقية وتفعيل الحساب ونقله إلى قائمة المدراء بنجاح!'), 'success');

    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET role = 'manager', subscription_type = ?, subscription_expires_at = ?, allowed_modules = ?, database_id = ?, layout_theme = ?, is_new_registration = 0, is_active = 1 WHERE id = ?;",
        [subscriptionType, expiresAt, allowedModules, databaseId, layoutTheme, id]
      );
    } catch {
      await queryTurso("ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;").catch(() => {});
      await queryTurso("ALTER TABLE users ADD COLUMN layout_theme TEXT DEFAULT 'classic';").catch(() => {});
      await queryTurso(
        "UPDATE users SET role = 'manager', subscription_type = ?, subscription_expires_at = ?, allowed_modules = ?, database_id = ?, layout_theme = ?, is_new_registration = 0, is_active = 1 WHERE id = ?;",
        [subscriptionType, expiresAt, allowedModules, databaseId, layoutTheme, id]
      ).catch(() => {});
    } finally {
      setIsSavingCloud(false);
      await loadManagersFromCloud(true);
    }
  };

  // Calculations: Single-pass ultra-fast calculation for instant performance even with 1,000,000,000 debtors
  const {
    totalAmount,
    debtorsOnlyCount,
    paidOnlyCount,
    highDebtorsCount,
    demoDebtorsCount,
    alertTriggeredCount,
    overdueCount,
  } = useMemo(() => {
    if (isBillionDemoActive || isBillionDebtorsProxy(allDebtors)) {
      return {
        totalAmount: 13_000_000_000_000,
        debtorsOnlyCount: 940_000_000,
        paidOnlyCount: 60_000_000,
        highDebtorsCount: 160_000_000,
        demoDebtorsCount: 1_000_000_000,
        alertTriggeredCount: 40_000_000,
        overdueCount: 40_000_000,
      };
    }

    let total = 0;
    let debtorsOnly = 0;
    let paidOnly = 0;
    let highDebtors = 0;
    let demoCount = 0;
    let alertCount = 0;
    let overdue = 0;

    const highThreshold = Number(settings.highDebtThreshold) || 25000;
    const isAlertsOn = Boolean(settings.enableDebtAlerts);
    const alertDays = Number(settings.alertDaysThreshold) || 30;
    const nowMs = Date.now();
    const alertMsThreshold = alertDays * 24 * 60 * 60 * 1000;
    const len = allDebtors.length;

    for (let i = 0; i < len; i++) {
      const d = allDebtors[i];
      if (!d) continue;
      const amt = Number(d.amount) || 0;
      total += amt;
      if (amt > 0) {
        debtorsOnly++;
        if (amt >= highThreshold) highDebtors++;
      } else {
        paidOnly++;
      }
      if (d.isDemo || (typeof d.id === 'number' && d.id < 0)) {
        demoCount++;
      }
      if (amt > 0 && d.status !== 'خالي من الدين') {
        if (d.status === 'متأخر') {
          overdue++;
        } else if (isAlertsOn && d.createdAt) {
          const createdMs = new Date(d.createdAt).getTime();
          if (nowMs - createdMs >= alertMsThreshold) {
            overdue++;
            alertCount++;
          }
        }
      }
    }

    return {
      totalAmount: total,
      debtorsOnlyCount: debtorsOnly,
      paidOnlyCount: paidOnly,
      highDebtorsCount: highDebtors,
      demoDebtorsCount: demoCount,
      alertTriggeredCount: alertCount,
      overdueCount: overdue,
    };
  }, [allDebtors, settings.highDebtThreshold, settings.enableDebtAlerts, settings.alertDaysThreshold, isBillionDemoActive]);

  // Demo installments count
  const demoInstallmentsCount = useMemo(() => {
    return installments.filter(isDemoInstallment).length;
  }, [installments]);

  // Due installments count for badge in BottomNav
  const dueInstallmentsCount = useMemo(() => {
    return installments.filter((i) => i.status === 'due' || i.status === 'overdue').length;
  }, [installments]);

  const totalInstallmentsRemaining = useMemo(() => {
    return installments.reduce((sum, i) => sum + (Number(i.remainingAmount) || 0), 0);
  }, [installments]);

  const deferredSearchTerm = useDeferredValue(searchTerm);
  const [visibleDebtorsLimit, setVisibleDebtorsLimit] = useState(50);

  useEffect(() => {
    setVisibleDebtorsLimit(50);
  }, [deferredSearchTerm, filter, headerMode]);

  // Fast filtered debtors with O(1) empty-query bypass and fast comparator
  const filteredDebtors = useMemo(() => {
    const highThreshold = Number(settings.highDebtThreshold) || 25000;

    if (isBillionDemoActive || isBillionDebtorsProxy(allDebtors)) {
      const query = deferredSearchTerm.toLowerCase().trim();
      const isFilterAll = filter === 'all';
      if (!query && isFilterAll) {
        return allDebtors;
      }

      // Check if user is searching for a number/ID e.g. "500000000", "#500,000,000", "5000"
      const cleanNum = query.replace(/[#,\s]/g, '');
      const parsedNum = parseInt(cleanNum, 10);
      if (!isNaN(parsedNum) && parsedNum > 0 && parsedNum <= 1_000_000_000) {
        const start = Math.max(0, parsedNum - 1);
        return (allDebtors as any).slice(start, start + 100);
      }

      // Sample first 1000 items and filter
      const sample = (allDebtors as any).slice(0, 1000);
      return sample.filter((d: Debtor) => {
        const amt = Number(d.amount) || 0;
        if (filter === 'debtors_only' && amt <= 0) return false;
        if (filter === 'paid_only' && amt > 0) return false;
        if (filter === 'high_debt' && (amt < highThreshold || amt <= 0)) return false;
        if (query) {
          const name = (d.name || '').toLowerCase();
          const phone = d.phone ? String(d.phone) : '';
          return name.includes(query) || phone.includes(query);
        }
        return true;
      });
    }

    const query = deferredSearchTerm.toLowerCase().trim();
    const isFilterAll = filter === 'all';

    const results: Debtor[] = [];
    const len = allDebtors.length;
    // Cap results during search for instantaneous responsiveness on massive lists
    const maxResults = 10000;

    for (let i = 0; i < len; i++) {
      const d = allDebtors[i];
      if (!d) continue;

      const amt = Number(d.amount) || 0;

      // Filter check
      if (filter === 'debtors_only' && amt <= 0) continue;
      if (filter === 'paid_only' && amt > 0) continue;
      if (filter === 'high_debt' && (amt < highThreshold || amt <= 0)) continue;

      // Query check
      if (query) {
        const name = (d.name || '').toLowerCase();
        const phone = d.phone ? String(d.phone) : '';
        if (!name.includes(query) && !phone.includes(query)) {
          continue;
        }
      }

      results.push(d);
      if (results.length >= maxResults) break;
    }

    // Always sort by amount descending (من الأعلى إلى الأدنى)
    results.sort((a, b) => {
      const diff = (Number(b?.amount) || 0) - (Number(a?.amount) || 0);
      if (diff !== 0) return diff;
      const nameA = a?.name || '';
      const nameB = b?.name || '';
      return nameA < nameB ? -1 : nameA > nameB ? 1 : 0;
    });

    return results;
  }, [allDebtors, deferredSearchTerm, filter, settings.highDebtThreshold, isBillionDemoActive]);

  const displayedDebtors = useMemo(() => {
    return filteredDebtors.slice(0, visibleDebtorsLimit);
  }, [filteredDebtors, visibleDebtorsLimit]);

  if (customerPortalTarget) {
    return (
      <div className="min-h-screen w-full bg-slate-950 text-slate-100 font-sans" dir={dir}>
        <CustomerPortalView
          type={customerPortalTarget.type}
          id={customerPortalTarget.id}
          onGoToLogin={() => {
            const url = new URL(window.location.href);
            url.searchParams.delete('portal');
            url.searchParams.delete('qr');
            url.searchParams.delete('id');
            window.history.replaceState({}, '', url.toString());
            setCustomerPortalTarget(null);
          }}
        />
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen w-full bg-[#080f24] text-slate-100 antialiased font-sans" dir={dir}>
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
        <LoginOverlay
          onLoginSuccess={handleLoginSuccess}
          initialErrorMessage={loginErrorMessage}
        />
      </div>
    );
  }

  return (
    <div
      className="h-[100dvh] w-full max-w-full md:max-w-none flex flex-col md:flex-row bg-slate-100 text-slate-800 relative shadow-2xl overflow-hidden select-none"
      dir={dir}
    >
      {/* Toast Messages */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Desktop Sidebar Navigation */}
      <SidebarNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenAddModal={handleOpenAddModal}
        currentUser={currentUser}
        overdueCount={overdueCount}
        dueInstallmentsCount={dueInstallmentsCount}
        mode={headerMode}
        onLogout={handleLogout}
        layoutTheme={settings.layoutTheme || 'classic'}
        onToggleTheme={handleToggleLayoutTheme}
      />

      {/* Main App Container */}
      <main className="flex-1 flex flex-col overflow-hidden relative w-full bg-slate-50 min-w-0" id="appContainer">
        {/* 1. HOME TAB (الرئيسية: تعرض دفتر الديون أو نظام الأقساط حسب القائمة المنسدلة العلوية) */}
        <div id="tab-home" className={`flex-1 flex flex-col overflow-hidden ${activeTab === 'home' ? '' : 'hidden'}`}>
          {/* Fixed Top Header & Filters */}
          <div className="shrink-0 z-30 bg-slate-50 shadow-xs border-b border-slate-200/40">
            <HeaderCard
              currentUser={currentUser}
              debtorsCount={allDebtors.length}
              totalAmount={totalAmount}
              installmentsCount={installments.length}
              totalInstallmentsRemaining={totalInstallmentsRemaining}
              headerMode={headerMode}
              mode={headerMode}
              onHeaderModeChange={(newMode) => {
                setHeaderMode(newMode);
              }}
              onModeChange={(newMode) => {
                setHeaderMode(newMode);
              }}
              onLogout={handleLogout}
              isSaving={isSavingCloud}
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              onSecretAdminUnlock={handleSecretAdminUnlock}
              layoutTheme={settings.layoutTheme || 'classic'}
              onToggleTheme={handleToggleLayoutTheme}
            />

            {headerMode === 'debts' && (
              <Controls
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                filter={filter}
                onFilterChange={setFilter}
                totalCount={allDebtors.length}
                debtorsOnlyCount={debtorsOnlyCount}
                paidOnlyCount={paidOnlyCount}
                highDebtCount={highDebtorsCount}
                viewMode={viewMode}
                onViewModeChange={handleViewModeChange}
                displayedCount={filteredDebtors.length}
              />
            )}
          </div>

          {/* Scrollable View Content (Debts or Installments) */}
          {headerMode === 'debts' ? (
            <div
              className="flex-1 overflow-y-auto overscroll-contain px-4 pt-2.5 pb-32 sm:pb-36 focus:outline-none"
              id="debtorsListScrollContainer"
            >
              {isBillionDemoActive && (
                <div className="mb-3 p-3 bg-gradient-to-r from-amber-500/15 via-orange-500/15 to-rose-500/15 border border-amber-300 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-2 shadow-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-xl bg-amber-500 text-white flex items-center justify-center text-xs shrink-0 shadow-xs">
                      <i className="fa-solid fa-bolt text-yellow-200"></i>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                        <span>محاكي المليار عميل الافتراضي نشط (1,000,000,000)</span>
                        <span className="bg-amber-600 text-white text-[10px] px-1.5 py-0.5 rounded-full font-mono">60 FPS</span>
                      </div>
                      <div className="text-[10px] text-amber-800">
                        استهلاك الذاكرة 0 بايت • توليد رياضي فوري في أجزاء من الملي ثانية
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap justify-end w-full sm:w-auto">
                    <span className="text-[10px] font-bold text-slate-500">انتقال سريع:</span>
                    <button
                      type="button"
                      onClick={() => setSearchTerm('1')}
                      className="px-2 py-0.5 rounded-lg bg-white border border-amber-200 text-slate-700 text-[10px] font-mono hover:bg-amber-50 cursor-pointer"
                    >
                      #1
                    </button>
                    <button
                      type="button"
                      onClick={() => setSearchTerm('100000')}
                      className="px-2 py-0.5 rounded-lg bg-white border border-amber-200 text-slate-700 text-[10px] font-mono hover:bg-amber-50 cursor-pointer"
                    >
                      #100K
                    </button>
                    <button
                      type="button"
                      onClick={() => setSearchTerm('500000000')}
                      className="px-2 py-0.5 rounded-lg bg-white border border-amber-200 text-slate-700 text-[10px] font-mono hover:bg-amber-50 cursor-pointer"
                    >
                      #500M
                    </button>
                    <button
                      type="button"
                      onClick={() => setSearchTerm('1000000000')}
                      className="px-2 py-0.5 rounded-lg bg-white border border-amber-200 text-slate-700 text-[10px] font-mono hover:bg-amber-50 cursor-pointer"
                    >
                      #1B
                    </button>
                    <button
                      type="button"
                      onClick={handleClearDemoDebtors}
                      className="px-2 py-0.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-100 cursor-pointer"
                    >
                      إيقاف
                    </button>
                  </div>
                </div>
              )}

              {filteredDebtors.length === 0 ? (
                <div className="text-center py-10 bg-white rounded-2xl border border-dashed border-slate-200 p-6 shadow-xs">
                  <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mx-auto mb-3 text-lg">
                    {filter === 'paid_only' ? (
                      <i className="fa-solid fa-circle-check text-emerald-500"></i>
                    ) : filter === 'high_debt' ? (
                      <i className="fa-solid fa-arrow-trend-up text-red-500"></i>
                    ) : (
                      <i className="fa-solid fa-users-slash"></i>
                    )}
                  </div>
                  <div className="font-bold text-sm text-slate-700 mb-1">
                    {searchTerm
                      ? t('debts.emptySearch', 'لم يتم العثور على نتائج مطابقة للبحث')
                      : filter === 'paid_only'
                      ? t('debts.emptyPaid', 'لا يوجد مدينين خاليين من الدين حالياً')
                      : filter === 'high_debt'
                      ? t('debts.emptyHigh', 'لا يوجد عملاء بذمم تتجاوز سقف الدين المرتفع')
                      : filter === 'debtors_only'
                      ? t('debts.emptyDebtorsOnly', 'لا يوجد مدينين بذمم قائمة حالياً')
                      : t('debts.emptyNoDebtors', 'لا يوجد مدينين مسجلين بعد')}
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    {searchTerm
                      ? t('debts.emptySearchDesc', 'تأكد من كتابة الاسم أو رقم الهاتف بشكل صحيح')
                      : filter === 'paid_only'
                      ? t('debts.emptyPaidDesc', 'عند قيام أحد المدينين بتسديد رصيده كاملاً سيظهر هنا')
                      : filter === 'high_debt'
                      ? `${t('debts.highDebtLimit', 'سقف الدين المرتفع محدد حالياً بـ')} (${formatNumber(settings.highDebtThreshold, numberFormat)} ${getCurrencySymbol()})`
                      : t('debts.emptyNoDebtorsDesc', 'يمكنك إضافة مدين جديد عبر زر (+) في الشريط السفلي')}
                  </p>
                </div>
              ) : (
                <VirtualGrid<Debtor>
                  items={filteredDebtors}
                  itemHeight={115}
                  gap={10}
                  columns={{ default: 1, md: 2, lg: 3 }}
                  overscan={4}
                  keyExtractor={(debtor: Debtor) => debtor.id}
                  renderItem={(debtor: Debtor) => (
                    <DebtorListItem
                      debtor={debtor}
                      settings={settings}
                      onPay={handleOpenPayModal}
                      onAddDebt={handleOpenAddDebtModal}
                      onDelete={handleDeleteDebtor}
                      onShowToast={showToast}
                      onViewHistory={handleOpenHistoryModal}
                      onShare={handleOpenShareModal}
                      onEditName={handleOpenEditNameModal}
                    />
                  )}
                />
              )}
            </div>
          ) : (
            <div className="flex-1 flex flex-col overflow-hidden px-4 pt-2.5" id="installmentsViewContainer">
              <InstallmentsTab
                installments={installments}
                onAddInstallment={handleAddInstallment}
                onUpdateInstallment={handleUpdateInstallment}
                onSettlePayment={handleSettleInstallmentPayment}
                onDeleteInstallment={handleDeleteInstallment}
                userId={currentUser.id}
                isTrialMode={isTrialMode}
                onTrialLimitReached={() => setIsTrialLimitModalOpen(true)}
                numberFormat={settings.numberFormat || 'english'}
              />
            </div>
          )}
        </div>

        {/* 2. INSTALLMENTS TAB FALLBACK (نظام الأقساط مع الهيدر الكامل) */}
        {visitedTabs.has('installments') && (
          <div id="tab-installments" className={`flex-1 flex flex-col overflow-hidden ${activeTab === 'installments' ? '' : 'hidden'}`}>
            <div className="shrink-0 z-30 bg-slate-50 shadow-xs border-b border-slate-200/40">
              <HeaderCard
                currentUser={currentUser}
                debtorsCount={allDebtors.length}
                totalAmount={totalAmount}
                installmentsCount={installments.length}
                totalInstallmentsRemaining={totalInstallmentsRemaining}
                headerMode="installments"
                mode="installments"
                onHeaderModeChange={(newMode) => {
                  setHeaderMode(newMode);
                  if (newMode === 'debts') {
                    setActiveTab('home');
                  }
                }}
                onModeChange={(newMode) => {
                  setHeaderMode(newMode);
                  if (newMode === 'debts') {
                    setActiveTab('home');
                  }
                }}
                onLogout={handleLogout}
                isSaving={isSavingCloud}
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                onSecretAdminUnlock={handleSecretAdminUnlock}
                layoutTheme={settings.layoutTheme || 'classic'}
                onToggleTheme={handleToggleLayoutTheme}
              />
            </div>
            <div className="flex-1 flex flex-col overflow-hidden px-4 pt-2.5" id="installmentsViewContainer">
              <InstallmentsTab
                installments={installments}
                onAddInstallment={handleAddInstallment}
                onUpdateInstallment={handleUpdateInstallment}
                onSettlePayment={handleSettleInstallmentPayment}
                onDeleteInstallment={handleDeleteInstallment}
                userId={currentUser.id}
                isTrialMode={isTrialMode}
                onTrialLimitReached={() => setIsTrialLimitModalOpen(true)}
                numberFormat={settings.numberFormat || 'english'}
              />
            </div>
          </div>
        )}

        {/* 3. REPORTS TAB (التقارير) */}
        {visitedTabs.has('reports') && (
          <div id="tab-reports" className={`flex-1 overflow-y-auto overscroll-contain ${activeTab === 'reports' ? '' : 'hidden'}`}>
            <ReportsTab
              currentUser={currentUser}
              debtors={allDebtors}
              installments={installments}
              stats={stats}
              settings={settings}
              mode={headerMode}
              isActive={activeTab === 'reports'}
              onUpdateStats={handleUpdateStats}
              onResetStats={handleResetStats}
              onShowToast={showToast}
            />
          </div>
        )}

        {/* 4. OVERDUE TAB (المتأخرون) */}
        {visitedTabs.has('overdue') && (
          <div id="tab-overdue" className={`flex-1 overflow-y-auto overscroll-contain ${activeTab === 'overdue' ? '' : 'hidden'}`}>
            <OverdueTab
              currentUser={currentUser}
              debtors={allDebtors}
              installments={installments}
              mode={headerMode}
              isActive={activeTab === 'overdue'}
              onSettleInstallmentPayment={handleSettleInstallmentPayment}
              settings={settings}
              onOpenPayModal={handleOpenPayModal}
              onToggleOverdueStatus={handleToggleOverdueStatus}
              onShowToast={showToast}
              onViewHistory={handleOpenHistoryModal}
              onShare={handleOpenShareModal}
              onDeleteInstallment={handleDeleteInstallment}
            />
          </div>
        )}

        {/* 5. SETTINGS TAB (الإعدادات) */}
        {visitedTabs.has('settings') && (
          <div id="tab-settings" className={`flex-1 overflow-y-auto overscroll-contain ${activeTab === 'settings' ? '' : 'hidden'}`}>
            <SettingsTab
              currentUser={currentUser}
              managers={managers}
              databases={databases}
              stats={stats}
              currentDebts={totalAmount}
              onUpdateStats={handleUpdateStats}
              onCreateManager={handleCreateManager}
              onToggleManagerStatus={handleToggleManagerStatus}
              onRenewSubscription={handleRenewSubscription}
              onChangeSubscriptionType={handleChangeSubscriptionType}
              onChangeManagerModules={handleChangeManagerModules}
              onChangeManagerDatabase={handleChangeManagerDatabase}
              onChangeManagerTheme={handleChangeManagerTheme}
              onDeleteManager={handleDeleteManager}
              onRefreshDatabases={handleRefreshDatabasesAndManagers}
              onLogout={handleLogout}
              isManagersLoading={isManagersLoading}
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              totalDebtorsCount={allDebtors.length}
              highDebtorsCount={highDebtorsCount}
              alertTriggeredCount={alertTriggeredCount}
              allDebtors={allDebtors}
              installments={installments}
              onImportBackup={handleImportBackup}
              onShowToast={showToast}
              onAddDemoDebtors={handleAddDemoDebtors}
              onAddMillionDemoDebtors={handleAddMillionDemoDebtors}
              onAddBillionDemoDebtors={handleAddBillionDemoDebtors}
              isBillionDemoActive={isBillionDemoActive}
              onClearDemoDebtors={handleClearDemoDebtors}
              demoDebtorsCount={demoDebtorsCount}
              onAddDemoInstallments={handleAddDemoInstallments}
              onClearDemoInstallments={handleClearDemoInstallments}
              demoInstallmentsCount={demoInstallmentsCount}
              onUpdateManagerPassword={handleUpdateManagerPassword}
              onUpgradeNewRegistration={handleUpgradeNewRegistration}
              onRefreshManagers={loadManagersFromCloud}
              onFullMigrationSuccess={async () => {
                await loadManagersFromCloud(false);
                await loadDatabasesFromCloud();
                if (currentUser) {
                  await syncCloudDataIfChanged(currentUser.id, false, true);
                  await fetchAndCacheInstallments(currentUser.id, true);
                }
              }}
            />
          </div>
        )}

        {/* 6. MANAGERS TAB (لوحة تحكم المدراء للمسؤول) */}
        {currentUser.role === 'admin' && visitedTabs.has('managers') && (
          <div id="tab-managers" className={`flex-1 overflow-y-auto overscroll-contain p-4 ${activeTab === 'managers' ? '' : 'hidden'}`}>
            <ManagersTab
              managers={managers}
              databases={databases}
              onRefreshDatabases={loadDatabasesFromCloud}
              onShowToast={showToast}
              onCreateManager={handleCreateManager}
              onToggleManagerStatus={handleToggleManagerStatus}
              onRenewSubscription={handleRenewSubscription}
              onChangeSubscriptionType={handleChangeSubscriptionType}
              onChangeManagerModules={handleChangeManagerModules}
              onChangeManagerDatabase={handleChangeManagerDatabase}
              onChangeManagerTheme={handleChangeManagerTheme}
              onDeleteManager={handleDeleteManager}
              onUpdateManagerPassword={handleUpdateManagerPassword}
              onUpgradeNewRegistration={handleUpgradeNewRegistration}
              onRefreshManagers={loadManagersFromCloud}
              isLoading={isManagersLoading}
            />
          </div>
        )}
      </main>

      {/* DEBTOR HISTORY MODAL */}
      <DebtorHistoryModal
        isOpen={historyModalState.isOpen}
        debtor={historyModalState.debtor}
        onClose={() => setHistoryModalState({ isOpen: false, debtor: null })}
        onShowToast={showToast}
      />

      {/* DEBTOR SHARE MODAL */}
      {shareModalState.isOpen && shareModalState.debtor && (
        <DebtorShareModal
          isOpen={shareModalState.isOpen}
          debtor={shareModalState.debtor}
          storeName={getUserBranchDisplayName(currentUser, t) || t('login.title', 'دفتر الديون')}
          onClose={() => setShareModalState({ isOpen: false, debtor: null })}
          onShowToast={showToast}
        />
      )}

      {/* ADD DEBTOR MODAL (Pure Debts Mode) */}
      <AddDebtorModal
        isOpen={isAddDebtorModalOpen}
        onClose={() => setIsAddDebtorModalOpen(false)}
        onSave={handleSaveDebtor}
      />

      {/* ADD INSTALLMENT MODAL (Pure Installments Mode) */}
      <AddInstallmentModal
        isOpen={isAddInstallmentModalOpen}
        onClose={() => setIsAddInstallmentModalOpen(false)}
        onAdd={handleAddInstallment}
        userId={currentUser.id}
      />

      {/* TRANSACTION MODAL (Pay / Add Debt) */}
      <TransactionModal
        isOpen={transactionState.isOpen}
        type={transactionState.type}
        debtor={transactionState.debtor}
        onClose={() =>
          setTransactionState({ isOpen: false, type: 'pay', debtor: null })
        }
        onConfirm={
          transactionState.type === 'pay'
            ? handleConfirmPay
            : handleConfirmAddDebt
        }
      />

      {/* CONFIRM MODAL */}
      <ConfirmModal
        isOpen={confirmState.isOpen}
        title={confirmState.title}
        message={confirmState.message}
        onConfirm={confirmState.onConfirm}
        onCancel={() => setConfirmState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* SETTLE COMPLETE MODAL */}
      <SettleCompleteModal
        isOpen={settleCompleteState.isOpen}
        debtor={settleCompleteState.debtor}
        onKeep={handleKeepSettledDebtor}
        onDelete={handleDeleteSettledDebtor}
      />

      {/* EDIT DEBTOR NAME MODAL */}
      <EditDebtorNameModal
        isOpen={isEditNameModalOpen}
        debtor={editingNameDebtor}
        onClose={() => {
          setIsEditNameModalOpen(false);
          setEditingNameDebtor(null);
        }}
        onSave={handleSaveDebtorName}
      />

      {/* TRIAL LIMIT MODAL */}
      <TrialLimitModal
        isOpen={isTrialLimitModalOpen}
        onClose={() => setIsTrialLimitModalOpen(false)}
        debtorsCount={allDebtors.length}
        mode={headerMode === 'installments' || activeTab === 'installments' ? 'installments' : 'debts'}
      />

      {/* SECRET ADMIN MODAL */}
      <SecretAdminModal
        isOpen={isSecretAdminModalOpen}
        onClose={() => setIsSecretAdminModalOpen(false)}
        currentUser={currentUser}
        onOpenManagersModal={() => setActiveTab('managers')}
        onOpenSettingsTab={() => setActiveTab('settings')}
        onShowToast={showToast}
      />

      {/* WHATSAPP CONFIRMATION MODAL */}
      <WhatsAppConfirmModal
        notice={whatsappNoticeToConfirm}
        onConfirm={handleConfirmWhatsAppSend}
        onCancel={handleCancelWhatsAppSend}
      />

      {/* BOTTOM NAVIGATION */}
      <BottomNav
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onOpenAddModal={handleOpenAddModal}
        isAdmin={currentUser.role === 'admin'}
        overdueCount={overdueCount}
        dueInstallmentsCount={dueInstallmentsCount}
        mode={headerMode}
        layoutTheme={settings.layoutTheme || 'classic'}
      />
    </div>
  );
}
