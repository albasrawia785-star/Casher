import React from 'react';
import { AppLayoutTheme, TabType, User } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';
import { getUserRoleDisplayName } from '../utils/userUtils';

interface SidebarNavProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenAddModal?: () => void;
  currentUser: User;
  overdueCount?: number;
  dueInstallmentsCount?: number;
  mode?: 'debts' | 'installments';
  onLogout: () => void;
  layoutTheme?: AppLayoutTheme;
  onToggleTheme?: () => void;
}

export const SidebarNav: React.FC<SidebarNavProps> = React.memo(({
  activeTab,
  onSelectTab,
  onOpenAddModal,
  currentUser,
  overdueCount = 0,
  dueInstallmentsCount = 0,
  mode = 'debts',
  onLogout,
  layoutTheme = 'fintech',
  onToggleTheme,
}) => {
  const { t, numberFormat } = useI18n();
  const isInstallments = mode === 'installments';
  const activeOverdueBadgeCount = isInstallments ? dueInstallmentsCount : overdueCount;

  const navItems: {
    id: TabType;
    label: string;
    icon: string;
    badge?: number;
  }[] = [
    {
      id: 'home',
      label: isInstallments ? t('nav.installments', 'الأقساط') : t('nav.home', 'دفتر الديون'),
      icon: isInstallments ? 'fa-solid fa-file-invoice-dollar' : 'fa-solid fa-house-chimney',
    },
    {
      id: 'overdue',
      label: t('nav.overdue', 'المتأخرون'),
      icon: 'fa-solid fa-hourglass-half',
      badge: activeOverdueBadgeCount,
    },
    {
      id: 'reports',
      label: t('nav.reports', 'التقارير والإحصائيات'),
      icon: 'fa-solid fa-chart-simple',
    },
    ...(currentUser.role === 'admin'
      ? [
          {
            id: 'managers' as TabType,
            label: t('nav.managers', 'إدارة المدراء والفروع'),
            icon: 'fa-solid fa-users-gear',
          },
        ]
      : []),
    {
      id: 'settings',
      label: t('nav.settings', 'الإعدادات والنسخ الاحتياطي'),
      icon: 'fa-solid fa-gear',
    },
  ];

  return (
    <aside
      aria-label={t('nav.mainNav', 'التنقل الجانبي')}
      className="hidden md:flex flex-col w-64 lg:w-72 bg-slate-900 border-r border-slate-800 text-white shrink-0 select-none z-30 shadow-xl"
    >
      {/* Brand & Logo Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between gap-3 bg-slate-950/50">
        <div className="flex items-center gap-3 min-w-0">
          <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-lg font-black shadow-inner shrink-0 ${
            isInstallments
              ? 'bg-gradient-to-tr from-emerald-600 to-teal-500 text-white ring-2 ring-emerald-400/30'
              : 'bg-gradient-to-tr from-blue-600 to-indigo-500 text-white ring-2 ring-blue-400/30'
          }`}>
            <i className={`fa-solid ${isInstallments ? 'fa-calculator' : 'fa-book-bookmark'}`}></i>
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="font-black text-sm text-white tracking-tight truncate">
              {isInstallments ? t('app.installmentsTitle', 'نظام الأقساط الذكي') : t('app.title', 'دفتر الديون السحابي')}
            </h2>
            <p className="text-[11px] text-slate-400 font-medium truncate mt-0.5">
              {currentUser.branchName || getUserRoleDisplayName(currentUser, t)}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Add Action Button */}
      {onOpenAddModal && (
        <div className="p-4 pb-2">
          <button
            type="button"
            onClick={onOpenAddModal}
            className={`w-full py-2.5 px-4 rounded-xl text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer active:scale-98 ${
              isInstallments
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-emerald-900/30'
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-blue-900/30'
            }`}
          >
            <i className="fa-solid fa-plus text-sm"></i>
            <span>{isInstallments ? t('installments.addInstallment', 'إضافة قسط جديد') : t('debtors.addDebtor', 'إضافة مدين جديد')}</span>
          </button>
        </div>
      )}

      {/* Navigation Links */}
      <nav className="flex-1 p-3 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-bold transition-all cursor-pointer ${
                isActive
                  ? isInstallments
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <i className={`${item.icon} text-base w-5 text-center ${isActive ? (isInstallments ? 'text-emerald-400' : 'text-blue-400') : 'text-slate-500'}`}></i>
                <span className="truncate">{item.label}</span>
              </div>

              {typeof item.badge === 'number' && item.badge > 0 && (
                <span className="bg-rose-600 text-white text-[11px] font-black px-2 py-0.5 rounded-full font-mono shadow-xs">
                  {formatNumber(item.badge, numberFormat)}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User Info & Logout Footer */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <button
          type="button"
          onClick={onLogout}
          className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors text-xs font-bold cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-arrow-right-from-bracket"></i>
            <span>{t('auth.logout', 'تسجيل الخروج')}</span>
          </div>
          <span className="text-[10px] text-slate-600 font-mono">v3.5 Desktop</span>
        </button>
      </div>
    </aside>
  );
});

SidebarNav.displayName = 'SidebarNav';
