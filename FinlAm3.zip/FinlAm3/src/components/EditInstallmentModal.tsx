import React, { useState } from 'react';
import { InstallmentRecord } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber, formatAmountInput, parseFormattedNumber, toEnglishDigits } from '../utils/formatters';
import { calculateNextMonthDueDate } from '../utils/installmentHelpers';

interface EditInstallmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  installment: InstallmentRecord;
  onSave: (updatedInstallment: InstallmentRecord) => Promise<void>;
}

export const EditInstallmentModal: React.FC<EditInstallmentModalProps> = ({
  isOpen,
  onClose,
  installment,
  onSave,
}) => {
  const { t, currency } = useI18n();

  if (!isOpen) return null;

  // Form States initialized with current installment values
  const [name, setName] = useState(installment.name || '');
  const [phone, setPhone] = useState(installment.phone || '');
  const [item, setItem] = useState(installment.item || '');
  const [totalAmountStr, setTotalAmountStr] = useState(
    installment.totalAmount ? installment.totalAmount.toLocaleString('en-US') : ''
  );
  const [downPaymentStr, setDownPaymentStr] = useState(
    installment.downPayment !== undefined ? installment.downPayment.toLocaleString('en-US') : '0'
  );
  const [registrationDate, setRegistrationDate] = useState(
    installment.registrationDate || new Date().toISOString().split('T')[0]
  );
  const [nextDueDate, setNextDueDate] = useState(
    installment.nextDueDate || calculateNextMonthDueDate(installment.registrationDate || new Date().toISOString().split('T')[0], 1)
  );
  const [nationalId, setNationalId] = useState(installment.nationalId || '');
  const [address, setAddress] = useState(installment.address || '');
  const [notes, setNotes] = useState(installment.notes || '');

  // Guarantor info
  const [guarantorEnabled, setGuarantorEnabled] = useState(Boolean(installment.guarantorEnabled || installment.guarantorName));
  const [guarantorName, setGuarantorName] = useState(installment.guarantorName || '');
  const [guarantorAddress, setGuarantorAddress] = useState(installment.guarantorAddress || '');
  const [guarantorJob, setGuarantorJob] = useState(installment.guarantorJob || '');
  const [guarantorRelation, setGuarantorRelation] = useState(installment.guarantorRelation || '');
  const [guarantorPhone, setGuarantorPhone] = useState(installment.guarantorPhone || '');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Calculations
  const totalAmount = parseFormattedNumber(totalAmountStr);
  const downPayment = parseFormattedNumber(downPaymentStr);
  
  // Sum of payments already made (excluding downpayment)
  const paymentsSum = (installment.payments || []).reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const totalSettled = downPayment + paymentsSum;
  const remainingAmount = Math.max(0, totalAmount - totalSettled);

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = toEnglishDigits(e.target.value);
    const val = raw.replace(/\D/g, '').slice(0, 11);
    setPhone(val);
  };

  const handleNationalIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = toEnglishDigits(e.target.value);
    const val = raw.replace(/\D/g, '').slice(0, 12);
    setNationalId(val);
  };

  const handleGuarantorPhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = toEnglishDigits(e.target.value);
    const val = raw.replace(/\D/g, '').slice(0, 11);
    setGuarantorPhone(val);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanName = name.trim();
    const cleanItem = item.trim();

    if (!cleanName) {
      setErrorMsg(t('modals.enterInstallmentPayerNameError', 'يرجى إدخال اسم صاحب الأقساط'));
      return;
    }
    if (!cleanItem) {
      setErrorMsg(t('modals.enterItemNameError', 'يرجى كتابة اسم السلعة أو الغرض المباع'));
      return;
    }
    if (totalAmount <= 0) {
      setErrorMsg(t('modals.enterTotalAmountError', 'يرجى إدخال مبلغ الأقساط الإجمالي بشكل صحيح'));
      return;
    }
    if (downPayment < 0) {
      setErrorMsg(t('modals.downPaymentNegativeError', 'الدفعة المقدمة لا يمكن أن تكون سالبة'));
      return;
    }
    if (downPayment > totalAmount) {
      setErrorMsg(t('modals.downPaymentExceedsTotalError', 'الدفعة المقدمة لا يمكن أن تتجاوز مبلغ القسط الإجمالي'));
      return;
    }

    try {
      setIsSubmitting(true);

      const updatedRecord: InstallmentRecord = {
        ...installment,
        name: cleanName,
        phone: phone.trim(),
        item: cleanItem,
        totalAmount,
        downPayment,
        remainingAmount,
        registrationDate,
        nextDueDate,
        nationalId: nationalId.trim() || undefined,
        address: address.trim() || undefined,
        guarantorEnabled,
        guarantorName: guarantorEnabled ? guarantorName.trim() || undefined : undefined,
        guarantorAddress: guarantorEnabled ? guarantorAddress.trim() || undefined : undefined,
        guarantorJob: guarantorEnabled ? guarantorJob.trim() || undefined : undefined,
        guarantorRelation: guarantorEnabled ? guarantorRelation.trim() || undefined : undefined,
        guarantorPhone: guarantorEnabled ? guarantorPhone.trim() || undefined : undefined,
        notes: notes.trim() || undefined,
      };

      await onSave(updatedRecord);
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || t('common.errorOccurred', 'حدث خطأ أثناء حفظ التعديلات'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-150 text-start">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92dvh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-teal-900 to-emerald-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center text-emerald-300 border border-white/10">
              <i className="fa-solid fa-pen-to-square text-base"></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">{t('installments.editInstallmentTransaction', 'تعديل تفاصيل معاملة القسط')}</h2>
              <p className="text-[10.5px] text-emerald-200/80 mt-0.5 font-medium">
                {installment.name} • {installment.item}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <i className="fa-solid fa-circle-exclamation shrink-0"></i>
              <span>{errorMsg}</span>
            </div>
          )}

          {/* 1. اسم صاحب الأقساط */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-user text-emerald-600 text-xs"></i>
              <span>{t('installments.clientName', 'اسم صاحب الأقساط')}</span>
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
            />
          </div>

          {/* 2. رقم الهاتف */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-phone text-emerald-600 text-xs"></i>
              <span>{t('debts.phoneNumber', 'رقم الهاتف')}</span>
              <span className="text-[10px] text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <div className="relative">
              <input
                type="tel"
                dir="ltr"
                maxLength={11}
                value={phone}
                onChange={handlePhoneChange}
                className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-mono border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
              />
              <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                <i className="fa-solid fa-phone"></i>
              </div>
            </div>
          </div>

          {/* 3. السلعة */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-box-open text-emerald-600 text-xs"></i>
              <span>{t('installments.itemPurchased', 'السلعة المباعة')}</span>
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={item}
              onChange={(e) => setItem(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
            />
          </div>

          {/* 4 & 5. مبالغ الأقساط والمقدمة */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* مبلغ القسط الكلي */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-money-bill-wave text-emerald-600 text-xs"></i>
                <span>{t('installments.totalAmount', 'مبلغ الأقساط الإجمالي')}</span>
                <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  dir="ltr"
                  inputMode="numeric"
                  required
                  value={totalAmountStr}
                  onChange={(e) => setTotalAmountStr(formatAmountInput(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 rounded-xl text-xs font-black font-mono border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                />
              </div>
            </div>

            {/* الدفعة المقدمة */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-hand-holding-dollar text-teal-600 text-xs"></i>
                <span>{t('installments.downPayment', 'الدفعة المقدمة')}</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  dir="ltr"
                  inputMode="numeric"
                  value={downPaymentStr}
                  onChange={(e) => setDownPaymentStr(formatAmountInput(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 rounded-xl text-xs font-black font-mono border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                />
              </div>
            </div>
          </div>

          {/* التلقائي: المتبقي المحسوب */}
          <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 flex items-center justify-between text-xs">
            <div>
              <span className="font-bold text-emerald-900 block">{t('installments.remainingAmount', 'المبلغ المتبقي الفعلي')}:</span>
              <span className="text-[10px] text-emerald-700">
                ({t('installments.totalMinusPaid', 'الإجمالي - المقدم - الدفعات المسددة')})
              </span>
            </div>
            <div className="text-end">
              <span className="text-base font-black text-emerald-800 font-mono">
                {formatNumber(remainingAmount)}
              </span>
              <span className="text-[11px] font-bold text-emerald-600 ms-1">{currency}</span>
            </div>
          </div>

          {/* التواريخ: تاريخ التسجيل وتاريخ الاستحقاق */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-calendar-day text-emerald-600 text-xs"></i>
                <span>{t('installments.registrationDate', 'تاريخ التسجيل')}</span>
              </label>
              <input
                type="date"
                required
                value={registrationDate}
                onChange={(e) => setRegistrationDate(toEnglishDigits(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-slate-50 text-slate-800 rounded-xl text-xs font-semibold border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-calendar-check text-emerald-600 text-xs"></i>
                <span>{t('installments.dueDate', 'تاريخ الاستحقاق القادم')}</span>
              </label>
              <input
                type="date"
                required
                value={nextDueDate}
                onChange={(e) => setNextDueDate(toEnglishDigits(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-slate-50 text-slate-800 rounded-xl text-xs font-semibold border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all font-mono"
              />
            </div>
          </div>

          {/* البطاقة الوطنية (اختياري) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-id-card text-emerald-600 text-xs"></i>
              <span>{t('installments.nationalId', 'رقم البطاقة الوطنية')}</span>
              <span className="text-[10px] text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <div className="relative">
              <input
                type="text"
                dir="ltr"
                inputMode="numeric"
                maxLength={12}
                value={nationalId}
                onChange={handleNationalIdChange}
                className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-mono font-bold border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
              />
              <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                <i className="fa-solid fa-id-card"></i>
              </div>
            </div>
          </div>

          {/* عنوان السكن وأقرب نقطة دالة */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-location-dot text-emerald-600 text-xs"></i>
              <span>{t('installments.address', 'عنوان السكن وأقرب نقطة دالة')}</span>
              <span className="text-[10px] text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
            />
          </div>

          {/* قائمة بيانات الكفيل */}
          <div className="border border-slate-200 rounded-2xl p-3.5 bg-slate-50/70 space-y-3">
            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={guarantorEnabled}
                onChange={(e) => setGuarantorEnabled(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer accent-emerald-600"
              />
              <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                <i className="fa-solid fa-user-shield text-emerald-600"></i>
                <span>{t('installments.guarantorInfo', 'بيانات الكفيل والضامن')}</span>
              </span>
            </label>

            {guarantorEnabled && (
              <div className="pt-2 border-t border-slate-200/80 space-y-2.5 animate-in fade-in duration-150">
                {/* اسم الكفيل */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {t('installments.guarantorName', 'اسم الكفيل')}
                  </label>
                  <input
                    type="text"
                    value={guarantorName}
                    onChange={(e) => setGuarantorName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                  />
                </div>

                {/* صلة القرابة ومهنة الكفيل */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {t('installments.guarantorRelation', 'صلة القرابة')}
                    </label>
                    <input
                      type="text"
                      value={guarantorRelation}
                      onChange={(e) => setGuarantorRelation(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {t('installments.guarantorJob', 'مهنة الكفيل')}
                    </label>
                    <input
                      type="text"
                      value={guarantorJob}
                      onChange={(e) => setGuarantorJob(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                    />
                  </div>
                </div>

                {/* عنوان الكفيل */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {t('installments.guarantorAddress', 'عنوان الكفيل')}
                  </label>
                  <input
                    type="text"
                    value={guarantorAddress}
                    onChange={(e) => setGuarantorAddress(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                  />
                </div>

                {/* رقم هاتف الكفيل */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {t('installments.guarantorPhone', 'رقم هاتف الكفيل')}
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    maxLength={11}
                    value={guarantorPhone}
                    onChange={handleGuarantorPhoneChange}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono outline-none focus:border-emerald-600 text-slate-800"
                  />
                </div>
              </div>
            )}
          </div>

          {/* ملاحظات إضافية */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-note-sticky text-slate-400 text-xs"></i>
              <span>{t('common.notes', 'ملاحظات إضافية')}</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all resize-none"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-3 pb-1 flex items-center gap-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-teal-700 via-emerald-700 to-emerald-800 hover:from-teal-800 hover:to-emerald-900 text-white text-xs font-black shadow-md shadow-emerald-700/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري حفظ التعديلات...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{t('debtors.saveChanges', 'حفظ التعديلات')}</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
