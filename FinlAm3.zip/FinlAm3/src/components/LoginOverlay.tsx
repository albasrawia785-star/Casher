import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import bcrypt from 'bcryptjs';
import { User, ManagerModuleAccess } from '../types';
import { queryTurso, setLocalSession } from '../services/turso';
import { useI18n } from '../i18n/index.tsx';

interface LoginOverlayProps {
  onLoginSuccess: (user: User) => void;
  initialErrorMessage?: string | null;
}

export const LoginOverlay: React.FC<LoginOverlayProps> = ({
  onLoginSuccess,
  initialErrorMessage,
}) => {
  const { t, language, setLanguage, dir } = useI18n();

  // Mode: 'login' | 'register'
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Register multi-step state:
  // Step 1: Identifier (اسم المستخدم / البريد / الهاتف)
  // Step 2: Password (كلمة المرور) & Confirm Password (تأكيد كلمة المرور)
  // Step 3: Security Question (تاريخ الميلاد بالتقويم) & System Selection (النظام)
  const [regStep, setRegStep] = useState<1 | 2 | 3>(1);
  const [regIdentifier, setRegIdentifier] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regBirthDate, setRegBirthDate] = useState('');
  const [regSelectedModule, setRegSelectedModule] = useState<ManagerModuleAccess>('both');

  // Forgot password modal state (Step 1: Identifier -> Step 2: Calendar Birth Date -> Step 3: New Pass & Confirm Pass)
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotStep, setForgotStep] = useState<1 | 2 | 3>(1);
  const [forgotIdentifier, setForgotIdentifier] = useState('');
  const [forgotBirthDate, setForgotBirthDate] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');
  const [showForgotNewPassword, setShowForgotNewPassword] = useState(false);
  const [forgotTargetUser, setForgotTargetUser] = useState<any | null>(null);
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotError, setForgotError] = useState<string | null>(null);
  const [forgotSuccess, setForgotSuccess] = useState<string | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(initialErrorMessage || null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Refs for calendar datepickers to trigger .showPicker() easily on mobile
  const regDateInputRef = useRef<HTMLInputElement | null>(null);
  const forgotDateInputRef = useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    if (initialErrorMessage) {
      setErrorMessage(initialErrorMessage);
    }
  }, [initialErrorMessage]);

  // Triple-click on title for quick admin access
  const clickCountRef = useRef(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleTripleClick = () => {
    clickCountRef.current += 1;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      clickCountRef.current = 0;
    }, 800);

    if (clickCountRef.current === 3) {
      clickCountRef.current = 0;
      const adminUser: User = {
        id: 1,
        username: 'admin',
        role: 'admin',
        branch_name: 'main_admin',
      };
      setLocalSession(adminUser);
      onLoginSuccess(adminUser);
    }
  };

  const handleInputFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    setTimeout(() => {
      e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 200);
  };

  const openRegCalendar = () => {
    if (regDateInputRef.current) {
      try {
        if ('showPicker' in regDateInputRef.current) {
          regDateInputRef.current.showPicker();
        } else {
          regDateInputRef.current.focus();
        }
      } catch {
        regDateInputRef.current.focus();
      }
    }
  };

  const openForgotCalendar = () => {
    if (forgotDateInputRef.current) {
      try {
        if ('showPicker' in forgotDateInputRef.current) {
          forgotDateInputRef.current.showPicker();
        } else {
          forgotDateInputRef.current.focus();
        }
      } catch {
        forgotDateInputRef.current.focus();
      }
    }
  };

  // ----------------------------------------------------
  // LOGIN HANDLER
  // ----------------------------------------------------
  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const identifier = loginIdentifier.trim();
    const trimmedPass = loginPassword.trim();

    if (!identifier || !trimmedPass) {
      setErrorMessage(t('login.enterUserPassError', 'يرجى إدخال اسم المستخدم/البريد وكلمة المرور'));
      return;
    }

    try {
      setIsLoading(true);
      let res;
      try {
        res = await queryTurso(
          "SELECT id, username, role, branch_name, password, is_active, subscription_type, subscription_expires_at, allowed_modules, phone_or_email, is_new_registration, plain_password, birth_date, layout_theme FROM users WHERE username = ? OR phone_or_email = ?;",
          [identifier, identifier]
        );
      } catch {
        // Auto-migrate columns if missing
        await queryTurso("ALTER TABLE users ADD COLUMN phone_or_email TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN birth_date TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN layout_theme TEXT DEFAULT 'classic';").catch(() => {});
        res = await queryTurso(
          "SELECT id, username, role, branch_name, password, is_active, subscription_type, subscription_expires_at, allowed_modules, phone_or_email, is_new_registration, plain_password, birth_date, layout_theme FROM users WHERE username = ? OR phone_or_email = ?;",
          [identifier, identifier]
        );
      }

      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      if (rows.length > 0) {
        const row = rows[0];
        const storedPass = row[4]?.value || '';
        let isMatch = false;

        // Bcrypt comparison or plain fallback
        if (storedPass.startsWith('$2a$') || storedPass.startsWith('$2b$') || storedPass.startsWith('$2y$')) {
          isMatch = bcrypt.compareSync(trimmedPass, storedPass);
        } else {
          isMatch = storedPass === trimmedPass;
          if (isMatch) {
            try {
              const salt = bcrypt.genSaltSync(10);
              const newHash = bcrypt.hashSync(trimmedPass, salt);
              queryTurso("UPDATE users SET password = ? WHERE id = ?;", [newHash, parseInt(row[0].value)]).catch(() => {});
            } catch (upgradeErr) {
              console.warn("Could not auto-upgrade password hash:", upgradeErr);
            }
          }
        }

        if (isMatch) {
          const role = row[2]?.value || 'manager';
          const isActiveVal = row[5]?.value;
          const isActive = isActiveVal === 0 || isActiveVal === '0' || isActiveVal === false ? false : true;
          const subscriptionType = (row[6]?.value as any) || 'permanent';
          const subscriptionExpiresAt = row[7]?.value || null;
          const allowedModules = (row[8]?.value as any) || 'both';
          const phoneOrEmail = row[9]?.value || '';
          const isNewRegVal = row[10]?.value;
          const isNewRegistration = isNewRegVal === 1 || isNewRegVal === '1' || isNewRegVal === true || subscriptionType === 'trial';
          const birthDate = row[12]?.value || '';

          // Admin is always active and unaffected by subscription
          if (role !== 'admin') {
            if (!isActive) {
              setErrorMessage(t('login.accountInactiveError', 'تم إيقاف هذا الحساب من قبل الإدارة العامة. يرجى التواصل مع الإدارة لإعادة تنشيطه.'));
              return;
            }

            if (subscriptionType === 'monthly') {
              if (!subscriptionExpiresAt || new Date(subscriptionExpiresAt).getTime() <= Date.now()) {
                setErrorMessage(t('login.subscriptionExpiredError', 'انتهت فترة الاشتراك الشهري لهذا الحساب. يرجى مراجعة الإدارة العامة لتأكيد تجديد الاشتراك.'));
                return;
              }
            }
          }

          const loggedUser: User = {
            id: parseInt(row[0].value),
            username: row[1].value,
            role,
            branch_name: row[3]?.value || row[1].value || 'الفرع الرئيسي',
            phoneOrEmail,
            password: trimmedPass,
            isActive,
            isNewRegistration,
            subscriptionType,
            subscriptionExpiresAt,
            allowedModules,
            layoutTheme: (row[13]?.value as any) || 'classic',
            birthDate,
          };

          localStorage.setItem(`user_pwd_${loggedUser.id}`, trimmedPass);
          localStorage.setItem(`user_pwd_${loggedUser.username}`, trimmedPass);
          queryTurso("UPDATE users SET plain_password = ? WHERE id = ?;", [trimmedPass, loggedUser.id]).catch(() => {});
          setLocalSession(loggedUser);
          localStorage.removeItem(`force_logout_user_${loggedUser.id}`);
          onLoginSuccess(loggedUser);
        } else {
          setErrorMessage(t('login.invalidCredentialsError', 'اسم المستخدم أو كلمة المرور غير صحيحة!'));
        }
      } else {
        setErrorMessage(t('login.invalidCredentialsError', 'اسم المستخدم أو كلمة المرور غير صحيحة!'));
      }
    } catch (err: any) {
      setErrorMessage(err.message || t('common.networkError', 'تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً'));
    } finally {
      setIsLoading(false);
    }
  };

  // ----------------------------------------------------
  // REGISTRATION VALIDATION & MULTI-STEP NAVIGATION
  // ----------------------------------------------------
  // Step 1: Identifier
  const validateStep1 = () => {
    setErrorMessage(null);
    const trimmedIdentifier = regIdentifier.trim();

    if (!trimmedIdentifier) {
      setErrorMessage(t('login.reqUsernameError', 'يرجى إدخال اسم المستخدم أو البريد أو الهاتف للحساب'));
      return false;
    }
    if (trimmedIdentifier.length < 3) {
      setErrorMessage(t('login.usernameMinError', 'اسم الحساب يجب ألا يقل عن 3 أحرف أو أرقام'));
      return false;
    }
    return true;
  };

  // Step 2: Password and Confirm Password
  const validateStep2 = () => {
    setErrorMessage(null);
    const trimmedPass = regPassword.trim();
    const trimmedConfirm = regConfirmPassword.trim();

    if (!trimmedPass) {
      setErrorMessage(t('login.reqPasswordError', 'يرجى كتابة كلمة المرور'));
      return false;
    }
    if (trimmedPass.length < 3) {
      setErrorMessage(t('login.passwordMinError', 'كلمة المرور يجب ألا تقل عن 3 خانات'));
      return false;
    }
    if (trimmedConfirm && trimmedConfirm !== trimmedPass) {
      setErrorMessage(t('login.passwordMismatchError', 'كلمتا المرور غير متطابقتين'));
      return false;
    }
    return true;
  };

  // Step 3: Security Question (Favorite Animal) & System
  const validateStep3 = () => {
    setErrorMessage(null);
    const trimmedBirthDate = regBirthDate.trim();
    if (!trimmedBirthDate) {
      setErrorMessage(t('login.reqBirthDateError', 'يرجى كتابة اسم حيوانك المفضل للإجابة على سؤال الأمان'));
      return false;
    }
    return true;
  };

  const handleNextStep = () => {
    if (regStep === 1) {
      if (validateStep1()) {
        setRegStep(2);
      }
    } else if (regStep === 2) {
      if (validateStep2()) {
        setRegStep(3);
      }
    }
  };

  const handlePrevStep = () => {
    setErrorMessage(null);
    if (regStep > 1) {
      setRegStep((prev) => (prev - 1) as 1 | 2 | 3);
    }
  };

  // ----------------------------------------------------
  // FINAL REGISTRATION SUBMIT
  // ----------------------------------------------------
  const handleRegister = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!validateStep1()) {
      setRegStep(1);
      return;
    }
    if (!validateStep2()) {
      setRegStep(2);
      return;
    }
    if (!validateStep3()) {
      setRegStep(3);
      return;
    }

    const trimmedIdentifier = regIdentifier.trim();
    const trimmedPass = regPassword.trim();
    const trimmedBirthDate = regBirthDate.trim();

    try {
      setIsLoading(true);

      // Check if identifier is already registered
      try {
        const checkRes = await queryTurso(
          "SELECT id FROM users WHERE username = ? OR phone_or_email = ?;",
          [trimmedIdentifier, trimmedIdentifier]
        );
        if (checkRes.results && checkRes.results[0]?.response?.result?.rows?.length > 0) {
          setErrorMessage(t('login.usernameTakenError', `هذا الحساب مسجل مسبقاً، يرجى اختيار اسم أو رقم آخر`));
          setRegStep(1);
          return;
        }
      } catch {
        // Table schema upgrade handled next
      }

      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(trimmedPass, salt);
      const nowIso = new Date().toISOString();

      let insertRes;
      try {
        insertRes = await queryTurso(
          "INSERT INTO users (username, phone_or_email, password, plain_password, role, branch_name, is_active, subscription_type, is_new_registration, allowed_modules, birth_date, created_at) VALUES (?, ?, ?, ?, 'manager', ?, 1, 'trial', 1, ?, ?, ?) RETURNING id;",
          [trimmedIdentifier, trimmedIdentifier, hashedPassword, trimmedPass, trimmedIdentifier, regSelectedModule, trimmedBirthDate, nowIso]
        );
      } catch {
        await queryTurso("ALTER TABLE users ADD COLUMN phone_or_email TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN allowed_modules TEXT DEFAULT 'both';").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN birth_date TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE users ADD COLUMN created_at TEXT;").catch(() => {});

        insertRes = await queryTurso(
          "INSERT INTO users (username, phone_or_email, password, plain_password, role, branch_name, is_active, subscription_type, is_new_registration, allowed_modules, birth_date, created_at) VALUES (?, ?, ?, ?, 'manager', ?, 1, 'trial', 1, ?, ?, ?) RETURNING id;",
          [trimmedIdentifier, trimmedIdentifier, hashedPassword, trimmedPass, trimmedIdentifier, regSelectedModule, trimmedBirthDate, nowIso]
        );
      }

      let newUserId = Date.now();
      if (insertRes?.results && insertRes.results[0]?.response?.result?.rows?.length > 0) {
        newUserId = parseInt(insertRes.results[0].response.result.rows[0][0].value) || newUserId;
      }

      const newUser: User = {
        id: newUserId,
        username: trimmedIdentifier,
        phoneOrEmail: trimmedIdentifier,
        role: 'manager',
        branch_name: trimmedIdentifier,
        password: trimmedPass,
        isActive: true,
        isNewRegistration: true,
        subscriptionType: 'trial',
        subscriptionExpiresAt: null,
        allowedModules: regSelectedModule,
        birthDate: trimmedBirthDate,
        createdAt: nowIso,
      };

      localStorage.setItem(`user_pwd_${newUserId}`, trimmedPass);
      localStorage.setItem(`user_pwd_${trimmedIdentifier}`, trimmedPass);
      setLocalSession(newUser);

      onLoginSuccess(newUser);
    } catch (err: any) {
      const msg = err?.message || '';
      if (msg.includes('UNIQUE constraint') || msg.includes('users.username')) {
        setErrorMessage(t('login.usernameTakenError', `هذا الحساب مسجل مسبقاً، يرجى اختيار اسم أو رقم آخر`));
        setRegStep(1);
      } else {
        setErrorMessage(msg || t('common.errorOccurred', 'تعذر إنشاء الحساب، يرجى المحاولة مرة أخرى'));
      }
    } finally {
      setIsLoading(false);
    }
  };

  // ----------------------------------------------------
  // FORGOT PASSWORD FLOW (Step 1: Check user -> Step 2: Calendar Birth Date -> Step 3: Set new password)
  // ----------------------------------------------------
  const handleOpenForgotModal = () => {
    setForgotStep(1);
    setForgotIdentifier(loginIdentifier.trim());
    setForgotBirthDate('');
    setForgotNewPassword('');
    setForgotConfirmPassword('');
    setForgotTargetUser(null);
    setForgotError(null);
    setForgotSuccess(null);
    setShowForgotModal(true);
  };

  const handleForgotStep1VerifyUser = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setForgotError(null);

    const identifier = forgotIdentifier.trim();
    if (!identifier) {
      setForgotError(t('login.reqUsernameError', 'يرجى إدخال اسم المستخدم أو البريد أو الهاتف للحساب'));
      return;
    }

    try {
      setForgotLoading(true);
      await queryTurso("ALTER TABLE users ADD COLUMN birth_date TEXT;").catch(() => {});
      const res = await queryTurso(
        "SELECT id, username, phone_or_email, role, branch_name, birth_date, is_active, subscription_type, subscription_expires_at, allowed_modules FROM users WHERE username = ? OR phone_or_email = ?;",
        [identifier, identifier]
      );

      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      if (rows.length === 0) {
        setForgotError(t('login.accountNotFound', 'لم يتم العثور على حساب مطابق لاسم المستخدم أو الهاتف أو البريد'));
        return;
      }

      const row = rows[0];
      const target = {
        id: parseInt(row[0].value),
        username: row[1].value,
        phoneOrEmail: row[2]?.value || '',
        role: row[3]?.value || 'manager',
        branch_name: row[4]?.value || row[1].value || 'الفرع الرئيسي',
        birth_date: row[5]?.value || '',
        isActive: row[6]?.value !== 0 && row[6]?.value !== '0',
        subscriptionType: row[7]?.value || 'permanent',
        subscriptionExpiresAt: row[8]?.value || null,
        allowedModules: row[9]?.value || 'both',
      };

      setForgotTargetUser(target);

      if (!target.birth_date || target.birth_date.trim() === '') {
        setForgotError(t('login.noSecurityQuestionSet', 'هذا الحساب لم يقم بتعيين سؤال أمان (مواليد) مسبقاً، يرجى التواصل مع الإدارة العامة للمساعدة.'));
        return;
      }

      setForgotStep(2);
    } catch (err: any) {
      setForgotError(err.message || t('common.networkError', 'تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً'));
    } finally {
      setForgotLoading(false);
    }
  };

  const normalizeSecurityAnswer = (str: string) => {
    return str
      .trim()
      .toLowerCase()
      .replace(/[أإآ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ي/g, 'ى')
      .replace(/[\s\-_]+/g, '');
  };

  const handleForgotStep2VerifyAnswer = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setForgotError(null);

    const answer = forgotBirthDate.trim();
    if (!answer) {
      setForgotError(t('login.reqBirthDateError', 'يرجى كتابة اسم حيوانك المفضل للإجابة على سؤال الأمان'));
      return;
    }

    if (!forgotTargetUser || !forgotTargetUser.birth_date) {
      setForgotError(t('login.noSecurityQuestionSet', 'هذا الحساب لم يقم بتعيين سؤال أمان مسبقاً'));
      return;
    }

    const stored = forgotTargetUser.birth_date.trim();

    // Normalized match (case-insensitive, unicode normalized) or direct / date year backward compatibility
    const normStored = normalizeSecurityAnswer(stored);
    const normInput = normalizeSecurityAnswer(answer);

    const storedYear = stored.match(/\b\d{4}\b/)?.[0] || stored;
    const inputYear = answer.match(/\b\d{4}\b/)?.[0] || answer;

    const isMatch =
      normStored === normInput ||
      normStored.includes(normInput) ||
      normInput.includes(normStored) ||
      stored.toLowerCase() === answer.toLowerCase() ||
      (storedYear && inputYear && storedYear === inputYear);

    if (isMatch) {
      setForgotStep(3);
    } else {
      setForgotError(t('login.securityAnswerMismatch', 'الإجابة غير متطابقة مع بيانات الحساب المسجلة'));
    }
  };

  const handleForgotStep3ResetPassword = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setForgotError(null);

    const newPass = forgotNewPassword.trim();
    const confirmPass = forgotConfirmPassword.trim();

    if (!newPass) {
      setForgotError(t('login.reqPasswordError', 'يرجى كتابة كلمة المرور الجديدة'));
      return;
    }
    if (newPass.length < 3) {
      setForgotError(t('login.passwordMinError', 'كلمة المرور يجب ألا تقل عن 3 خانات'));
      return;
    }
    if (confirmPass && confirmPass !== newPass) {
      setForgotError(t('login.passwordMismatchError', 'كلمتا المرور غير متطابقتين'));
      return;
    }

    try {
      setForgotLoading(true);
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(newPass, salt);

      await queryTurso(
        "UPDATE users SET password = ?, plain_password = ? WHERE id = ?;",
        [hashedPassword, newPass, forgotTargetUser.id]
      );

      localStorage.setItem(`user_pwd_${forgotTargetUser.id}`, newPass);
      localStorage.setItem(`user_pwd_${forgotTargetUser.username}`, newPass);

      setForgotSuccess(t('login.passwordResetSuccess', 'تم تحديث كلمة المرور بنجاح! تم تسجيل دخولك الآن'));

      // Log in automatically after short delay
      const updatedUser: User = {
        id: forgotTargetUser.id,
        username: forgotTargetUser.username,
        role: forgotTargetUser.role,
        branch_name: forgotTargetUser.branch_name,
        phoneOrEmail: forgotTargetUser.phoneOrEmail,
        password: newPass,
        isActive: forgotTargetUser.isActive,
        subscriptionType: forgotTargetUser.subscriptionType,
        subscriptionExpiresAt: forgotTargetUser.subscriptionExpiresAt,
        allowedModules: forgotTargetUser.allowedModules,
        birthDate: forgotTargetUser.birth_date,
      };

      setLocalSession(updatedUser);
      setTimeout(() => {
        setShowForgotModal(false);
        onLoginSuccess(updatedUser);
      }, 1200);
    } catch (err: any) {
      setForgotError(err.message || t('common.errorOccurred', 'تعذر تحديث كلمة المرور، يرجى المحاولة مرة أخرى'));
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div
      id="loginOverlay"
      dir={dir}
      className="min-h-[100dvh] w-full flex flex-col items-center justify-between px-3.5 py-3 sm:py-5 safe-top safe-bottom bg-[#070e24] relative selection:bg-cyan-500 selection:text-white overflow-y-auto overscroll-contain select-none"
    >
      {/* 1. Subtle Circuit Background Pattern */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.06] stroke-cyan-400 fill-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <pattern id="circuit-grid-native" width="100" height="100" patternUnits="userSpaceOnUse">
          <path d="M 0 25 L 25 25 L 40 40 L 65 40 L 75 25 L 100 25" strokeWidth="1" />
          <path d="M 25 100 L 25 75 L 45 55 L 70 55 L 85 70 L 100 70" strokeWidth="1" />
          <circle cx="40" cy="40" r="1.8" className="fill-cyan-400 stroke-none" />
          <circle cx="75" cy="25" r="1.5" className="fill-blue-400 stroke-none" />
          <circle cx="45" cy="55" r="1.5" className="fill-cyan-300 stroke-none" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#circuit-grid-native)" />
      </svg>

      {/* Soft Ambient Glows */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full bg-blue-600/10 blur-[70px] pointer-events-none" />
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full bg-cyan-600/10 blur-[80px] pointer-events-none" />

      {/* 2. Top Language Selector (عربي | كردي) */}
      <div className="relative z-20 w-full max-w-[390px] flex justify-center items-center shrink-0">
        <div className="bg-[#0b142d] border border-slate-700/60 p-0.5 rounded-xl flex items-center gap-1 shadow-sm">
          <button
            type="button"
            id="langBtnAr"
            onClick={() => setLanguage('ar')}
            className={`px-3.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              language === 'ar'
                ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t('login.langAr', 'عربي')}
          </button>
          <button
            type="button"
            id="langBtnKu"
            onClick={() => setLanguage('ku')}
            className={`px-3.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              language === 'ku'
                ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t('login.langKu', 'كردي')}
          </button>
        </div>
      </div>

      {/* 3. Main Center Area (Brand Header + Clean Responsive Card) */}
      <div className="relative z-10 w-full max-w-[390px] flex flex-col items-center my-auto py-1">
        
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-2.5 w-full">
          {/* Logo Mark */}
          <div className="mb-1.5 filter drop-shadow-[0_4px_12px_rgba(6,182,212,0.25)]">
            <svg
              className="w-13 h-10 sm:w-16 sm:h-12"
              viewBox="0 0 120 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="logoSilver" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="60%" stopColor="#cbd5e1" />
                  <stop offset="100%" stopColor="#94a3b8" />
                </linearGradient>
                <linearGradient id="logoBlue" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#1d4ed8" />
                </linearGradient>
                <linearGradient id="logoDarkBlue" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563eb" />
                  <stop offset="100%" stopColor="#1e3a8a" />
                </linearGradient>
                <linearGradient id="logoCyan" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#06b6d4" />
                  <stop offset="50%" stopColor="#22d3ee" />
                  <stop offset="100%" stopColor="#38bdf8" />
                </linearGradient>
                <linearGradient id="logoPeach" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f8fafc" />
                  <stop offset="100%" stopColor="#cbd5e1" />
                </linearGradient>
                <linearGradient id="logoTeal" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0891b2" />
                  <stop offset="100%" stopColor="#0e7490" />
                </linearGradient>
              </defs>

              <polygon points="18,22 42,22 34,48 18,36" fill="url(#logoSilver)" />
              <polygon points="42,22 56,48 34,48" fill="#94a3b8" opacity="0.8" />
              <polygon points="18,36 34,48 26,74 18,66" fill="url(#logoBlue)" />
              <polygon points="26,74 34,48 48,74" fill="url(#logoDarkBlue)" />
              <polygon points="56,22 74,22 84,62 66,62" fill="url(#logoPeach)" />
              <polygon points="48,74 62,50 72,74" fill="#172554" />
              <polygon points="72,74 84,62 94,74" fill="url(#logoTeal)" />
              <polygon points="34,74 54,48 64,60 48,74" fill="url(#logoBlue)" />
              <polygon points="54,48 64,60 92,26 84,18" fill="url(#logoCyan)" />
              <polygon points="78,20 102,14 96,38 88,28" fill="url(#logoCyan)" />
            </svg>
          </div>

          <h1
            id="loginTitle"
            onClick={handleTripleClick}
            className="text-lg sm:text-xl font-bold text-white tracking-wide cursor-pointer select-none"
            title={t('login.adminTripleClickHint', 'انقر 3 مرات سريعة للوصول الإداري')}
          >
            {t('login.title', 'دفتر الديون والأقساط')}
          </h1>

          <p className="text-[11px] font-normal text-slate-300/80 mt-0.5">
            {t('login.subtitle', 'نظام إدارة الديون والأقساط والحسابات المالية')}
          </p>
        </div>

        {/* 4. Native iOS/Android Optimized Card */}
        <div className="w-full bg-[#0d162f]/95 rounded-2xl p-3.5 sm:p-4 shadow-[0_12px_32px_rgba(0,0,0,0.5)] border border-slate-700/50 relative overflow-hidden text-start">
          
          {/* Top Tabs (تسجيل الدخول / إنشاء حساب جديد) */}
          <div className="grid grid-cols-2 p-1 bg-[#081024] border border-slate-700/40 rounded-xl mb-3">
            <button
              type="button"
              id="tabSwitchLogin"
              onClick={() => {
                setAuthMode('login');
                setErrorMessage(null);
              }}
              className={`h-9 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                authMode === 'login'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <i className="fa-solid fa-right-to-bracket text-xs"></i>
              <span className="truncate">{t('login.loginTab', 'تسجيل الدخول')}</span>
            </button>

            <button
              type="button"
              id="tabSwitchRegister"
              onClick={() => {
                setAuthMode('register');
                setRegStep(1);
                setErrorMessage(null);
              }}
              className={`h-9 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                authMode === 'register'
                  ? 'bg-gradient-to-r from-cyan-600 to-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <i className="fa-solid fa-user-plus text-xs"></i>
              <span className="truncate">{t('login.registerTab', 'إنشاء حساب جديد')}</span>
            </button>
          </div>

          {/* Feedback messages */}
          {errorMessage && (
            <div className="mb-2.5 p-2 bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs font-medium rounded-xl flex items-start gap-2 animate-in fade-in duration-150">
              <i className="fa-solid fa-circle-exclamation text-rose-400 mt-0.5 shrink-0 text-xs"></i>
              <span className="leading-relaxed flex-1">{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="mb-2.5 p-2 bg-emerald-950/70 border border-emerald-500/40 text-emerald-200 text-xs font-medium rounded-xl flex items-start gap-2 animate-in fade-in duration-150">
              <i className="fa-solid fa-circle-check text-emerald-400 mt-0.5 shrink-0 text-xs"></i>
              <span className="leading-relaxed flex-1">{successMessage}</span>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 1: LOGIN VIEW */}
          {/* ======================================================== */}
          {authMode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-3">
              {/* Field: Username / Email / Phone */}
              <div>
                <label
                  htmlFor="loginIdentifier"
                  className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                >
                  {t('login.loginIdentifier', 'اسم المستخدم / البريد / الهاتف')}
                </label>

                <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                  <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                    <i className="fa-solid fa-user text-xs"></i>
                  </div>

                  <input
                    type="text"
                    id="loginIdentifier"
                    dir={dir}
                    autoComplete="off"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    onFocus={handleInputFocus}
                    disabled={isLoading}
                    required
                  />
                </div>
              </div>

              {/* Field: Password */}
              <div>
                <label
                  htmlFor="loginPassword"
                  className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                >
                  {t('login.password', 'كلمة المرور')}
                </label>

                <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                  <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                    <i className="fa-solid fa-lock text-xs"></i>
                  </div>

                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    id="loginPassword"
                    dir={dir}
                    autoComplete="off"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    onFocus={handleInputFocus}
                    disabled={isLoading}
                    required
                  />

                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer text-xs shrink-0 active:scale-95"
                    tabIndex={-1}
                    title={showLoginPassword ? t('login.hidePassword', 'إخفاء كلمة المرور') : t('login.showPassword', 'إظهار كلمة المرور')}
                  >
                    <i className={`fa-regular ${showLoginPassword ? 'fa-eye text-cyan-400' : 'fa-eye-slash text-slate-400'}`}></i>
                  </button>
                </div>
              </div>

              {/* Forgot Password Link */}
              <div className="flex justify-end pt-0.5">
                <button
                  type="button"
                  onClick={handleOpenForgotModal}
                  className="text-[11px] text-cyan-300/85 hover:text-cyan-200 font-medium cursor-pointer transition-colors"
                >
                  {t('login.forgotPassword', 'نسيت كلمة المرور؟')}
                </button>
              </div>

              {/* Submit Login Button */}
              <div className="pt-0.5">
                <button
                  type="submit"
                  id="btnLoginSubmit"
                  className="w-full h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 via-teal-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-60 disabled:pointer-events-none cursor-pointer shadow-md shadow-cyan-900/20"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                      <span>{t('login.loggingIn', 'جاري التحقق...')}</span>
                    </>
                  ) : (
                    <>
                      <span>{t('login.loginBtn', 'تسجيل الدخول')}</span>
                      <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
                    </>
                  )}
                </button>
              </div>

              {/* Switch to Register */}
              <div className="pt-1 text-center text-xs text-slate-400">
                <span>{t('login.noAccount', 'ليس لديك حساب؟')}{' '}</span>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('register');
                    setRegStep(1);
                    setErrorMessage(null);
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-bold cursor-pointer underline-offset-2 hover:underline"
                >
                  {t('login.createAccountNow', 'إنشاء حساب جديد')}
                </button>
              </div>
            </form>
          ) : (
            /* ======================================================== */
            /* TAB 2: REGISTER VIEW (MULTI-STEP WIZARD) */
            /* ======================================================== */
            <div className="space-y-3">
              {/* Horizontal Steps Indicator:
                  1. البيانات (الاسم / البريد / الهاتف)
                  2. كلمة المرور (كلمة المرور + تأكيد كلمة المرور)
                  3. الأمان والنظام (تاريخ الميلاد بالتقويم + اختيار النظام)
              */}
              <div className="py-1 px-1 bg-[#091126] border border-slate-700/40 rounded-xl">
                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400">
                  
                  {/* Step 1 Item */}
                  <button
                    type="button"
                    onClick={() => {
                      if (regStep > 1) {
                        setErrorMessage(null);
                        setRegStep(1);
                      }
                    }}
                    className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                      regStep === 1
                        ? 'text-cyan-400 font-bold'
                        : regStep > 1
                        ? 'text-emerald-400'
                        : 'text-slate-500'
                    }`}
                  >
                    <span
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        regStep === 1
                          ? 'bg-cyan-500 text-slate-950 font-black'
                          : regStep > 1
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {regStep > 1 ? <i className="fa-solid fa-check text-[9px]"></i> : '1'}
                    </span>
                    <span>{t('login.stepData', 'البيانات')}</span>
                  </button>

                  <i className={`fa-solid ${dir === 'rtl' ? 'fa-angle-left' : 'fa-angle-right'} text-[10px] text-slate-600`}></i>

                  {/* Step 2 Item */}
                  <button
                    type="button"
                    onClick={() => {
                      if (regStep === 3) {
                        setErrorMessage(null);
                        setRegStep(2);
                      } else if (regStep === 1 && validateStep1()) {
                        setRegStep(2);
                      }
                    }}
                    className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                      regStep === 2
                        ? 'text-cyan-400 font-bold'
                        : regStep > 2
                        ? 'text-emerald-400'
                        : 'text-slate-500'
                    }`}
                  >
                    <span
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        regStep === 2
                          ? 'bg-cyan-500 text-slate-950 font-black'
                          : regStep > 2
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {regStep > 2 ? <i className="fa-solid fa-check text-[9px]"></i> : '2'}
                    </span>
                    <span>{t('login.stepPassword', 'كلمة المرور')}</span>
                  </button>

                  <i className={`fa-solid ${dir === 'rtl' ? 'fa-angle-left' : 'fa-angle-right'} text-[10px] text-slate-600`}></i>

                  {/* Step 3 Item */}
                  <button
                    type="button"
                    onClick={() => {
                      if (regStep === 1 && validateStep1()) {
                        if (validateStep2()) setRegStep(3);
                        else setRegStep(2);
                      } else if (regStep === 2 && validateStep2()) {
                        setRegStep(3);
                      }
                    }}
                    className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                      regStep === 3 ? 'text-cyan-400 font-bold' : 'text-slate-500'
                    }`}
                  >
                    <span
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        regStep === 3
                          ? 'bg-cyan-500 text-slate-950 font-black'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      3
                    </span>
                    <span>{t('login.stepConfirm', 'تأكيد الحساب')}</span>
                  </button>
                </div>
              </div>

              {/* Step Content */}
              <AnimatePresence mode="wait">
                {/* ----------------- STEP 1: IDENTIFIER ONLY ----------------- */}
                {regStep === 1 && (
                  <motion.div
                    key="step-1"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-3"
                  >
                    <div className="text-[11px] font-semibold text-cyan-300/90 flex items-center gap-1.5">
                      <i className="fa-solid fa-user-check text-xs"></i>
                      <span>{t('login.step1Title', 'بيانات الحساب')}</span>
                    </div>

                    {/* Unified Single Identifier Field */}
                    <div>
                      <label
                        htmlFor="regIdentifier"
                        className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                      >
                        {t('login.loginIdentifier', 'اسم المستخدم / البريد / الهاتف')} <span className="text-cyan-400">*</span>
                      </label>

                      <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                        <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                          <i className="fa-solid fa-user-tag text-xs"></i>
                        </div>

                        <input
                          type="text"
                          id="regIdentifier"
                          dir={dir}
                          autoComplete="off"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                          value={regIdentifier}
                          onChange={(e) => setRegIdentifier(e.target.value)}
                          onFocus={handleInputFocus}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleNextStep();
                            }
                          }}
                          disabled={isLoading}
                          required
                          autoFocus
                        />
                      </div>
                    </div>

                    {/* Step 1 Action Button */}
                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={handleNextStep}
                        className="w-full h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-cyan-900/20"
                      >
                        <span>{t('login.nextToPassword', 'متابعة')}</span>
                        <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
                      </button>
                    </div>

                    {/* Back to Login Link */}
                    <div className="pt-0.5 text-center text-xs text-slate-400">
                      <span>{t('login.haveAccount', 'لديك حساب بالفعل؟')}{' '}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode('login');
                          setErrorMessage(null);
                        }}
                        className="text-cyan-400 hover:text-cyan-300 font-bold cursor-pointer underline-offset-2 hover:underline"
                      >
                        {t('login.loginTab', 'تسجيل الدخول')}
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* ----------------- STEP 2: PASSWORD + CONFIRM PASSWORD ----------------- */}
                {regStep === 2 && (
                  <motion.div
                    key="step-2"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-3"
                  >
                    <div className="text-[11px] font-semibold text-cyan-300/90 flex items-center gap-1.5">
                      <i className="fa-solid fa-shield-halved text-xs"></i>
                      <span>{t('login.step2Title', 'تعيين كلمة المرور')}</span>
                    </div>

                    {/* Field 1: Password */}
                    <div>
                      <label
                        htmlFor="regPassword"
                        className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                      >
                        {t('login.password', 'كلمة المرور')} <span className="text-cyan-400">*</span>
                      </label>

                      <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                        <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                          <i className="fa-solid fa-lock text-xs"></i>
                        </div>

                        <input
                          type={showRegPassword ? 'text' : 'password'}
                          id="regPassword"
                          dir={dir}
                          autoComplete="off"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          onFocus={handleInputFocus}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleNextStep();
                            }
                          }}
                          disabled={isLoading}
                          required
                          autoFocus
                        />

                        <button
                          type="button"
                          onClick={() => setShowRegPassword(!showRegPassword)}
                          className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer text-xs shrink-0 active:scale-95"
                          tabIndex={-1}
                        >
                          <i className={`fa-regular ${showRegPassword ? 'fa-eye text-cyan-400' : 'fa-eye-slash text-slate-400'}`}></i>
                        </button>
                      </div>
                    </div>

                    {/* Field 2: Confirm Password */}
                    <div>
                      <label
                        htmlFor="regConfirmPassword"
                        className="block text-[11px] font-medium text-slate-300 mb-1 text-start"
                      >
                        {t('login.confirmPassword', 'تأكيد كلمة المرور')} <span className="text-cyan-400">*</span>
                      </label>

                      <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                        <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                          <i className="fa-solid fa-key text-xs"></i>
                        </div>

                        <input
                          type={showRegPassword ? 'text' : 'password'}
                          id="regConfirmPassword"
                          dir={dir}
                          autoComplete="off"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                          value={regConfirmPassword}
                          onChange={(e) => setRegConfirmPassword(e.target.value)}
                          onFocus={handleInputFocus}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleNextStep();
                            }
                          }}
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    {/* Step 2 Actions */}
                    <div className="pt-1 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handlePrevStep}
                        className="h-11 px-3.5 rounded-xl font-semibold text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all flex items-center justify-center gap-1 cursor-pointer border border-slate-700/60 shrink-0 active:scale-95"
                      >
                        <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-right' : 'fa-arrow-left'} text-xs`}></i>
                        <span>{t('login.prevStep', 'السابق')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleNextStep}
                        className="flex-1 h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-cyan-900/20"
                      >
                        <span>{t('login.nextToConfirm', 'متابعة')}</span>
                        <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* ----------------- STEP 3: SECURITY QUESTION (FAVORITE ANIMAL) + SYSTEM SELECTION ----------------- */}
                {regStep === 3 && (
                  <motion.div
                    key="step-3"
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-3"
                  >
                    <div className="text-[11px] font-semibold text-cyan-300/90 flex items-center gap-1.5">
                      <i className="fa-solid fa-shield-halved text-xs"></i>
                      <span>{t('login.step3Title', 'سؤال الأمان واختيار النظام')}</span>
                    </div>

                    {/* Security Question: Favorite Animal */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label
                          htmlFor="regBirthDate"
                          className="block text-[11px] font-medium text-slate-300 text-start"
                        >
                          {t('login.securityQuestionLabel', 'ما هو اسم حيوانك المفضل؟')} <span className="text-cyan-400">*</span>
                        </label>
                      </div>

                      <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                        <div className="w-5 flex items-center justify-center shrink-0 text-cyan-400">
                          <i className="fa-solid fa-paw text-sm"></i>
                        </div>

                        <input
                          type="text"
                          id="regBirthDate"
                          dir={dir}
                          autoComplete="off"
                          autoCapitalize="none"
                          autoCorrect="off"
                          spellCheck={false}
                          className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                          value={regBirthDate}
                          onChange={(e) => setRegBirthDate(e.target.value)}
                          onFocus={handleInputFocus}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleRegister();
                            }
                          }}
                          disabled={isLoading}
                          required
                          autoFocus
                        />
                      </div>
                    </div>

                    {/* Module Selection */}
                    <div>
                      <label className="block text-[11px] font-medium text-slate-300 mb-1 text-start">
                        {t('login.selectSystemPrompt', 'تحديد النظام:')}
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        <button
                          type="button"
                          onClick={() => setRegSelectedModule('debts')}
                          className={`h-11 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                            regSelectedModule === 'debts'
                              ? 'bg-emerald-950/80 border-emerald-400 text-emerald-300 shadow-sm'
                              : 'bg-[#131d3d] border-slate-700/50 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <i className="fa-solid fa-book-bookmark text-xs"></i>
                          <span className="text-[11px]">{t('login.debtsSystem', 'دفتر ديون')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setRegSelectedModule('installments')}
                          className={`h-11 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                            regSelectedModule === 'installments'
                              ? 'bg-blue-950/80 border-blue-400 text-blue-300 shadow-sm'
                              : 'bg-[#131d3d] border-slate-700/50 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <i className="fa-solid fa-receipt text-xs"></i>
                          <span className="text-[11px]">{t('login.installmentsSystem', 'نظام أقساط')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setRegSelectedModule('both')}
                          className={`h-11 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                            regSelectedModule === 'both'
                              ? 'bg-cyan-950/80 border-cyan-400 text-cyan-300 shadow-sm'
                              : 'bg-[#131d3d] border-slate-700/50 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <i className="fa-solid fa-layer-group text-xs"></i>
                          <span className="text-[11px]">{t('login.bothSystems', 'كلاهما')}</span>
                        </button>
                      </div>
                    </div>

                    {/* Step 3 Actions */}
                    <div className="pt-1 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handlePrevStep}
                        className="h-11 px-3.5 rounded-xl font-semibold text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all flex items-center justify-center gap-1 cursor-pointer border border-slate-700/60 shrink-0 active:scale-95"
                      >
                        <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-right' : 'fa-arrow-left'} text-xs`}></i>
                        <span>{t('login.prevStep', 'السابق')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleRegister}
                        disabled={isLoading}
                        className="flex-1 h-11 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer shadow-md shadow-teal-900/25"
                      >
                        {isLoading ? (
                          <>
                            <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                            <span>{t('login.creatingAccount', 'جاري إنشاء الحساب...')}</span>
                          </>
                        ) : (
                          <>
                            <i className="fa-solid fa-circle-check text-xs"></i>
                            <span>{t('login.createAccountBtn', 'تأكيد وإنشاء الحساب')}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* 5. Secure Bottom Badge */}
          <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-slate-400 text-[11px]">
            <i className="fa-solid fa-shield-halved text-cyan-400 text-xs"></i>
            <span>{t('login.secureBadge', 'بياناتك محفوظة وآمنة')}</span>
          </div>
        </div>
      </div>

      {/* 6. Forgot Password Interactive Calendar Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 animate-in fade-in duration-150 select-none overflow-y-auto safe-top safe-bottom">
          <div className="bg-[#0e1733] border border-slate-700/80 rounded-2xl w-full max-w-sm p-4 text-start shadow-2xl relative my-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2 text-cyan-400">
                <i className="fa-solid fa-key text-sm"></i>
                <h3 className="text-xs sm:text-sm font-bold text-white">{t('login.forgotPasswordTitle', 'استعادة كلمة المرور')}</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            {/* Steps Progress Pills */}
            <div className="grid grid-cols-3 gap-1 mb-3 text-[10px] font-bold text-center">
              <div
                className={`py-1 rounded-lg transition-all ${
                  forgotStep === 1
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : forgotStep > 1
                    ? 'bg-emerald-950 border border-emerald-500/50 text-emerald-300'
                    : 'bg-[#081024] text-slate-500 border border-slate-800'
                }`}
              >
                {t('login.forgotStepIdentifier', '1. الحساب')}
              </div>
              <div
                className={`py-1 rounded-lg transition-all ${
                  forgotStep === 2
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : forgotStep > 2
                    ? 'bg-emerald-950 border border-emerald-500/50 text-emerald-300'
                    : 'bg-[#081024] text-slate-500 border border-slate-800'
                }`}
              >
                {t('login.forgotStepSecurity', '2. تاريخ الميلاد')}
              </div>
              <div
                className={`py-1 rounded-lg transition-all ${
                  forgotStep === 3
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : 'bg-[#081024] text-slate-500 border border-slate-800'
                }`}
              >
                {t('login.forgotStepReset', '3. كلمة جديدة')}
              </div>
            </div>

            {/* Error Message inside modal */}
            {forgotError && (
              <div className="mb-3 p-2 bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs font-medium rounded-xl flex items-start gap-2">
                <i className="fa-solid fa-circle-exclamation text-rose-400 mt-0.5 shrink-0 text-xs"></i>
                <span className="leading-relaxed flex-1">{forgotError}</span>
              </div>
            )}

            {/* Success Message inside modal */}
            {forgotSuccess && (
              <div className="mb-3 p-2 bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs font-medium rounded-xl flex items-start gap-2">
                <i className="fa-solid fa-circle-check text-emerald-400 mt-0.5 shrink-0 text-xs"></i>
                <span className="leading-relaxed flex-1">{forgotSuccess}</span>
              </div>
            )}

            {/* ----------------- FORGOT STEP 1: Find Account ----------------- */}
            {forgotStep === 1 && (
              <form onSubmit={handleForgotStep1VerifyUser} className="space-y-3">
                <p className="text-xs text-slate-300 leading-relaxed">
                  {t('login.forgotPasswordDesc', 'أدخل اسم المستخدم أو رقم الهاتف أو البريد الإلكتروني للبحث عن حسابك.')}
                </p>

                <div>
                  <label htmlFor="forgotIdentifierInput" className="block text-[11px] font-medium text-slate-300 mb-1 text-start">
                    {t('login.loginIdentifier', 'اسم المستخدم / البريد / الهاتف')}
                  </label>
                  <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                    <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                      <i className="fa-solid fa-user-tag text-xs"></i>
                    </div>
                    <input
                      type="text"
                      id="forgotIdentifierInput"
                      dir={dir}
                      autoComplete="off"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                      value={forgotIdentifier}
                      onChange={(e) => setForgotIdentifier(e.target.value)}
                      onFocus={handleInputFocus}
                      disabled={forgotLoading}
                      required
                      autoFocus
                    />
                  </div>
                </div>

                <div className="pt-1 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowForgotModal(false)}
                    className="h-11 px-3.5 rounded-xl font-semibold text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all flex items-center justify-center cursor-pointer border border-slate-700/60 shrink-0"
                  >
                    {t('common.close', 'إغلاق')}
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="flex-1 h-11 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-blue-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer shadow-md shadow-cyan-900/20"
                  >
                    {forgotLoading ? (
                      <>
                        <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                        <span>{t('login.loggingIn', 'جاري التحقق...')}</span>
                      </>
                    ) : (
                      <>
                        <span>{t('login.verifyAccountBtn', 'متابعة')}</span>
                        <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* ----------------- FORGOT STEP 2: Favorite Animal Security Question ----------------- */}
            {forgotStep === 2 && (
              <form onSubmit={handleForgotStep2VerifyAnswer} className="space-y-3">
                <div className="p-2.5 bg-[#081024] rounded-xl border border-slate-800 text-xs text-slate-300">
                  <div className="font-semibold text-cyan-300 flex items-center gap-1.5 mb-1">
                    <i className="fa-solid fa-user-shield text-xs"></i>
                    <span>{forgotTargetUser?.username}</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    {t('login.securityQuestionPrompt', 'ما هو اسم حيوانك المفضل المسجل للحساب؟')}
                  </p>
                </div>

                <div>
                  <label htmlFor="forgotBirthDateInput" className="block text-[11px] font-medium text-slate-300 mb-1 text-start">
                    {t('login.favoriteAnimal', 'اسم حيوانك المفضل')}
                  </label>
                  <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                    <div className="w-5 flex items-center justify-center shrink-0 text-cyan-400">
                      <i className="fa-solid fa-paw text-sm"></i>
                    </div>
                    <input
                      type="text"
                      id="forgotBirthDateInput"
                      dir={dir}
                      autoComplete="off"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                      value={forgotBirthDate}
                      onChange={(e) => setForgotBirthDate(e.target.value)}
                      onFocus={handleInputFocus}
                      required
                      autoFocus
                    />
                  </div>
                </div>

                <div className="pt-1 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setForgotError(null);
                      setForgotStep(1);
                    }}
                    className="h-11 px-3.5 rounded-xl font-semibold text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all flex items-center justify-center gap-1 cursor-pointer border border-slate-700/60 shrink-0"
                  >
                    <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-right' : 'fa-arrow-left'} text-xs`}></i>
                    <span>{t('login.prevStep', 'السابق')}</span>
                  </button>
                  <button
                    type="submit"
                    className="flex-1 h-11 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-blue-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-cyan-900/20"
                  >
                    <span>{t('login.verifySecurityBtn', 'تأكيد ومتابعة')}</span>
                    <i className={`fa-solid ${dir === 'rtl' ? 'fa-arrow-left' : 'fa-arrow-right'} text-xs`}></i>
                  </button>
                </div>
              </form>
            )}

            {/* ----------------- FORGOT STEP 3: Set New Password & Confirm Password ----------------- */}
            {forgotStep === 3 && (
              <form onSubmit={handleForgotStep3ResetPassword} className="space-y-3">
                {/* Field: New Password */}
                <div>
                  <label htmlFor="forgotNewPassInput" className="block text-[11px] font-medium text-slate-300 mb-1 text-start">
                    {t('login.newPassword', 'كلمة المرور الجديدة')} <span className="text-cyan-400">*</span>
                  </label>
                  <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                    <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                      <i className="fa-solid fa-lock text-xs"></i>
                    </div>
                    <input
                      type={showForgotNewPassword ? 'text' : 'password'}
                      id="forgotNewPassInput"
                      dir={dir}
                      autoComplete="off"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                      value={forgotNewPassword}
                      onChange={(e) => setForgotNewPassword(e.target.value)}
                      onFocus={handleInputFocus}
                      disabled={forgotLoading}
                      required
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => setShowForgotNewPassword(!showForgotNewPassword)}
                      className="p-1.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer text-xs shrink-0 active:scale-95"
                      tabIndex={-1}
                    >
                      <i className={`fa-regular ${showForgotNewPassword ? 'fa-eye text-cyan-400' : 'fa-eye-slash text-slate-400'}`}></i>
                    </button>
                  </div>
                </div>

                {/* Field: Confirm New Password */}
                <div>
                  <label htmlFor="forgotConfirmPassInput" className="block text-[11px] font-medium text-slate-300 mb-1 text-start">
                    {t('login.confirmNewPassword', 'تأكيد كلمة المرور الجديدة')} <span className="text-cyan-400">*</span>
                  </label>
                  <div className="relative flex items-center bg-[#131d3d] focus-within:bg-[#16234b] border border-slate-700/60 focus-within:border-cyan-400/60 rounded-xl px-3 h-11 transition-all">
                    <div className="w-5 flex items-center justify-center shrink-0 text-slate-400">
                      <i className="fa-solid fa-key text-xs"></i>
                    </div>
                    <input
                      type={showForgotNewPassword ? 'text' : 'password'}
                      id="forgotConfirmPassInput"
                      dir={dir}
                      autoComplete="off"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      className="flex-1 bg-transparent text-start text-white text-sm outline-none px-2 h-full"
                      value={forgotConfirmPassword}
                      onChange={(e) => setForgotConfirmPassword(e.target.value)}
                      onFocus={handleInputFocus}
                      disabled={forgotLoading}
                    />
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="w-full h-11 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer shadow-md shadow-teal-900/25"
                  >
                    {forgotLoading ? (
                      <>
                        <i className="fa-solid fa-circle-notch fa-spin text-xs"></i>
                        <span>{t('login.loggingIn', 'جاري التحديث...')}</span>
                      </>
                    ) : (
                      <>
                        <i className="fa-solid fa-circle-check text-xs"></i>
                        <span>{t('login.resetPasswordBtn', 'حفظ كلمة المرور والدخول')}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}
    </div>
  );
};
