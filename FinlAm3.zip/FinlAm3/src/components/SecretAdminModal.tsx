import React, { useState } from 'react';
import { User } from '../types';
import { getBackendBaseUrl, setBackendBaseUrl, queryTurso } from '../services/turso';
import { useI18n } from '../i18n/index.tsx';

interface SecretAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onOpenManagersModal: () => void;
  onOpenSettingsTab: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const SecretAdminModal: React.FC<SecretAdminModalProps> = ({
  isOpen,
  onClose,
  currentUser: _currentUser,
  onOpenManagersModal,
  onOpenSettingsTab,
  onShowToast,
}) => {
  const { t, dir } = useI18n();
  const [serverUrl, setServerUrl] = useState(() => getBackendBaseUrl());
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; ms?: number } | null>(null);

  if (!isOpen) return null;

  const handleSaveServerUrl = () => {
    try {
      setBackendBaseUrl(serverUrl);
      onShowToast(t('common.saved', 'تم الحفظ بنجاح'), 'success');
    } catch {
      onShowToast(t('common.error', 'حدث خطأ أثناء الحفظ'), 'error');
    }
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const startTime = Date.now();
      await queryTurso('SELECT 1 as ping_test;');
      const ms = Date.now() - startTime;
      setTestResult({
        success: true,
        message: t('secretAdmin.connectionSafe', 'الاتصال بقاعدة البيانات مشفر ومحمي وآمن 100%!'),
        ms,
      });
      onShowToast(t('common.success', 'الاتصال آمن ومشفر بنجاح'), 'success');
    } catch (err: any) {
      setTestResult({
        success: false,
        message: `${t('common.error', 'خطأ')}: ${err?.message || 'Server connection error'}`,
      });
      onShowToast(t('common.error', 'فشل فحص الاتصال'), 'error');
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div
      id="secretAdminModalOverlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
      dir={dir}
      onClick={onClose}
    >
      <div
        id="secretAdminModalCard"
        className="w-full max-w-lg bg-slate-900 border border-slate-700/80 text-white rounded-3xl p-5 sm:p-6 shadow-2xl relative overflow-hidden max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow ambient background */}
        <div className="absolute -top-16 -right-16 w-44 h-44 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-16 -left-16 w-44 h-44 bg-emerald-600/15 rounded-full blur-3xl pointer-events-none"></div>

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 text-lg">
              <i className="fa-solid fa-shield-halved"></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">{t('secretAdmin.modalTitle', 'لوحة الإدارة والتحكم السرية')}</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {t('secretAdmin.unlockedBadge', 'تم الفتح بـ 3 نقرات')}
                </span>
              </div>
              <p className="text-xs text-slate-400">{t('secretAdmin.modalDesc', 'إدارة النظام، الأمان والتشفير، وحسابات المشتركين')}</p>
            </div>
          </div>
          <button
            id="closeSecretAdminModalBtn"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center text-xs transition-colors"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        {/* Security Badge Card */}
        <div className="mt-4 p-3.5 rounded-2xl bg-slate-950/60 border border-blue-500/30 text-xs space-y-2 relative z-10">
          <div className="flex items-center justify-between">
            <span className="font-bold text-blue-400 flex items-center gap-1.5">
              <i className="fa-solid fa-lock text-[11px]"></i>
              <span>{t('secretAdmin.securityShieldTitle', 'نظام الحماية العالمي (Zero-Token Architecture)')}</span>
            </span>
            <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10.5px] font-mono font-bold">
              {t('secretAdmin.shieldActive', 'درع نشط 100%')}
            </span>
          </div>
          <p className="text-slate-300 leading-relaxed text-[11.5px]">
            {t('secretAdmin.shieldDesc', 'كود التطبيق ونسخة الـ APK خالية تماماً من رمز قاعدة البيانات السري ورابطها المباشر. جميع الطلبات تمر حصرياً عبر جدار ناري خادم مع فحص Anti-SQL Injection.')}
          </p>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 gap-2.5 mt-4 relative z-10">
          {/* Managers Button */}
          <button
            id="secretModalManagersBtn"
            type="button"
            onClick={() => {
              onClose();
              onOpenManagersModal();
            }}
            className="p-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-blue-500/50 flex flex-col items-start gap-1.5 transition-all active:scale-95 group text-start"
          >
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center text-sm group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-users-gear"></i>
            </div>
            <span className="text-xs font-bold text-white">{t('managers.title', 'إدارة المشتركين والفروع')}</span>
            <span className="text-[10px] text-slate-400">{t('managers.subtitle', 'إضافة وتفعيل وتعطيل المشتركين')}</span>
          </button>

          {/* Settings Button */}
          <button
            id="secretModalSettingsBtn"
            type="button"
            onClick={() => {
              onClose();
              onOpenSettingsTab();
            }}
            className="p-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-blue-500/50 flex flex-col items-start gap-1.5 transition-all active:scale-95 group text-start"
          >
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-sm group-hover:scale-110 transition-transform">
              <i className="fa-solid fa-sliders"></i>
            </div>
            <span className="text-xs font-bold text-white">{t('common.settings', 'الإعدادات الموسعة')}</span>
            <span className="text-[10px] text-slate-400">{t('settings.subtitle', 'النسخ الاحتياطي، المظهر، التنبيهات')}</span>
          </button>
        </div>

        {/* APK & Server Hosting Config */}
        <div className="mt-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/70 space-y-3 relative z-10">
          <div className="flex items-center justify-between">
            <label htmlFor="secretServerUrlInput" className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <i className="fa-solid fa-server text-blue-400 text-xs"></i>
              <span>{t('secretAdmin.serverUrlLabel', 'رابط خادم التطبيق (APK & Hosting Server URL)')}</span>
            </label>
            <span className="text-[10px] text-slate-400 font-mono">{t('secretAdmin.defaultAuto', 'الافتراضي تلقائي')}</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            {t('secretAdmin.serverUrlDesc', 'عند تحويل التطبيق إلى ملف APK أو رفعه على استضافة خاصة بك، يمكنك ربطه بعنوان خادم الـ API هنا:')}
          </p>
          <div className="flex gap-2">
            <input
              id="secretServerUrlInput"
              type="url"
              dir="ltr"
              value={serverUrl}
              onChange={(e) => setServerUrl(e.target.value)}
              placeholder="https://your-domain.com"
              className="flex-1 bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs font-mono outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
            <button
              id="saveServerUrlBtn"
              type="button"
              onClick={handleSaveServerUrl}
              className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors shrink-0 cursor-pointer"
            >
              {t('common.save', 'حفظ')}
            </button>
          </div>
        </div>

        {/* Database Connection Diagnostic */}
        <div className="mt-4 p-4 rounded-2xl bg-slate-800/50 border border-slate-700/70 space-y-3 relative z-10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <i className="fa-solid fa-database text-emerald-400 text-xs"></i>
              <span>{t('secretAdmin.testDbConnection', 'فحص الاتصال بقاعدة البيانات السحابية')}</span>
            </span>
            <button
              id="testTursoConnectionBtn"
              type="button"
              disabled={isTesting}
              onClick={handleTestConnection}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isTesting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.loading', 'جاري الفحص...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-bolt text-xs"></i>
                  <span>{t('secretAdmin.testNow', 'فحص الآن')}</span>
                </>
              )}
            </button>
          </div>

          {testResult && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                testResult.success
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
              }`}
            >
              <i
                className={`fa-solid ${
                  testResult.success ? 'fa-circle-check text-emerald-400' : 'fa-triangle-exclamation text-rose-400'
                } mt-0.5`}
              ></i>
              <div className="flex-1 space-y-0.5">
                <p className="font-bold">{testResult.message}</p>
                {testResult.ms !== undefined && (
                  <p className="text-[10.5px] opacity-80 font-mono">{t('secretAdmin.responseTime', 'زمن الاستجابة')}: {testResult.ms} ms</p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-5 pt-3 border-t border-slate-800 flex justify-end">
          <button
            id="closeSecretModalFooterBtn"
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
          >
            {t('common.close', 'إغلاق')}
          </button>
        </div>
      </div>
    </div>
  );
};
