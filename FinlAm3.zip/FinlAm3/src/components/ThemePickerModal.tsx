import React, { useState } from 'react';
import { AppLayoutTheme, Manager } from '../types';
import { LAYOUT_THEMES, getLayoutThemeMeta } from '../utils/layoutThemes';
import { useI18n } from '../i18n/index.tsx';

interface ThemePickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: AppLayoutTheme;
  onSelectTheme: (theme: AppLayoutTheme) => void;
  targetManager?: Manager | null;
  isSaving?: boolean;
}

export const ThemePickerModal: React.FC<ThemePickerModalProps> = ({
  isOpen,
  onClose,
  currentTheme,
  onSelectTheme,
  targetManager = null,
  isSaving = false,
}) => {
  const { t } = useI18n();
  const [selectedTheme, setSelectedTheme] = useState<AppLayoutTheme>(currentTheme);

  // Sync selected theme when opened
  React.useEffect(() => {
    if (isOpen) {
      setSelectedTheme(currentTheme || 'classic');
    }
  }, [isOpen, currentTheme]);

  if (!isOpen) return null;

  const handleApply = () => {
    onSelectTheme(selectedTheme);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center z-50 p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden text-start">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-indigo-50/70 via-slate-50 to-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-base shadow-md">
              <i className="fa-solid fa-palette"></i>
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                {targetManager
                  ? `تغيير وتخصيص واجهة فرع (${targetManager.branch || targetManager.username})`
                  : 'معرض واجهات وتصاميم التطبيق (10 تصاميم حديثة)'}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                اختر التصميم والشكل الهندسي المفضل، وسيتم تطبيقه فوراً.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Modal Body: 10 Layout Themes list with rich interactive previews */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {LAYOUT_THEMES.map((theme) => {
              const isSelected = selectedTheme === theme.id;
              return (
                <div
                  key={theme.id}
                  onClick={() => setSelectedTheme(theme.id)}
                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-2.5 ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-md ring-2 ring-indigo-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  {/* Top Bar */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs shrink-0 border ${theme.accentColor}`}>
                        <i className={theme.icon}></i>
                      </div>
                      <div className="min-w-0">
                        <div className="font-black text-xs text-slate-900 truncate">
                          {theme.title}
                        </div>
                        <div className="text-[10px] font-mono text-slate-400">
                          {theme.englishTitle}
                        </div>
                      </div>
                    </div>

                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                      isSelected ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-300 bg-white'
                    }`}>
                      {isSelected && <i className="fa-solid fa-check text-[9px]"></i>}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-[11px] text-slate-600 leading-snug">
                    {theme.description}
                  </p>

                  {/* Badges */}
                  <div className="flex items-center gap-1 flex-wrap pt-1 border-t border-slate-100">
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700">
                      {theme.badge}
                    </span>
                    {theme.keyFeatures.slice(0, 2).map((kf, i) => (
                      <span key={i} className="text-[9px] font-medium text-slate-500 bg-slate-50 px-1.5 py-0.5 rounded-md">
                        {kf}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <div className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
            <span>التصميم المختار:</span>
            <span className="text-indigo-700 font-black">{getLayoutThemeMeta(selectedTheme).title}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-100 cursor-pointer transition-colors"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleApply}
              disabled={isSaving}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white font-black text-xs shadow-md cursor-pointer transition-all flex items-center gap-1.5"
            >
              {isSaving && <i className="fa-solid fa-spinner fa-spin text-xs"></i>}
              <span>تطبيق التصميم الآن</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
