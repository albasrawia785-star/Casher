import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  ShieldCheck,
  RefreshCw,
  Printer,
  Calendar,
  Phone,
  User,
  Clock,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  FileText,
  Building2,
  Sparkles,
  Lock,
  ExternalLink,
} from 'lucide-react';
import { PortalType, getPortalUrl } from '../utils/qrUtils';
import { formatNumber } from '../utils/formatters';
import { queryTurso, getBackendBaseUrl, isStaticOrNetlifyEnv } from '../services/turso';

interface CustomerPortalViewProps {
  type: PortalType;
  id: number;
  onGoToLogin?: () => void;
}

export const CustomerPortalView: React.FC<CustomerPortalViewProps> = ({
  type,
  id,
  onGoToLogin,
}) => {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const fetchLiveStatement = async (isManualRefresh = false) => {
    if (isManualRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);

    try {
      // 1. Only query local backend proxy if running on dev server with Express API
      if (!isStaticOrNetlifyEnv()) {
        try {
          const baseUrl = getBackendBaseUrl();
          const res = await fetch(`${baseUrl}/api/public/statement?type=${type}&id=${id}`);
          if (res.ok) {
            const json = await res.json();
            if (json.success && json.data) {
              setData(json.data);
              setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
              setLoading(false);
              setRefreshing(false);
              return;
            }
          }
        } catch {
          // Fall through to direct Turso connection
        }
      }

      // 2. Query Turso database directly (zero delay, instant connection from Netlify or mobile)
      try {
        if (type === 'debtor') {
          const queryRes = await queryTurso(
            `SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
            [id, String(id), `%${id}%`]
          );
          const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

          if (rows.length > 0) {
            const row = rows[0];
            const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
            let history = [];
            try {
              history = val(7) ? JSON.parse(String(val(7))) : [];
            } catch {}

            const remainingAmount = Number(val(3) || 0);
            let paidAmount = 0;
            if (Array.isArray(history)) {
              paidAmount = history
                .filter((h: any) => h && h.type === 'pay')
                .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
            }
            const totalAmount = remainingAmount + paidAmount;

            setData({
              id: Number(val(0)),
              name: String(val(1) || ''),
              phone: String(val(2) || ''),
              amount: totalAmount,
              paidAmount,
              remainingAmount,
              debtDate: String(val(6) || new Date().toISOString()),
              notes: '',
              history,
              userId: Number(val(5) || 1),
              updatedAt: String(val(6) || new Date().toISOString()),
              branchName: 'الفرع الرئيسي',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          }
        } else {
          const queryRes = await queryTurso(
            `SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, status, notes, payments, user_id, created_at, guarantor_name, guarantor_phone FROM installments WHERE id = ? OR CAST(id AS TEXT) = ? OR CAST(id AS TEXT) LIKE ? LIMIT 1;`,
            [id, String(id), `%${id}%`]
          );
          const rows = queryRes?.results?.[0]?.response?.result?.rows || [];

          if (rows.length > 0) {
            const row = rows[0];
            const val = (idx: number) => (row[idx] && typeof row[idx] === 'object' && 'value' in row[idx] ? row[idx].value : row[idx]);
            let payments = [];
            try {
              payments = val(12) ? JSON.parse(String(val(12))) : [];
            } catch {}

            setData({
              id: Number(val(0)),
              debtorName: String(val(1) || ''),
              phoneNumber: String(val(2) || ''),
              itemName: String(val(3) || ''),
              totalAmount: Number(val(4) || 0),
              downPayment: Number(val(5) || 0),
              remainingAmount: Number(val(6) || 0),
              monthlyInstallment: Number(val(7) || 0),
              registrationDate: String(val(8) || ''),
              nextDueDate: String(val(9) || ''),
              status: String(val(10) || 'active'),
              notes: String(val(11) || ''),
              payments,
              userId: Number(val(13) || 1),
              updatedAt: String(val(14) || new Date().toISOString()),
              guarantorName: String(val(15) || ''),
              guarantorPhone: String(val(16) || ''),
              branchName: 'الفرع الرئيسي',
            });
            setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
            setLoading(false);
            setRefreshing(false);
            return;
          }
        }
      } catch (tursoErr) {
        console.warn('Direct Turso query failed, attempting local cache fallback...', tursoErr);
      }

      // Fallback 2: Local storage check for offline or demo / trial records
      if (typeof window !== 'undefined' && window.localStorage) {
        if (type === 'debtor') {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('debtors_user_') || key === 'local_debtors')) {
              try {
                const debtors = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(debtors)) {
                  const found = debtors.find((d: any) => Number(d.id) === Number(id));
                  if (found) {
                    const history = found.history || [];
                    const remainingAmount = Number(found.amount || 0);
                    const paidAmount = history
                      .filter((h: any) => h && h.type === 'pay')
                      .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
                    const totalAmount = remainingAmount + paidAmount;

                    setData({
                      id: Number(found.id),
                      name: String(found.name || ''),
                      phone: String(found.phone || ''),
                      amount: totalAmount,
                      paidAmount,
                      remainingAmount,
                      debtDate: found.createdAt || new Date().toISOString(),
                      notes: '',
                      history,
                      userId: found.userId || 1,
                      updatedAt: found.createdAt || new Date().toISOString(),
                      branchName: 'الفرع الرئيسي',
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        } else {
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('installments_user_') || key === 'local_installments')) {
              try {
                const insts = JSON.parse(localStorage.getItem(key) || '[]');
                if (Array.isArray(insts)) {
                  const found = insts.find((item: any) => Number(item.id) === Number(id));
                  if (found) {
                    setData({
                      id: Number(found.id),
                      debtorName: String(found.name || ''),
                      phoneNumber: String(found.phone || ''),
                      itemName: String(found.item || ''),
                      totalAmount: Number(found.totalAmount || 0),
                      downPayment: Number(found.downPayment || 0),
                      remainingAmount: Number(found.remainingAmount || 0),
                      monthlyInstallment: Number(found.monthlyInstallmentAmount || 0),
                      registrationDate: String(found.registrationDate || ''),
                      nextDueDate: String(found.nextDueDate || ''),
                      status: String(found.status || 'active'),
                      notes: String(found.notes || ''),
                      payments: found.payments || [],
                      userId: found.userId || 1,
                      updatedAt: found.createdAt || new Date().toISOString(),
                      guarantorName: String(found.guarantorName || ''),
                      guarantorPhone: String(found.guarantorPhone || ''),
                      branchName: 'الفرع الرئيسي',
                    });
                    setLastUpdated(new Date().toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }));
                    setLoading(false);
                    setRefreshing(false);
                    return;
                  }
                }
              } catch {}
            }
          }
        }
      }

      setError('لم يتم العثور على سجل الحساب المطلوب في قاعدة البيانات');
    } catch (err: any) {
      console.error('Failed to load customer portal statement:', err);
      setError('تعذر الاتصال بقاعدة البيانات لجلب كشف الحساب التفاعلي. يرجى التاكد من الاتصال بالإنترنت.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLiveStatement();
  }, [type, id]);

  const handlePrint = () => {
    window.print();
  };

  const isInstallment = type === 'installment';
  const portalUrl = getPortalUrl(type, id);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-4 dir-rtl font-sans">
        <div className="bg-slate-800/80 backdrop-blur-xl border border-slate-700/60 rounded-3xl p-8 max-w-md w-full text-center shadow-2xl">
          <div className="relative w-16 h-16 mx-auto mb-6">
            <div className="absolute inset-0 rounded-full border-4 border-indigo-500/20 animate-ping"></div>
            <div className="w-16 h-16 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin flex items-center justify-center">
              <ShieldCheck className="w-8 h-8 text-indigo-400" />
            </div>
          </div>
          <h2 className="text-xl font-bold mb-2">جاري تحميل كشف الحساب الحي...</h2>
          <p className="text-slate-400 text-sm">يتم الاتصال بالنظام لجلب أحدث التحديثات المالية المباشرة</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-4 dir-rtl font-sans">
        <div className="bg-slate-800/80 backdrop-blur-xl border border-red-500/30 rounded-3xl p-8 max-w-md w-full text-center shadow-2xl">
          <div className="w-16 h-16 bg-red-500/10 rounded-2xl border border-red-500/20 flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-xl font-bold text-red-200 mb-2">عذراً، لم نتمكن من جلب الحساب</h2>
          <p className="text-slate-400 text-sm mb-6">{error || 'السجل غير موجود أو تم حذفه'}</p>
          <div className="flex flex-col gap-3">
            <button
              onClick={() => fetchLiveStatement(true)}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <RefreshCw className="w-5 h-5" />
              إعادة المحاولة
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Calculate percentages and financial metrics
  const name = isInstallment ? data.debtorName : data.name;
  const phone = isInstallment ? data.phoneNumber : data.phone;
  const totalAmount = isInstallment ? data.totalAmount : data.amount;
  const remainingAmount = data.remainingAmount ?? 0;
  const paidAmount = isInstallment
    ? totalAmount - remainingAmount
    : data.paidAmount ?? (totalAmount - remainingAmount);

  const percentage = totalAmount > 0 ? Math.min(100, Math.round((paidAmount / totalAmount) * 100)) : 0;
  const transactions = isInstallment ? data.payments || [] : data.history || [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans dir-rtl pb-16 selection:bg-indigo-500 selection:text-white">
      {/* Background Glow */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-indigo-600/10 blur-[120px] pointer-events-none rounded-full" />

      {/* Top Bar Navigation */}
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800/80 px-4 py-3">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white">كشف حساب رقمي مباشر</h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  مباشر حي
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-1">
                <Building2 className="w-3 h-3 text-slate-500" />
                {data.branchName || 'الفرع الرئيسي'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => fetchLiveStatement(true)}
              disabled={refreshing}
              title="تحديث البيانات من السحابة"
              className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-all flex items-center gap-1.5 text-xs font-medium"
            >
              <RefreshCw className={`w-4 h-4 text-indigo-400 ${refreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">تحديث الآن</span>
            </button>
            <button
              onClick={handlePrint}
              title="طباعة كشف الحساب"
              className="p-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white transition-all flex items-center gap-1.5 text-xs font-semibold shadow-lg shadow-indigo-600/20"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">طباعة</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-3xl mx-auto px-4 pt-6 space-y-6">
        {/* Customer Header Card */}
        <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 rounded-3xl p-6 border border-slate-800 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-1 rounded-xl text-xs font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {isInstallment ? 'عقد أقساط متجدد' : 'حساب دين مباشر'}
                </span>
                <span className="text-xs text-slate-500">رقم الحساب: #{data.id}</span>
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight">{name}</h2>
              {phone && (
                <div className="flex items-center gap-2 mt-2 text-slate-400 text-sm dir-ltr justify-end sm:justify-start">
                  <span>{phone}</span>
                  <Phone className="w-4 h-4 text-slate-500" />
                </div>
              )}
            </div>

            {/* Live QR Badge */}
            <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800/80 flex items-center gap-3 self-start sm:self-center">
              <div className="bg-white p-1.5 rounded-xl">
                <QRCodeSVG value={portalUrl} size={64} level="M" />
              </div>
              <div className="text-right space-y-0.5">
                <p className="text-[11px] font-semibold text-slate-300">باركود الحساب الثابت</p>
                <p className="text-[10px] text-slate-500 max-w-[120px] leading-tight">
                  يتحدث آلياً كل شهر مع كل دفعة جديدة
                </p>
              </div>
            </div>
          </div>

          {/* Additional Installment Details if applicable */}
          {isInstallment && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-5 pt-4 border-t border-slate-800/80 text-xs">
              <div>
                <span className="text-slate-500 block mb-0.5">السلعة / المادة:</span>
                <span className="font-semibold text-slate-200">{data.itemName || 'أجهزة ومشتريات'}</span>
              </div>
              <div>
                <span className="text-slate-500 block mb-0.5">القسط الشهري:</span>
                <span className="font-bold text-amber-400">
                  {formatNumber(data.monthlyInstallment || 0)} د.ع
                </span>
              </div>
              <div>
                <span className="text-slate-500 block mb-0.5">تاريخ الاستحقاق القادم:</span>
                <span className="font-semibold text-slate-200">{data.nextDueDate || 'غير محدد'}</span>
              </div>
            </div>
          )}
        </div>

        {/* Financial Summary Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Total Amount Card */}
          <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 flex flex-col justify-between">
            <span className="text-xs font-medium text-slate-400 block mb-1">المبلغ الإجمالي المتفق عليه</span>
            <div className="text-xl font-bold text-slate-100">
              {formatNumber(totalAmount)} <span className="text-xs text-slate-400 font-normal">د.ع</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-2">المبلغ الكلي المسجل في العقد</div>
          </div>

          {/* Paid Amount Card */}
          <div className="bg-emerald-950/20 rounded-2xl p-4 border border-emerald-500/20 flex flex-col justify-between">
            <span className="text-xs font-medium text-emerald-400 block mb-1">إجمالي التسديدات والمدفوعات</span>
            <div className="text-xl font-bold text-emerald-400">
              {formatNumber(paidAmount)} <span className="text-xs text-emerald-500/80 font-normal">د.ع</span>
            </div>
            <div className="text-[11px] text-emerald-500/70 mt-2 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              تم سداد {percentage}% من القيمة
            </div>
          </div>

          {/* Remaining Amount Card */}
          <div className="bg-rose-950/20 rounded-2xl p-4 border border-rose-500/30 flex flex-col justify-between relative overflow-hidden">
            <span className="text-xs font-medium text-rose-300 block mb-1">المبلغ المتبقي الذمة حالياً</span>
            <div className="text-2xl font-black text-rose-400">
              {formatNumber(remainingAmount)} <span className="text-xs text-rose-400/80 font-normal">د.ع</span>
            </div>
            <div className="text-[11px] text-rose-300/80 mt-2 flex items-center gap-1">
              {remainingAmount === 0 ? (
                <span className="text-emerald-400 font-bold">🎉 الحساب مسدد بالكامل</span>
              ) : (
                <span>ذمة قائمة مطلوبة للتسديد</span>
              )}
            </div>
          </div>
        </div>

        {/* Progress Bar Component */}
        <div className="bg-slate-900/90 rounded-2xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              نسبة اكتمال التسديد
            </span>
            <span className="font-bold text-indigo-400 text-sm">{percentage}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden p-0.5 border border-slate-700/50">
            <div
              className="bg-gradient-to-r from-indigo-500 via-emerald-500 to-emerald-400 h-full rounded-full transition-all duration-1000 ease-out shadow-lg"
              style={{ width: `${percentage}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-slate-500 pt-1">
            <span>مدفوع: {formatNumber(paidAmount)} د.ع</span>
            <span>متبقي: {formatNumber(remainingAmount)} د.ع</span>
          </div>
        </div>

        {/* Transaction History Section */}
        <div className="bg-slate-900/90 rounded-3xl p-6 border border-slate-800 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <Clock className="w-4 h-4" />
              </div>
              <h3 className="text-base font-bold text-white">سجل الدفعات والتسديدات التفاعلي</h3>
            </div>
            <span className="text-xs text-slate-400 bg-slate-800 px-3 py-1 rounded-full border border-slate-700">
              {transactions.length} حركات مسجلة
            </span>
          </div>

          {transactions.length === 0 ? (
            <div className="text-center py-10 text-slate-500 space-y-2">
              <FileText className="w-10 h-10 mx-auto text-slate-600 opacity-60" />
              <p className="text-sm font-medium">لا توجد حركات تسديد مسجلة سابقاً حتى الآن</p>
            </div>
          ) : (
            <div className="space-y-3">
              {transactions.map((tx: any, idx: number) => {
                const txDate = tx.date || tx.createdAt || 'سابقاً';
                const txAmount = tx.amount || 0;
                const txNotes = tx.notes || tx.description || 'سداد دفعات';

                return (
                  <div
                    key={tx.id || idx}
                    className="bg-slate-950/60 hover:bg-slate-950 rounded-2xl p-4 border border-slate-800/80 flex items-center justify-between gap-4 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-200">
                          دفعة تسديد بقيمة {formatNumber(txAmount)} د.ع
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-500" />
                            {txDate}
                          </span>
                          {txNotes && <span className="text-slate-500">• {txNotes}</span>}
                        </div>
                      </div>
                    </div>

                    {tx.remainingAfter !== undefined && (
                      <div className="text-left shrink-0">
                        <span className="text-[10px] text-slate-500 block">المتبقي بعدها</span>
                        <span className="text-xs font-bold text-slate-300">
                          {formatNumber(tx.remainingAfter)} د.ع
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Live Sync Footer & Store Contact */}
        <div className="bg-slate-900/60 rounded-2xl p-4 border border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span>كشف حساب محمي بالكامل ومحدث سحابياً فورياً</span>
            {lastUpdated && <span className="text-slate-500">(آخر تحديث: {lastUpdated})</span>}
          </div>

          {onGoToLogin && (
            <button
              onClick={onGoToLogin}
              className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 hover:underline"
            >
              دخول لوحة إدارة النظام
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
            </button>
          )}
        </div>
      </main>
    </div>
  );
};
