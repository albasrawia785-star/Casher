import React from 'react';
import { AppLayoutTheme, InstallmentRecord } from '../types';
import { formatNumber, formatDateDigits } from '../utils/formatters';
import { formatDueDateBadge, buildInstallmentWhatsAppUrl } from '../utils/installmentHelpers';
import { useI18n } from '../i18n/index.tsx';

interface InstallmentCardProps {
  installment: InstallmentRecord;
  onOpenDetails: (inst: InstallmentRecord) => void;
  onOpenSettleModal: (inst: InstallmentRecord) => void;
  onOpenEditModal?: (inst: InstallmentRecord) => void;
  onDelete: (id: number) => void;
  numberFormat?: 'english' | 'arabic';
  layoutTheme?: AppLayoutTheme;
}

export const InstallmentCard: React.FC<InstallmentCardProps> = React.memo(({
  installment,
  onOpenDetails,
  onOpenSettleModal,
  onOpenEditModal,
  onDelete,
  numberFormat: propsNumFormat,
  layoutTheme = 'classic',
}) => {
  const { t, numberFormat: ctxNumFormat } = useI18n();
  const numberFormat = propsNumFormat || ctxNumFormat;

  const badgeInfo = formatDueDateBadge(installment.nextDueDate, installment.status);
  const totalPaid = installment.totalAmount - installment.remainingAmount;
  const progressPercent = Math.min(100, Math.round((totalPaid / (installment.totalAmount || 1)) * 100));

  const whatsappUrl = installment.phone && installment.remainingAmount > 0
    ? buildInstallmentWhatsAppUrl(
        installment.phone,
        installment.name,
        installment.item,
        installment.remainingAmount,
        installment.nextDueDate
      )
    : '';

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(installment.id);
  };

  const formattedDueDate = formatDateDigits(installment.nextDueDate, numberFormat);

  // -------------------------------------------------------------
  // THEME: FINTECH (Neo-Banking Clean Flow - تصميم 1 الحديث)
  // -------------------------------------------------------------
  if (layoutTheme === 'fintech') {
    const customerInitial = (installment.name || 'ق').trim().charAt(0);
    return (
      <div className="bg-white rounded-2xl p-3.5 border border-slate-200/90 shadow-[0_2px_10px_-2px_rgba(15,23,42,0.06)] hover:shadow-md relative overflow-hidden group fast-list-item gpu-layer flex flex-col justify-between gap-3 text-start">
        {/* Header: Avatar, Name, Item & Badge */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-50 via-teal-50 to-blue-50 text-emerald-800 border border-emerald-200/60 flex items-center justify-center font-black text-xs shrink-0 shadow-2xs">
              {customerInitial}
            </div>
            <div className="min-w-0 flex-1">
              <h3
                onClick={() => onOpenDetails(installment)}
                className="text-sm font-black text-slate-900 hover:text-emerald-700 cursor-pointer truncate transition-colors"
              >
                {installment.name}
              </h3>
              <div className="text-[11px] text-slate-500 font-mono truncate mt-0.5 flex items-center gap-1.5">
                <span className="font-semibold text-slate-700">{installment.item}</span>
                {installment.phone && <span>• {installment.phone}</span>}
              </div>
            </div>
          </div>

          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold tracking-tight shrink-0 border ${badgeInfo.badgeClass}`}>
            {badgeInfo.label}
          </span>
        </div>

        {/* Progress Bar (Paid vs Total) */}
        <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-200/70">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-500 font-medium">المتبقي من القسط:</span>
            <span className="font-mono font-black text-blue-950 text-xs">
              {formatNumber(installment.remainingAmount, numberFormat)} د.ع
            </span>
          </div>
          <div className="w-full bg-slate-200/80 rounded-full h-2 overflow-hidden flex">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>نسبة السداد: {progressPercent}%</span>
            <span>الاستحقاق: {formattedDueDate}</span>
          </div>
        </div>

        {/* Action Buttons: Emerald Pay Installment + Eye Details + Edit */}
        <div className="flex items-center gap-1.5 pt-0.5">
          {installment.remainingAmount > 0 ? (
            <button
              type="button"
              onClick={() => onOpenSettleModal(installment)}
              className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer active:scale-95"
            >
              <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
              <span>تسديد قسط</span>
            </button>
          ) : (
            <div className="flex-1 py-2 px-3 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-xs flex items-center justify-center gap-1.5">
              <i className="fa-solid fa-circle-check text-xs"></i>
              <span>مسدد بالكامل</span>
            </div>
          )}

          <button
            type="button"
            onClick={() => onOpenDetails(installment)}
            className="p-2 w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors flex items-center justify-center text-xs cursor-pointer"
            title="عرض التفاصيل الكاملة"
          >
            <i className="fa-solid fa-eye text-xs"></i>
          </button>

          {onOpenEditModal && (
            <button
              type="button"
              onClick={() => onOpenEditModal(installment)}
              className="p-2 w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors flex items-center justify-center text-xs cursor-pointer"
              title="تعديل العقد"
            >
              <i className="fa-solid fa-pen text-xs"></i>
            </button>
          )}

          <button
            type="button"
            onClick={handleDelete}
            className="p-2 w-8 h-8 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors flex items-center justify-center text-xs cursor-pointer"
            title="حذف القسط"
          >
            <i className="fa-solid fa-trash-can text-xs"></i>
          </button>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME: BENTO (Bento Grid 3D)
  // -------------------------------------------------------------
  if (layoutTheme === 'bento') {
    return (
      <div className="bg-white rounded-3xl p-3.5 border border-purple-100 shadow-sm hover:border-purple-300 transition-all flex flex-col gap-2.5 fast-list-item gpu-layer">
        <div className="grid grid-cols-3 gap-2">
          <div className="col-span-2 bg-purple-50/60 rounded-2xl p-2.5 border border-purple-100/80">
            <span className="text-[9.5px] font-bold text-purple-600 uppercase">قسط شهري</span>
            <h3
              onClick={() => onOpenDetails(installment)}
              className="text-xs sm:text-sm font-black text-slate-900 truncate mt-0.5 cursor-pointer hover:text-purple-700"
            >
              {installment.name}
            </h3>
            <div className="text-[10px] text-slate-500 font-medium truncate mt-0.5">
              {installment.item}
            </div>
          </div>

          <div className="col-span-1 bg-slate-50 rounded-2xl p-2.5 border border-slate-100 flex flex-col justify-between items-center text-center">
            <span className="text-[9px] text-slate-400">الاستحقاق</span>
            <span className="font-mono text-[10px] font-bold text-slate-700">{formattedDueDate}</span>
            <span className="text-[9.5px] font-black text-purple-700 bg-purple-100 px-1.5 py-0.2 rounded-md">
              {progressPercent}%
            </span>
          </div>
        </div>

        <div className="bg-slate-900 text-white rounded-2xl p-2.5 flex items-center justify-between">
          <div className="text-start">
            <div className="text-[9px] text-slate-400">المتبقي</div>
            <div className="text-xs sm:text-sm font-black font-mono text-white">
              {formatNumber(installment.remainingAmount, numberFormat)} د.ع
            </div>
          </div>

          <div className="flex items-center gap-1">
            {installment.remainingAmount > 0 && (
              <button
                type="button"
                onClick={() => onOpenSettleModal(installment)}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs cursor-pointer shadow-xs"
              >
                تسديد
              </button>
            )}
            <button
              type="button"
              onClick={() => onOpenDetails(installment)}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs cursor-pointer"
            >
              <i className="fa-solid fa-eye text-xs"></i>
            </button>
            <button
              type="button"
              onClick={handleDelete}
              className="p-1.5 rounded-xl bg-rose-500/20 text-rose-300 text-xs cursor-pointer"
            >
              <i className="fa-solid fa-trash-can text-xs"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // DEFAULT / CLASSIC THEME
  // -------------------------------------------------------------
  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all p-4 space-y-3 relative overflow-hidden group fast-list-item gpu-layer">
      {/* Top Banner with Item & Status Badge */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <h3
              onClick={() => onOpenDetails(installment)}
              className="text-sm font-black text-slate-900 hover:text-emerald-700 cursor-pointer break-words leading-snug transition-colors"
            >
              {installment.name}
            </h3>
            {installment.phone && (
              <span className="text-[11px] font-mono font-medium text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-md" dir="ltr">
                {formatDateDigits(installment.phone, numberFormat)}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 text-xs text-slate-500 mt-1 font-medium">
            <i className="fa-solid fa-box text-emerald-600 text-[10px]"></i>
            <span>{installment.item}</span>
          </div>
        </div>

        {/* Status Badge */}
        <span className={`px-2.5 py-1 rounded-full text-[10.5px] font-black tracking-tight shrink-0 flex items-center gap-1 border ${badgeInfo.badgeClass}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${
            installment.status === 'completed' ? 'bg-emerald-500' :
            installment.status === 'overdue' ? 'bg-rose-500' :
            installment.status === 'due' ? 'bg-amber-500 animate-pulse' : 'bg-blue-500'
          }`}></span>
          <span>{badgeInfo.label}</span>
        </span>
      </div>

      {/* Financial Numbers Grid */}
      <div className="bg-slate-50/90 rounded-xl p-2.5 border border-slate-100 grid grid-cols-3 gap-2 text-center select-text">
        <div>
          <span className="text-[10px] text-slate-400 block font-medium">{t('installments.total', 'الإجمالي')}</span>
          <span className="text-xs font-black text-slate-800 font-mono block mt-0.5">
            {formatNumber(installment.totalAmount, numberFormat)}
          </span>
        </div>
        <div className="border-x border-slate-200/80 px-1">
          <span className="text-[10px] text-slate-400 block font-medium">{t('installments.remaining', 'المتبقي')}</span>
          <span className={`text-xs font-black font-mono block mt-0.5 ${installment.remainingAmount > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
            {formatNumber(installment.remainingAmount, numberFormat)}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-slate-400 block font-medium">{t('installments.totalPaid', 'إجمالي المدفوع')}</span>
          <span className="text-xs font-black text-emerald-700 font-mono block mt-0.5">
            {formatNumber(totalPaid, numberFormat)}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div>
        <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 mb-1">
          <span>{t('installments.paidProgress', 'نسبة السداد')}</span>
          <span className="font-mono text-emerald-700">{formatNumber(progressPercent, numberFormat)}%</span>
        </div>
        <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>
      </div>

      {/* Next Due Date & Days Remaining */}
      <div className="flex items-center justify-between text-[11px] text-slate-600 pt-0.5">
        <div className="flex items-center gap-1">
          <i className="fa-regular fa-calendar text-slate-400 text-[10px]"></i>
          <span className="text-slate-400 text-[10.5px]">{t('installments.nextDue', 'الاستحقاق')}:</span>
          <span className="font-mono font-bold text-slate-800 text-xs" dir="ltr">
            {formattedDueDate}
          </span>
        </div>

        {whatsappUrl && (
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 px-2 py-0.5 rounded-lg transition-colors"
            title={t('debtors.sendWhatsApp', 'إرسال تذكير عبر واتساب')}
          >
            <i className="fa-brands fa-whatsapp text-xs text-emerald-500"></i>
            <span>{t('common.remind', 'تذكير')}</span>
          </a>
        )}
      </div>

      {/* Actions Row */}
      <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100">
        {installment.remainingAmount > 0 ? (
          <button
            type="button"
            onClick={() => onOpenSettleModal(installment)}
            className="flex-1 py-1.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
          >
            <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
            <span>{t('installments.payInstallment', 'تسديد قسط')}</span>
          </button>
        ) : (
          <div className="flex-1 py-1.5 px-3 rounded-xl bg-emerald-50 text-emerald-700 font-bold text-xs flex items-center justify-center gap-1.5 border border-emerald-200/60">
            <i className="fa-solid fa-circle-check text-xs"></i>
            <span>{t('installments.fullyPaid', 'مسدد بالكامل')}</span>
          </div>
        )}

        {onOpenEditModal && (
          <button
            type="button"
            onClick={() => onOpenEditModal(installment)}
            className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200/80 transition-colors flex items-center justify-center text-xs cursor-pointer"
            title={t('common.edit', 'تعديل')}
          >
            <i className="fa-solid fa-pen text-xs"></i>
          </button>
        )}

        <button
          type="button"
          onClick={() => onOpenDetails(installment)}
          className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer"
        >
          <i className="fa-solid fa-eye text-xs"></i>
          <span>{t('common.details', 'التفاصيل')}</span>
        </button>

        <button
          type="button"
          onClick={handleDelete}
          className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-100 transition-colors flex items-center justify-center text-xs cursor-pointer"
          title={t('common.delete', 'حذف')}
        >
          <i className="fa-solid fa-trash-can text-xs"></i>
        </button>
      </div>
    </div>
  );
});

InstallmentCard.displayName = 'InstallmentCard';
