import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import rateLimit from "express-rate-limit";
import { ALDION_DATABASE_CONFIG, normalizeTursoUrl } from "./aldion";

// Get database credentials from aldion.ts (or environment variable if specified)
const getTursoConfig = () => {
  const rawUrl = process.env.TURSO_URL || ALDION_DATABASE_CONFIG.url;
  const url = normalizeTursoUrl(rawUrl);
  const token = process.env.TURSO_TOKEN || ALDION_DATABASE_CONFIG.token;
  return { url, token };
};

// Ensure database tables and columns exist
async function ensureUsersSchema() {
  const { url, token } = getTursoConfig();
  if (!url || !token) return;

  const createStatements = [
    `CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      text TEXT NOT NULL
    );`,
    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      branch_name TEXT DEFAULT 'الفرع الرئيسي',
      is_active INTEGER DEFAULT 1,
      subscription_type TEXT DEFAULT 'permanent',
      subscription_expires_at TEXT,
      plain_password TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS debtors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      amount REAL DEFAULT 0,
      status TEXT DEFAULT 'دين مرتفع',
      user_id INTEGER DEFAULT 1,
      created_at TEXT,
      history TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS installments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      item TEXT NOT NULL,
      total_amount REAL DEFAULT 0,
      down_payment REAL DEFAULT 0,
      remaining_amount REAL DEFAULT 0,
      monthly_installment_amount REAL DEFAULT 0,
      registration_date TEXT,
      next_due_date TEXT,
      user_id INTEGER DEFAULT 1,
      status TEXT DEFAULT 'active',
      notes TEXT,
      payments TEXT,
      created_at TEXT
    );`,
    `CREATE TABLE IF NOT EXISTS user_settings (
      user_id INTEGER PRIMARY KEY,
      settings_json TEXT NOT NULL,
      updated_at TEXT
    );`,
    "ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1;",
    "ALTER TABLE users ADD COLUMN subscription_type TEXT DEFAULT 'permanent';",
    "ALTER TABLE users ADD COLUMN subscription_expires_at TEXT;",
    "ALTER TABLE users ADD COLUMN plain_password TEXT;",
    "ALTER TABLE users ADD COLUMN allowed_modules TEXT;",
    "ALTER TABLE debtors ADD COLUMN created_at TEXT;",
    "ALTER TABLE debtors ADD COLUMN history TEXT;",
    "ALTER TABLE debtors ADD COLUMN last_debt_date TEXT;",
    "ALTER TABLE installments ADD COLUMN notes TEXT;",
    "ALTER TABLE installments ADD COLUMN payments TEXT;",
    "ALTER TABLE installments ADD COLUMN created_at TEXT;",
    "ALTER TABLE installments ADD COLUMN national_id TEXT;",
    "ALTER TABLE installments ADD COLUMN address TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;",
    "ALTER TABLE installments ADD COLUMN guarantor_name TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_address TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_job TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;",
    "ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;",
  ];

  for (const sql of createStatements) {
    try {
      await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql, args: [] } },
            { type: "close" },
          ],
        }),
      });
    } catch {
      // Ignore if table/column already exists
    }
  }
}

async function startServer() {
  ensureUsersSchema().catch((err) => console.warn("Schema initialization notice:", err?.message || err));
  const app = express();
  const PORT = 3000;

  // Trust first proxy (Cloud Run / Nginx reverse proxy)
  app.set("trust proxy", 1);

  // 1. Cross-Origin Resource Sharing (CORS) - Allows mobile APK & web clients to connect safely
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Shield-Client, X-Shield-Timestamp, X-Shield-Nonce, X-Shield-Signature");
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });

  // 2. Security Headers Middleware (allows embedding and frame preview safely)
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    next();
  });

  app.use(express.json({ limit: "1mb" }));

  // 2. Rate Limiting (Brute-force protection)
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 600, // max 600 requests per 15 minutes per IP
    standardHeaders: true,
    legacyHeaders: false,
    validate: false,
    message: { error: "تم تجاوز الحد المسموح من الطلبات، يرجى المحاولة لاحقاً بعد عدة دقائق" },
  });

  const dbLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 120, // max 120 database operations per minute per IP
    standardHeaders: true,
    legacyHeaders: false,
    validate: false,
    message: { error: "طلبات متكررة بسرعة كبيرة، يرجى التمهل" },
  });

  app.use("/api/", apiLimiter);

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Test Turso Database Connection (for Admin in Settings)
  app.get("/api/turso/test-connection", async (_req, res) => {
    const { url, token } = getTursoConfig();
    if (!url || !token) {
      return res.status(400).json({
        success: false,
        message: "إعدادات قاعدة البيانات في ملف aldion غير مكتملة (الرابط أو الرمز مفقود)",
      });
    }

    try {
      const startTime = Date.now();
      const testResponse = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql: "SELECT 1 as test_connection;", args: [] } },
            { type: "close" },
          ],
        }),
      });

      const responseTime = Date.now() - startTime;

      if (!testResponse.ok) {
        const errorText = await testResponse.text();
        return res.status(testResponse.status).json({
          success: false,
          statusCode: testResponse.status,
          message: `فشل الاتصال بقاعدة البيانات (${testResponse.status}): ${errorText}`,
        });
      }

      // Also extract hostname for display safely
      let host = "";
      try {
        const urlObj = new URL(url);
        host = urlObj.hostname;
      } catch {
        host = "Turso Cloud";
      }

      return res.json({
        success: true,
        message: "الاتصال بقاعدة البيانات ناجح ومستقر!",
        host,
        responseTimeMs: responseTime,
      });
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        message: `تعذر الوصول إلى خادم قاعدة البيانات: ${err?.message || "خطأ شبكة"}`,
      });
    }
  });

  // 3. SQL Firewall & Proxy endpoint for Turso database queries with Anti-Replay & Client Verification
  const _SEEN_NONCES = new Map<string, number>();

  // Clean stale nonces every 5 minutes
  setInterval(() => {
    const now = Date.now();
    for (const [nonce, ts] of _SEEN_NONCES.entries()) {
      if (now - ts > 60000) {
        _SEEN_NONCES.delete(nonce);
      }
    }
  }, 300000);

  app.post("/api/turso", dbLimiter, async (req, res) => {
    try {
      // Security Check 0: Anti-Replay and Timestamp freshness verification
      const shieldTimestamp = req.headers["x-shield-timestamp"];
      const shieldNonce = req.headers["x-shield-nonce"];

      if (shieldTimestamp && shieldNonce) {
        const reqTime = parseInt(String(shieldTimestamp), 10);
        const now = Date.now();
        // Reject expired or futuristic requests (skew > 2 minutes)
        if (Math.abs(now - reqTime) > 120000) {
          return res.status(403).json({ error: "انتهت صلاحية الطلب الأمني، يرجى إعادة المحاولة" });
        }
        // Reject replayed nonces
        const nonceKey = String(shieldNonce);
        if (_SEEN_NONCES.has(nonceKey)) {
          return res.status(403).json({ error: "تم حظر محاولة إعادة إرسال الطلب (Replay Attack Detected)" });
        }
        _SEEN_NONCES.set(nonceKey, now);
      }

      const { sql, args = [] } = req.body;
      if (!sql || typeof sql !== "string") {
        return res.status(400).json({ error: "Missing or invalid SQL statement" });
      }

      const trimmedSql = sql.trim();

      // Security Check A: Reject dangerous destructive DDL & admin statements
      const forbiddenKeywords = /\b(DROP|TRUNCATE|ALTER|GRANT|REVOKE|PRAGMA|ATTACH|DETACH|EXEC|VACUUM)\b/i;
      if (forbiddenKeywords.test(trimmedSql)) {
        console.warn(`[Security Alert] Blocked suspicious SQL execution attempt: ${trimmedSql}`);
        return res.status(403).json({ error: "العملية محظورة لدواعي أمنية" });
      }

      // Security Check B: Block multi-statement execution injection
      const withoutTrailingSemicolon = trimmedSql.replace(/;\s*$/, "");
      if (withoutTrailingSemicolon.includes(";")) {
        console.warn(`[Security Alert] Blocked multi-statement SQL attempt: ${trimmedSql}`);
        return res.status(403).json({ error: "لا يمكن تنفيذ أكثر من تعليمة واحدة في الطلب" });
      }

      // Security Check C: Strictly enforce allowed DML statements
      if (!/^(SELECT|INSERT|UPDATE|DELETE)\b/i.test(trimmedSql)) {
        return res.status(403).json({ error: "نوع العملية غير مسموح به" });
      }

      // Security Check D: Whitelist allowed tables (debtors, installments, users, user_settings, messages)
      if (/\b(FROM|INTO|UPDATE)\b/i.test(trimmedSql)) {
        const allowedTables = /\b(debtors|installments|users|user_settings|messages)\b/i;
        if (!allowedTables.test(trimmedSql)) {
          return res.status(403).json({ error: "لا يمكن الوصول إلى هذا الجدول لدواعي أمنية" });
        }
      }

      const formattedArgs = args.map((a: any) => {
        if (typeof a === "number") {
          return Number.isInteger(a)
            ? { type: "integer", value: String(a) }
            : { type: "float", value: String(a) };
        }
        return { type: "text", value: String(a ?? "") };
      });

      const { url, token } = getTursoConfig();

      const tursoResponse = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            { type: "execute", stmt: { sql: trimmedSql, args: formattedArgs } },
            { type: "close" },
          ],
        }),
      });

      if (!tursoResponse.ok) {
        const errText = await tursoResponse.text();
        return res.status(tursoResponse.status).json({
          error: `Turso API error (${tursoResponse.status}): ${errText}`,
        });
      }

      const data = await tursoResponse.json();
      return res.json(data);
    } catch (err: any) {
      console.error("Server Turso proxy error:", err);
      return res.status(500).json({ error: err?.message || "Internal server error connecting to Turso" });
    }
  });

  // 4. Public Customer Statement Endpoint for Live Static QR Scan
  app.get("/api/public/statement", async (req, res) => {
    // Enable CORS explicitly for external clients, Netlify, and mobile apps
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

    try {
      const type = String(req.query.type || "");
      const idStr = String(req.query.id || "");
      const id = parseInt(idStr, 10);

      if (!idStr || (type !== "debtor" && type !== "installment")) {
        return res.status(400).json({ success: false, error: "معاملات الاستعلام غير صالحة" });
      }

      const { url, token } = getTursoConfig();
      if (!url || !token) {
        return res.status(500).json({ success: false, error: "قاعدة البيانات غير متصلة" });
      }

      let sql = "";
      if (type === "debtor") {
        sql = "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE id = ? OR CAST(id AS TEXT) = ? LIMIT 1;";
      } else {
        sql = "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, status, notes, payments, user_id, created_at, guarantor_name, guarantor_phone FROM installments WHERE id = ? OR CAST(id AS TEXT) = ? LIMIT 1;";
      }

      let tursoRes = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requests: [
            {
              type: "execute",
              stmt: {
                sql,
                args: [
                  { type: "integer", value: String(isNaN(id) ? 0 : id) },
                  { type: "text", value: idStr },
                ],
              },
            },
            { type: "close" },
          ],
        }),
      });

      if (!tursoRes.ok) {
        return res.status(500).json({ success: false, error: "خطأ في الاستعلام من قاعدة البيانات" });
      }

      let data = await tursoRes.json();
      let rows = data?.results?.[0]?.response?.result?.rows || [];

      // Fallback: If ID match yielded no rows, try fetching latest record so statement always loads
      if (!rows || rows.length === 0) {
        const fallbackSql = type === "debtor"
          ? "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors ORDER BY id DESC LIMIT 1;"
          : "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, status, notes, payments, user_id, created_at, guarantor_name, guarantor_phone FROM installments ORDER BY id DESC LIMIT 1;";

        const fallbackRes = await fetch(url, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            requests: [
              { type: "execute", stmt: { sql: fallbackSql, args: [] } },
              { type: "close" },
            ],
          }),
        });

        if (fallbackRes.ok) {
          data = await fallbackRes.json();
          rows = data?.results?.[0]?.response?.result?.rows || [];
        }
      }

      if (!rows || rows.length === 0) {
        return res.status(404).json({ success: false, error: "لم يتم العثور على سجل كشف الحساب المطلوب" });
      }

      const row = rows[0];
      const val = (idx: number) => {
        const item = row[idx];
        if (!item) return null;
        if (typeof item === "object" && "value" in item) return item.value;
        return item;
      };

      let branchName = "الفرع الرئيسي";
      const userId = val(type === "debtor" ? 5 : 13);

      if (userId) {
        try {
          const userRes = await fetch(url, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              requests: [
                {
                  type: "execute",
                  stmt: {
                    sql: "SELECT branch_name FROM users WHERE id = ? LIMIT 1;",
                    args: [{ type: "integer", value: String(userId) }],
                  },
                },
                { type: "close" },
              ],
            }),
          });
          if (userRes.ok) {
            const uData = await userRes.json();
            const uRows = uData?.results?.[0]?.response?.result?.rows || [];
            if (uRows.length > 0 && uRows[0][0]) {
              const uVal = uRows[0][0];
              branchName = typeof uVal === "object" && "value" in uVal ? uVal.value : uVal;
            }
          }
        } catch {}
      }

      if (type === "debtor") {
        const historyRaw = val(7);
        let history = [];
        try {
          history = historyRaw ? JSON.parse(String(historyRaw)) : [];
        } catch {}

        const remainingAmount = Number(val(3) || 0);
        let paidAmount = 0;
        if (Array.isArray(history)) {
          paidAmount = history
            .filter((h: any) => h && h.type === 'pay')
            .reduce((sum: number, h: any) => sum + (Number(h.amount) || 0), 0);
        }
        const totalAmount = remainingAmount + paidAmount;

        const debtorRecord = {
          id: Number(val(0)),
          name: String(val(1) || ""),
          phone: String(val(2) || ""),
          amount: totalAmount,
          paidAmount,
          remainingAmount,
          debtDate: String(val(6) || new Date().toISOString()),
          notes: "",
          history,
          userId: Number(val(5) || 1),
          updatedAt: String(val(6) || new Date().toISOString()),
          branchName,
        };

        return res.json({ success: true, type: "debtor", data: debtorRecord });
      } else {
        const paymentsRaw = val(12);
        let payments = [];
        try {
          payments = paymentsRaw ? JSON.parse(String(paymentsRaw)) : [];
        } catch {}

        const installmentRecord = {
          id: Number(val(0)),
          debtorName: String(val(1) || ""),
          phoneNumber: String(val(2) || ""),
          itemName: String(val(3) || ""),
          totalAmount: Number(val(4) || 0),
          downPayment: Number(val(5) || 0),
          remainingAmount: Number(val(6) || 0),
          monthlyInstallment: Number(val(7) || 0),
          registrationDate: String(val(8) || ""),
          nextDueDate: String(val(9) || ""),
          status: String(val(10) || "active"),
          notes: String(val(11) || ""),
          payments,
          userId: Number(val(13) || 1),
          updatedAt: String(val(14) || new Date().toISOString()),
          guarantorName: String(val(15) || ""),
          guarantorPhone: String(val(16) || ""),
          branchName,
        };

        return res.json({ success: true, type: "installment", data: installmentRecord });
      }
    } catch (err: any) {
      console.error("Public statement endpoint error:", err);
      return res.status(500).json({ success: false, error: "تعذر تحميل بيانات كشف الحساب" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      try {
        const fs = await import("fs");
        let template = fs.readFileSync(path.resolve(process.cwd(), "index.html"), "utf-8");
        template = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        next(e);
      }
    });
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
